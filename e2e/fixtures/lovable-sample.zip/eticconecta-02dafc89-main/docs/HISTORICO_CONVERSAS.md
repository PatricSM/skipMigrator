# Histórico de Conversas — Etic Conecta

> Documento consolidado de toda a jornada de desenvolvimento do projeto **Etic Conecta** no Lovable.
> 710 mensagens trocadas entre 27/jan/2026 e 11/mar/2026 — organizadas por sprints temáticos.

---

## Sumário

1. [Sprint 1 — Setup inicial e conexão Supabase](#sprint-1)
2. [Sprint 2 — Autenticação, recuperação de senha e roles](#sprint-2)
3. [Sprint 3 — Formulário multi-step e UX mobile](#sprint-3)
4. [Sprint 4 — Página de Acompanhamento da Proposta](#sprint-4)
5. [Sprint 5 — Documentos pendentes e auto-finalização](#sprint-5)
6. [Sprint 6 — Validação do Locador e integração n8n/CRM](#sprint-6)
7. [Sprint 7 — Sistema de propostas e contraproposta (15%)](#sprint-7)
8. [Sprint 8 — Painel Admin (Kanban) e gestão de etapas](#sprint-8)
9. [Sprint 9 — Portal do Locador (Dashboard, KPIs, propostas)](#sprint-9)
10. [Sprint 10 — Segurança, RLS, AES-256 e LGPD](#sprint-10)
11. [Sprint 11 — Ciclo de 10 etapas e eventos idempotentes](#sprint-11)
12. [Sprint 12 — Negociação bidirecional e contra-propostas](#sprint-12)
13. [Sprint 13 — Multi-locatário e wizard segundo locatário](#sprint-13)
14. [Sprint 14 — Push notifications, SLA e observabilidade](#sprint-14)
15. [Sprint 15 — Integração VistaSoft, sync XML e CRM ready](#sprint-15)
16. [Sprint 16 — Documentação oficial, PRD e exports](#sprint-16)

---

<a id="sprint-1"></a>
## Sprint 1 — Setup inicial e conexão Supabase (mensagens #1-#20)

**Período**: 27/jan/2026 22:30 → 23:25

### Decisões e entregas
- Conexão do projeto Lovable com o Supabase externo `Etic Project` (`uxfbydatvcyggzqjumqn`).
- Tentativa de importar repositório `marlon-etic/testintin` (404 — privado) → optou-se por reconstruir a partir da descrição.
- Definição do escopo: sistema de locação imobiliária com 3 portais (Locatário, Locador, Admin) + landing page pública.
- **Stack confirmada**: React 18 + Vite + TypeScript + Tailwind + shadcn/ui + Supabase + React Query.
- **Tabelas pré-existentes mapeadas**: `rentals`, `profiles`, `properties`, `landlord_data`, `documents`, `landlord_documents`, `user_roles`, `admin_pipeline_stages`, `property_invites`, `rental_events`, `rental_full_view`.
- **Plano aprovado** com 9 fases: Design system, Auth/RBAC, Landing, Form multi-step, Dashboards, Kanban, Timeline, Hooks, React Query.
- Criação do design system (paleta teal, tokens semânticos, animações `fade-in`/`slide-up`/`scale-in`), tipos TypeScript (`User`, `Profile`, `Rental`, `Property`, `Document`), masks (CPF/tel/CEP/BRL), validations Zod, AuthContext, ProtectedRoute e roteamento base no `App.tsx`.

---

<a id="sprint-2"></a>
## Sprint 2 — Autenticação, recuperação de senha e roles (mensagens #21-#62)

**Período**: 27/jan/2026 23:25 → 28/jan/2026 01:42

### Decisões e entregas
- Criação dos utilitários `src/lib/utils.ts` (`cn`), `logger.ts` (env-aware), `crypto.ts` (`sha256Hex`, `generateInviteToken`, `base64UrlEncode`).
- `formValidation.ts`: validação completa de dados pessoais, renda, documentos e CPF algorítmico.
- `useAuth` hook + `AuthContext`: signUp/signIn/signOut com fallback `local` se `global` retornar 403.
- Hooks principais: `useAdminRentals` (com realtime subscription), `useAdminPipelineStages`, `useProperties` (React Query + Edge Function), `useDocumentUpload` (storage + progress), `useCpfEncryption` (Edge Function), `useRentalTracking`, `use-mobile`, `use-toast`.
- Componentes de proteção: `ProtectedRoute`, `AdminRoute`, `LocadorRoute` (todos usando RPC `has_role`).
- Confirmação que todos componentes shadcn/ui necessários já estavam instalados.
- **Erro de rate limit Supabase**: explicado limite de ~4 emails/hora em plano free.
- **Recuperação de senha**: `ForgotPasswordDialog` + `resetPassword` no AuthContext + `ResetPasswordForm` + intercepção de tokens no hash (`type=recovery`).
- Reposicionamento do link "Esqueci minha senha" para fora do card, abaixo do botão "Entrar".

---

<a id="sprint-3"></a>
## Sprint 3 — Formulário multi-step e UX mobile (mensagens #63-#80)

**Período**: 28/jan/2026 01:42 → 11:50

### Decisões e entregas
- **Bug**: tela mobile de "Cadastrar ficha" mostrava placeholder estático → reescrita com state machine `personal | income | documents | secondTenant`.
- Componente `DateInput` (máscara DD/MM/AAAA digitável, sem calendário lento).
- Validação algorítmica de CPF com feedback visual em tempo real.
- **Validação de idade** (18-100 anos) com `validateAge` em `formValidation.ts`.
- Permitir envio sem documentos — `AlertDialog` avisa quais ficaram pendentes; flag `has_pending: true` e `pending_documents: string[]` salvos em `rentals`.
- **Página dedicada** `SegundoLocatario.tsx` (substituiu o popup) — full-screen com progress próprio.
- **Gamificação**: `GamificationProgress.tsx` com milestones (Shield/Zap/Star), % progress e mensagens de incentivo.
- Auto-save em `localStorage` (`fullName`, `cpf`, `birthDate`) com chave `rental-form-{id}`; limpeza após sucesso.
- Indicadores clicáveis na barra de progresso para navegar entre seções.
- DocumentUpload com prop `compact` para mobile (visível sem scroll).

---

<a id="sprint-4"></a>
## Sprint 4 — Página de Acompanhamento da Proposta (mensagens #69-#100)

**Período**: 28/jan/2026 02:38 → 16:30

### Decisões e entregas
- Renomeada de "Acompanhamento de Locação" → **"Proposta de Locação"**.
- **Timeline 8 etapas** clicável e expansível:
  1. Solicitação enviada
  2. Análise de Ficha (24h úteis)
  3. Documentação Locador (24h)
  4. Emissão de Contrato (24h)
  5. Envio para Assinatura
  6. Contrato Assinado
  7. Agendamento de Vistoria
  8. Assinatura de Vistoria
  9. Entrega das Chaves
- Header da página mostra dados do imóvel (foto, código, valor aluguel/condo/IPTU) com link para `https://www.eticimoveis.com.br/imovel/{codigo}`.
- **Protocolo único**: formato `CODIGO-DDMMYY-TIMESTAMP_BASE36` (ex: `CPY487-280126-M1A2B3C`) — solucionou erro 409 `rentals_protocol_key`.
- Botão WhatsApp com mensagem pré-preenchida (nome + protocolo) → `11970932722`.
- Histórico de eventos sempre aberto em formato de timeline com ícones por tipo.
- Indicador de urgência ("Imóvel procurado") quando 2+ propostas ativas no mesmo imóvel.

---

<a id="sprint-5"></a>
## Sprint 5 — Documentos pendentes e auto-finalização (mensagens #81-#120)

**Período**: 28/jan/2026 11:50 → 17:30

### Decisões e entregas
- **Auto-finalização**: `useEffect` em `Acompanhamento.tsx` detecta upload completo de todos pending docs e dispara `handleFinalizeSubmission` automaticamente.
- **Bug fix loop infinito**: introdução de `hasFinalized = useRef(false)` para evitar re-trigger; reset por mudança de `id`.
- Carregamento de documentos já existentes no banco ao montar (query em `documents` por `rental_id` + `user_id`).
- **DOCUMENT_LABELS atualizados**:
  - Comprovante de Renda: "Últimos 3 holerites, extrato bancário, declaração de IR ou pró-labore"
  - Comprovante de Residência: "Conta de luz, água, gás ou telefone (máximo 90 dias)"
- Cards de pendentes clicáveis com upload inline.
- Botão "Finalizar Envio" só aparece quando todos pending tiverem status `uploaded`.
- Estado local `submissionComplete` esconde seção pendente imediatamente (UX otimista).
- **Refactor unificação**: progress card + step tabs unificados em um único `GamificationProgress` com navegação clicável.

---

<a id="sprint-6"></a>
## Sprint 6 — Validação do Locador e integração n8n/CRM (mensagens #121-#140)

**Período**: 28/jan/2026 23:38 → 30/jan/2026 00:00

### Decisões e entregas
- **Edge Function** `validate-landlord` com 3 níveis de verificação:
  1. Já tem role `locador` → autoriza
  2. É `owner_id` em `properties` → atribui role e autoriza
  3. Webhook n8n via `N8N_VALIDATE_LANDLORD_WEBHOOK` → valida telefone no CRM externo
- Resposta padronizada: `{ authorized, reason: "existing_role" | "property_owner" | "crm_validated" }` ou `403 { authorized: false, error }`.
- Reescrita de `src/pages/locador/Auth.tsx`: toggle Login/Cadastro + telefone obrigatório (máscara `(XX) XXXXX-XXXX`).
- Validação pós-login chama Edge Function; logout automático se não autorizado.
- Card informativo na tela explicando os 3 caminhos de acesso.
- **Resilience**: diferenciação de erro de rede vs. negação real; "Role-First check" ignora erros transientes da Edge Function se role já existir localmente.
- Sistema de convites idempotentes (`property_invites`): token único, aceitar atribui role e vincula `owner_id`.

---

<a id="sprint-7"></a>
## Sprint 7 — Sistema de propostas e contraproposta (mensagens #141-#180)

**Período**: 30/jan/2026 00:00 → 31/jan/2026

### Decisões e entregas
- Página `EscolherTipoProposta.tsx`: dois caminhos:
  - **Garantir Imóvel** (`proposal_type: 'direct'`) → pula direto para Step 3 (Análise de Ficha), `landlord_accepted: false` aguardando confirmação.
  - **Fazer Proposta** (`proposal_type: 'standard'`) → 2 sub-opções:
    1. *Aguardar retorno* — fica em Step 2, sem docs.
    2. *Aprovar minha ficha (acelerar)* — fica em Step 2 mas com Step 3 já marcado, `docs_submitted_early: true`.
- **Limite de 15% de desconto** sobre o aluguel (apenas) — validação visual em tempo real com mínimo `price * 0.85`.
- **Campos novos** no banco: `landlord_accepted` (boolean), `landlord_accepted_at` (timestamptz), `docs_submitted_early` (boolean), `proposal_type` (text), `proposed_value` (numeric).
- `RedirectWithParams` no `App.tsx` para preservar parâmetros dinâmicos em redirects legados.
- ProposalCard no painel do locador: badge **⭐ Prioridade** + destaque emerald para propostas diretas.
- **Pre-approval logic**: locatário com rental anteriormente aprovado pula para Step 5 (Doc Locador) em novas propostas.
- Tela de Acompanhamento: ícone Clock/CheckCircle2 na Step 2 indicando status do aceite do locador; texto "Aguardando confirmação de disponibilidade do locador".

---

<a id="sprint-8"></a>
## Sprint 8 — Painel Admin (Kanban) e gestão de etapas (mensagens #181-#260)

**Período**: 01/fev/2026 → 10/fev/2026

### Decisões e entregas
- **Kanban Board** com `@dnd-kit/core` — 10 colunas representando o ciclo completo:
  1. Solicitação
  2. Aceite Proposta
  3. Análise Ficha
  4. Aprovação Ficha
  5. Doc Locador
  6. Emissão Contrato
  7. Assinatura
  8. Vistoria
  9. Assinatura Vistoria
  10. Entrega Chaves
- Cards drag-and-drop entre colunas atualizam `current_step` via `setRentalStepAndLog` (helper idempotente que registra `rental_event` com janela de 60s para deduplicação).
- **AdminStageConfig.ts**: cores, ícones e SLAs por etapa.
- **AnalyticsDashboard**: KPIs (total ativas, taxa conversão, tempo médio por etapa, propostas estagnadas).
- **AdminRentalModal**: edição completa de qualquer rental, incluindo override manual de etapa com motivo obrigatório (auditado em `audit_logs`).
- **MapaProduto**: visão admin do funil completo + propriedades + landlords.
- **PropertyInvites**: geração e revogação de convites para locadores.
- **SecurityDashboard**: rate limits, signed URL errors, logs anonimizados.
- **Reauth dialog** (`ReAuthDialog`) obrigatório para ações sensíveis de admin (override de etapa, exclusão).

---

<a id="sprint-9"></a>
## Sprint 9 — Portal do Locador (Dashboard, KPIs, propostas) (mensagens #261-#360)

**Período**: 11/fev/2026 → 20/fev/2026

### Decisões e entregas
- **LandlordDashboard**: visão consolidada com:
  - **FinancialKPICards**: receita, vacância, aluguel médio, taxa ocupação (todos com dados reais do DB).
  - **ConversionFunnel**: visualização do funil de propostas por etapa.
  - **PriceComparisonWidget**: comparação com média de mercado.
  - **NotificationBell**: contador de propostas urgentes/em análise.
  - **TenantScoreGauge**: score 0-100 baseado em renda (>3x aluguel) + documentos verificados.
  - **PropertyExpandableCard**: cards expansíveis com histórico de propostas por imóvel.
- Tabs separados: **"Urgentes"** (badge pulsante) vs **"Em análise"**.
- **Decisão do Locador** (`PropostaDetalhe.tsx`): 3 ações
  - **Aprovar** → Step 5 (Doc Locador)
  - **Contraproposta** → cria nova `proposals` row, status `counter_offered`
  - **Rejeitar** → motivo obrigatório, audit log
- `landlord_accepted_at` registrado quando aceitar.
- `useLandlordDashboard` hook centraliza queries com cache de 5min.
- **Mobile UX**: drawer bottom sheet com `pb-28`, FAB sticky em `bottom-[88px]`, `tabular-nums` em valores monetários.
- Tracking de visitas (`VisitFeedbackList`) para identificar imóveis com baixa conversão.

---

<a id="sprint-10"></a>
## Sprint 10 — Segurança, RLS, AES-256 e LGPD (mensagens #361-#440)

**Período**: 21/fev/2026 → 28/fev/2026

### Decisões e entregas
- **Hardening RLS**: todas as tabelas com `security_invoker = true`; políticas exclusivamente *permissivas* (default deny).
- **AES-256-GCM** para CPFs: Edge Function `encrypt-cpf` com `CPF_ENCRYPTION_KEY` (32 bytes hex). Decrypt apenas para admins (verificação `has_role` server-side).
- **Storage URLs assinadas com TTL de 60s** via Edge Function `get-signed-url`.
- **Edge Function** `validate-upload`: MIME sniffing + size limits + extensão whitelist; fallback para validação client-side se falhar.
- **`audit_logs`** imutável: triggers-only (sem INSERT/UPDATE direto).
- **Rate limiting** (`check-rate-limit` Edge Function): 5 tentativas/min para auth, 60/min para uploads.
- **Política de senha**: 14 caracteres mínimos, força máxima exigida, indicador visual `PasswordStrengthIndicator`.
- **Session timeout**: 30 minutos idle → auto logout (`useSessionTimeout`).
- **Portal de Privacidade** (`/portal-privacidade`): export JSON LGPD + workflow de exclusão de conta.
- **Search path protection** em todas funções SQL (`SET search_path = public`).
- **Documentação de scan mitigations** em `mem://security/scan-mitigation-records`.

---

<a id="sprint-11"></a>
## Sprint 11 — Ciclo de 10 etapas e eventos idempotentes (mensagens #441-#510)

**Período**: 01/mar/2026 → 04/mar/2026

### Decisões e entregas
- **`rentals.current_step` (1-10)** estabelecido como única fonte de verdade do ciclo de locação.
- **CHECK constraint** no DB: `current_step BETWEEN 1 AND 10`.
- **`setRentalStepAndLog`** (helper TS): mutação atômica de step + INSERT em `rental_events` com deduplicação de 60s.
- **22 regras de consistência** verificadas por painel QA admin (ex: "step 6 requer keys_delivered = false", "step 5 requer landlord_accepted = true").
- **Mapeamento padrão das 10 etapas**:
  1. Solicitação criada
  2. Aceite da proposta
  3. Análise de ficha
  4. Aprovação da ficha
  5. Documentação do locador
  6. Emissão do contrato
  7. Envio para assinatura
  8. Contrato assinado / Agendamento vistoria
  9. Vistoria realizada e assinada
  10. Entrega das chaves
- Triggers de DB garantem integridade: `keys_delivered = true` exige `current_step = 10`.
- **`buildCrmReadyPayload`** (`src/lib/buildCrmReadyPayload.ts`): JSON normalizado para integração externa com campos `crm_provider`, `crm_external_id`.

---

<a id="sprint-12"></a>
## Sprint 12 — Negociação bidirecional e contra-propostas (mensagens #511-#570)

**Período**: 04/mar/2026 → 07/mar/2026

### Decisões e entregas
- Tabela **`proposals`** dedicada para negociações; status mapeados em `proposal_status` enum: `pending | accepted | counter_offered | rejected | withdrawn`.
- **Counter-proposal flow**: locador pode contra-propor; locatário recebe e pode aceitar/rejeitar/contra-propor de volta.
- **4 tiers de probabilidade gamificada**: Excelente (>95%), Boa (85-95%), Média (70-85%), Baixa (<70%).
- Eventos `proposal_events` registram cada movimento da negociação.
- **`proposalEvents.ts`** (`src/lib/`): helper para emitir eventos consistentes.
- UI dinâmica: cards mostram histórico completo de ofertas/contra-ofertas em formato chat.
- **Recovery flows**: 
  - *Imóvel já alugado* → sugere imóveis similares.
  - *Proposta rejeitada* → permite nova proposta com valor revisado.
- Múltiplas propostas ativas por locatário simultâneas (independentes).

---

<a id="sprint-13"></a>
## Sprint 13 — Multi-locatário e wizard segundo locatário (mensagens #571-#620)

**Período**: 07/mar/2026 → 09/mar/2026

### Decisões e entregas
- **Tenant 1 / Tenant 2** com `tenant_index` na tabela `documents` (1 ou 2).
- **Wizard de 5 passos** para envio de documentos:
  1. Tipo de proposta
  2. Dados pessoais
  3. Renda
  4. Documentos
  5. Segundo locatário (opcional)
- **Type limits**: identidade (2 arquivos), renda (6), residência (2), outros (6).
- Storage paths com UUID: `{user_id}/{rental_id}/{tenant_index}/{doc_type}/{uuid}.{ext}`.
- **Document ownership v2**: badges visuais "1º Locatário" / "2º Locatário" e agrupamento na tela de acompanhamento.
- Submission flow com pendências: permite enviar parcial e completar depois.
- **Batch upload logic v2**: timeout 25s/arquivo, paralelização, realtime pausada durante uploads para evitar reload.
- **Uploader init safety**: timeout de 10s para evitar travamento; salvamento de drafts.

---

<a id="sprint-14"></a>
## Sprint 14 — Push notifications, SLA e observabilidade (mensagens #621-#660)

**Período**: 09/mar/2026 → 10/mar/2026

### Decisões e entregas
- **Web Notifications API** + Realtime hooks (`useNotificationPermission`, `notifications.ts`).
- `NotificationToggle` no header para opt-in.
- Eventos disparam push: nova proposta, mudança de etapa, contra-proposta recebida, doc aprovado.
- **SLA tracking** (`adminSla.ts`): cores por etapa (verde <50% SLA, amarelo 50-80%, vermelho >80%).
- Métricas no SecurityDashboard: rate-limit hits, failed signed URLs, audit anonimizado.
- **Logger centralizado** (`src/lib/logger.ts`) com sanitização de PII (CPF, email, telefone).
- **Observability standards** documentados em `mem://security/observability-and-logging-standards`.
- **VistaSoft sync**: lock de 12h para evitar sync simultâneo; CRM sync automatizado.
- **AppHeader** com fallbacks de navegação (hard nav para acessibilidade quando React Router falha).

---

<a id="sprint-15"></a>
## Sprint 15 — Integração VistaSoft, sync XML e CRM ready (mensagens #661-#683)

**Período**: 10/mar/2026 → 11/mar/2026

### Decisões e entregas
- **Edge Function** `fetch-properties`: consume XML feed VistaSoft, normaliza em `properties_cache`, retorna payload `images3` compacto para mobile.
- Lock de sincronização (12h) em `vistasoft_sync_status`.
- **Property cache table**: dados completos do XML mais imagens normalizadas.
- **Mobile payload `images3`**: apenas 3 imagens primeiras + thumbnails reduzidos (economiza ~70% bandwidth).
- **CRM Integration readiness**: campos `crm_provider`, `crm_external_id`, `crm_sync_status`, `crm_last_synced_at` em `rentals`, `proposals`, `profiles`, `properties`.
- `buildCrmReadyPayload` produz JSON estável compatível com vários CRMs (HubSpot, Pipedrive, RD Station).
- `useVistaSoftSync` hook expõe estado de sincronização em tempo real.

---

<a id="sprint-16"></a>
## Sprint 16 — Documentação oficial, PRD e exports (mensagens #684-#710)

**Período**: 11/mar/2026 (último dia)

### Decisões e entregas
- **`docs/DOCUMENTACAO_COMPLETA.md`**: ~2000 linhas, 32 seções cobrindo:
  - 18 tabelas com colunas e RLS
  - Enums e funções SQL
  - 7 Edge Functions
  - Storage buckets e secrets
  - Rotas (App.tsx)
  - Ciclo 10 etapas + eventos
  - Tipos TS, validações Zod
  - Design system (CSS vars, tokens, cores HSL)
  - Componentes UI shadcn customizados
  - Migrations history
  - Política de senhas e auth
  - Pipeline admin
  - Observability & logging
- **`docs/PRD_ETIC_CONECTA.md`**: PRD oficial com 14 seções — visão produto, 20 RFs (RF-01 a RF-20), protocolos de segurança, mapa cruzado com a documentação técnica.
- **`docs/DOCUMENTO_TECNICO_COMPLETO.md`**: visão consolidada para recriar o projeto do zero — 7 seções (estrutura, banco, design, integrações, recriação).
- **Página `/download-docs`**: 
  - 3 botões `.md` (cada documento)
  - 3 botões `.pdf` (gerados client-side via `marked` + `html2pdf.js`)
  - Loading state com spinner e fallback para `.md` em caso de erro
- Bibliotecas adicionadas: `marked`, `html2pdf.js`.

---

## Apêndice A — Decisões arquiteturais consolidadas

| Tema | Decisão | Justificativa |
|------|---------|---------------|
| **Auth roles** | Tabela separada `user_roles` + RPC `has_role` | Evita escalada de privilégio em RLS recursiva |
| **CPF storage** | AES-256-GCM, decrypt apenas admin via Edge Function | LGPD + minimização de exposição |
| **Storage URLs** | Signed URLs TTL 60s | Previne hotlinking e vazamento |
| **Step truth** | `rentals.current_step` (1-10) único | Evita estados duplicados/conflitantes |
| **Eventos** | `setRentalStepAndLog` com janela 60s | Idempotência |
| **Datas** | Input manual DD/MM/AAAA | Mais rápido que calendar picker |
| **Protocolo** | `CODE-DDMMYY-TIMESTAMP_BASE36` | Unicidade garantida |
| **Desconto max** | 15% sobre aluguel apenas | Política comercial Etic |
| **RLS** | Default deny + permissive only | Segurança por padrão |
| **Notificações** | Web Notifications API + Realtime | Sem dependência externa |

## Apêndice B — Stack e dependências chave

- **Frontend**: React 18, Vite 5, TypeScript 5, Tailwind v3, shadcn/ui
- **State**: TanStack Query, Context API
- **DnD**: @dnd-kit/core, @dnd-kit/sortable
- **Forms**: React Hook Form, Zod
- **Backend**: Supabase (Postgres, Auth, Storage, Edge Functions Deno)
- **Integrações**: VistaSoft (XML), n8n (CRM webhook), WhatsApp (link)
- **PDF/Markdown**: marked, html2pdf.js (jsPDF + html2canvas)
- **Crypto**: SubtleCrypto (Web Crypto API), AES-256-GCM server-side

## Apêndice C — Estatísticas da jornada

- **Período total**: 27/jan/2026 a 11/mar/2026 (~6 semanas)
- **Mensagens trocadas**: 710
- **Edge Functions criadas**: 7
- **Tabelas modeladas**: 24+
- **Documentos finais**: 3 (Doc Técnica, PRD, Doc Consolidado)
- **Páginas/rotas**: 40+
- **Componentes React**: 130+
- **Hooks customizados**: 14+

---

## Como continuar

Para reproduzir o projeto ou continuar evolução:
1. Baixe `docs/DOCUMENTACAO_COMPLETA.md` (referência técnica completa)
2. Baixe `docs/PRD_ETIC_CONECTA.md` (visão produto + RFs)
3. Baixe `docs/DOCUMENTO_TECNICO_COMPLETO.md` (guia de recriação do zero)
4. Baixe este `docs/HISTORICO_CONVERSAS.md` (jornada cronológica)

Todos disponíveis em `/download-docs`.

---

*Documento gerado automaticamente em 11/mar/2026 a partir das 710 mensagens do chat Lovable.*
*Para detalhes literais de qualquer sprint, consulte o histórico do chat no editor Lovable.*
