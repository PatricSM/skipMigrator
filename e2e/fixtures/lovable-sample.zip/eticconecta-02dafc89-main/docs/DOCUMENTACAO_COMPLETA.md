# Etic Conecta — Documentação Completa do Projeto

> Gerado em: 2026-03-11  
> Versão: 1.0

---

## Índice

1. [Visão Geral](#1-visão-geral)
2. [Banco de Dados — Tabelas](#2-banco-de-dados--tabelas)
3. [View — rental_full_view](#3-view--rental_full_view)
4. [Enums](#4-enums)
5. [Funções SQL](#5-funções-sql)
6. [Edge Functions](#6-edge-functions)
7. [Storage Buckets](#7-storage-buckets)
8. [Secrets](#8-secrets)
9. [Autenticação](#9-autenticação)
10. [Rotas da Aplicação](#10-rotas-da-aplicação)
11. [Ciclo de Vida da Locação](#11-ciclo-de-vida-da-locação)
12. [Sistema de Eventos](#12-sistema-de-eventos)
13. [Sistema de Propostas](#13-sistema-de-propostas)
14. [Documentos](#14-documentos)
15. [Validações (Zod)](#15-validações-zod)
16. [Política de Senhas](#16-política-de-senhas)
17. [Pipeline Admin (Kanban)](#17-pipeline-admin-kanban)
18. [Tipos TypeScript](#18-tipos-typescript)
19. [Migrações](#19-migrações)

---

## 1. Visão Geral

| Item | Valor |
|------|-------|
| **Stack** | React 18 + Vite + TypeScript + Tailwind CSS |
| **UI** | shadcn/ui (Radix primitives) |
| **Backend** | Supabase (Postgres + Auth + Storage + Edge Functions) |
| **State** | React Query (@tanstack/react-query) |
| **Routing** | react-router-dom v6 |
| **Supabase Project ID** | `uxfbydatvcyggzqjumqn` |
| **Preview URL** | https://id-preview--c14509fb-d831-4615-bc3e-f231e7d71a9e.lovable.app |
| **Published URL** | https://eticconecta.lovable.app |

### Variáveis de Ambiente (auto-populadas)

- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_PUBLISHABLE_KEY`
- `VITE_SUPABASE_PROJECT_ID`

---

## 2. Banco de Dados — Tabelas

### 2.1 `profiles`

Perfil do usuário, criado automaticamente via trigger `handle_new_user`.

| Coluna | Tipo | Nullable | Default |
|--------|------|----------|---------|
| id | uuid | Não | — (FK auth.users) |
| full_name | text | Sim | null |
| email | text | Sim | null |
| phone | text | Sim | null |
| phone_clean | varchar | Sim | null |
| phone_e164 | text | Sim | null |
| cpf_encrypted | text | Sim | null |
| birth_date | date | Sim | null |
| nationality | text | Sim | null |
| nationality_country | text | Sim | null |
| marital_status | text | Sim | null |
| profession | text | Sim | null |
| monthly_income | numeric | Sim | null |
| is_politically_exposed | boolean | Sim | null |
| is_onboarded | boolean | Sim | false |
| role | text | Sim | null |
| codigo_locador | integer | Sim | null |
| nome_locador | varchar | Sim | null |
| vista_codigo | text | Sim | null |
| property_codes | jsonb | Sim | null |
| total_imoveis | integer | Sim | 0 |
| has_suspended_properties | boolean | Sim | false |
| last_vista_sync_at | timestamptz | Sim | null |
| last_vista_sync_status | text | Sim | null |
| last_vista_sync_error | text | Sim | null |
| created_at | timestamptz | Não | now() |
| updated_at | timestamptz | Não | now() |

**RLS:**
- `Users can view own profile` — SELECT — `auth.uid() = id`
- `Users can insert own profile` — INSERT — `auth.uid() = id`
- `Users can update own profile` — UPDATE — `auth.uid() = id`
- `Admins can view all profiles` — SELECT — `has_role(auth.uid(), 'admin')`
- DELETE: **bloqueado**

**Triggers:**
- `format_phone_on_profile` — normaliza telefone em INSERT/UPDATE
- `validate_phone` — valida formato 10-11 dígitos

---

### 2.2 `user_roles`

Tabela separada de roles (evita privilege escalation).

| Coluna | Tipo | Nullable | Default |
|--------|------|----------|---------|
| id | uuid | Não | gen_random_uuid() |
| user_id | uuid | Não | — |
| role | app_role (enum) | Não | 'locatario' |
| created_at | timestamptz | Não | now() |

**Unique constraint:** `(user_id, role)`

**RLS:**
- `Users can view own roles` — SELECT — `auth.uid() = user_id`
- `Users can assign tenant role to themselves` — INSERT — `auth.uid() = user_id AND role = 'locatario'`
- `Admins can manage all roles` — ALL — `has_role(auth.uid(), 'admin')`

---

### 2.3 `rentals`

Tabela principal do ciclo de locação.

| Coluna | Tipo | Nullable | Default |
|--------|------|----------|---------|
| id | uuid | Não | gen_random_uuid() |
| user_id | uuid | Não | — |
| protocol | text | Não | — |
| property_id | text | Não | — |
| property_code | text | Não | — |
| property_address | text | Não | — |
| rent_value | numeric | Sim | null |
| condo_fee | numeric | Sim | null |
| iptu | numeric | Sim | null |
| current_step | integer | Sim | 1 |
| step_status | text | Sim | 'in_progress' |
| tenant_status | text | Sim | 'in_analysis' |
| is_rejected | boolean | Sim | false |
| rejection_reason | text | Sim | null |
| has_pending | boolean | Sim | false |
| pending_reason | text | Sim | null |
| pending_description | text | Sim | null |
| pending_documents | jsonb | Sim | '[]' |
| proposal_status | rental_proposal_status (enum) | Sim | 'waiting_landlord_acceptance' |
| proposal_type | text | Sim | 'standard' |
| proposed_value | numeric | Sim | null |
| landlord_accepted | boolean | Sim | false |
| landlord_accepted_at | timestamptz | Sim | null |
| landlord_property_id | uuid | Sim | null |
| landlord_action_required | boolean | Sim | false |
| landlord_progress | integer | Sim | 0 |
| docs_submitted_early | boolean | Sim | false |
| documents_finalized_at | timestamptz | Sim | null |
| documents_cycle | integer | Não | 1 |
| admin_stage | integer | Não | 1 |
| admin_stage_id | uuid | Sim | null |
| admin_stage_entered_at | timestamptz | Não | now() |
| contract_preview_url | text | Sim | null |
| contract_sign_url | text | Sim | null |
| crm_deal_id | text | Sim | null |
| crm_provider | text | Sim | null |
| crm_last_sync_at | timestamptz | Sim | null |
| steps_version | text | Sim | 'v10' |
| created_at | timestamptz | Sim | now() |
| updated_at | timestamptz | Sim | now() |

**RLS:**
- `Users can view own rentals` — SELECT — `auth.uid() = user_id`
- `Users can insert own rentals` — INSERT — `auth.uid() = user_id`
- `Users can update own rentals` — UPDATE — `auth.uid() = user_id`
- `Landlords can view rentals for their properties` — SELECT — via JOIN properties
- `Landlords can update rentals for their properties` — UPDATE — via JOIN properties
- `Admins can view all rentals` — SELECT — `has_role(auth.uid(), 'admin')`
- `Admins can update rentals` — UPDATE — `has_role(auth.uid(), 'admin')`
- `Admins can delete rentals` — DELETE — `has_role(auth.uid(), 'admin')`

**Triggers:**
- `set_admin_stage_entered_at` — atualiza timestamp quando admin_stage muda
- `update_updated_at` — atualiza updated_at em cada UPDATE

---

### 2.4 `rental_events`

Histórico de eventos auditáveis do rental.

| Coluna | Tipo | Nullable | Default |
|--------|------|----------|---------|
| id | uuid | Não | gen_random_uuid() |
| rental_id | uuid | Não | — (FK rentals.id) |
| event_type | text | Não | — |
| description | text | Não | — |
| created_by | uuid | Sim | — |
| idempotency_key | text | Sim | null |
| metadata | jsonb | Sim | null |
| created_at | timestamptz | Sim | now() |

**RLS:**
- `Users can view own rental events` — SELECT — via rentals.user_id
- `Users can insert own rental events` — INSERT — via rentals.user_id
- `Users can delete own rental events` — DELETE — via rentals.user_id
- `Admins can view/insert/update/delete` — todas — `has_role(auth.uid(), 'admin')`

**Trigger:** `rental_events_set_created_by` — preenche created_by com auth.uid()

---

### 2.5 `documents`

Documentos enviados pelo locatário.

| Coluna | Tipo | Nullable | Default |
|--------|------|----------|---------|
| id | uuid | Não | gen_random_uuid() |
| user_id | uuid | Não | — |
| rental_id | uuid | Sim | null |
| document_type | text | Não | — |
| document_label | text | Sim | null |
| file_name | text | Não | — |
| file_path | text | Não | — |
| file_type | text | Não | — |
| status | text | Não | 'pending' |
| reviewed_by | uuid | Sim | null |
| reviewed_at | timestamptz | Sim | null |
| created_at | timestamptz | Não | now() |

**RLS:**
- `Users can view own documents` — SELECT — `auth.uid() = user_id`
- `Users can insert own documents` — INSERT — `auth.uid() = user_id`
- `Users can delete own pending documents` — DELETE — `auth.uid() = user_id AND status = 'pending'`
- `Admins can view/update/delete all documents` — has_role admin

---

### 2.6 `landlord_data`

Dados cadastrais do locador vinculados a um rental.

| Coluna | Tipo | Nullable | Default |
|--------|------|----------|---------|
| id | uuid | Não | gen_random_uuid() |
| rental_id | uuid | Não | — (FK rentals.id, oneToOne) |
| landlord_id | uuid | Não | — |
| full_name | text | Sim | null |
| email | text | Sim | null |
| phone | text | Sim | null |
| profession | text | Sim | null |
| marital_status | text | Sim | null |
| has_second_landlord | boolean | Sim | false |
| second_landlord_name | text | Sim | null |
| second_landlord_email | text | Sim | null |
| second_landlord_phone | text | Sim | null |
| second_landlord_profession | text | Sim | null |
| second_landlord_marital_status | text | Sim | null |
| bank_name | text | Sim | null |
| bank_agency | text | Sim | null |
| bank_account | text | Sim | null |
| bank_account_type | text | Sim | null |
| pix_key | text | Sim | null |
| bills_responsible | text | Sim | null |
| created_at | timestamptz | Não | now() |
| updated_at | timestamptz | Não | now() |

**RLS:**
- `Landlords can view/insert/update own data` — `auth.uid() = landlord_id`
- `Admins can manage/view all` — has_role admin

---

### 2.7 `landlord_documents`

Documentos enviados pelo locador.

| Coluna | Tipo | Nullable | Default |
|--------|------|----------|---------|
| id | uuid | Não | gen_random_uuid() |
| landlord_id | uuid | Não | — |
| rental_id | uuid | Não | — (FK rentals.id) |
| document_type | text | Não | — |
| file_name | text | Não | — |
| file_path | text | Não | — |
| file_type | text | Não | — |
| status | text | Não | 'pending' |
| reviewed_by | uuid | Sim | null |
| reviewed_at | timestamptz | Sim | null |
| created_at | timestamptz | Não | now() |

**RLS:**
- `Landlords can view/insert own documents` — `auth.uid() = landlord_id`
- `Landlords can delete pending documents` — `auth.uid() = landlord_id AND status = 'pending'`
- `Admins can manage/view all` — has_role admin

---

### 2.8 `properties`

Imóveis cadastrados pelos locadores.

| Coluna | Tipo | Nullable | Default |
|--------|------|----------|---------|
| id | uuid | Não | gen_random_uuid() |
| owner_id | uuid | Não | — |
| code | text | Não | — |
| address | text | Não | — |
| short_address | text | Não | — |
| description | text | Sim | null |
| rent_value | numeric | Sim | null |
| condo_fee | numeric | Sim | null |
| iptu | numeric | Sim | null |
| has_condo | boolean | Sim | false |
| images | text[] | Sim | '{}' |
| status | text | Não | 'active' |
| created_at | timestamptz | Não | now() |
| updated_at | timestamptz | Não | now() |

**RLS:**
- `Anyone can view available properties` — SELECT — `status IN ('disponivel', 'em_negociacao')`
- `Landlords can view/insert/update/delete own` — `auth.uid() = owner_id`
- `Admins can manage/view all` — has_role admin

---

### 2.9 `properties_cache`

Cache do XML de imóveis (Edge Function fetch-properties).

| Coluna | Tipo | Nullable | Default |
|--------|------|----------|---------|
| id | text | Não | 'current' |
| data | jsonb | Não | — |
| count | integer | Não | 0 |
| fetched_at | timestamptz | Não | now() |
| expires_at | timestamptz | Não | now() + 10min |

**RLS:**
- `Authenticated users can read` — SELECT — `true` (role: authenticated)
- `Service role can manage` — ALL — `auth.role() = 'service_role'`

---

### 2.10 `property_invites`

Convites para locadores vincularem imóveis.

| Coluna | Tipo | Nullable | Default |
|--------|------|----------|---------|
| id | uuid | Não | gen_random_uuid() |
| property_id | uuid | Não | — (FK properties.id) |
| token_hash | text | Não | — |
| created_by | uuid | Não | — |
| expires_at | timestamptz | Não | — |
| used_at | timestamptz | Sim | null |
| used_by | uuid | Sim | null |
| revoked_at | timestamptz | Sim | null |
| created_at | timestamptz | Não | now() |

**RLS:**
- `Admins can manage all` — ALL — has_role admin

---

### 2.11 `proposals`

Propostas e contrapropostas de valor.

| Coluna | Tipo | Nullable | Default |
|--------|------|----------|---------|
| id | uuid | Não | gen_random_uuid() |
| rental_id | uuid | Não | — (FK rentals.id) |
| author | proposal_author (enum) | Não | — |
| rent_value | numeric | Sim | null |
| deposit_value | numeric | Sim | null |
| start_date | date | Sim | null |
| notes | text | Sim | null |
| status | proposal_status_enum (enum) | Não | 'pending' |
| created_at | timestamptz | Não | now() |

**RLS:**
- `Tenants can view/insert(author=tenant)/update own proposals` — via rentals.user_id
- `Landlords can view/insert(author=landlord)/update proposals for their properties` — via properties.owner_id
- `Admins can manage/view all` — has_role admin

---

### 2.12 `contracts`

Contratos de locação gerados.

| Coluna | Tipo | Nullable | Default |
|--------|------|----------|---------|
| id | uuid | Não | gen_random_uuid() |
| rental_id | uuid | Não | — (FK rentals.id) |
| content | text | Sim | null |
| preview_url | text | Sim | null |
| signature_url | text | Sim | null |
| status | text | Não | 'generated' |
| generated_by | uuid | Sim | null |
| signed_by_tenant_at | timestamptz | Sim | null |
| signed_by_landlord_at | timestamptz | Sim | null |
| created_at | timestamptz | Não | now() |
| updated_at | timestamptz | Não | now() |

**RLS:**
- `Tenants can view/update own contracts` — via rentals.user_id
- `Landlords can view/update contracts for their properties` — via properties.owner_id
- `Admins can manage all` — has_role admin

---

### 2.13 `inspections`

Vistorias de entrada.

| Coluna | Tipo | Nullable | Default |
|--------|------|----------|---------|
| id | uuid | Não | gen_random_uuid() |
| rental_id | uuid | Não | — (FK rentals.id) |
| scheduled_date | date | Sim | null |
| scheduled_time | text | Sim | null |
| location_notes | text | Sim | null |
| report_url | text | Sim | null |
| signature_url | text | Sim | null |
| status | text | Não | 'pending' |
| signed_by_tenant_at | timestamptz | Sim | null |
| signed_by_landlord_at | timestamptz | Sim | null |
| keys_delivered_at | timestamptz | Sim | null |
| keys_delivered_by | uuid | Sim | null |
| created_at | timestamptz | Não | now() |
| updated_at | timestamptz | Não | now() |

**RLS:**
- `Tenants can view/insert/update own` — via rentals.user_id
- `Landlords can view/insert/update for their properties` — via properties.owner_id
- `Admins can manage all` — has_role admin

---

### 2.14 `document_types`

Catálogo de tipos de documentos.

| Coluna | Tipo | Nullable | Default |
|--------|------|----------|---------|
| id | uuid | Não | gen_random_uuid() |
| key | text | Não | — |
| label | text | Não | — |
| is_required | boolean | Sim | true |
| required_for_role | text | Sim | null |
| required_step | text | Sim | null |

**RLS:**
- `Authenticated users can read` — SELECT — `true` (role: authenticated)
- INSERT/UPDATE/DELETE: **bloqueado**

---

### 2.15 `rental_steps`

Definição das etapas do fluxo de locação.

| Coluna | Tipo | Nullable | Default |
|--------|------|----------|---------|
| step_number | integer | Não | — (PK) |
| name | text | Não | — |
| description | text | Sim | null |
| responsible | text | Não | 'admin' |
| sla_hours | integer | Sim | null |
| is_active | boolean | Não | true |
| created_at | timestamptz | Não | now() |
| updated_at | timestamptz | Não | now() |

**RLS:**
- `Anyone can read` — SELECT — `true` (role: authenticated)
- `Admins can manage` — ALL — has_role admin

---

### 2.16 `admin_pipeline_stages`

Etapas do pipeline Kanban admin.

| Coluna | Tipo | Nullable | Default |
|--------|------|----------|---------|
| id | uuid | Não | gen_random_uuid() |
| name | text | Não | — |
| order_index | integer | Não | — |
| color_key | text | Não | 'teal' |
| is_active | boolean | Não | true |
| created_at | timestamptz | Não | now() |
| updated_at | timestamptz | Não | now() |

**RLS:** Somente admins (view + manage)

---

### 2.17 `audit_logs`

Log de auditoria completo.

| Coluna | Tipo | Nullable | Default |
|--------|------|----------|---------|
| id | uuid | Não | gen_random_uuid() |
| user_id | uuid | Sim | — |
| action | text | Não | — |
| table_name | text | Não | — |
| record_id | uuid | Sim | null |
| old_data | jsonb | Sim | null |
| new_data | jsonb | Sim | null |
| ip_address | inet | Sim | null |
| user_agent | text | Sim | null |
| created_at | timestamptz | Não | now() |

**RLS:**
- `Users can read own audit logs` — `auth.uid() = user_id`
- `Admins can read all` — has_role admin
- INSERT: `false` (somente service_role via função log_audit)
- UPDATE/DELETE: **bloqueado**

---

### 2.18 `auth_rate_limits`

Rate limiting progressivo de autenticação.

| Coluna | Tipo | Nullable | Default |
|--------|------|----------|---------|
| id | uuid | Não | gen_random_uuid() |
| identifier | text | Não | — (hash SHA-256) |
| action | text | Não | — |
| attempts | integer | Não | 1 |
| first_attempt_at | timestamptz | Não | now() |
| last_attempt_at | timestamptz | Não | now() |
| blocked_until | timestamptz | Sim | null |
| created_at | timestamptz | Não | now() |

**RLS:** Somente service_role

---

### 2.19 Outras tabelas

| Tabela | Descrição |
|--------|-----------|
| `security_events` | Eventos de segurança (rate_limit_block, etc.) — admins + service_role |
| `notification_queue` | Fila de notificações WhatsApp — somente service_role |
| `n8n_chat_histories` | Histórico de chat n8n — bloqueado para usuários |
| `rental_applications` | Candidaturas legadas — tenant/owner/second_tenant access |
| `application_documents` | Documentos de candidaturas legadas |
| `application_events` | Eventos de candidaturas legadas |

---

## 3. View — rental_full_view

View agregada que junta `rentals` + `profiles` (tenant) + `landlord_data` + `admin_pipeline_stages` + contagens de documentos e eventos.

```sql
-- Configuração de segurança
ALTER VIEW public.rental_full_view SET (security_invoker = true);
```

Com `security_invoker = true`, a view respeita as políticas RLS das tabelas base. Não possui RLS policies próprias.

**Campos principais:**
- Todos os campos de `rentals`
- `tenant_name`, `tenant_email`, `tenant_phone`, `tenant_cpf_encrypted`, `tenant_birth_date`, `tenant_nationality`, `tenant_marital_status`, `tenant_profession`, `tenant_monthly_income`, `tenant_is_pep`
- `landlord_name`, `landlord_email`, `landlord_phone`, `bank_name`, `bank_agency`, `bank_account`, `pix_key`, `bills_responsible`, `has_second_landlord`, `second_landlord_*`
- `stage_name`, `stage_color`, `stage_order`
- `tenant_doc_count`, `landlord_doc_count`, `event_count`

---

## 4. Enums

```sql
CREATE TYPE public.app_role AS ENUM ('locatario', 'locador', 'admin');

CREATE TYPE public.proposal_author AS ENUM ('tenant', 'landlord');

CREATE TYPE public.proposal_status_enum AS ENUM ('pending', 'accepted', 'rejected', 'countered');

CREATE TYPE public.rental_proposal_status AS ENUM (
  'waiting_landlord_acceptance',
  'counter_proposal_pending',
  'proposal_accepted',
  'proposal_rejected'
);
```

---

## 5. Funções SQL

### 5.1 `has_role(_user_id uuid, _role app_role) → boolean`
Verifica se o usuário tem determinado role. `SECURITY DEFINER` para bypassar RLS e evitar recursão.

### 5.2 `handle_new_user() → trigger`
Trigger em `auth.users` (AFTER INSERT). Cria perfil em `profiles` e atribui role `locatario` (exceto se `user_type = 'locador'`).

### 5.3 `log_audit(p_action, p_table_name, ...) → uuid`
Insere registro em `audit_logs`. `SECURITY DEFINER` pois a tabela tem INSERT bloqueado para usuários.

### 5.4 `audit_trigger_fn() → trigger`
Trigger genérico que chama `log_audit` em INSERT/UPDATE/DELETE.

### 5.5 `format_brazilian_phone_e164(phone_input text) → text`
Converte telefone brasileiro para formato E.164 (`+55XXXXXXXXXXX`).

### 5.6 `format_phone_on_profile() → trigger`
Trigger em `profiles`. Normaliza `phone`, `phone_clean` e `phone_e164` em INSERT/UPDATE.

### 5.7 `validate_phone() → trigger`
Valida que phone tem 10 ou 11 dígitos numéricos.

### 5.8 `update_updated_at() → trigger` / `update_updated_at_column()` / `set_updated_at()`
Triggers para atualizar `updated_at = now()`.

### 5.9 `set_admin_stage_entered_at() → trigger`
Atualiza `admin_stage_entered_at` quando `admin_stage` muda.

### 5.10 `rental_events_set_created_by() → trigger`
Preenche `created_by` com `auth.uid()` se null.

### 5.11 `cleanup_old_rate_limits() → void`
Remove entradas de rate limit com mais de 24h.

### 5.12 `get_user_applications(user_id uuid) → TABLE`
Retorna candidaturas do usuário (tenant, second_tenant ou owner).

Todas as funções usam `SECURITY DEFINER` com `SET search_path = public`.

---

## 6. Edge Functions

### 6.1 `accept-property-invite`
- **Método:** POST
- **Auth:** Bearer JWT
- **verify_jwt:** false (validação manual via getClaims)
- **Lógica:** Valida token de convite (SHA-256 hash), verifica expiração/revogação, atribui `owner_id` da property ao usuário, concede role `locador`, marca convite como usado.
- **Idempotente:** Se mesmo usuário aceita novamente, retorna sucesso.

### 6.2 `check-rate-limit`
- **Método:** POST
- **Auth:** Nenhum (service_role interno)
- **verify_jwt:** false
- **Lógica:** Rate limiting progressivo:
  - 5 tentativas em 15min → bloqueia 1min
  - 10 tentativas → 5min
  - 20 tentativas → 15min
  - 30+ tentativas → 60min
- **Fail-open:** Em caso de erro, permite a requisição.

### 6.3 `encrypt-cpf`
- **Método:** POST
- **Auth:** Bearer JWT
- **verify_jwt:** false (validação manual)
- **Secret:** `CPF_ENCRYPTION_KEY`
- **Lógica:**
  - `action: 'encrypt'` — qualquer usuário autenticado pode encriptar seu CPF (AES-256-GCM via PBKDF2)
  - `action: 'decrypt'` — **somente admins** podem decriptar

### 6.4 `fetch-properties`
- **Método:** GET/POST
- **Auth:** Nenhum
- **verify_jwt:** false
- **Lógica:** Busca XML de imóveis do VistaSoft, parseia listings para aluguel, cacheia em `properties_cache` por 10 minutos. Retorna versão "light" (~80% menor payload).
- **Fonte XML:** `https://eticimov17806-portais.vistahost.com.br/...`

### 6.5 `get-signed-url`
- **Método:** POST
- **Auth:** Bearer JWT
- **verify_jwt:** false (validação manual)
- **Lógica:** Gera URL assinada (60s TTL) para download de arquivo no Storage. Verifica que o `userId` no path corresponde ao usuário autenticado (ou admin). Registra acesso em `audit_logs`.

### 6.6 `validate-landlord`
- **Método:** POST
- **Auth:** Bearer JWT
- **verify_jwt:** false (validação manual)
- **Secret:** `N8N_VALIDATE_LANDLORD_WEBHOOK`
- **Lógica (cascata):**
  1. Já tem role `locador`? → autorizado
  2. Tem `property_codes` no perfil (sync anterior)? → atribui role e autoriza
  3. É `owner_id` de alguma property? → atribui role e autoriza
  4. Chama webhook n8n para validação CRM por telefone → se válido, salva dados e atribui role
  5. Senão → não autorizado

### 6.7 `validate-upload`
- **Método:** POST (multipart/form-data)
- **Auth:** Nenhum
- **verify_jwt:** false
- **Lógica:** Valida arquivo por tamanho (max 10MB) e magic bytes (PDF, JPEG, PNG, GIF, WebP). Retorna `{ valid: true/false }`.

---

## 7. Storage Buckets

| Bucket | Público | Uso |
|--------|---------|-----|
| `documents` | Não | Documentos do locatário (identity, income, residence, other) |
| `landlord-documents` | Não | Documentos do locador |
| `property-images` | Sim | Imagens de imóveis |

**Path pattern:** `{user_id}/{rental_id}/{document_type}/{filename}`

**Acesso a arquivos privados:** Via Edge Function `get-signed-url` (URL com TTL de 60s).

---

## 8. Secrets

| Nome | Uso |
|------|-----|
| `SUPABASE_URL` | URL do projeto Supabase |
| `SUPABASE_ANON_KEY` | Chave anônima (publishable) |
| `SUPABASE_PUBLISHABLE_KEY` | Alias da anon key |
| `SUPABASE_SERVICE_ROLE_KEY` | Chave de serviço (privada) |
| `SUPABASE_DB_URL` | URL de conexão direta ao banco |
| `CPF_ENCRYPTION_KEY` | Chave para AES-256-GCM (encrypt-cpf) |
| `N8N_VALIDATE_LANDLORD_WEBHOOK` | URL do webhook n8n para validação CRM |
| `LOVABLE_API_KEY` | Chave da API Lovable |
| `Etic Conecta` | (Metadata/nome do projeto) |

---

## 9. Autenticação

### 9.1 AuthContext

Arquivo: `src/contexts/AuthContext.tsx`

**Estado gerenciado:**
- `user: User | null`
- `session: Session | null`
- `profile: Profile | null`
- `roles: AppRole[]`
- `isLoading: boolean`

**Flags derivadas:**
- `isAuthenticated`, `isAdmin`, `isLandlord`, `isTenant`

**Métodos:**
- `login(email, password)` — `signInWithPassword`
- `register(email, password, fullName, options?)` — `signUp` com metadata (full_name, phone, user_type)
- `logout()` — `signOut` com flag explícita
- `resetPassword(email)` — `resetPasswordForEmail` → redirect `/reset-password`
- `updatePassword(newPassword)` — `updateUser`
- `hasRole(role)` — verifica se role está no array
- `refreshProfile()` — recarrega profile e roles

### 9.2 Fluxo de Refresh Token Inválido

`handleInvalidRefreshToken()`:
1. Limpa estado local (user, session, profile, roles)
2. `signOut({ scope: 'local' })`
3. Remove tokens do localStorage (`sb-*-auth-token`)
4. Toast "Sessão expirada"
5. Redireciona baseado na rota atual:
   - `/locatario/*` → `/locatario/login?redirect=...`
   - `/admin/*` → `/login`
   - `/locador/*` → `/locador/auth`

### 9.3 onAuthStateChange

- `SIGNED_OUT` só limpa estado se for logout explícito (evita "flicker" de refresh token)
- Outros eventos: atualiza session/user, busca profile+roles em setTimeout(0)

### 9.4 Route Guards

| Guard | Arquivo | Lógica |
|-------|---------|--------|
| `ProtectedRoute` | `src/components/auth/ProtectedRoute.tsx` | Requer `user`. Pode restringir por `allowedRoles`. Redirect contextual (locador→/locador/auth, default→/locatario/login). |
| `AdminRoute` | `src/components/auth/AdminRoute.tsx` | Requer `user` + `isAdmin`. Redirect → `/forbidden`. |
| `LocadorRoute` | `src/components/auth/LocadorRoute.tsx` | Requer `user` + `isLandlord`. Redirect → `/locador/auth`. |

---

## 10. Rotas da Aplicação

### Públicas

| Rota | Componente | Descrição |
|------|-----------|-----------|
| `/` | Redirect → `/locatario` | — |
| `/locatario` | `LocatarioLanding` | Landing page do locatário |
| `/locatario/login` | `LocatarioLogin` | Login locatário |
| `/locatario/register` | `LocatarioRegister` | Cadastro locatário |
| `/locatario/verifique-email` | `VerifiqueEmail` | Confirmação de e-mail |
| `/locatario/selecionar-imovel` | `SelecionarImovel` | Catálogo de imóveis |
| `/locatario/escolher-tipo-proposta/:id` | `EscolherTipoProposta` | Tipo de proposta |
| `/locatario/iniciar-locacao-direta` | `IniciarLocacaoDireta` | Locação direta |
| `/anunciar-imovel` | `AnunciarImovel` | Anunciar imóvel |
| `/privacidade` | `PortalPrivacidade` | Portal de privacidade |
| `/locador/auth` | `LocadorAuth` | Login/cadastro locador |
| `/auth` | `Auth` | Auth legado + reset password |
| `/reset-password` | `Auth` | Reset de senha |
| `/convite/:token` | `AcceptInvite` | Aceitar convite de imóvel |
| `/forbidden` | `Forbidden` | Acesso negado |

### Protegidas (ProtectedRoute)

| Rota | Componente |
|------|-----------|
| `/locatario/enviar-documentos/:id` | `EnviarDocumentos` |
| `/locatario/enviar-documentos/:id/segundo-locatario` | `SegundoLocatario` |
| `/locatario/enviar-documentos-pendentes/:id` | `EnviarDocumentosPendentes` |
| `/locatario/envio-sucesso/:id` | `EnvioSucesso` |
| `/locatario/acompanhamento/:id?` | `Acompanhamento` |
| `/locatario/painel` | `TenantDashboard` |
| `/locatario/meu-cadastro` | `MeuCadastro` |
| `/locatario/segundo-locatario` | `SegundoLocatario` |

### Admin (AdminRoute)

| Rota | Componente |
|------|-----------|
| `/admin` | `Admin` (Kanban dashboard) |
| `/admin/rentals` | `AdminRentalsList` |
| `/admin/rentals/:rentalId` | `AdminRentalDetail` |
| `/admin/security` | `SecurityDashboard` |
| `/admin/invites` | `PropertyInvitesAdmin` |
| `/mapa` | `MapaProduto` |

### Locador (LocadorRoute + LocadorLayout)

| Rota | Componente |
|------|-----------|
| `/locador/home` | `LocadorHome` |
| `/locador/propostas` | `LocadorPropostas` |
| `/locador/proposta/:protocolo` | `PropostaDetalhe` |
| `/locador/imoveis` | `LocadorImoveis` |
| `/locador/imovel/:id` | `ImovelForm` |
| `/locador/anunciar` | `LocadorAnunciar` |
| `/locador/ajuda` | `LocadorAjuda` |

### Redirects Legados

| De | Para |
|----|------|
| `/login` | `/locatario/login` |
| `/cadastro` | `/locatario/register` |
| `/selecionar-imovel` | `/locatario/selecionar-imovel` |
| `/enviar-documentos/:id` | `/locatario/escolher-tipo-proposta/:id` |
| `/acompanhamento/:id` | `/locatario/acompanhamento/:id` |
| `/acompanhamento` | `/locatario/acompanhamento` |

---

## 11. Ciclo de Vida da Locação

10 etapas padronizadas (campo `rentals.current_step`):

| Step | Título | Responsável | SLA | O que pode atrasar |
|------|--------|-------------|-----|---------------------|
| 1 | Proposta | Locatário | — | Dados incompletos |
| 2 | Aceite da Proposta | Locador | 24h | Tempo de resposta do locador |
| 3 | Documentação | Locatário | Depende do user | Docs incompletos/ilegíveis |
| 4 | Análise da Ficha | Admin | 24h úteis | Volume alto de análises |
| 5 | Documentos do Locador | Locador | Depende do locador | Locador não enviou docs |
| 6 | Emissão do Contrato | Admin | 48h úteis | Ajustes no contrato |
| 7 | Assinatura do Contrato | Todos | Depende das assinaturas | Partes não assinaram |
| 8 | Agendamento de Vistoria | Locatário | Usuário agenda | Disponibilidade de horários |
| 9 | Assinatura de Vistoria | Todos | Depende das assinaturas | Partes não assinaram |
| 10 | Entrega das Chaves | Todos | — | — |

### Transição de etapas

Toda transição é feita pela função `setRentalStepAndLog()`:
1. Busca `current_step` e `documents_cycle` atuais
2. Atualiza `rentals.current_step` + campos extras
3. Insere evento `step_changed` com `from_step` e `to_step` no metadata

### Status do step

- `in_progress` — etapa ativa
- `completed` — etapa concluída
- `pending` — ação necessária (docs pendentes)
- `rejected` — ficha reprovada

---

## 12. Sistema de Eventos

### Catálogo de Eventos

| Evento | Etapa | Descrição PT-BR |
|--------|-------|-----------------|
| `proposal_created` | 1 | Proposta criada |
| `proposal_sent` | 1 | Proposta enviada |
| `proposal_countered` | 2 | Contraproposta enviada pelo locador |
| `counter_proposal_accepted` | 2 | Contraproposta aceita pelo locatário |
| `counter_proposal_rejected` | 2 | Contraproposta rejeitada pelo locatário |
| `proposal_accepted` | 2 | Proposta aceita |
| `proposal_rejected` | 2 | Proposta rejeitada |
| `documents_ready_to_finalize` | 3 | Documentos prontos para finalização |
| `documents_finalized` | 3 | Documentação finalizada |
| `documents_reopened` | 3 | Documentação reaberta |
| `documents_uploaded` | 3 | Documentos enviados |
| `ficha_analysis_started` | 4 | Análise de ficha iniciada |
| `ficha_analysis_completed` | 4 | Análise concluída |
| `ficha_approved` | 4 | Ficha aprovada |
| `ficha_rejected` | 4 | Ficha reprovada |
| `landlord_documents_sent` | 5 | Docs do locador enviados |
| `contract_emitted` | 6 | Contrato emitido |
| `contract_signed` | 7 | Contrato assinado (ambas partes) |
| `inspection_scheduled` | 8 | Vistoria agendada |
| `inspection_signed` | 9 | Laudo assinado (ambas partes) |
| `keys_delivered` | 10 | Chaves entregues |
| `step_changed` | — | Etapa alterada |
| `second_tenant_added` | — | 2º locatário adicionado |

### Idempotência

- Campo `idempotency_key` na tabela `rental_events`
- Em caso de constraint violation (23505), o evento é considerado já registrado (não é erro)
- Eventos de upload de documentos têm dedupe de 60 segundos

---

## 13. Sistema de Propostas

### Fluxo

1. **Locatário cria proposta** → `createTenantProposal()` → evento `proposal_created`
2. **Locador pode:**
   - Aceitar → `proposal_accepted` → avança para step 3
   - Contraproposta → `createCounterProposal()` → `proposal_countered`
3. **Locatário responde contraproposta:**
   - Aceitar → `acceptCounterProposal()` → `counter_proposal_accepted` → step 3
   - Rejeitar → `rejectCounterProposal()` → `counter_proposal_rejected`

### Contrato

1. `emitContract()` — Gera contrato (status: 'generated'), registra `contract_emitted`
2. `sendContractForSignature()` — Envia para assinatura (status: 'sent')
3. `signContract({ signerRole: 'tenant' })` — Registra assinatura do locatário
4. `signContract({ signerRole: 'landlord' })` — Registra assinatura do locador
5. Quando ambos assinaram → status 'signed', avança para step 8

### Vistoria

1. `scheduleInspection()` — Agenda vistoria (data + hora + notas)
2. `signInspectionReport({ signerRole })` — Assinatura do laudo
3. Quando ambos assinaram → avança para step 10
4. `deliverKeys()` — Entrega das chaves (finaliza o processo)

### QA / Consistency Checks

`runConsistencyChecks()` verifica:
- Evento de proposta existe quando step ≥ 1
- Documentos finalizados quando step ≥ 4
- Ciclo de documentos consistente
- Eventos correspondentes ao step atual
- Propostas existem para proposals ativas

---

## 14. Documentos

### Tipos obrigatórios (locatário)

| Tipo | Label | Limite | Descrição |
|------|-------|--------|-----------|
| `identity` | RG ou CNH | 2 arquivos | Foto legível, frente e verso |
| `income` | Comprovante de Renda | 6 arquivos | 90 dias de extratos, IR ou holerites |
| `residence` | Comprovante de Residência | 2 arquivos | Conta de luz/água/gás (até 90 dias) |
| `other` | Outros (opcional) | 6 arquivos | Documentos complementares |

### Validação de upload

**Client-side (quickValidateFile):**
- Tamanho máximo: 10MB
- Tipos permitidos: PDF, JPEG, PNG, GIF, WebP

**Server-side (Edge Function validate-upload):**
- Magic bytes verification (primeiros 16 bytes)
- Fallback: se server indisponível, usa validação client-side

### Microcopy por tipo

- `identity`: "(Documento oficial dentro da validade)"
- `income`: "(90 dias de extratos bancários em PDF com número da conta e dados, últimos 3 holerites ou Imposto de Renda completo)"
- `residence`: "(Enviar com no máximo 90 dias de vencimento)"

---

## 15. Validações (Zod)

### loginSchema
```typescript
{ email: string().email(), password: string().min(1) }
```

### registerSchema
```typescript
{ fullName: min(3), email: email(), phone: isValidPhone(), password: strongPasswordSchema, confirmPassword: match(password) }
```

### personalDataSchema
```typescript
{ fullName: min(3), email: email(), phone: isValidPhone(), cpf: isValidCPF(), birthDate: min(1), nationality: min(1), maritalStatus: min(1), profession: min(1), monthlyIncome: positive(), isPoliticallyExposed: boolean() }
```

### propertyDataSchema
```typescript
{ propertyCode: min(1), propertyAddress: min(10), rentValue: positive(), condoFee?: nonnegative(), iptu?: nonnegative() }
```

### landlordDataSchema
```typescript
{ fullName, email, phone, maritalStatus, profession, hasSecondLandlord, secondLandlord*, bankName, bankAgency, bankAccount, bankAccountType, pixKey?, billsResponsible }
```

### Opções de Select

- **Estado civil:** solteiro, casado, divorciado, viúvo, união estável
- **Tipo de conta:** corrente, poupança
- **Nacionalidade:** brasileiro, estrangeiro

### sanitizeRedirect(url)

Previne open redirect attacks. Aceita apenas paths internos (`/...` mas não `//...`).

---

## 16. Política de Senhas

**Requisitos (strongPasswordSchema):**
- Mínimo 14 caracteres
- Pelo menos 3 de 4 classes: maiúsculas, minúsculas, números, caracteres especiais
- Não pode ser senha comum (lista de 50 senhas)

**Score de força (getPasswordStrength):**
- 0: Muito fraca (< 8 chars)
- 1: Fraca (8+ chars)
- 2: Razoável (14+ chars)
- 3: Forte (14+ chars + 3 classes)
- 4: Muito forte (20+ chars + 4 classes)

**Lista de senhas comuns bloqueadas:**
`password`, `123456`, `12345678`, `qwerty`, `abc123`, `senha`, `senha123`, `mudar123`, `trocar123`, `brasil`, `flamengo`, `palmeiras`, `corinthians`, `santos`, `amor`, `jesus`, `deus`, e outras.

---

## 17. Pipeline Admin (Kanban)

7 estágios do Kanban administrativo (campo `rentals.admin_stage`):

| Stage | Título | Subtítulo |
|-------|--------|-----------|
| 1 | Etapa 1 | Aprovação da ficha |
| 2 | Etapa 2 | Receber docs. locador |
| 3 | Etapa 3 | Emissão do contrato |
| 4 | Etapa 4 | Assinatura do contrato |
| 5 | Etapa 5 | Agendamento de vistoria |
| 6 | Etapa 6 | Assinatura da vistoria |
| 7 | Etapa 7 | Entrega das chaves |

> **Nota:** O pipeline admin (7 etapas) é diferente do ciclo do locatário (10 etapas). O admin_stage começa a partir da análise da ficha (step 4 do locatário).

---

## 18. Tipos TypeScript

### Principais interfaces

```typescript
// src/types/index.ts
type AppRole = 'admin' | 'locatario' | 'locador';
interface Profile { id, full_name, email, phone, cpf_encrypted, birth_date, nationality, marital_status, profession, monthly_income, is_politically_exposed, ... }
interface UserRole { id, user_id, role: AppRole, created_at }
interface Property { id, owner_id, code, address, short_address, rent_value, condo_fee, iptu, images, status, ... }
interface PropertyInvite { id, property_id, token_hash, created_by, expires_at, used_at, used_by, revoked_at, ... }
interface Rental { id, user_id, protocol, property_id, property_code, property_address, current_step, step_status, tenant_status, is_rejected, has_pending, pending_documents, admin_stage, landlord_property_id, contract_preview_url, ... }
interface RentalEvent { id, rental_id, event_type, description, created_by, created_at }
interface Document { id, user_id, rental_id, document_type, file_name, file_path, file_type, status, ... }
interface LandlordData { id, rental_id, landlord_id, full_name, bank_name, bank_agency, bank_account, pix_key, has_second_landlord, ... }
interface PipelineStage { id, name, order_index, color_key, is_active }
interface RentalFullView extends Rental { tenant_*, landlord_*, stage_*, *_doc_count, event_count }
interface RentalFormData { propertyCode, propertyAddress, rentValue, fullName, email, phone, cpf, birthDate, ... }

// src/types/tracking.ts
type RentalStepStatus = 'completed' | 'current' | 'future' | 'rejected';
interface TrackingStep { step, title, description, responsible, whatCanDelay, whatUserNeedsToDo, status }
interface RentalTracking { id, protocol, propertyId, propertyAddress, currentStep, stepStatus, tenantStatus, hasPending, isRejected, pendingDocuments, proposalType, proposalStatus, documentsFinalizedAt, documentsCycle, proposalCount, ... }
interface RentalEvent { id, eventType, description, createdAt }

// src/types/rental.ts
interface TenantData { fullName, email, phone, birthDate, cpf, nationality, maritalStatus, profession, isPoliticallyExposed, monthlyIncome }
type DocumentStatus = 'empty' | 'uploading' | 'uploaded' | 'error';
interface DocumentUploadState { id, type, label, description, status, progress?, fileName?, fileUrl?, errorMessage? }
```

---

## 19. Migrações

Lista de migrações aplicadas (em ordem cronológica):

| Data | ID | Arquivo |
|------|----|---------|
| 2026-01-28 | 80ea27e5 | `20260128005616_80ea27e5-cc5c-4ffa-99ae-2dace78d48f4.sql` |
| 2026-01-28 | 60b0804d | `20260128160745_60b0804d-ff14-4cfc-8511-8e08f481ac68.sql` |
| 2026-01-29 | 4c4f7d34 | `20260129235919_4c4f7d34-a1b7-4b75-a35c-3aed1fe599e1.sql` |
| 2026-01-30 | 4654f4f9 | `20260130003554_4654f4f9-023a-4120-8d5b-225c30f745c5.sql` |
| 2026-01-30 | 26d2b4eb | `20260130004749_26d2b4eb-3719-4f47-985b-e49120115831.sql` |
| 2026-01-31 | 185bbb28 | `20260131232034_185bbb28-e591-4726-9efb-c62c2fb3eede.sql` |
| 2026-02-02 | 913c87e3 | `20260202212822_913c87e3-8c02-4758-9d6d-5ff0dc886116.sql` |
| 2026-02-03 | e92484ae | `20260203021022_e92484ae-e4da-4c1a-a9e2-018ed59569fb.sql` |
| 2026-02-05 | 6cdc4a6c | `20260205011202_6cdc4a6c-b29e-47e8-9f28-80106604afd5.sql` |
| 2026-02-24 | 903e441e | `20260224150609_903e441e-a59e-4a6a-b7f7-5e6d8090cfcc.sql` |
| 2026-02-24 | 67b82e40 | `20260224154942_67b82e40-85d2-469b-8e69-e366b938efd1.sql` |
| 2026-02-25 | a717d0aa | `20260225195154_a717d0aa-cd1d-4de0-91e7-594a4f44a2d7.sql` |
| 2026-02-25 | a85b40bd | `20260225203907_a85b40bd-fd9a-4db3-b87b-10664b86ea06.sql` |
| 2026-02-25 | 4f2324d7 | `20260225231617_4f2324d7-4dfe-49e7-8115-a75c3f544271.sql` |
| 2026-02-25 | 8bb6dc5b | `20260225233405_8bb6dc5b-28d8-4994-ad60-650f86793a09.sql` |
| 2026-02-25 | 8a8eddc6 | `20260225235201_8a8eddc6-fbcf-410c-b92b-b41865fa0923.sql` |
| 2026-02-25 | d8606e70 | `20260225235647_d8606e70-e0d5-4214-bcee-cd7116abe4f8.sql` |
| 2026-02-26 | d2a8bb21 | `20260226001747_d2a8bb21-e871-4969-8694-dc832769d29d.sql` |
| 2026-02-26 | 7642a5b5 | `20260226002759_7642a5b5-5755-4728-b9c5-9e51ebcdc1cb.sql` |
| 2026-02-26 | 5bfbb30b | `20260226010019_5bfbb30b-823e-4adb-b8c7-9297e7256b7f.sql` |
| 2026-02-26 | ea2d80ac | `20260226014805_ea2d80ac-5678-4874-bb3f-ed70c92cd79d.sql` |
| 2026-02-26 | 97580ba3 | `20260226015631_97580ba3-9d8b-467e-96fd-64c5b9319efa.sql` |
| 2026-02-26 | b0c4402a | `20260226020805_b0c4402a-7a8e-4d26-994a-38d19d14bf08.sql` |
| 2026-03-03 | 579d50ee | `20260303212101_579d50ee-b561-4e8f-8e5e-4765a955d0da.sql` |

---

## 20. Design System

### 20.1 Paleta de Cores (CSS Variables — HSL)

#### Light Mode (`:root`)

| Token | Valor HSL | Uso |
|-------|-----------|-----|
| `--background` | `210 40% 98%` | Fundo geral |
| `--foreground` | `222 47% 11%` | Texto principal |
| `--card` | `0 0% 100%` | Fundo de cards |
| `--card-foreground` | `222 47% 11%` | Texto de cards |
| `--popover` | `0 0% 100%` | Fundo de popovers |
| `--popover-foreground` | `222 47% 11%` | Texto de popovers |
| `--primary` | `188 85% 35%` | Teal — cor principal (botões, links, ring) |
| `--primary-foreground` | `210 40% 98%` | Texto sobre primary |
| `--secondary` | `222 25% 92%` | Navy claro — fundo secundário |
| `--secondary-foreground` | `222 47% 11%` | Texto sobre secondary |
| `--muted` | `210 30% 94%` | Fundo muted |
| `--muted-foreground` | `215 16% 47%` | Texto muted |
| `--accent` | `190 55% 96%` | Fundo de destaque sutil |
| `--accent-foreground` | `188 85% 25%` | Texto sobre accent |
| `--destructive` | `0 72% 50%` | Vermelho para erros/exclusão |
| `--destructive-foreground` | `0 85% 97%` | Texto sobre destructive |
| `--border` | `214 25% 86%` | Bordas |
| `--input` | `214 25% 86%` | Borda de inputs |
| `--ring` | `188 85% 35%` | Focus ring |
| `--radius` | `1.25rem` | Border radius padrão |

#### Dark Mode (`.dark`)

| Token | Valor HSL |
|-------|-----------|
| `--background` | `222 47% 9%` |
| `--foreground` | `210 40% 98%` |
| `--card` | `222 47% 12%` |
| `--primary` | `188 90% 45%` |
| `--primary-foreground` | `222 47% 10%` |
| `--secondary` | `222 35% 18%` |
| `--muted` | `222 35% 16%` |
| `--muted-foreground` | `215 20% 70%` |
| `--accent` | `222 35% 16%` |
| `--accent-foreground` | `188 90% 45%` |
| `--destructive` | `0 84% 60%` |
| `--border` | `222 35% 18%` |
| `--ring` | `188 90% 45%` |

#### Cores Customizadas (Semânticas)

| Grupo | Token | Valor HSL | Uso |
|-------|-------|-----------|-----|
| **Step** | `--step-complete` | `160 60% 42%` | Etapa concluída (emerald) |
| | `--step-active` | `188 85% 35%` | Etapa atual (teal) |
| | `--step-pending` | `210 30% 92%` | Etapa pendente |
| **Gamification** | `--gamification-badge` | `45 95% 55%` | Badge dourado |
| | `--gamification-badge-foreground` | `30 60% 20%` | Texto do badge |
| | `--gamification-progress` | `188 85% 35%` | Barra de progresso |
| **SLA** | `--sla-ok` | `160 60% 42%` | Dentro do prazo |
| | `--sla-warning` | `45 95% 50%` | Próximo do limite |
| | `--sla-breach` | `0 72% 50%` | Prazo estourado |
| **Chart** | `--chart-1` a `--chart-5` | Teal → Navy → Blue → Emerald | Gráficos Recharts |
| **Sidebar** | `--sidebar-background` | `222 47% 10%` | Menu lateral admin |
| | `--sidebar-primary` | `188 85% 35%` | Item ativo |
| | `--sidebar-accent` | `222 35% 16%` | Item hover |

### 20.2 Gradientes

```css
--gradient-hero: linear-gradient(135deg, hsl(222 47% 16%) 0%, hsl(188 85% 35%) 100%);
--gradient-gold: linear-gradient(135deg, hsl(188 85% 35%) 0%, hsl(190 70% 55%) 100%);
--gradient-subtle: linear-gradient(180deg, hsl(210 40% 98%) 0%, hsl(210 30% 96%) 100%);
```

Classes utilitárias:
- `.bg-gradient-hero` — fundo hero sections
- `.text-gradient-gold` — texto com gradiente (clip)
- `.bg-gradient-subtle` — fundo sutil vertical

### 20.3 Sombras

```css
--shadow-soft: 0 6px 24px -10px hsl(222 47% 11% / 0.12);
--shadow-card: 0 10px 30px -14px hsl(222 47% 11% / 0.16);
--shadow-elevated: 0 18px 56px -18px hsl(222 47% 11% / 0.22);
```

Classes: `.shadow-soft`, `.shadow-card`, `.shadow-elevated`

Sombras do sistema (Tailwind override via `boxShadow`):
- `shadow-2xs`, `shadow-xs`, `shadow-sm`, `shadow-md`, `shadow-lg`, `shadow-xl`, `shadow-2xl`

### 20.4 Border Radius

```css
--radius: 1.25rem;
```

Tailwind mappings:
- `rounded-lg` → `var(--radius)` = `1.25rem`
- `rounded-md` → `calc(var(--radius) - 2px)` = ~`1.125rem`
- `rounded-sm` → `calc(var(--radius) - 4px)` = ~`1rem`

### 20.5 Tipografia

| Stack | Fonte | Uso |
|-------|-------|-----|
| **Body** | `Plus Jakarta Sans` (300–800) | `body { font-family }` — texto principal |
| **Sans** | `Lato` (400, 700) | `font-sans` — heading alternativo |
| **Serif** | `EB Garamond` (400–700) | `font-serif` — textos editoriais |
| **Mono** | `Fira Code` (400, 700) | `font-mono` — códigos, protocolos |

Todas carregadas via Google Fonts com `display=swap` para CLS < 0.1.

### 20.6 Tailwind Config — Cores Mapeadas

Todas as cores são consumidas via `hsl(var(--token))` no `tailwind.config.ts`:

```typescript
colors: {
  primary: { DEFAULT: 'hsl(var(--primary))', foreground: 'hsl(var(--primary-foreground))' },
  secondary: { DEFAULT: 'hsl(var(--secondary))', foreground: 'hsl(var(--secondary-foreground))' },
  destructive: { DEFAULT: 'hsl(var(--destructive))', foreground: 'hsl(var(--destructive-foreground))' },
  muted: { DEFAULT: 'hsl(var(--muted))', foreground: 'hsl(var(--muted-foreground))' },
  accent: { DEFAULT: 'hsl(var(--accent))', foreground: 'hsl(var(--accent-foreground))' },
  step: { complete: '...', active: '...', pending: '...' },
  gamification: { badge: '...', 'badge-foreground': '...', progress: '...' },
  sla: { ok: '...', warning: '...', breach: '...' },
  chart: { c1: '...', c2: '...', c3: '...', c4: '...', c5: '...' },
  sidebar: { DEFAULT, foreground, primary, 'primary-foreground', accent, 'accent-foreground', border, ring },
}
```

**Regra**: Nunca usar cores hardcoded nos componentes. Sempre usar tokens semânticos (`bg-primary`, `text-muted-foreground`, `border-destructive`, etc.).

---

## 21. Componentes UI (shadcn/ui + Radix)

### 21.1 Button — Variantes e Tamanhos

```typescript
// src/components/ui/button.tsx
const buttonVariants = cva("inline-flex items-center justify-center ...", {
  variants: {
    variant: {
      default: "bg-primary text-primary-foreground hover:bg-primary/90",
      destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
      outline: "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
      secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
      ghost: "hover:bg-accent hover:text-accent-foreground",
      link: "text-primary underline-offset-4 hover:underline",
    },
    size: {
      default: "h-10 px-4 py-2",
      sm: "h-9 rounded-md px-3",
      lg: "h-11 rounded-md px-8",
      icon: "h-10 w-10",
    },
  },
  defaultVariants: { variant: "default", size: "default" },
});
```

### 21.2 StickySubmitButton

Componente reutilizável para CTAs fixos no rodapé mobile:

```typescript
// src/components/rental/StickySubmitButton.tsx
interface StickySubmitButtonProps {
  label: string;
  sublabel?: string;
  disabled?: boolean;
  isLoading?: boolean;
  onClick: () => void;
}
```

Posicionamento: `fixed bottom-0 left-0 right-0` com `paddingBottom: max(1rem, env(safe-area-inset-bottom))`.

### 21.3 Componentes Radix Instalados

| Componente | Pacote |
|------------|--------|
| Accordion | `@radix-ui/react-accordion` |
| Alert Dialog | `@radix-ui/react-alert-dialog` |
| Aspect Ratio | `@radix-ui/react-aspect-ratio` |
| Avatar | `@radix-ui/react-avatar` |
| Checkbox | `@radix-ui/react-checkbox` |
| Collapsible | `@radix-ui/react-collapsible` |
| Context Menu | `@radix-ui/react-context-menu` |
| Dialog | `@radix-ui/react-dialog` |
| Dropdown Menu | `@radix-ui/react-dropdown-menu` |
| Hover Card | `@radix-ui/react-hover-card` |
| Label | `@radix-ui/react-label` |
| Menubar | `@radix-ui/react-menubar` |
| Navigation Menu | `@radix-ui/react-navigation-menu` |
| Popover | `@radix-ui/react-popover` |
| Progress | `@radix-ui/react-progress` |
| Radio Group | `@radix-ui/react-radio-group` |
| Scroll Area | `@radix-ui/react-scroll-area` |
| Select | `@radix-ui/react-select` |
| Separator | `@radix-ui/react-separator` |
| Slider | `@radix-ui/react-slider` |
| Slot | `@radix-ui/react-slot` |
| Switch | `@radix-ui/react-switch` |
| Tabs | `@radix-ui/react-tabs` |
| Toast | `@radix-ui/react-toast` |
| Toggle | `@radix-ui/react-toggle` |
| Toggle Group | `@radix-ui/react-toggle-group` |
| Tooltip | `@radix-ui/react-tooltip` |

### 21.4 Outros Componentes UI

| Componente | Arquivo | Uso |
|------------|---------|-----|
| Card | `ui/card.tsx` | Container padrão |
| Badge | `ui/badge.tsx` | Labels de status |
| Calendar | `ui/calendar.tsx` | Seleção de data (react-day-picker) |
| Command | `ui/command.tsx` | Busca/comando (cmdk) |
| Date Input | `ui/date-input.tsx` | Input de data formatado |
| Drawer | `ui/drawer.tsx` | Gaveta mobile (vaul) |
| Form | `ui/form.tsx` | Integração react-hook-form |
| Input OTP | `ui/input-otp.tsx` | Campos de código |
| Optimized Image | `ui/optimized-image.tsx` | Lazy loading de imagens |
| Range Slider | `ui/range-slider.tsx` | Slider duplo |
| Sheet | `ui/sheet.tsx` | Painel lateral |
| Skeleton | `ui/skeleton.tsx` | Loading state |
| Sonner | `ui/sonner.tsx` | Toasts modernos |
| Table | `ui/table.tsx` | Tabelas |
| Textarea | `ui/textarea.tsx` | Campo multi-linha |

### 21.5 Padrões de Uso

- **Card + CardHeader + CardContent**: container padrão para seções
- **Dialog / AlertDialog**: confirmações e modais (com `DialogTrigger` + `DialogContent`)
- **Sheet**: menus laterais em mobile
- **Tabs**: navegação entre visualizações (ex: dashboard admin)
- **Accordion**: FAQs, detalhes expansíveis
- **Toast + Sonner**: feedback de ações (success/error)
- **Form + zodResolver**: validação de formulários
- **Carousel (embla-carousel-react)**: galeria de imagens do imóvel

---

## 22. Animações e Microinterações

### 22.1 Keyframes (tailwind.config.ts)

| Keyframe | Duração | Uso |
|----------|---------|-----|
| `accordion-down` | `0.2s ease-out` | Abertura de accordion |
| `accordion-up` | `0.2s ease-out` | Fechamento de accordion |
| `fade-in-up` | `0.5s ease-out forwards` | Entrada de elementos na tela |
| `scale-in` | `0.3s ease-out forwards` | Entrada com escala |

### 22.2 Keyframes (index.css)

| Keyframe | Duração | Uso |
|----------|---------|-----|
| `float` | `6s ease-in-out infinite` | Elementos flutuantes (hero) |
| `pulse-border` | `2s ease-in-out` (3x) | Dica de foco no primeiro input |
| `shake` | `0.5s ease-in-out` | Erro de validação |
| `check-pop` | `0.4s ease-out` | Sucesso de upload |
| `slide-in-left` | `0.3s ease-out` | Transição wizard → próximo |
| `slide-in-right` | `0.3s ease-out` | Transição wizard ← anterior |
| `step-check-in` | `0.4s ease-out` | Check de etapa completa |

### 22.3 Classes Utilitárias de Animação

| Classe | Animação |
|--------|----------|
| `.animate-float` | Flutuação suave vertical |
| `.animate-pulse-slow` | Pulse 3s |
| `.animate-shake` | Tremida horizontal (erro) |
| `.animate-check-pop` | Pop de confirmação |
| `.animate-slide-in-left` | Slide da direita |
| `.animate-slide-in-right` | Slide da esquerda |
| `.animate-step-check` | Scale-in de check |
| `.animate-pulse-border` | Ring pulsante (3 ciclos) |
| `.animate-fade-in-up` | Fade + translate Y |
| `.animate-scale-in` | Scale de 0.95 → 1 |
| `.animate-accordion-down` | Accordion abrir |
| `.animate-accordion-up` | Accordion fechar |

### 22.4 Utilitários CSS Customizados

```css
/* Aspect ratios para prevenção de CLS */
.aspect-property-card { aspect-ratio: 4 / 3; }
.aspect-property-hero { aspect-ratio: 16 / 9; }

/* Safe area para dispositivos com notch */
.pb-safe { padding-bottom: env(safe-area-inset-bottom); }
.pt-safe { padding-top: env(safe-area-inset-top); }
```

---

## 23. Padrões de Layout Mobile

### 23.1 CTA Fixo no Rodapé

```tsx
<div className="fixed bottom-0 left-0 right-0 p-4 bg-background/95 backdrop-blur-sm border-t border-border z-50"
     style={{ paddingBottom: 'max(1rem, env(safe-area-inset-bottom))' }}>
  <Button size="lg" className="w-full h-14 text-base font-semibold">
    Continuar
  </Button>
</div>
```

**Regra**: Todo conteúdo acima do CTA fixo deve ter `pb-28` ou `pb-32` para não ser coberto.

### 23.2 FAB WhatsApp

Posicionamento: `fixed bottom-[88px] right-4 z-40` (acima do CTA fixo).

### 23.3 Wizard Multi-Etapa

Padrão de navegação:
- Header fixo com `ProgressBar` mostrando `currentStep / totalSteps`
- Conteúdo scrollável com `overflow-y-auto`
- Footer fixo com botões "Voltar" e "Continuar"/"Enviar"
- Transições entre etapas: `animate-slide-in-left` (avançar) e `animate-slide-in-right` (voltar)

### 23.4 Grid Responsivo de Valores

```tsx
<div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
  <div className="text-center">
    <span className="text-xs text-muted-foreground">Aluguel</span>
    <p className="font-semibold tabular-nums whitespace-nowrap">R$ 2.500</p>
  </div>
  {/* Condomínio, IPTU... */}
</div>
```

### 23.5 Container Padrão

```typescript
// tailwind.config.ts
container: {
  center: true,
  padding: '1.5rem',
  screens: { '2xl': '1280px' }
}
```

Uso: `<div className="container max-w-lg mx-auto">` para páginas de formulário.

### 23.6 Scroll Indicator (Conteúdo Abaixo da Dobra)

Padrão usado em wizards longos:
- Gradiente inferior: `bg-gradient-to-t from-background via-background/80 to-transparent h-20`
- Seta animada com bounce: `animate-bounce`
- Escondido após scroll via `IntersectionObserver` ou `scrollTop`

### 23.7 Accordion de Pendências

- Máximo de 3 itens visíveis
- Itens adicionais via `<Collapsible>` com trigger "Ver todas (X)"
- Cada item com ícone de status (check/warning/clock)

### 23.8 Stepper Horizontal

```tsx
// src/components/tracking/GamifiedStepper.tsx
<GamifiedStepper
  currentStep={rental.current_step}
  hasPendingDocs={rental.has_pending}
  isRejected={rental.is_rejected}
  docsSubmittedEarly={rental.docs_submitted_early}
/>
```

- Scrollável horizontalmente em mobile
- Ícones com cores: `step-complete` (emerald), `step-active` (teal), `step-pending` (cinza)
- Barra de progresso linear acima

---

## 24. Arquitetura de Componentes

### 24.1 Árvore de Pastas

```
src/components/
├── admin/          # Kanban, modais de rental/property, analytics, KPIs
├── auth/           # ProtectedRoute, AdminRoute, LocadorRoute, ForgotPassword, ReAuth
├── documents/      # TenantDocumentsUploader
├── landing/        # Hero, Benefits, FAQ, Footer, Header, HowItWorks, Security, CTASection, Testimonials
├── layout/         # AppHeader, PageSkeleton
├── locador/        # LocadorLayout + dashboard widgets
│   └── dashboard/  # ConversionFunnel, FinancialKPICards, NotificationBell, PropertyExpandableCard, etc.
├── notifications/  # NotificationToggle
├── property/       # PropertyFilters, PropertyImageCarousel
├── rental/         # DocumentUpload, GamificationProgress, PersonalDataForm, IncomeDataForm, ProgressBar, PropertyCard, RentalTimeline, SecondTenantCard/Section, StickySubmitButton
├── tenant/         # Dashboard widgets
│   └── dashboard/  # JourneyCard, MatchmakerQuiz, ProposalCards, SmartCTA, UpdatesFeed, etc.
├── tracking/       # GamifiedStepper
└── ui/             # ~50 componentes shadcn/ui (accordion, button, card, dialog, form, input, select, sheet, tabs, toast, etc.)
```

### 24.2 Code Splitting

| Tipo | Estratégia | Exemplos |
|------|-----------|----------|
| **Eager** | Import direto | `Landing`, `Login`, `Register`, `NotFound` |
| **Lazy** | `React.lazy()` + `<Suspense>` | Todas as demais páginas |
| **Fallback** | `<PageSkeleton variant="form\|list\|default">` | Skeleton contextual por tipo de página |

```typescript
// Eager (critical path)
import LocatarioLanding from "./pages/locatario/Landing";
import LocatarioLogin from "./pages/locatario/Login";

// Lazy (code splitting)
const SelecionarImovel = lazy(() => import("./pages/SelecionarImovel"));
const Admin = lazy(() => import("./pages/Admin"));
```

### 24.3 Hierarquia de Providers

```
QueryClientProvider (react-query)
└── AuthProvider (Supabase auth + role)
    └── TooltipProvider (Radix)
        └── Toaster + Sonner (notificações)
            └── BrowserRouter (react-router-dom)
                └── Routes
```

### 24.4 Guards de Rota

| Guard | Arquivo | Função |
|-------|---------|--------|
| `ProtectedRoute` | `auth/ProtectedRoute.tsx` | Redireciona para `/locatario/login` se não autenticado |
| `AdminRoute` | `auth/AdminRoute.tsx` | Verifica role `admin` via `has_role()` |
| `LocadorRoute` | `auth/LocadorRoute.tsx` | Verifica role `locador` via `has_role()` |
| `SmartRedirect` | `auth/SmartRedirect.tsx` | Redireciona baseado no role do user |

### 24.5 Bibliotecas Externas

| Biblioteca | Versão | Uso |
|------------|--------|-----|
| `@tanstack/react-query` | ^5.83.0 | Cache e fetching de dados |
| `react-router-dom` | ^6.30.1 | Roteamento SPA |
| `@supabase/supabase-js` | ^2.93.1 | Cliente Supabase |
| `react-hook-form` | ^7.61.1 | Formulários |
| `zod` | ^3.25.76 | Validação de schemas |
| `@hookform/resolvers` | ^3.10.0 | Integração zod + react-hook-form |
| `recharts` | ^2.15.4 | Gráficos e analytics |
| `@hello-pangea/dnd` | ^18.0.1 | Drag-and-drop (Kanban) |
| `embla-carousel-react` | ^8.6.0 | Carousel de imagens |
| `date-fns` | ^3.6.0 | Formatação de datas |
| `lucide-react` | ^0.462.0 | Ícones |
| `sonner` | ^1.7.4 | Toast moderno |
| `vaul` | ^0.9.9 | Drawer mobile |
| `cmdk` | ^1.1.1 | Command palette |
| `input-otp` | ^1.4.2 | Input de código OTP |
| `next-themes` | ^0.3.0 | Dark mode toggle |
| `tailwindcss-animate` | ^1.0.7 | Plugin de animações |

---

## 25. Utilitários JavaScript (`src/lib/`)

Módulos puros (sem dependência React) usados em todo o app.

### 25.1 masks.ts — Formatação e Validação Brasileira

| Função | Entrada | Saída | Descrição |
|--------|---------|-------|-----------|
| `maskCPF(value)` | `"12345678901"` | `"123.456.789-01"` | Aplica máscara CPF |
| `unmaskCPF(value)` | `"123.456.789-01"` | `"12345678901"` | Remove pontos e traço |
| `maskPhone(value)` | `"11999887766"` | `"(11) 99988-7766"` | Máscara telefone BR |
| `unmaskPhone(value)` | `"(11) 99988-7766"` | `"11999887766"` | Remove formatação |
| `maskCEP(value)` | `"01310100"` | `"01310-100"` | Máscara CEP |
| `unmaskCEP(value)` | `"01310-100"` | `"01310100"` | Remove traço |
| `maskCurrency(value)` | `1500.50` | `"R$ 1.500,50"` | Formata BRL via `Intl.NumberFormat('pt-BR')` |
| `unmaskCurrency(value)` | `"R$ 1.500,50"` | `1500.50` | Parse string → number |
| `maskCurrencyInput(value)` | `"150050"` | `"R$ 1.500,50"` | Mesmo que `maskCurrency`, retorna `""` se vazio |
| `formatDate(date)` | `Date` ou string ISO | `"28/01/2026"` | Formato DD/MM/YYYY |
| `formatDateForInput(date)` | `Date` ou string ISO | `"2026-01-28"` | Formato YYYY-MM-DD para `<input type="date">` |

#### Validações

| Função | Regra |
|--------|-------|
| `isValidCPF(cpf)` | 11 dígitos + algoritmo de dígitos verificadores (módulo 11). Rejeita sequências repetidas (`111...`, `222...`). |
| `isValidPhone(phone)` | 10 ou 11 dígitos numéricos (fixo ou celular) |
| `isValidCEP(cep)` | Exatamente 8 dígitos numéricos |

### 25.2 crypto.ts — Criptografia Client-Side

Nenhum segredo armazenado neste arquivo. Usa Web Crypto API nativa do browser.

| Função | Descrição |
|--------|-----------|
| `base64UrlEncode(bytes: Uint8Array): string` | Codifica bytes em base64url sem padding (RFC 4648) |
| `sha256Hex(input: string): Promise<string>` | Gera hash SHA-256 hexadecimal via `crypto.subtle.digest` |
| `generateInviteToken(byteLength = 32): string` | Gera token aleatório de 32 bytes via `crypto.getRandomValues` + base64url |

**Uso principal:** Geração de tokens para `property_invites` e hashing de identificadores no rate limiter.

### 25.3 rateLimiter.ts — Rate Limiting Client-Side

```typescript
interface RateLimitResult {
  allowed: boolean;
  blocked: boolean;
  remaining_seconds: number;
  attempts: number;
}
```

| Função | Descrição |
|--------|-----------|
| `checkRateLimit(identifier, action)` | Chama edge function `check-rate-limit`. **Fail-open**: se a rede falhar, retorna `{ allowed: true }` para não bloquear usuários legítimos. |
| `formatBlockTime(seconds)` | Converte segundos em texto pt-BR: `"45 segundos"`, `"3 minutos"` |

**Escalas de bloqueio progressivo:**

| Tentativas | Bloqueio |
|------------|----------|
| 5+ | 1 minuto |
| 10+ | 5 minutos |
| 20+ | 15 minutos |
| 30+ | 60 minutos |

### 25.4 logger.ts — Logger Environment-Aware

```typescript
export const logger = {
  error: (message, ...args) => { if (import.meta.env.DEV) console.error(...) },
  warn:  (message, ...args) => { if (import.meta.env.DEV) console.warn(...) },
  info:  (message, ...args) => { if (import.meta.env.DEV) console.info(...) },
  log:   (message, ...args) => { if (import.meta.env.DEV) console.log(...) },
};
```

**Regra:** Todo `console.log/warn/error` no código deve usar `logger.*` para evitar vazamento de informações em produção.

### 25.5 fileValidation.ts — Validação de Uploads

**Tipos MIME permitidos:**
- `application/pdf`
- `image/jpeg`, `image/png`, `image/gif`, `image/webp`

**Limite de tamanho:** 10 MB (`10 * 1024 * 1024` bytes)

| Função | Tipo | Descrição |
|--------|------|-----------|
| `validateFileUpload(file)` | Client + Server | Valida tipo, tamanho e chama edge function `validate-upload` para verificação de magic bytes. Se o servidor falhar, aceita validação client-side (fallback seguro). |
| `quickValidateFile(file)` | Client-only | Validação rápida para feedback imediato na UI. Deve sempre ser seguida por `validateFileUpload` antes do upload real. |

**Magic bytes verificados no servidor (`validate-upload`):**

| Formato | Bytes iniciais |
|---------|---------------|
| PDF | `%PDF` (25 50 44 46) |
| JPEG | `FF D8 FF` |
| PNG | `89 50 4E 47` |
| GIF | `47 49 46 38` |
| WebP | `52 49 46 46` (RIFF) |

### 25.6 scrollToFirstError.ts

```typescript
export function scrollToFirstError(container: HTMLElement | null): void
```

Busca o primeiro elemento com classe `border-destructive` ou `text-destructive`, faz scroll suave até ele (`block: 'center'`), e após 300ms dá foco no primeiro `input/select/textarea` encontrado. Delay inicial de 50ms para aguardar renderização do DOM.

### 25.7 passwordPolicy.ts — Política de Senhas

| Regra | Valor |
|-------|-------|
| Comprimento mínimo | 14 caracteres |
| Classes de caracteres mínimas | 3 de 4 (maiúscula, minúscula, dígito, especial) |
| Blacklist | Top 50 senhas comuns (case-insensitive) |
| Schema Zod | `strongPasswordSchema` |

**Score de força (UI):**

| Score | Label | Condição |
|-------|-------|----------|
| 0 | Muito fraca | < 8 chars |
| 1 | Fraca | ≥ 8 chars |
| 2 | Razoável | ≥ 14 chars |
| 3 | Forte | ≥ 14 chars + 3 classes |
| 4 | Muito forte | ≥ 20 chars + 4 classes |

### 25.8 buildCrmReadyPayload.ts — Payload CRM

```typescript
export interface CrmReadyPayload {
  rental: { id, protocol, property_code, property_address, current_step, rent_value, condo_fee, iptu, is_rejected, step_status, tenant_status, created_at, updated_at };
  tenant?: { id, full_name, email, phone, cpf_encrypted, birth_date, profession, marital_status, nationality, monthly_income, is_politically_exposed };
  landlord?: { full_name, email, phone, profession, marital_status, bank_name, bank_agency, bank_account, pix_key, has_second_landlord, second_landlord_* };
  documents: { tenant: [{ id, document_type, file_name, status, bucket }], landlord: [...] };
  recent_events: [{ id, event_type, description, created_at }]; // últimos 10
  links: { admin_detail: string, tenant_tracking: string };
}
```

**Uso futuro:** Será consumido por fluxos n8n para sincronizar com CRM externo.

### 25.9 proposalEvents.ts — Eventos de Proposta

Funções para inserir eventos na tabela `rental_events` com tipo de proposta:
- `logProposalEvent(rentalId, eventType, description, metadata)`
- Tipos: `proposal_sent`, `proposal_accepted`, `proposal_rejected`, `counter_proposal_sent`

### 25.10 notifications.ts — Catálogo de Notificações

Detalhado na Seção 27.

---

## 26. Hooks Customizados (`src/hooks/`)

### 26.1 useSessionTimeout

**Finalidade:** Logout automático após inatividade.

| Parâmetro | Valor |
|-----------|-------|
| Timeout | 30 minutos (`30 * 60 * 1000` ms) |
| Eventos monitorados | `mousedown`, `keydown`, `scroll`, `touchstart`, `mousemove` |
| Listener options | `{ passive: true }` |
| Ação no timeout | `logout()` + toast "Sessão expirada" + navigate `/login` |

**Fluxo:** Cada evento de interação reinicia o timer. Se nenhum evento ocorrer em 30 min, dispara `handleTimeout`. Só ativo quando `user !== null`.

### 26.2 useVistaSoftSync

**Finalidade:** Sincronizar dados do locador com VistaSoft via webhook n8n.

| Parâmetro | Valor |
|-----------|-------|
| Intervalo de sync | 12 horas |
| Webhook URL | `N8N_VALIDATE_LANDLORD_WEBHOOK` (secret) |
| Método | POST com `{ userId, phoneE164 }` |
| Campos atualizados no profile | `last_vista_sync_at`, `last_vista_sync_status`, `last_vista_sync_error` |
| Trava de duplicação | `useRef` para prevenir chamadas simultâneas |

**Condições para sync:**
1. Usuário autenticado com role `locador`
2. Última sync há mais de 12h (ou nunca feita)
3. Telefone E.164 disponível no profile

### 26.3 useNotificationPermission

**Finalidade:** Gerenciar permissão de Web Notifications.

```typescript
interface Return {
  supported: boolean;       // Browser suporta Notifications API
  enabled: boolean;         // Permissão concedida + não desabilitada pelo usuário
  permission: NotificationPermission | 'unsupported';
  requestPermission: () => Promise<boolean>;
  disable: () => void;      // Salva em localStorage
}
```

### 26.4 useDebounce / useDebouncedCallback

**Duas variantes:**

| Hook | Uso | Default delay |
|------|-----|--------------|
| `useDebounce<T>(value, delay)` | Debounce de valor reativo | 150ms |
| `useDebouncedCallback(callback, delay)` | Debounce de função (event handlers) | 150ms |

**Target:** INP < 150ms (Core Web Vitals).

### 26.5 useCpfEncryption

**Finalidade:** Criptografar CPF via edge function `encrypt-cpf`.

Chama `supabase.functions.invoke('encrypt-cpf', { body: { action: 'encrypt', cpf } })` e retorna o valor AES-256-GCM criptografado em base64. Requer JWT válido.

### 26.6 useDocumentUpload

**Finalidade:** Lógica completa de upload de documentos.

```typescript
interface Return {
  uploading: boolean;
  uploadDocument: (docId, file, documentType, setDocs, rentalId?, documentLabel?) => Promise<string | null>;
  removeDocument: (docId, fileUrl, setDocs) => Promise<void>;
  retryDocument: (docId, setDocs) => void;
}
```

**Fluxo de upload:**
1. Verifica autenticação
2. Checa limite por tipo (`DOCUMENT_LIMITS[documentType]`) consultando `documents` table
3. Valida arquivo via `validateFileUpload(file)` (client + server)
4. Sanitiza filename (remove caracteres especiais)
5. Upload para `supabase.storage.from('documents')`
6. Insere registro na tabela `documents`
7. Atualiza estado de progresso na UI

### 26.7 useProperties

**Finalidade:** Fetch de imóveis disponíveis via edge function `fetch-properties`.

Chama a edge function que consulta a API VistaSoft e cacheia resultados em `properties_cache` (TTL 10 minutos). Retorna lista tipada de imóveis com endereço, fotos, valores.

### 26.8 useRentalTracking

**Finalidade:** Carregamento + subscription realtime de uma locação e seus eventos.

```typescript
interface Return {
  rental: RentalTracking | null;
  events: RentalEvent[];
  loading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
}
```

**Realtime channels:**
- `rental_events` INSERT → push notification + refetch
- `rentals` UPDATE (filtro por `id`) → refetch

**Enriquecimento:** Após carregar o rental, busca imagens e valores do imóvel via `fetch-properties` e conta propostas ativas.

### 26.9 useAdminRentals

Carrega todos os rentals via `rental_full_view` para o Kanban admin. Agrupa por `admin_stage_id`. Inclui contadores de documentos, dados do locador/locatário, e calcula SLA.

### 26.10 useAdminPipelineStages

CRUD de stages do pipeline admin (`admin_pipeline_stages`). Operações: listar, criar, reordenar, ativar/desativar.

### 26.11 useLandlordDashboard

Carrega dados do dashboard do locador: imóveis próprios (`properties`), locações associadas (`rentals` via `landlord_property_id`), propostas pendentes, e progresso de cada locação.

### 26.12 useTenantDashboard

Carrega dados do dashboard do locatário: locações do usuário (`rentals` por `user_id`), eventos recentes, status de documentos, e propostas.

### 26.13 useAuditLog

```typescript
interface Return {
  logAction: (action: string, tableName: string, recordId?: string, data?: Record<string, unknown>) => Promise<void>;
}
```

Chama `supabase.rpc('log_audit', { p_action, p_table_name, p_record_id, p_new_data })`. Erros são logados via `logger.error` (silenciosos para o usuário).

### 26.14 useMobile

```typescript
export function useIsMobile(): boolean
```

Retorna `true` se `window.innerWidth < 768px`. Usa `matchMedia` com listener de `change` para reatividade.

---

## 27. Sistema de Notificações Browser (`src/lib/notifications.ts`)

### 27.1 Notificações por Etapa (Step)

| Step | Título | Corpo |
|------|--------|-------|
| 2 | "Documentos recebidos" | "Seus documentos foram recebidos e estão em análise." |
| 3 | "Análise cadastral" | "Sua ficha está sendo analisada pela equipe." |
| 4 | "Proposta ao proprietário" | "Uma proposta foi encaminhada ao proprietário." |
| 5 | "Proposta aceita!" | "O proprietário aceitou a proposta. Próximo: contrato." |
| 6 | "Contrato em elaboração" | "O contrato está sendo preparado." |
| 7 | "Contrato pronto!" | "Seu contrato está pronto para assinatura." |
| 8 | "Contrato assinado" | "Todas as partes assinaram o contrato." |
| 9 | "Vistoria agendada" | "A vistoria do imóvel foi agendada." |

### 27.2 Notificações por Evento

| Evento | Título | Corpo |
|--------|--------|-------|
| `proposal_accepted` | "Proposta aceita!" | "Sua proposta foi aceita pelo proprietário." |
| `proposal_rejected` | "Proposta recusada" | "O proprietário recusou a proposta." |
| `counter_proposal` | "Contraproposta" | "O proprietário enviou uma contraproposta." |
| `contract_signed` | "Contrato assinado" | "O contrato foi assinado com sucesso." |
| `inspection_scheduled` | "Vistoria agendada" | "A vistoria foi agendada." |
| `keys_delivered` | "Chaves entregues!" | "As chaves do imóvel foram entregues." |

### 27.3 Gerenciamento de Permissão

| Função | Descrição |
|--------|-----------|
| `isNotificationSupported()` | Verifica `'Notification' in window` |
| `getNotificationPermission()` | Retorna `Notification.permission` ou `'unsupported'` |
| `isNotificationEnabled()` | Permissão `'granted'` **E** `localStorage.notifications_enabled !== 'false'` |
| `requestNotificationPermission()` | Chama `Notification.requestPermission()`, salva em localStorage |
| `disableNotifications()` | Seta `localStorage.notifications_enabled = 'false'` |

### 27.4 Deduplicação

Cada notificação usa `tag` para evitar duplicatas:
- Steps: `tag: 'step-${newStep}'`
- Eventos: `tag: 'event-${eventType}'`

---

## 28. Integração CRM / n8n

### 28.1 Campos CRM na Tabela `rentals`

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `crm_provider` | `text` | Identificador do CRM (ex: `"pipedrive"`, `"hubspot"`) |
| `crm_deal_id` | `text` | ID do deal/negócio no CRM externo |
| `crm_last_sync_at` | `timestamptz` | Última sincronização com CRM |

### 28.2 Webhook VistaSoft (n8n)

| Parâmetro | Valor |
|-----------|-------|
| Secret | `N8N_VALIDATE_LANDLORD_WEBHOOK` |
| Método | POST |
| Body | `{ userId, phoneE164 }` |
| Resposta esperada | Dados do locador (código, imóveis, nome) |
| Campos salvos no profile | `codigo_locador`, `nome_locador`, `property_codes`, `total_imoveis`, `has_suspended_properties`, `vista_codigo`, `last_vista_sync_at`, `last_vista_sync_status` |

### 28.3 Payload CRM (`buildCrmReadyPayload`)

Função utilitária que consolida todos os dados de uma locação em JSON estável para consumo por automações:

- **rental**: Dados financeiros + status + protocolo
- **tenant**: Dados pessoais do locatário (CPF criptografado)
- **landlord**: Dados bancários + contato do locador
- **documents**: Referências de arquivos com `bucket: 'documents'` (sem URLs temporárias)
- **recent_events**: Últimos 10 eventos
- **links**: URLs do admin detail e tenant tracking

### 28.4 Edge Function `validate-landlord`

Chamada durante onboarding do locador. Envia telefone E.164 para o webhook n8n, que consulta VistaSoft e retorna dados do locador. A edge function salva os dados no profile e retorna sucesso/falha.

---

## 29. Segurança — Resumo Consolidado

### 29.1 Autenticação

| Controle | Implementação |
|----------|---------------|
| **Senha forte** | Mínimo 14 chars, 3/4 classes, blacklist top 50 (`strongPasswordSchema`) |
| **Rate limiting** | Progressivo: 5→1min, 10→5min, 20→15min, 30+→60min. Edge function + tabela `auth_rate_limits` |
| **Anti-enumeração** | Mensagem genérica em login e reset: "Se o email existir, enviamos..." |
| **Session timeout** | 30 min inatividade → logout automático |
| **ReAuth admin** | Dialog de reautenticação por senha antes de Admin Override |

### 29.2 Dados Sensíveis

| Dado | Proteção |
|------|----------|
| **CPF** | Criptografado com AES-256-GCM via edge function `encrypt-cpf`. Chave derivada com PBKDF2. Nunca armazenado em plaintext. |
| **Tokens de convite** | Hash SHA-256 armazenado; token original nunca persistido |
| **Logs** | `logger.*` só emite em `import.meta.env.DEV` |

### 29.3 Banco de Dados

| Controle | Detalhes |
|----------|----------|
| **RLS** | Habilitado em todas as tabelas. Políticas por role e ownership. |
| **Views** | `rental_full_view` com `security_invoker = true` (respeita RLS das tabelas base) |
| **SECURITY DEFINER** | `has_role()`, `log_audit()`, `format_brazilian_phone_e164()` com `SET search_path = public` |
| **Constraint CHECK** | `rentals.current_step` entre 1 e 10 |
| **service_role only** | `auth_rate_limits`, `notification_queue`, `security_events` |

### 29.4 Uploads

| Controle | Detalhes |
|----------|----------|
| **Tipo MIME** | Whitelist: PDF, JPEG, PNG, GIF, WebP |
| **Tamanho** | Máximo 10 MB |
| **Magic bytes** | Verificação server-side dos primeiros 16 bytes |
| **Limite por tipo** | `DOCUMENT_LIMITS` por `(rental_id, document_type, user_id)` |
| **Sanitização** | Filename sanitizado antes do upload |

### 29.5 Frontend

| Controle | Detalhes |
|----------|----------|
| **Open redirect** | Sanitização de parâmetros `redirect` / `next` |
| **Role checking** | Sempre via `has_role()` server-side (RPC), nunca localStorage |
| **Guards de rota** | `ProtectedRoute`, `AdminRoute`, `LocadorRoute` |

---

## 30. Estrutura de Pastas (`src/`)

```
src/
├── App.tsx                    # Rotas principais + lazy loading
├── App.css                    # Estilos globais mínimos
├── main.tsx                   # Entry point + providers
├── index.css                  # Design tokens CSS + Tailwind
├── vite-env.d.ts              # Tipos Vite
│
├── assets/                    # Arquivos estáticos
│   ├── logo-etic.jpg          # Logo principal
│   └── logo-etic-blue.png     # Logo variante azul
│
├── components/
│   ├── admin/                 # Kanban, KPIs, modais de gestão
│   │   ├── AdminKanbanBoard.tsx
│   │   ├── AdminKanbanCard.tsx
│   │   ├── AdminKanbanColumn.tsx
│   │   ├── AdminPropertyModal.tsx
│   │   ├── AdminRentalHistoryCard.tsx
│   │   ├── AdminRentalModal.tsx
│   │   ├── AdminStageConfig.ts
│   │   ├── AnalyticsDashboard.tsx
│   │   ├── KPICards.tsx
│   │   └── adminSla.ts
│   │
│   ├── auth/                  # Guards e componentes de autenticação
│   │   ├── AdminRoute.tsx
│   │   ├── ForgotPasswordDialog.tsx
│   │   ├── LocadorRoute.tsx
│   │   ├── PasswordStrengthIndicator.tsx
│   │   ├── ProtectedRoute.tsx
│   │   ├── ReAuthDialog.tsx
│   │   ├── ResetPasswordForm.tsx
│   │   └── SmartRedirect.tsx
│   │
│   ├── documents/             # Upload de documentos do locatário
│   │   └── TenantDocumentsUploader.tsx
│   │
│   ├── landing/               # Página pública (landing page)
│   │   ├── Benefits.tsx
│   │   ├── CTASection.tsx
│   │   ├── FAQ.tsx
│   │   ├── Footer.tsx
│   │   ├── Header.tsx
│   │   ├── Hero.tsx
│   │   ├── HowItWorks.tsx
│   │   ├── Security.tsx
│   │   └── Testimonials.tsx
│   │
│   ├── layout/                # Estrutura de layout
│   │   ├── AppHeader.tsx
│   │   └── PageSkeleton.tsx
│   │
│   ├── locador/               # Componentes do painel do locador
│   │   ├── LocadorLayout.tsx
│   │   └── dashboard/
│   │       ├── ConversionFunnel.tsx
│   │       ├── FinancialKPICards.tsx
│   │       ├── NotificationBell.tsx
│   │       ├── PriceComparisonWidget.tsx
│   │       ├── PropertyExpandableCard.tsx
│   │       ├── PropertyLeadForm.tsx
│   │       ├── ProposalCard.tsx
│   │       ├── RentalJourneyStepper.tsx
│   │       ├── TenantScoreGauge.tsx
│   │       ├── TrustBadges.tsx
│   │       └── VisitFeedbackList.tsx
│   │
│   ├── notifications/         # Toggle de notificações browser
│   │   └── NotificationToggle.tsx
│   │
│   ├── property/              # Filtros e carousel de imóveis
│   │   ├── PropertyFilters.tsx
│   │   └── PropertyImageCarousel.tsx
│   │
│   ├── rental/                # Formulário de locação (wizard)
│   │   ├── DocumentUpload.tsx
│   │   ├── GamificationProgress.tsx
│   │   ├── IncomeDataForm.tsx
│   │   ├── PersonalDataForm.tsx
│   │   ├── ProgressBar.tsx
│   │   ├── PropertyCard.tsx
│   │   ├── RentalTimeline.tsx
│   │   ├── SecondTenantCard.tsx
│   │   ├── SecondTenantSection.tsx
│   │   └── StickySubmitButton.tsx
│   │
│   ├── tenant/                # Dashboard do locatário
│   │   └── dashboard/
│   │       ├── DashboardSkeleton.tsx
│   │       ├── JourneyCard.tsx
│   │       ├── JourneyStepperHorizontal.tsx
│   │       ├── MatchmakerQuiz.tsx
│   │       ├── MatchmakerResults.tsx
│   │       ├── ProposalDashboardCard.tsx
│   │       ├── ProposalMiniCard.tsx
│   │       ├── QuizStep*.tsx
│   │       ├── ResourcesCard.tsx
│   │       ├── ResourcesFooter.tsx
│   │       ├── SmartCTAButton.tsx
│   │       ├── TenantHeader.tsx
│   │       ├── TenantKPIBar.tsx
│   │       ├── UpdateFeedItem.tsx
│   │       └── UpdatesFeed.tsx
│   │
│   ├── tracking/              # Stepper gamificado
│   │   └── GamifiedStepper.tsx
│   │
│   └── ui/                    # shadcn/ui (40+ componentes)
│       ├── accordion.tsx ... tooltip.tsx
│       ├── date-input.tsx     # Input de data customizado
│       ├── optimized-image.tsx # Lazy loading de imagens
│       └── range-slider.tsx   # Slider de faixa de valores
│
├── contexts/
│   └── AuthContext.tsx         # Provider de autenticação + role
│
├── hooks/                     # Custom hooks (documentados na Seção 26)
│   ├── use-mobile.tsx
│   ├── use-toast.ts
│   ├── useAdminPipelineStages.ts
│   ├── useAdminRentals.ts
│   ├── useAuditLog.ts
│   ├── useAuth.ts
│   ├── useCpfEncryption.ts
│   ├── useDebounce.ts
│   ├── useDocumentUpload.tsx
│   ├── useLandlordDashboard.ts
│   ├── useNotificationPermission.ts
│   ├── useProperties.ts
│   ├── useRentalTracking.ts
│   ├── useSessionTimeout.ts   # ← Novo
│   ├── useTenantDashboard.ts
│   └── useVistaSoftSync.ts
│
├── integrations/
│   └── supabase/
│       ├── client.ts          # createClient com env vars
│       └── types.ts           # Tipos gerados (read-only)
│
├── lib/                       # Utilitários puros (documentados na Seção 25)
│   ├── buildCrmReadyPayload.ts
│   ├── crypto.ts
│   ├── fileValidation.ts
│   ├── logger.ts
│   ├── masks.ts
│   ├── notifications.ts
│   ├── passwordPolicy.ts
│   ├── proposalEvents.ts
│   ├── rateLimiter.ts
│   ├── scrollToFirstError.ts
│   ├── utils.ts               # cn() helper (clsx + tailwind-merge)
│   └── validations.ts         # Schemas Zod dos formulários
│
├── pages/
│   ├── AcceptInvite.tsx
│   ├── Acompanhamento.tsx
│   ├── Admin.tsx
│   ├── AnunciarImovel.tsx
│   ├── Auth.tsx
│   ├── DownloadDocs.tsx       # Página de download da documentação
│   ├── EnviarDocumentos.tsx
│   ├── EnviarDocumentosPendentes.tsx
│   ├── EnvioSucesso.tsx
│   ├── Forbidden.tsx
│   ├── Index.tsx
│   ├── IniciarLocacaoDireta.tsx
│   ├── Login.tsx
│   ├── NewRental.tsx
│   ├── NotFound.tsx
│   ├── PortalPrivacidade.tsx
│   ├── Register.tsx
│   ├── SegundoLocatario.tsx
│   ├── SelecionarImovel.tsx
│   ├── admin/
│   │   ├── AdminRentalDetail.tsx
│   │   ├── AdminRentalsList.tsx
│   │   ├── MapaProduto.tsx
│   │   ├── PropertyInvites.tsx
│   │   └── SecurityDashboard.tsx
│   ├── landlord/
│   │   └── LandlordDashboard.tsx
│   ├── locador/
│   │   ├── Ajuda.tsx
│   │   ├── Anunciar.tsx
│   │   ├── Auth.tsx
│   │   ├── Home.tsx
│   │   ├── Imoveis.tsx
│   │   ├── ImovelForm.tsx
│   │   ├── PropostaDetalhe.tsx
│   │   └── Propostas.tsx
│   ├── locatario/
│   │   ├── EscolherTipoProposta.tsx
│   │   ├── Landing.tsx
│   │   ├── Login.tsx
│   │   ├── Register.tsx
│   │   └── VerifiqueEmail.tsx
│   └── tenant/
│       ├── MeuCadastro.tsx
│       └── TenantDashboard.tsx
│
├── types/                     # TypeScript interfaces
│   ├── admin.ts
│   ├── documentLimits.ts
│   ├── index.ts
│   ├── landlord.ts
│   ├── locador-dashboard.ts
│   ├── property.ts
│   ├── rental.ts
│   ├── tenant-dashboard.ts
│   └── tracking.ts
│
├── utils/                     # Helpers específicos
│   ├── formValidation.ts
│   └── properties.ts
│
└── test/                      # Testes
    ├── example.test.ts
    ├── rental-flow-e2e.test.ts
    └── setup.ts
```

---

## 31. Dependências Completas (`package.json`)

### 31.1 Dependências de Produção

| Pacote | Versão | Propósito |
|--------|--------|-----------|
| `react` | ^18.3.1 | Framework UI |
| `react-dom` | ^18.3.1 | Renderização DOM |
| `react-router-dom` | ^6.30.1 | Roteamento SPA |
| `@supabase/supabase-js` | ^2.93.1 | Cliente Supabase (Auth, DB, Storage, Functions) |
| `@tanstack/react-query` | ^5.83.0 | Cache, fetching e sincronização de dados |
| `react-hook-form` | ^7.61.1 | Gerenciamento de formulários |
| `@hookform/resolvers` | ^3.10.0 | Integração zod + react-hook-form |
| `zod` | ^3.25.76 | Validação de schemas |
| `date-fns` | ^3.6.0 | Manipulação e formatação de datas |
| `recharts` | ^2.15.4 | Gráficos e visualizações |
| `@hello-pangea/dnd` | ^18.0.1 | Drag-and-drop (Kanban board) |
| `embla-carousel-react` | ^8.6.0 | Carousel de imagens |
| `lucide-react` | ^0.462.0 | Biblioteca de ícones |
| `sonner` | ^1.7.4 | Toast notifications modernas |
| `vaul` | ^0.9.9 | Drawer mobile (bottom sheet) |
| `cmdk` | ^1.1.1 | Command palette |
| `input-otp` | ^1.4.2 | Input de código OTP |
| `next-themes` | ^0.3.0 | Toggle dark/light mode |
| `class-variance-authority` | ^0.7.1 | Variantes de componentes (cva) |
| `clsx` | ^2.1.1 | Concatenação condicional de classes |
| `tailwind-merge` | ^2.6.0 | Merge inteligente de classes Tailwind |
| `tailwindcss-animate` | ^1.0.7 | Plugin de animações Tailwind |
| `react-resizable-panels` | ^2.1.9 | Painéis redimensionáveis |
| `react-day-picker` | ^8.10.1 | Date picker |

#### Radix UI Primitives (25 componentes)

| Componente | Versão |
|------------|--------|
| `@radix-ui/react-accordion` | ^1.2.11 |
| `@radix-ui/react-alert-dialog` | ^1.1.14 |
| `@radix-ui/react-aspect-ratio` | ^1.1.7 |
| `@radix-ui/react-avatar` | ^1.1.10 |
| `@radix-ui/react-checkbox` | ^1.3.2 |
| `@radix-ui/react-collapsible` | ^1.1.11 |
| `@radix-ui/react-context-menu` | ^2.2.15 |
| `@radix-ui/react-dialog` | ^1.1.14 |
| `@radix-ui/react-dropdown-menu` | ^2.1.15 |
| `@radix-ui/react-hover-card` | ^1.1.14 |
| `@radix-ui/react-label` | ^2.1.7 |
| `@radix-ui/react-menubar` | ^1.1.15 |
| `@radix-ui/react-navigation-menu` | ^1.2.13 |
| `@radix-ui/react-popover` | ^1.1.14 |
| `@radix-ui/react-progress` | ^1.1.7 |
| `@radix-ui/react-radio-group` | ^1.3.7 |
| `@radix-ui/react-scroll-area` | ^1.2.9 |
| `@radix-ui/react-select` | ^2.2.5 |
| `@radix-ui/react-separator` | ^1.1.7 |
| `@radix-ui/react-slider` | ^1.3.5 |
| `@radix-ui/react-slot` | ^1.2.3 |
| `@radix-ui/react-switch` | ^1.2.5 |
| `@radix-ui/react-tabs` | ^1.1.12 |
| `@radix-ui/react-toast` | ^1.2.14 |
| `@radix-ui/react-toggle` | ^1.1.9 |
| `@radix-ui/react-toggle-group` | ^1.1.10 |
| `@radix-ui/react-tooltip` | ^1.2.7 |

### 31.2 Dependências de Desenvolvimento

| Pacote | Versão | Propósito |
|--------|--------|-----------|
| `vite` | ^5.4.11 | Build tool |
| `@vitejs/plugin-react-swc` | ^3.5.0 | Plugin React com SWC |
| `typescript` | ~5.6.2 | Compilador TypeScript |
| `tailwindcss` | ^3.4.17 | Framework CSS utilitário |
| `@tailwindcss/typography` | ^0.5.16 | Plugin de tipografia |
| `postcss` | ^8.4.49 | Processador CSS |
| `autoprefixer` | ^10.4.20 | Prefixos CSS automáticos |
| `eslint` | ^9.13.0 | Linter |
| `vitest` | ^3.0.5 | Test runner |
| `jsdom` | ^25.0.1 | DOM virtual para testes |
| `@testing-library/react` | ^16.1.0 | Utilitários de teste React |
| `@testing-library/jest-dom` | ^6.6.3 | Matchers DOM para testes |

### 31.3 Supabase Edge Functions Runtime

Edge functions rodam em **Deno** (runtime do Supabase). Não usam `package.json` — importam módulos via URL ou `supabase-js` built-in.

| Edge Function | Dependências |
|---------------|-------------|
| Todas | `@supabase/supabase-js` (built-in Deno) |
| `encrypt-cpf` | Web Crypto API (PBKDF2 + AES-GCM) |
| `validate-upload` | Nenhuma extra (lê bytes do FormData) |
| `check-rate-limit` | Web Crypto API (SHA-256) |

---

## 32. Configurações de Build e Deploy

### 32.1 Vite (`vite.config.ts`)

- Plugin: `@vitejs/plugin-react-swc`
- Resolve alias: `@` → `./src`
- Server port: 8080

### 32.2 TypeScript (`tsconfig.app.json`)

- Target: ES2020
- Module: ESNext
- Strict mode: habilitado
- Path alias: `@/*` → `src/*`

### 32.3 Testes (`vitest.config.ts`)

- Environment: `jsdom`
- Setup files: `src/test/setup.ts`
- Globals: habilitado

### 32.4 Supabase (`supabase/config.toml`)

- Configuração local do projeto Supabase
- Edge functions deploy automático via Lovable

---

## Fim da Documentação

Este documento cobre **toda** a arquitetura, banco de dados, lógica de negócio, utilitários JavaScript, hooks customizados, sistema de notificações, integração CRM/n8n, controles de segurança, design system, componentes UI, animações, padrões mobile, estrutura de pastas, dependências e configurações de build do projeto **Etic Conecta**.

**Versão:** 2.0 — Documentação definitiva para replicação de projeto  
**Última atualização:** Março 2026  
**Total de seções:** 32
