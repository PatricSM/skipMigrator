# PRD — Etic Conecta

**Product Requirements Document (Documento Oficial de Produto)**
Versão 1.0 — Maio/2026
Documento complementar a `DOCUMENTACAO_COMPLETA.md` (referência técnica).

---

## 1. Sumário Executivo

### 1.1 Visão do produto
O **Etic Conecta** é uma plataforma digital end-to-end de locação de imóveis residenciais que conecta locatários, locadores e a equipe administrativa da imobiliária Etic em um único fluxo transparente, gamificado e auditável. O sistema substitui processos analógicos (planilhas, e-mails, papéis) por uma jornada 100% online com rastreamento em tempo real, validação automatizada de documentos e integração com CRM externo (n8n / VistaSoft).

### 1.2 Proposta de valor
- **Para o locatário:** alugar um imóvel em poucos cliques, com acompanhamento visual de cada etapa, upload seguro de documentos e notificações em tempo real.
- **Para o locador:** anunciar imóveis, receber propostas qualificadas, validar inquilinos com score automatizado e assinar contratos digitalmente.
- **Para o admin:** operar todo o pipeline de locações em um Kanban centralizado, com SLA por etapa, override auditado e visão analítica do funil.

### 1.3 Público-alvo
- Inquilinos urbanos de classe B/C que buscam praticidade digital.
- Pequenos e médios proprietários (1 a 20 imóveis).
- Equipe interna da imobiliária Etic (administradores e analistas).

### 1.4 Diferenciais
- **Transparência radical:** todas as etapas visíveis para todos os perfis envolvidos.
- **Segurança bancária:** CPF criptografado (AES-256-GCM), RLS em 100% das tabelas, rate limiting progressivo e session timeout.
- **Tempo real:** updates instantâneos via Supabase Realtime.
- **Mobile-first:** desenhado primeiro para celular, responsivo até desktop.
- **CRM-ready:** payload consolidado pronto para sincronizar com qualquer CRM via webhook.

---

## 2. Contexto e Problema

### 2.1 Dor do mercado tradicional
A locação tradicional sofre de:
- Documentação física dispersa e perdida;
- Comunicação fragmentada (WhatsApp, e-mail, telefone);
- Falta de visibilidade do status para o cliente;
- Validações manuais demoradas (3 a 15 dias);
- Risco de fraude (CPF, comprovantes adulterados);
- Atrito entre locador e locatário por falta de informação simétrica.

### 2.2 Oportunidade
Digitalizar e automatizar a jornada reduz o ciclo de locação de **~15 dias para ~5 dias**, aumenta a taxa de conversão do funil e libera a equipe operacional para foco em casos excepcionais (override, exceções jurídicas).

### 2.3 Por que agora
- Maturidade de stacks serverless (Supabase / Lovable Cloud).
- LGPD exige criptografia e auditoria de dados sensíveis.
- Concorrentes (QuintoAndar, Loft) provaram demanda.

---

## 3. Visão e Objetivos do Produto

### 3.1 Visão de longo prazo
Tornar-se o sistema operacional padrão da imobiliária Etic, expandindo de locação residencial para venda, comercial e administração de carteira.

### 3.2 Objetivos estratégicos (12 meses)
| Objetivo | Métrica-alvo |
|---|---|
| Reduzir ciclo médio de locação | -60% (de 15 para 6 dias) |
| Aumentar taxa de conversão do funil | +30% (etapa proposta → contrato) |
| Eliminar perda de documentos | 0% (100% digital, com auditoria) |
| Aumentar NPS do locatário | ≥ 70 |
| Cobertura de validação automática | ≥ 80% das propostas sem intervenção humana |

### 3.3 KPIs principais
1. **Tempo médio por stage** (admin Kanban).
2. **Taxa de aprovação de documentos** (1ª submissão).
3. **Conversão do funil** (cadastro → chaves entregues).
4. **Número de overrides admin** (quanto menor, mais maduro o sistema).
5. **Volume de propostas / contratos / mês.**

---

## 4. Personas e Perfis de Usuário

### 4.1 Locatário (inquilino)
- **Quem é:** 25-45 anos, urbano, smartphone-first, busca praticidade.
- **Dores:** desconfia de processos manuais, odeia esperar sem saber o status, teme perder o imóvel para outro candidato.
- **Ganhos esperados:** acompanhar tudo no celular, receber notificações, saber exatamente o que falta enviar.
- **Acesso ao sistema:** rotas `/locatario/*`, role `locatario`.

### 4.2 Locador (proprietário)
- **Quem é:** 35-65 anos, possui 1-20 imóveis, quer renda passiva sem dor.
- **Dores:** medo de inadimplência, dificuldade em filtrar bons inquilinos, burocracia para entregar chaves.
- **Ganhos esperados:** ver propostas qualificadas, assinar digitalmente, dashboard financeiro.
- **Acesso ao sistema:** rotas `/locador/*`, role `locador`. Cadastro validado por webhook n8n.

### 4.3 Administrador (equipe Etic)
- **Quem é:** analista interno operando o pipeline.
- **Dores:** múltiplos canais para acompanhar cada locação, falta de visão de SLA, retrabalho.
- **Ganhos esperados:** Kanban único, KPIs visuais, override auditado com reautenticação.
- **Acesso ao sistema:** rotas `/admin/*`, role `admin`. Reautenticação obrigatória para mudanças manuais de etapa.

---

## 5. Jornadas do Usuário

### 5.1 Jornada do Locatário (10 steps)
1. **Descoberta** — Landing page (`/locatario`) → escolha do tipo de proposta.
2. **Cadastro** — Registro com e-mail, senha forte (14+ chars), validação anti-enumeração.
3. **Verificação** — Confirmação por e-mail.
4. **Seleção de imóvel** — Catálogo com filtros (faixa de preço, bairro) ou via convite (`/aceitar-convite`).
5. **Dados pessoais** — Nome, CPF (criptografado), nascimento, profissão, renda, PEP.
6. **Segundo locatário** (opcional) — Dados completos.
7. **Documentos** — Upload com magic-byte validation, limite 10MB.
8. **Análise admin** — Pipeline Kanban; locatário vê progresso em tempo real.
9. **Contrato** — Preview + assinatura digital.
10. **Chaves entregues** — Encerramento da jornada.

Cada step dispara **notificação browser** específica + **evento gravado** em `rental_events`.

### 5.2 Jornada do Locador
1. Cadastro com validação por webhook n8n (`validate-landlord`).
2. Anúncio de imóvel (`/locador/anunciar`) — formulário com fotos, valores.
3. Recebimento de propostas (`/locador/propostas`) — com score do inquilino.
4. Aceite/rejeição da proposta.
5. Envio de documentos do locador.
6. Assinatura do contrato.
7. Confirmação de entrega de chaves.
8. Dashboard financeiro contínuo.

### 5.3 Jornada do Admin
1. Login admin (`/admin`).
2. Visão Kanban (`/admin/rentals`) com colunas = stages do pipeline.
3. Drag-and-drop entre stages → grava evento + atualiza `admin_stage`.
4. Override manual com **ReAuth Dialog** (senha obrigatória).
5. Marcar pendência (locatário recebe notificação para enviar documento adicional).
6. Validar documentos.
7. Encerrar locação.

---

## 6. Escopo Funcional (Requisitos Funcionais)

| ID | Requisito | Descrição | Status |
|---|---|---|---|
| RF-01 | Autenticação multi-perfil | Login separado para locatário, locador, admin com redirect contextual | Implementado |
| RF-02 | Onboarding locatário | Fluxo de 10 steps com validação Zod por etapa | Implementado |
| RF-03 | Validação locador | Webhook n8n decide aprovação; role atribuída após sucesso | Implementado |
| RF-04 | Catálogo de imóveis | Lista + filtros + integração VistaSoft (sync 12h) | Implementado |
| RF-05 | Sistema de propostas | Locatário envia → locador aceita/rejeita | Implementado |
| RF-06 | Upload de documentos | Magic-byte client+server, 10MB, tipos PDF/JPEG/PNG | Implementado |
| RF-07 | Pipeline Kanban admin | Stages configuráveis (`pipeline_stages`), drag-drop, SLA por stage | Implementado |
| RF-08 | Acompanhamento realtime | Subscriptions Supabase em `rentals` e `rental_events` | Implementado |
| RF-09 | Notificações browser | Permissão opt-in, notificações por step e por evento | Implementado |
| RF-10 | Convites de imóvel | Token criptográfico (32 bytes), hash SHA256, expiração | Implementado |
| RF-11 | Gamificação | Barra de progresso, conquistas visuais por step | Implementado |
| RF-12 | Matchmaker | Quiz 4 etapas (orçamento, localização, features, motivação) | Implementado |
| RF-13 | Dashboards | Locatário, Locador (KPIs financeiros), Admin (analytics) | Implementado |
| RF-14 | ReAuth admin | Senha obrigatória para override manual | Implementado |
| RF-15 | Segundo locatário/locador | Dados completos do co-titular | Implementado |
| RF-16 | Contrato | Preview URL + Sign URL armazenados em `rentals` | Implementado |
| RF-17 | Eventos / timeline | Toda mudança gera entrada em `rental_events` | Implementado |
| RF-18 | CRM-ready payload | `buildCrmReadyPayload` para sync n8n | Implementado |
| RF-19 | Portal de privacidade | LGPD: `/portal-privacidade` com direitos do titular | Implementado |
| RF-20 | Audit logs | Função `log_audit` + tabela `audit_logs` | Implementado |

---

## 7. Requisitos Não-Funcionais

### 7.1 Segurança
- **RLS** habilitado em 100% das tabelas; views com `security_invoker`.
- **Roles em tabela separada** (`user_roles` + função `has_role`) — nunca em `profiles`.
- **CPF criptografado** com AES-256-GCM via edge function `encrypt-cpf`; nunca em plaintext.
- **Rate limiting progressivo:** 5 tentativas → 1 min; 30+ → 60 min (`auth_rate_limits`).
- **Anti-enumeração:** mensagens genéricas em login e reset.
- **Session timeout:** logout após 30 min de inatividade (`useSessionTimeout`).
- **Política de senha:** 14+ caracteres, 3 das 4 classes, bloqueio de senhas comuns.
- **Magic-byte validation** em uploads (header binário verificado server-side).
- **ReAuth obrigatória** para `Admin Override`.
- **Logger environment-aware:** sem logs em produção.
- **Audit logs** automáticos (INSERT/UPDATE/DELETE) em tabelas críticas.

### 7.2 Performance
- Realtime subscriptions com cleanup correto.
- Debounce em buscas (`useDebounce`).
- Skeleton loaders em todas as páginas com fetch.
- Lazy loading de imagens (`OptimizedImage`).
- Edge functions stateless e cacheable quando aplicável.

### 7.3 Acessibilidade
- HTML semântico (header, main, section, article).
- Contraste WCAG AA via tokens HSL.
- Foco visível, navegação por teclado em modais (Radix UI).
- Alt text em imagens críticas.

### 7.4 Compatibilidade
- Mobile-first (375px+) → desktop (1920px).
- Browsers modernos (últimos 2 majors de Chrome, Safari, Firefox, Edge).

### 7.5 LGPD
- Portal de privacidade público.
- Criptografia de CPF.
- Direito de portabilidade via `buildCrmReadyPayload`.
- Direito de exclusão via cascade nas FKs (`on delete cascade`).

---

## 8. Arquitetura de Alto Nível

### 8.1 Stack
- **Frontend:** React 18, Vite 5, TypeScript 5, Tailwind v3, shadcn/ui, React Router 6, TanStack Query.
- **Backend:** Lovable Cloud (Supabase) — Postgres, Auth, Storage, Edge Functions (Deno), Realtime.
- **Integrações externas:** n8n (validação locador, sync CRM), VistaSoft (catálogo).
- **AI Gateway:** Lovable AI Gateway (uso futuro previsto, ex.: análise de documentos).

### 8.2 Edge Functions
| Função | Propósito |
|---|---|
| `accept-property-invite` | Valida e consome token de convite |
| `check-rate-limit` | Controle progressivo de tentativas |
| `encrypt-cpf` | Criptografia AES-256-GCM |
| `fetch-properties` | Catálogo (com filtros + integração VistaSoft) |
| `get-signed-url` | URLs temporárias de Storage |
| `validate-landlord` | Webhook n8n para aprovar locador |
| `validate-upload` | Magic-byte server-side |

### 8.3 Storage Buckets
- `documents` (privado) — Documentos do locatário.
- `landlord-documents` (privado) — Documentos do locador.
- `property-images` (público) — Fotos de imóveis.

### 8.4 Secrets configurados
`LOVABLE_API_KEY`, `CPF_ENCRYPTION_KEY`, `N8N_VALIDATE_LANDLORD_WEBHOOK`, `SUPABASE_*`.

---

## 9. Modelo de Dados (resumo)

### 9.1 Entidades principais
- **profiles** — Dados do usuário (nome, e-mail, telefone E.164, CPF criptografado).
- **user_roles** — `app_role` enum (`admin`, `locador`, `locatario`).
- **properties** — Imóveis (código, endereço, valores, fotos, status).
- **property_invites** — Convites (token_hash, expira, usado).
- **rentals** — Locação (protocol, step, status, stage admin, contrato URLs).
- **rental_events** — Timeline (event_type, descrição, criado_por).
- **documents** / **landlord_documents** — Uploads (file_path, status, reviewer).
- **landlord_data** — Dados bancários e do co-locador.
- **pipeline_stages** — Configuração do Kanban admin.
- **auth_rate_limits** — Tentativas por identifier+action.
- **audit_logs** — Trilha de auditoria.

### 9.2 Funções SQL críticas
`has_role`, `handle_new_user`, `log_audit`, `set_admin_stage_entered_at`, `format_brazilian_phone_e164`, `cleanup_old_rate_limits`.

> Para o detalhamento completo (colunas, tipos, RLS, triggers), ver `DOCUMENTACAO_COMPLETA.md` seções 2-6.

---

## 10. Regras de Negócio Críticas

### 10.1 Ciclo de 10 steps da locação
| Step | Descrição |
|---|---|
| 1 | Início / seleção do imóvel |
| 2 | Dados pessoais do locatário |
| 3 | Dados do segundo locatário (opcional) |
| 4 | Upload de documentos |
| 5 | Validação admin |
| 6 | Dados do locador |
| 7 | Documentos do locador |
| 8 | Geração de contrato |
| 9 | Assinatura |
| 10 | Entrega de chaves |

### 10.2 Stages do pipeline admin
Configurável em `pipeline_stages` (ordem, nome, cor). Padrão: Novo → Análise → Documentação → Contrato → Assinatura → Entrega → Concluído.

### 10.3 Pendência vs. Rejeição
- **Pendência** (`has_pending=true`): bloqueia avanço, locatário pode corrigir, gera notificação, aceita upload em `/enviar-documentos-pendentes`.
- **Rejeição** (`is_rejected=true`): encerra locação; motivo obrigatório.

### 10.4 Matriz de permissões
| Ação | locatario | locador | admin |
|---|---|---|---|
| Criar locação | ✅ | ❌ | ❌ |
| Ver própria locação | ✅ | ✅ (se dono) | ✅ (todas) |
| Mudar admin_stage | ❌ | ❌ | ✅ (com ReAuth) |
| Aceitar proposta | ❌ | ✅ | ❌ |
| Anunciar imóvel | ❌ | ✅ | ✅ |
| Override manual | ❌ | ❌ | ✅ |

### 10.5 Limites de documentos
Por tipo (RG, CPF, comprovante de renda, comprovante de residência) — configurado em `src/types/documentLimits.ts`. Limite global: 10MB / arquivo.

---

## 11. Métricas de Sucesso (KPIs)

### 11.1 KPIs operacionais
- **Tempo médio por stage** (em horas) — exibido no dashboard admin (`AnalyticsDashboard`).
- **Throughput** — locações concluídas / semana.
- **Taxa de aprovação na 1ª submissão de documentos** — alvo ≥ 70%.
- **% de overrides** sobre o total — alvo ≤ 10%.

### 11.2 KPIs de produto
- **Conversão do funil** — cadastro → chaves entregues (alvo ≥ 25%).
- **NPS do locatário** (placeholder — instrumentação futura).
- **Tempo médio do ciclo end-to-end** — alvo ≤ 6 dias.

### 11.3 KPIs financeiros (locador)
- Receita projetada do mês.
- Vacância média da carteira.
- Comparação de preço (`PriceComparisonWidget`).

---

## 12. Roadmap e Próximos Passos

### 12.1 Curto prazo (Q3/2026)
- Sync bidirecional com CRM via n8n (escrita de `crm_deal_id`).
- Assinatura digital integrada (Clicksign / DocuSign API).
- Score de crédito automatizado (Serasa/Boa Vista API).

### 12.2 Médio prazo (Q4/2026)
- Pagamentos in-app (boleto, PIX) via gateway.
- Notificações via WhatsApp Business API.
- App mobile nativo (React Native) reaproveitando hooks.

### 12.3 Longo prazo (2027)
- Análise documental por IA (Lovable AI Gateway).
- Expansão para imóveis comerciais.
- Marketplace de serviços agregados (mudança, seguro, vistoria).

---

## 13. Glossário

| Termo | Definição |
|---|---|
| **Locatário** | Inquilino que aluga o imóvel |
| **Locador** | Proprietário que oferece o imóvel |
| **Admin** | Analista da imobiliária Etic |
| **Step** | Etapa do fluxo do locatário (1-10) |
| **Stage** | Coluna do Kanban administrativo |
| **Pipeline** | Conjunto de stages configuráveis |
| **Override** | Mudança manual de stage pelo admin (com ReAuth) |
| **Pendência** | Bloqueio temporário aguardando ação do locatário |
| **Rejeição** | Encerramento definitivo da locação |
| **Magic Byte** | Validação do header binário do arquivo |
| **RLS** | Row-Level Security do Postgres |
| **ReAuth** | Reautenticação por senha para ações sensíveis |
| **PEP** | Pessoa Politicamente Exposta |
| **E.164** | Padrão internacional de telefone (+55…) |
| **CRM-ready** | Payload JSON consolidado para sincronização externa |

---

## 14. Anexos — Mapa de Referência Cruzada

| Tema deste PRD | Seção em `DOCUMENTACAO_COMPLETA.md` |
|---|---|
| Modelo de dados detalhado | Seções 2, 3, 4 |
| RLS e funções SQL | Seções 5, 6 |
| Edge Functions | Seção 7 |
| Storage e Secrets | Seções 8, 9 |
| Autenticação | Seção 10 |
| Rotas e ProtectedRoute | Seção 11 |
| Ciclo de locação e eventos | Seções 12, 13 |
| Validações Zod | Seção 14 |
| Política de senhas | Seção 15 |
| Pipeline admin | Seção 16 |
| Tipos TypeScript | Seção 17 |
| Migrações | Seção 18 |
| Design System | Seções 19, 20 |
| Componentes UI | Seção 21 |
| Animações e Layout Mobile | Seções 22, 23 |
| Arquitetura | Seção 24 |
| Utilitários JS | Seção 25 |
| Hooks Customizados | Seção 26 |
| Notificações | Seção 27 |
| Integração CRM/n8n | Seção 28 |
| Resumo de Segurança | Seção 29 |
| Estrutura de Pastas | Seção 30 |
| Dependências | Seções 31, 32 |

---

**Fim do PRD — Etic Conecta v1.0**
