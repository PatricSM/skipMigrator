# Documento Técnico Completo — Etic Conecta

> Documento oficial consolidado para recriação integral do projeto.
> Versão: 1.0 — Maio/2026
> Documentos relacionados: `DOCUMENTACAO_COMPLETA.md` (32 seções técnicas detalhadas) e `PRD_ETIC_CONECTA.md` (requisitos de produto).

---

## SUMÁRIO

1. Estrutura do Projeto
2. Funcionalidades Principais
3. Banco de Dados
4. Interface e Design
5. Funcionalidades Avançadas
6. Integrações e APIs
7. Instruções para Recriação

---

# 1. ESTRUTURA DO PROJETO

## 1.1. Nome e Descrição Geral

**Nome**: Etic Conecta
**Slug**: `etic-conecta`
**Domínio publicado**: `https://eticconecta.lovable.app`
**Tipo**: Plataforma SaaS web responsiva (mobile-first) para gestão completa do ciclo de locação imobiliária residencial.

**Descrição**: Sistema que digitaliza ponta-a-ponta a jornada de locação — da descoberta do imóvel à entrega das chaves — conectando **locatários**, **locadores (proprietários)** e a **administradora (imobiliária Etic)**. Cobre 10 etapas formais com timeline em tempo real, upload e validação de documentos, sistema de propostas com contraproposta, encriptação de CPF, contratos digitais e dashboard administrativo Kanban.

## 1.2. Objetivo Principal e Público-Alvo

### Objetivo
Reduzir o tempo médio de fechamento de uma locação de **~15 dias** (modelo tradicional) para **menos de 72 horas** úteis, com auditoria completa, conformidade LGPD e zero papel.

### Públicos
| Persona | Papel (`app_role`) | Necessidade central |
|---------|-------------------|---------------------|
| **Locatário** | `locatario` | Encontrar imóvel, enviar documentos, propor valor e acompanhar status sem ligar para a imobiliária. |
| **Locador / Proprietário** | `locador` | Cadastrar imóvel, receber e analisar propostas, assinar contrato e acompanhar inquilinos. |
| **Administradora (Etic)** | `admin` | Validar documentação, mover negócios pelo pipeline, intermediar contraproposta, gerar contrato e auditar tudo. |

## 1.3. Fluxo de Usuário Completo (10 Etapas)

```
[Landing] → [Cadastro/Login] → [Catálogo de Imóveis] → [Proposta]
   ↓
[Etapa 1] Imóvel selecionado / Proposta criada
[Etapa 2] Cadastro pessoal completo (CPF, renda, profissão)
[Etapa 3] Upload de documentos (RG, renda, residência) + 2º locatário (opc.)
[Etapa 4] Análise da ficha pela administradora (até 24h)
[Etapa 5] Documentos do locador (dados bancários, IPTU, matrícula)
[Etapa 6] Geração e assinatura do contrato
[Etapa 7] Agendamento da vistoria
[Etapa 8] Assinatura do laudo de vistoria
[Etapa 9] Liberação para entrega
[Etapa 10] Entrega das chaves (locação concluída)
```

Cada transição é registrada em `rental_events` (idempotente, janela de 60s) e propagada via Supabase Realtime para todos os atores.

---

# 2. FUNCIONALIDADES PRINCIPAIS

## 2.1. Sistema de Autenticação

**Provedor**: Supabase Auth (email + senha, sessão JWT em `localStorage`).
**Roles**: armazenadas em tabela `user_roles` separada (NUNCA na `profiles`) e validadas via RPC `has_role(_user_id, _role)` com `SECURITY DEFINER`.

| Tipo | Rota de cadastro | Rota de login | Pós-login |
|------|-----------------|---------------|-----------|
| Locatário | `/locatario/register` | `/locatario/login` | `/tenant/dashboard` |
| Locador | `/locador/auth` | `/locador/auth` | `/locador/home` |
| Admin | criado manualmente via SQL | `/auth` | `/admin` |

**Política de senha**: mínimo 14 caracteres, indicador de força (`PasswordStrengthIndicator`), validado em `lib/passwordPolicy.ts`.
**Rate limiting**: tabela `auth_rate_limits` + edge function `check-rate-limit` (progressivo: 5 tentativas → bloqueio 15min → 1h).
**Anti-enumeração**: respostas genéricas em `/forgot-password`.
**Session timeout**: hook `useSessionTimeout` desloga após 30 min de inatividade.
**Reauth**: ações sensíveis (override admin) exigem `ReAuthDialog`.
**Trigger**: `handle_new_user()` insere em `profiles` e atribui role `locatario` (locadores são validados pela edge function `validate-landlord` que sincroniza com CRM via webhook n8n).

## 2.2. Solicitação de Visita / Proposta de Aluguel

A "solicitação de visita" no Etic Conecta é materializada como **proposta de locação** — não há etapa de visita física isolada; a vistoria ocorre na etapa 8 após contrato.

**Formulário de proposta** (`SelecionarImovel.tsx` → `NewRental.tsx`):

| Campo | Tipo | Obrigatório | Validação Zod |
|-------|------|-------------|---------------|
| `propertyCode` | text | Sim | min 3 |
| `rentValue` | number | Sim | >= R$ 100 |
| `proposedValue` | number | Não (negociação) | desconto máx. **12%** sobre `rentValue` |
| `startDate` | date | Sim | >= hoje, máscara DD/MM/AAAA manual |
| `fullName` | text | Sim | min 5 |
| `email` | email | Sim | regex RFC 5322 |
| `phone` | text | Sim | máscara (XX) XXXXX-XXXX, 10-11 dígitos |
| `cpf` | text | Sim | algoritmo de validação + criptografia AES-256-GCM |
| `birthDate` | date | Sim | >= 18 anos |
| `monthlyIncome` | number | Sim | >= 3× rent_value para score 100 |
| `profession` | text | Sim | min 2 |
| `maritalStatus` | enum | Sim | solteiro/casado/divorciado/viuvo/uniao_estavel |
| `isPoliticallyExposed` | boolean | Sim | declaração obrigatória |

**Múltiplas propostas ativas**: o mesmo locatário pode ter N propostas simultâneas (cada uma é um `rental` independente).

## 2.3. Proposta de Aluguel — Criação, Edição, Visualização

| Ação | Quem | Como |
|------|------|------|
| **Criar** | Locatário | `/selecionar-imovel` → `/new-rental` (cria `rental` + `proposal` autor `tenant`) |
| **Visualizar** | Tenant/Landlord/Admin | `/acompanhamento/:id`, `/locador/propostas/:id`, `/admin/rentals/:id` |
| **Contraproposta** | Locador | `/locador/propostas/:id` → cria nova `proposal` autor `landlord` |
| **Aceitar** | Ambos | atualiza `proposals.status = accepted` + `rentals.proposal_status` |
| **Rejeitar** | Ambos | exige `rejection_reason` (texto livre min 10 chars) |
| **Editar** | Apenas em `pending` | locatário/locador, antes de aceite |

**Estados (`proposal_status_enum`)**: `pending`, `accepted`, `rejected`, `countered`, `expired`.
**Estados de rental (`rental_proposal_status`)**: `waiting_landlord_acceptance`, `landlord_accepted`, `in_negotiation`, `tenant_accepted`, `finalized`, `rejected`.
**Gamificação**: 4 tiers de probabilidade (Baixa/Média/Alta/Excelente) com base em (a) % de desconto pedido, (b) score do locatário, (c) urgência do imóvel (≥2 propostas ativas).

## 2.4. Acompanhamento 100% da Locação

**Página principal**: `/acompanhamento/:rentalId` (`Acompanhamento.tsx`).

**Componentes**:
- `RentalTimeline` — 10 marcos verticais com status (concluído/atual/pendente).
- `GamifiedStepper` — versão mobile com windowed view (anterior, atual, próximo).
- `JourneyStepperHorizontal` — desktop, todos os 10 steps.
- `UpdatesFeed` — eventos cronológicos puxados de `rental_events`.
- `ResourcesCard` — documentos relevantes (URLs assinadas TTL 60s).

**Fonte da verdade**: `rentals.current_step` (1-10). Toda mutação obrigatoriamente via helper `setRentalStepAndLog()` que insere `rental_events` com `idempotency_key` (janela 60s).

**Realtime**: subscription Supabase Realtime no canal `rentals:id=eq.{rentalId}` + `rental_events:rental_id=eq.{rentalId}`.

**Notificações Web**: hook `useNotificationPermission` + Notifications API; toast em `sonner` para ações inline.

---

# 3. BANCO DE DADOS

## 3.1. Tabelas Principais (24 tabelas)

| Tabela | Propósito | Linhas-chave |
|--------|-----------|--------------|
| `profiles` | Dados do usuário (1:1 com auth.users) | id, full_name, email, phone, cpf_encrypted, monthly_income |
| `user_roles` | Atribuição de papéis (separada por segurança) | user_id, role (`admin`/`locador`/`locatario`) |
| `properties` | Imóveis cadastrados | id, owner_id, code, address, rent_value, status, images[] |
| `properties_cache` | Cache 10min do XML VistaSoft | id='current', data jsonb, expires_at |
| `property_invites` | Convites token-based para locadores | property_id, token_hash, expires_at, used_by |
| `rentals` | **Núcleo do ciclo** — uma locação | id, user_id, protocol, current_step (1-10), proposal_status, landlord_property_id |
| `rental_events` | Log idempotente de eventos | rental_id, event_type, idempotency_key, metadata jsonb |
| `rental_steps` | Catálogo dos 10 steps + SLA | step_number, name, sla_hours, responsible |
| `proposals` | Propostas e contrapropostas | rental_id, author (tenant/landlord), rent_value, status |
| `documents` | Documentos do locatário | user_id, rental_id, document_type, file_path, status |
| `landlord_documents` | Documentos do locador | landlord_id, rental_id, document_type, file_path |
| `landlord_data` | Dados bancários do locador | rental_id, landlord_id, bank_name, pix_key, bills_responsible |
| `contracts` | Contratos gerados | rental_id, content, preview_url, signature_url, signed_by_*_at |
| `inspections` | Vistorias agendadas | rental_id, scheduled_date, signature_url, keys_delivered_at |
| `admin_pipeline_stages` | Colunas Kanban admin | name, order_index, color_key |
| `audit_logs` | Log imutável (triggers-only) | user_id, action, table_name, old_data, new_data |
| `auth_rate_limits` | Rate limiting auth | identifier, action, attempts, blocked_until |
| `security_events` | Eventos suspeitos anonimizados | event_type, identifier_hash |
| `notification_queue` | Fila de notificações (WhatsApp/email) | recipient_profile_id, channel, payload, status |
| `document_types` | Catálogo de tipos exigidos | key, label, required_for_role |
| `application_documents` | (legado) | application_id, file_path |
| `application_events` | (legado) | application_id, event_type |
| `rental_applications` | (legado, mantido para compat.) | tenant_id, owner_id, current_step |
| `n8n_chat_histories` | Logs de chat n8n (uso interno) | session_id, message |

## 3.2. Relacionamentos

```
auth.users (1) ─── (1) profiles
                    │
                    ├── (N) user_roles
                    ├── (N) properties [owner_id]
                    ├── (N) rentals [user_id = locatário]
                    └── (N) landlord_data [landlord_id]

properties (1) ─── (N) rentals [landlord_property_id]
                    │
                    └── (N) property_invites

rentals (1) ─── (N) rental_events
            ├── (N) proposals
            ├── (N) documents
            ├── (N) landlord_documents
            ├── (1) contracts
            ├── (1) inspections
            └── (1) landlord_data
```

> **Importante**: NÃO há foreign keys físicas (decisão arquitetural Supabase) — relacionamentos são lógicos, validados em RLS e código de aplicação. Uso de `ON DELETE CASCADE` simulado via triggers quando necessário.

## 3.3. Campos Detalhados (extrato — ver `DOCUMENTACAO_COMPLETA.md` §1 para tipos exaustivos)

**`rentals`** (tabela mais importante):
```
id              uuid PK
user_id         uuid NOT NULL  -- FK lógica para auth.users
protocol        text NOT NULL UNIQUE  -- formato: CODE-YYYYMMDD-XXXX
property_id     text NOT NULL          -- código VistaSoft
property_code   text NOT NULL
property_address text NOT NULL
rent_value      numeric
proposed_value  numeric                -- valor da contraproposta
current_step    integer DEFAULT 1 CHECK (current_step BETWEEN 1 AND 10)
step_status     text DEFAULT 'in_progress'
proposal_status rental_proposal_status DEFAULT 'waiting_landlord_acceptance'
admin_stage     integer DEFAULT 1
admin_stage_id  uuid                   -- FK lógica admin_pipeline_stages
landlord_property_id uuid              -- FK lógica properties.id
landlord_accepted boolean DEFAULT false
has_pending     boolean DEFAULT false
pending_documents jsonb DEFAULT '[]'
is_rejected     boolean DEFAULT false
rejection_reason text
contract_preview_url text
contract_sign_url    text
crm_provider    text                   -- 'n8n', 'pipedrive', etc.
crm_deal_id     text
created_at, updated_at timestamptz
```

## 3.4. Dados de Exemplo

```sql
-- Profile
INSERT INTO profiles (id, full_name, email, phone, monthly_income)
VALUES ('11111111-1111-1111-1111-111111111111', 'Maria Silva', 'maria@example.com', '11987654321', 8500);

-- User role
INSERT INTO user_roles (user_id, role)
VALUES ('11111111-1111-1111-1111-111111111111', 'locatario');

-- Property
INSERT INTO properties (owner_id, code, address, short_address, rent_value, status, images)
VALUES ('22222222-2222-2222-2222-222222222222', 'AP1234',
        'Rua das Flores, 100, Apto 52, Pinheiros, São Paulo - SP',
        'Pinheiros - Rua das Flores', 3500, 'disponivel',
        ARRAY['https://cdn.vistasoft/img1.jpg','https://cdn.vistasoft/img2.jpg']);

-- Rental
INSERT INTO rentals (user_id, protocol, property_id, property_code, property_address, rent_value, current_step)
VALUES ('11111111-1111-1111-1111-111111111111', 'AP1234-20260511-7821',
        'AP1234', 'AP1234', 'Rua das Flores, 100', 3500, 3);

-- Proposal
INSERT INTO proposals (rental_id, author, rent_value, status, start_date)
VALUES ('<rental_id>', 'tenant', 3300, 'pending', '2026-06-01');

-- Document
INSERT INTO documents (user_id, rental_id, document_type, file_name, file_path, file_type, status)
VALUES ('11111111-1111-1111-1111-111111111111', '<rental_id>', 'rg',
        'rg_maria.pdf', '11111111-1111-1111-1111-111111111111/rg_maria.pdf',
        'application/pdf', 'pending');

-- Rental Event
INSERT INTO rental_events (rental_id, event_type, description, idempotency_key)
VALUES ('<rental_id>', 'documents_uploaded', 'Locatário enviou 3 documentos',
        '<rental_id>:documents_uploaded:1715450000');
```

---

# 4. INTERFACE E DESIGN

## 4.1. Páginas (rotas)

### Públicas
- `/` — Landing (`Index.tsx`)
- `/locatario` — Landing locatário
- `/locador` — Landing locador
- `/auth`, `/login`, `/register` — Auth admin/legado
- `/locatario/login`, `/locatario/register`, `/locatario/verifique-email`
- `/locador/auth`
- `/forbidden`, `/404` (`NotFound.tsx`)
- `/aceitar-convite/:token` (`AcceptInvite.tsx`)
- `/portal-privacidade` (LGPD)
- `/download-docs` — Download desta documentação

### Locatário (protegidas)
- `/tenant/dashboard` — KPI bar, propostas ativas, matchmaker quiz
- `/tenant/meu-cadastro`
- `/selecionar-imovel`, `/new-rental`
- `/escolher-tipo-proposta`
- `/iniciar-locacao-direta`
- `/enviar-documentos`, `/enviar-documentos-pendentes`, `/envio-sucesso`
- `/segundo-locatario`
- `/acompanhamento/:rentalId`

### Locador (protegidas)
- `/locador/home` — Dashboard com KPIs financeiros
- `/locador/imoveis`, `/locador/imoveis/novo`
- `/locador/anunciar`, `/anunciar-imovel`
- `/locador/propostas`, `/locador/propostas/:id`
- `/locador/ajuda`
- `/landlord/dashboard` (legado)

### Admin (protegidas, role `admin`)
- `/admin` — Kanban board 10 colunas
- `/admin/rentals` — Lista
- `/admin/rentals/:id` — Detalhe
- `/admin/property-invites`
- `/admin/security` — Dashboard de segurança
- `/admin/mapa-produto`

## 4.2. Componentes Reutilizáveis

**UI base** (`src/components/ui/` — shadcn): `button`, `card`, `dialog`, `sheet`, `drawer`, `form`, `input`, `select`, `tabs`, `toast`, `sonner`, `skeleton`, `badge`, `alert`, `accordion`, `calendar`, `carousel`, `chart`, `command`, `date-input` (custom DD/MM/AAAA), `range-slider`, `optimized-image`, `sidebar`.

**Domínio**:
- **Auth**: `ProtectedRoute`, `AdminRoute`, `LocadorRoute`, `SmartRedirect`, `ForgotPasswordDialog`, `PasswordStrengthIndicator`, `ResetPasswordForm`, `ReAuthDialog`.
- **Layout**: `AppHeader`, `PageSkeleton`, `LocadorLayout`.
- **Landing**: `Hero`, `Benefits`, `HowItWorks`, `FAQ`, `Testimonials`, `Security`, `CTASection`, `Footer`, `Header`.
- **Rental**: `PropertyCard`, `PersonalDataForm`, `IncomeDataForm`, `DocumentUpload`, `SecondTenantCard`, `SecondTenantSection`, `RentalTimeline`, `GamificationProgress`, `ProgressBar`, `StickySubmitButton`.
- **Tenant Dashboard**: `TenantHeader`, `TenantKPIBar`, `JourneyCard`, `JourneyStepperHorizontal`, `MatchmakerQuiz`, `ProposalDashboardCard`, `ResourcesCard`, `SmartCTAButton`, `UpdatesFeed`.
- **Landlord Dashboard**: `FinancialKPICards`, `ConversionFunnel`, `PropertyExpandableCard`, `ProposalCard`, `RentalJourneyStepper`, `TenantScoreGauge`, `NotificationBell`, `PriceComparisonWidget`, `TrustBadges`, `VisitFeedbackList`.
- **Admin**: `AdminKanbanBoard`, `AdminKanbanColumn`, `AdminKanbanCard`, `AdminPropertyModal`, `AdminRentalModal`, `AdminRentalHistoryCard`, `AnalyticsDashboard`, `KPICards`.
- **Documents**: `TenantDocumentsUploader`.
- **Property**: `PropertyFilters`, `PropertyImageCarousel`.
- **Tracking**: `GamifiedStepper`.

## 4.3. Cores, Fontes e Estilos

**Tipografia**: `Plus Jakarta Sans` (300-800), via Google Fonts. NUNCA serif.

**Tokens HSL semânticos** (definidos em `src/index.css` e mapeados em `tailwind.config.ts`):
```css
:root {
  --background: 0 0% 100%;
  --foreground: 222 47% 11%;
  --primary: 188 85% 35%;        /* Teal Etic */
  --primary-foreground: 0 0% 100%;
  --secondary: 222 25% 92%;      /* Navy claro */
  --accent: 188 85% 95%;
  --muted: 210 20% 96%;
  --destructive: 0 75% 50%;      /* red */
  --warning: 38 92% 50%;         /* amber */
  --success: 158 64% 40%;        /* emerald */
  --border: 220 13% 91%;
  --ring: 188 85% 35%;
  --radius: 0.75rem;

  /* Gradientes e sombras de marca */
  --gradient-primary: linear-gradient(135deg, hsl(188 85% 35%), hsl(188 85% 50%));
  --shadow-elegant: 0 10px 30px -10px hsl(188 85% 35% / 0.3);
}
```

**Status SLA** (cores fixas semânticas): `emerald` (no prazo), `amber` (atenção), `red` (estourado).

**Regra crítica**: jamais usar classes diretas como `text-white`, `bg-black`. Sempre tokens (`bg-primary`, `text-foreground`).

## 4.4. Layout Responsivo

**Breakpoints Tailwind**: `sm 640px`, `md 768px`, `lg 1024px`, `xl 1280px`, `2xl 1536px`.

**Mobile-first**:
- Bottom sheets em vez de modais.
- FAB de ações em `bottom-[88px]`.
- Footer fixo em `bottom-0 pb-28` para safe-area iOS.
- `tabular-nums` em valores monetários.
- Auto-peek do drawer com pulse/shake quando há pendência.
- Cabeçalho do wizard colapsa no scroll.
- Stepper "windowed" (anterior/atual/próximo) em telas <768px; horizontal completo em desktop.

## 4.5. Fluxo de Navegação

```
Landing (/)
  ├─→ /locatario → /locatario/register → /locatario/verifique-email → /tenant/dashboard
  │                                                                    ├─→ /selecionar-imovel → /new-rental → /enviar-documentos → /envio-sucesso → /acompanhamento/:id
  │                                                                    ├─→ /escolher-tipo-proposta → /iniciar-locacao-direta
  │                                                                    └─→ /tenant/meu-cadastro
  ├─→ /locador → /locador/auth → /locador/home
  │                              ├─→ /locador/imoveis → /locador/imoveis/novo
  │                              ├─→ /locador/propostas → /locador/propostas/:id
  │                              └─→ /locador/anunciar
  └─→ /auth → /admin (role=admin) → Kanban
                                    ├─→ /admin/rentals/:id
                                    ├─→ /admin/property-invites → token → /aceitar-convite/:token
                                    └─→ /admin/security
```

`SmartRedirect` resolve a home certa por role após login. `?redirect=` é preservado (memória `auth/context-preservation-and-stability`).

---

# 5. FUNCIONALIDADES AVANÇADAS

## 5.1. Validações de Formulário

**Stack**: `react-hook-form` + `zod` (resolver `@hookform/resolvers`).
**Schemas centralizados**: `src/lib/validations.ts` e `src/utils/formValidation.ts`.

| Campo | Regra |
|-------|-------|
| `email` | regex RFC 5322 |
| `cpf` | algoritmo dígitos verificadores + máscara `999.999.999-99` |
| `phone` | 10-11 dígitos, máscara dinâmica fixo/celular |
| `cep` | 8 dígitos, máscara `99999-999` |
| `birthDate` | DD/MM/AAAA manual (sem date-picker — memória `date-input-manual`) + idade ≥18 |
| `monthlyIncome` | numérico, sem máscara, conversão para number |
| `password` | min 14, 1 maiúscula, 1 minúscula, 1 número, 1 especial |
| Texto livre | `min(5)` para nome, `min(10)` para descrições |
| Arquivos | máx 10MB, magic byte check (`lib/fileValidation.ts`) |

`scrollToFirstError()` rola para o primeiro campo inválido após `submit`.

## 5.2. Mensagens de Erro/Sucesso

- **Toast inline**: `sonner` (`@/hooks/use-toast`) — sucesso/erro/warning/info.
- **Inline em formulário**: `<FormMessage />` do shadcn, conectado ao Zod.
- **Página de erro**: `Forbidden.tsx` (403) e `NotFound.tsx` (404).
- **Recuperação**: ao falhar upload, fallback de validação client-side (memória `file-upload-validation`).
- **Loading states**: `<Skeleton />` por seção, nunca spinner full-page.

## 5.3. Permissões por Tipo de Usuário

Camadas:
1. **Roteamento**: `<ProtectedRoute>`, `<AdminRoute>`, `<LocadorRoute>` (com fallback resiliente — memória `landlord-auth-resilience`).
2. **RLS Postgres**: políticas permissivas explícitas com `has_role()`. Padrão = deny.
3. **UI**: componentes condicionados via `useAuth().role`.

| Recurso | locatario | locador | admin |
|---------|:---------:|:-------:|:-----:|
| Ver próprios `rentals` | ✅ | imóveis dele | tudo |
| Criar `rental` | ✅ | ❌ | ✅ override |
| Editar `current_step` | ❌ | ❌ | ✅ (com reauth) |
| Ver `documents` | próprios | dos rentals dele | todos |
| Decryptografar CPF | ❌ | ❌ | ✅ (edge function) |
| Acessar `audit_logs` | próprios | ❌ | todos |
| Mover Kanban | ❌ | ❌ | ✅ |

## 5.4. Filtros e Buscas

- **Catálogo de imóveis** (`/selecionar-imovel`): `PropertyFilters` com `RangeSlider` (preço), select de bairro, switch (mobiliado/petfriendly), busca textual debounced 300ms (`useDebounce`).
- **Admin lista** (`/admin/rentals`): filtros por stage, status, tenant_name, protocolo.
- **Locador propostas**: tabs "Urgente" (≤24h) vs "Em análise".

## 5.5. Paginação

- **Catálogo**: scroll infinito com `IntersectionObserver`, 20 itens/lote.
- **Admin lista**: paginação clássica (`<Pagination />`), 25/página.
- **Audit logs**: paginação server-side via Supabase `.range()`.

## 5.6. Notificações e Alertas

- **Web Notifications API**: `useNotificationPermission` solicita permissão; disparada em mudança de step ou nova proposta.
- **Toast (`sonner`)**: feedback imediato.
- **`NotificationBell`** (locador): badge com contador de novidades (Realtime).
- **Sino pulsante** (memória `landlord-dashboard-proposals`): pulsa quando há proposta urgente.
- **`notification_queue`**: fila para integração futura WhatsApp/email (provider via n8n).

---

# 6. INTEGRAÇÕES E APIs

## 6.1. Serviços Externos

| Serviço | Uso | Como |
|---------|-----|------|
| **Supabase** | Auth, DB Postgres, Storage, Realtime, Edge Functions | SDK `@supabase/supabase-js` |
| **VistaSoft** | XML feed de imóveis | Edge function `fetch-properties` (cache 10min, lock 12h) |
| **n8n** | Webhook de validação de locador + sync CRM | `N8N_VALIDATE_LANDLORD_WEBHOOK` |
| **Lovable AI Gateway** | Reservado p/ futuro (matchmaker IA) | `LOVABLE_API_KEY` |
| **Google Fonts** | Plus Jakarta Sans | `<link>` em `index.html` |
| **CRM (futuro)** | Pipedrive/HubSpot | campos `crm_provider`/`crm_deal_id` em `rentals` + `buildCrmReadyPayload()` |
| **Assinatura digital (futuro)** | DocuSign/Clicksign | `contracts.signature_url` |
| **Pagamentos (futuro)** | Boleto/PIX | a definir |

## 6.2. Endpoints (Edge Functions Deno)

Localizadas em `supabase/functions/`. URL base: `https://uxfbydatvcyggzqjumqn.supabase.co/functions/v1/`.

| Função | Método | Auth | Descrição |
|--------|--------|------|-----------|
| `fetch-properties` | POST | anon | Baixa XML VistaSoft, normaliza, salva em `properties_cache` |
| `encrypt-cpf` | POST | JWT | Encripta CPF AES-256-GCM com `CPF_ENCRYPTION_KEY` |
| `validate-landlord` | POST | JWT | Valida cadastro de locador via webhook n8n; atribui role |
| `validate-upload` | POST | JWT | Magic byte check, MIME, tamanho ≤10MB |
| `get-signed-url` | POST | JWT | Gera URL assinada TTL 60s para `documents`/`landlord-documents` |
| `accept-property-invite` | POST | JWT | Consome token `property_invites`, atribui ownership |
| `check-rate-limit` | POST | anon | Consulta/atualiza `auth_rate_limits` |

## 6.3. Autenticação / Tokens

- **Anon key** (publishable): `eyJhbGciOiJIUzI1NiI...l9BSThdQiqo2wvFVzt1X5GqH8swkXcb4xd69qZww0Hw` — pode estar em código.
- **Service role key**: NUNCA no front; apenas em edge functions via `Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')`.
- **JWT**: gerado por `supabase.auth.signInWithPassword`, persistido em `localStorage`, auto-refresh.
- **Tokens de convite**: gerados via `crypto.randomBytes(32)`, armazenados como `token_hash` (SHA-256) em `property_invites`, validade 7 dias.
- **CPF**: AES-256-GCM com `CPF_ENCRYPTION_KEY` (32 bytes), IV aleatório por registro, tag de autenticação concatenada.

## 6.4. Secrets Configurados (Supabase Vault)

```
LOVABLE_API_KEY                  -- Lovable AI Gateway (rotação via tool dedicada)
CPF_ENCRYPTION_KEY               -- 32 bytes hex para AES-256-GCM
N8N_VALIDATE_LANDLORD_WEBHOOK    -- URL do webhook n8n
SUPABASE_URL, SUPABASE_ANON_KEY,
SUPABASE_PUBLISHABLE_KEY,
SUPABASE_SERVICE_ROLE_KEY,
SUPABASE_DB_URL                  -- Auto-provisionados
```

## 6.5. Storage Buckets

| Bucket | Público? | Uso | Path pattern |
|--------|:--------:|-----|--------------|
| `documents` | ❌ | Documentos do locatário | `{user_id}/{filename}` |
| `landlord-documents` | ❌ | Documentos do locador | `{landlord_id}/{rental_id}/{filename}` |
| `property-images` | ✅ | Fotos dos imóveis (sync VistaSoft) | `{property_code}/{n}.jpg` |

URLs assinadas com TTL 60s para buckets privados (memória `seguranca-de-documentos`).

---

# 7. INSTRUÇÕES PARA RECRIAÇÃO

## 7.1. Stack Tecnológico

| Camada | Tecnologia | Versão |
|--------|------------|--------|
| Build tool | Vite | 5.x |
| Framework | React | 18.x |
| Linguagem | TypeScript | 5.x |
| Estilo | Tailwind CSS | 3.x |
| UI primitives | shadcn/ui (Radix UI) | latest |
| Forms | react-hook-form + zod | latest |
| Estado servidor | @tanstack/react-query | 5.x |
| Roteamento | react-router-dom | 6.x |
| Backend | Supabase (Postgres 15 + Auth + Storage + Realtime + Edge Functions Deno) | hosted |
| Toast | sonner | latest |
| Ícones | lucide-react | latest |
| Drag-and-drop (Kanban) | @dnd-kit | latest |
| PDF (download docs) | html2pdf.js + marked | latest |
| Charts | recharts | latest |
| Animação | tailwindcss-animate | latest |
| Testes | vitest + @testing-library/react | latest |
| Datas | date-fns | latest |

## 7.2. Dependências (package.json)

```bash
# Core
bun add react react-dom react-router-dom
bun add @supabase/supabase-js
bun add @tanstack/react-query

# Forms + validação
bun add react-hook-form @hookform/resolvers zod

# UI
bun add tailwindcss postcss autoprefixer tailwindcss-animate
bun add @radix-ui/react-{dialog,dropdown-menu,popover,select,tabs,toast,...}
bun add class-variance-authority clsx tailwind-merge
bun add lucide-react sonner

# Funcionalidades
bun add @dnd-kit/core @dnd-kit/sortable @dnd-kit/utilities
bun add recharts date-fns
bun add html2pdf.js marked

# Dev / Testes
bun add -d vitest @testing-library/react @testing-library/jest-dom jsdom
bun add -d typescript @types/react @types/react-dom
bun add -d eslint @typescript-eslint/parser @typescript-eslint/eslint-plugin
bun add -d vite @vitejs/plugin-react-swc
```

## 7.3. Variáveis de Ambiente (`.env`)

Auto-populadas pelo Lovable ao conectar Supabase:
```env
VITE_SUPABASE_URL=https://uxfbydatvcyggzqjumqn.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=eyJhbGciOiJIUzI1NiIs...
VITE_SUPABASE_PROJECT_ID=uxfbydatvcyggzqjumqn
```

Secrets do servidor (configurar no painel Supabase → Settings → Edge Functions):
```
CPF_ENCRYPTION_KEY=<32 bytes em hex>
N8N_VALIDATE_LANDLORD_WEBHOOK=<URL>
LOVABLE_API_KEY=<gerado pelo gateway>
```

## 7.4. Passos para Reproduzir do Zero

### Etapa 1 — Setup do projeto Lovable
1. Criar novo projeto em `lovable.dev`.
2. Conectar Lovable Cloud (Supabase).
3. Confirmar que `.env` foi populado.

### Etapa 2 — Banco de dados
4. Aplicar migrations na ordem (ver `supabase/migrations/` ou recriar a partir da seção 3 deste documento):
   - `0001_create_enums` — `app_role`, `proposal_status_enum`, `proposal_author`, `rental_proposal_status`.
   - `0002_create_profiles` + trigger `handle_new_user`.
   - `0003_create_user_roles` + função `has_role`.
   - `0004_create_properties` + `properties_cache` + `property_invites`.
   - `0005_create_rentals` + `rental_events` + `rental_steps` (CHECK 1-10).
   - `0006_create_proposals`.
   - `0007_create_documents` + `landlord_documents` + `landlord_data` + `document_types`.
   - `0008_create_contracts` + `inspections`.
   - `0009_create_admin_pipeline_stages` + seed das 10 colunas.
   - `0010_create_audit_logs` + função `log_audit` + trigger `audit_trigger_fn`.
   - `0011_create_auth_rate_limits` + `security_events`.
   - `0012_create_notification_queue`.
5. Aplicar todas as policies RLS (default deny, permissive only — ver tabela completa em `DOCUMENTACAO_COMPLETA.md` §2).
6. Criar buckets de Storage: `documents` (privado), `landlord-documents` (privado), `property-images` (público).

### Etapa 3 — Edge Functions
7. Criar 7 funções em `supabase/functions/` (códigos em `DOCUMENTACAO_COMPLETA.md` §5).
8. Adicionar secrets via painel.

### Etapa 4 — Frontend
9. Configurar `tailwind.config.ts` + `index.css` com tokens HSL (seção 4.3).
10. Importar Plus Jakarta Sans em `index.html`.
11. Criar componentes shadcn via `npx shadcn@latest add <componente>` para todos listados em 4.2.
12. Implementar `AuthContext` + `useAuth` + rotas protegidas.
13. Criar páginas na ordem do fluxo (landings → auth → dashboards → wizard de locação → acompanhamento → admin).
14. Implementar hooks de domínio: `useRentalTracking`, `useTenantDashboard`, `useLandlordDashboard`, `useAdminRentals`, `useDocumentUpload`, `useCpfEncryption`, `useVistaSoftSync`, `useSessionTimeout`, `useAuditLog`, `useNotificationPermission`.
15. Implementar libs auxiliares: `crypto.ts`, `masks.ts`, `validations.ts`, `passwordPolicy.ts`, `rateLimiter.ts`, `fileValidation.ts`, `notifications.ts`, `proposalEvents.ts`, `buildCrmReadyPayload.ts`, `logger.ts`, `scrollToFirstError.ts`.

### Etapa 5 — Integração e seeds
16. Disparar primeira sincronização VistaSoft (`fetch-properties`).
17. Criar usuário admin inicial via SQL: `INSERT INTO user_roles (user_id, role) VALUES ('<seu_uuid>', 'admin');`.
18. Seedar `rental_steps` (1-10) e `admin_pipeline_stages` (10 colunas).
19. Seedar `document_types` com keys `rg`, `cpf`, `comprovante_renda`, `comprovante_residencia`, `iptu`, `matricula`, `dados_bancarios`.

### Etapa 6 — Testes e publicação
20. Rodar `vitest` (`src/test/rental-flow-e2e.test.ts`).
21. Rodar security scan (`security--run_security_scan`).
22. QA manual nos 3 perfis (locatário, locador, admin).
23. Publicar via Lovable.

---

# Anexos

## A. Memórias do projeto (regras imutáveis)

> A pasta `mem://` mantém ~70 memórias detalhando regras técnicas e de produto. As mais críticas:
> - `rental-step-management` — toda mutação via `setRentalStepAndLog`.
> - `rls-policy-architecture` — default deny, sem policies restritivas.
> - `cpf-encryption` — AES-256-GCM, nunca em texto plano.
> - `seguranca-de-documentos` — URLs assinadas TTL 60s.
> - `style-guide` — Plus Jakarta Sans + paleta Teal/Navy.
> - `date-input-manual` — máscara DD/MM/AAAA, sem date-picker.
> - `multi-file-document-upload` — limites 2/6/2/6 arquivos por tipo.
> - `landlord-validation-resilience` — diferenciar erros de rede vs. negócio.

## B. Arquivos-chave para começar

```
src/
├── App.tsx                          # Definição de rotas
├── contexts/AuthContext.tsx         # Provedor de auth
├── hooks/useAuth.ts                 # Hook principal
├── integrations/supabase/client.ts  # Cliente Supabase
├── integrations/supabase/types.ts   # Types gerados (NÃO editar)
├── lib/
│   ├── validations.ts               # Schemas Zod
│   ├── crypto.ts                    # Wrapper para edge functions de CPF
│   └── masks.ts                     # Máscaras BR (CPF/phone/CEP/data)
├── types/
│   ├── index.ts                     # Tipos de domínio
│   └── rental.ts                    # Tipos do ciclo de locação
└── pages/Acompanhamento.tsx         # Tela central da experiência
```

## C. Cross-reference

- **Detalhe técnico exaustivo**: `docs/DOCUMENTACAO_COMPLETA.md` (32 seções).
- **Visão de produto / requisitos**: `docs/PRD_ETIC_CONECTA.md` (14 seções, 20 RFs).
- **Este documento**: visão consolidada para recriação rápida.

---

**FIM DO DOCUMENTO TÉCNICO COMPLETO**
*Etic Conecta © 2026 — Documento oficial para recriação do projeto.*
