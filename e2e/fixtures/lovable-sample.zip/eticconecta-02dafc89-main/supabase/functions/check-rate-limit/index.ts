import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
};

/**
 * Progressive rate limiting:
 * - 5 attempts in 15 min window → block 1 min
 * - 10 attempts → block 5 min
 * - 20 attempts → block 15 min
 * - 30+ attempts → block 60 min
 */
function getBlockDuration(attempts: number): number {
  if (attempts >= 30) return 60;
  if (attempts >= 20) return 15;
  if (attempts >= 10) return 5;
  if (attempts >= 5) return 1;
  return 0;
}

async function hashIdentifier(identifier: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(identifier.toLowerCase().trim());
  const hash = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, '0')).join('');
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const adminClient = createClient(supabaseUrl, serviceKey);

    const { identifier, action } = await req.json();

    if (!identifier || !action) {
      return new Response(
        JSON.stringify({ error: 'identifier and action required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const identifierHash = await hashIdentifier(identifier);
    const windowStart = new Date(Date.now() - 15 * 60 * 1000).toISOString(); // 15 min window

    // Cleanup old entries first (best effort)
    await adminClient.rpc('cleanup_old_rate_limits').catch(() => {});

    // Check existing rate limit entries in window
    const { data: existing } = await adminClient
      .from('auth_rate_limits')
      .select('*')
      .eq('identifier', identifierHash)
      .eq('action', action)
      .gte('first_attempt_at', windowStart)
      .order('first_attempt_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    // Check if currently blocked
    if (existing?.blocked_until) {
      const blockedUntil = new Date(existing.blocked_until);
      if (blockedUntil > new Date()) {
        const remainingSeconds = Math.ceil((blockedUntil.getTime() - Date.now()) / 1000);
        return new Response(
          JSON.stringify({
            allowed: false,
            blocked: true,
            remaining_seconds: remainingSeconds,
            attempts: existing.attempts,
          }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }

    // Increment or create entry
    let attempts: number;
    if (existing) {
      attempts = existing.attempts + 1;
      await adminClient
        .from('auth_rate_limits')
        .update({
          attempts,
          last_attempt_at: new Date().toISOString(),
          blocked_until: getBlockDuration(attempts) > 0
            ? new Date(Date.now() + getBlockDuration(attempts) * 60 * 1000).toISOString()
            : null,
        })
        .eq('id', existing.id);
    } else {
      attempts = 1;
      await adminClient
        .from('auth_rate_limits')
        .insert({
          identifier: identifierHash,
          action,
          attempts: 1,
        });
    }

    const blockMinutes = getBlockDuration(attempts);
    const blocked = blockMinutes > 0;

    // Log security event if blocked
    if (blocked) {
      await adminClient
        .from('security_events')
        .insert({
          event_type: 'rate_limit_block',
          identifier_hash: identifierHash.substring(0, 16), // truncated hash
          metadata: {
            action,
            attempts,
            block_minutes: blockMinutes,
          },
        });
    }

    return new Response(
      JSON.stringify({
        allowed: !blocked,
        blocked,
        remaining_seconds: blocked ? blockMinutes * 60 : 0,
        attempts,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Rate limit error:', error);
    // On error, allow the request (fail open for auth)
    return new Response(
      JSON.stringify({ allowed: true, blocked: false, attempts: 0 }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
