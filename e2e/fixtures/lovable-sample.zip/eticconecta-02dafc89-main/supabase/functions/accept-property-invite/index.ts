import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

function json(status: number, body: unknown) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

function isLikelyToken(token: string) {
  // base64url-ish token, 32+ chars
  return typeof token === "string" && /^[A-Za-z0-9_-]{32,}$/.test(token);
}

async function sha256Hex(input: string): Promise<string> {
  const data = new TextEncoder().encode(input);
  const digest = await crypto.subtle.digest("SHA-256", data);
  const bytes = new Uint8Array(digest);
  return Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("");
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response('ok', { headers: corsHeaders });
  if (req.method !== "POST") return json(405, { error: "Method not allowed" });

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!supabaseUrl || !anonKey || !serviceKey) {
      return json(500, { error: "Server not configured" });
    }

    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) return json(401, { error: "Unauthorized" });

    const tokenJwt = authHeader.slice("Bearer ".length);
    const authClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    // Validate JWT and extract user id
    const { data: claimsData, error: claimsError } = await authClient.auth.getClaims(tokenJwt);
    if (claimsError || !claimsData?.claims?.sub) return json(401, { error: "Unauthorized" });
    const userId = claimsData.claims.sub;

    const { token } = await req.json().catch(() => ({ token: null }));
    if (!token || !isLikelyToken(token)) return json(400, { error: "Invalid token" });

    const tokenHash = await sha256Hex(token);
    const adminClient = createClient(supabaseUrl, serviceKey);

    // Look up invite
    const { data: invite, error: inviteError } = await adminClient
      .from("property_invites")
      .select("id, property_id, expires_at, used_at, used_by, revoked_at")
      .eq("token_hash", tokenHash)
      .maybeSingle();

    if (inviteError) return json(500, { error: "Failed to validate invite" });
    if (!invite) return json(404, { error: "Invite not found" });
    if (invite.revoked_at) return json(410, { error: "Invite revoked" });

    const now = new Date();
    const expiresAt = new Date(invite.expires_at);
    if (Number.isFinite(expiresAt.getTime()) && expiresAt.getTime() < now.getTime()) {
      return json(410, { error: "Invite expired" });
    }

    // Idempotency: if already used by same user, treat as success
    if (invite.used_at) {
      if (invite.used_by === userId) {
        return json(200, { ok: true, property_id: invite.property_id, already_accepted: true });
      }
      return json(409, { error: "Invite already used" });
    }

    // Assign property ownership to user
    const { error: propError } = await adminClient
      .from("properties")
      .update({ owner_id: userId })
      .eq("id", invite.property_id);
    if (propError) return json(500, { error: "Failed to assign property" });

    // Grant locador role (upsert)
    const { error: roleError } = await adminClient
      .from("user_roles")
      .upsert({ user_id: userId, role: "locador" }, { onConflict: "user_id,role" });
    if (roleError) return json(500, { error: "Failed to grant role" });

    // Mark invite as used
    const { error: usedError } = await adminClient
      .from("property_invites")
      .update({ used_at: now.toISOString(), used_by: userId })
      .eq("id", invite.id)
      .is("used_at", null);
    if (usedError) return json(500, { error: "Failed to finalize invite" });

    return json(200, { ok: true, property_id: invite.property_id, role_granted: true });
  } catch (e) {
    console.error("accept-property-invite error:", e);
    return json(500, { error: "Unexpected error" });
  }
});
