import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

// Full property with all fields (internal use)
interface PropertyFull {
  id: string;
  code: string;
  title: string;
  streetName: string;
  neighborhood: string;
  address: string;
  shortAddress: string;
  price: number;
  bedrooms: number;
  bathrooms: number;
  suites: number;
  parkingSpaces: number;
  area: number;
  image: string;
  images: string[];
  condoFee: number;
  iptu: number;
  description: string;
  locacao: boolean;
  venda: boolean;
  status: string;
}

// Light property for listings (smaller payload - ~80% reduction)
interface PropertyLight {
  id: string;
  code: string;
  title: string;
  streetName: string;
  neighborhood: string;
  shortAddress: string;
  price: number;
  bedrooms: number;
  bathrooms: number;
  suites: number;
  parkingSpaces: number;
  area: number;
  image: string;
  images3: string[];
  condoFee: number;
  iptu: number;
}

// Convert full property to light version
function toPropertyLight(prop: PropertyFull): PropertyLight {
  return {
    id: prop.id,
    code: prop.code,
    title: prop.title,
    streetName: prop.streetName,
    neighborhood: prop.neighborhood,
    shortAddress: prop.shortAddress,
    price: prop.price,
    bedrooms: prop.bedrooms,
    bathrooms: prop.bathrooms,
    suites: prop.suites,
    parkingSpaces: prop.parkingSpaces,
    area: prop.area,
    image: prop.image,
    images3: prop.images.slice(0, 3),
    condoFee: prop.condoFee,
    iptu: prop.iptu,
  };
}

interface CacheRow {
  id: string;
  data: PropertyFull[];
  count: number;
  fetched_at: string;
  expires_at: string;
}

function extractText(xml: string, tag: string): string {
  const regex = new RegExp(`<${tag}[^>]*><!\\[CDATA\\[([^\\]]*?)\\]\\]></${tag}>|<${tag}[^>]*>([^<]*)</${tag}>`, "i");
  const match = xml.match(regex);
  return match ? (match[1] || match[2] || "").trim() : "";
}

function extractNumber(xml: string, tag: string): number {
  const text = extractText(xml, tag);
  const cleaned = text.replace(/[^\d.,]/g, "").replace(",", ".");
  return parseFloat(cleaned) || 0;
}

function extractImages(xml: string): string[] {
  const images: string[] = [];
  
  // Vista/VivaReal format: URL is directly inside <Item> tag
  const itemRegex = /<Item[^>]*medium="image"[^>]*>([^<]+)<\/Item>/gi;
  let match;
  while ((match = itemRegex.exec(xml)) !== null) {
    const url = match[1]?.trim();
    if (url?.startsWith("http") && !images.includes(url)) {
      images.push(url);
    }
  }
  
  // Fallback: try any Item tag with URL content
  if (images.length === 0) {
    const anyItemRegex = /<Item[^>]*>([^<]+)<\/Item>/gi;
    while ((match = anyItemRegex.exec(xml)) !== null) {
      const url = match[1]?.trim();
      if (url?.startsWith("http") && !images.includes(url)) {
        images.push(url);
      }
    }
  }
  
  return images;
}

function parseVivaRealListing(listingXml: string): PropertyFull | null {
  try {
    // Check transaction type - For Rent = locação
    const transactionType = extractText(listingXml, "TransactionType").toLowerCase();
    const hasRentalPrice = listingXml.includes("<RentalPrice");
    const isForRent = transactionType.includes("rent") || hasRentalPrice;
    const isForSale = transactionType.includes("sale") || listingXml.includes("<ListPrice");
    
    // Skip if NOT for rent
    if (!isForRent) return null;

    const code = extractText(listingXml, "ListingID");
    const propertyType = extractText(listingXml, "PropertyType");
    const description = extractText(listingXml, "Description");
    
    // Location
    const streetName = extractText(listingXml, "Address");
    const neighborhood = extractText(listingXml, "Neighborhood");
    const city = extractText(listingXml, "City");
    const state = extractText(listingXml, "State");
    
    const fullAddress = [streetName, neighborhood, city, state].filter(Boolean).join(", ");
    const shortAddress = neighborhood || city || "Local não informado";
    
    // Price - prefer rental price
    let price = extractNumber(listingXml, "RentalPrice");
    if (!price) price = extractNumber(listingXml, "ListPrice");
    
    // Details
    const bedrooms = extractNumber(listingXml, "Bedrooms");
    const bathrooms = extractNumber(listingXml, "Bathrooms");
    const suites = extractNumber(listingXml, "Suites");
    const parkingSpaces = extractNumber(listingXml, "Garage");
    // Use LivingArea for usable area (área útil), not LotArea (total area)
    const area = extractNumber(listingXml, "LivingArea");
    const condoFee = extractNumber(listingXml, "PropertyAdministrationFee");
    const iptu = extractNumber(listingXml, "YearlyTax");
    
    const images = extractImages(listingXml);
    const mainImage = images[0] || "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=400&h=300&fit=crop";

    const title = propertyType || `Imóvel ${code}`;

    return {
      id: code,
      code,
      title,
      streetName: streetName || "Rua não informada",
      neighborhood: shortAddress,
      address: fullAddress || "Endereço não informado",
      shortAddress,
      price,
      bedrooms: Math.floor(bedrooms),
      bathrooms: Math.floor(bathrooms),
      suites: Math.floor(suites),
      parkingSpaces: Math.floor(parkingSpaces),
      area: Math.floor(area),
      image: mainImage,
      images,
      condoFee,
      iptu,
      description,
      locacao: isForRent,
      venda: isForSale,
      status: "Ativo",
    };
  } catch (error) {
    console.error("Error parsing listing:", error);
    return null;
  }
}

async function fetchAndParseXML(): Promise<PropertyFull[]> {
  const xmlUrl = "https://eticimov17806-portais.vistahost.com.br/0b54b1f930d61fe652cd78e52c8269fe";
  
  const response = await fetch(xmlUrl, {
    headers: { "Accept": "application/xml, text/xml, */*", "User-Agent": "EticImoveis/1.0" },
  });

  if (!response.ok) throw new Error(`Failed to fetch XML: ${response.status}`);

  const xmlText = await response.text();
  console.log("XML fetched, size:", xmlText.length, "bytes");
  
  // Parse <Listing> elements
  const listingMatches: string[] = [];
  const listingRegex = /<Listing>([\s\S]*?)<\/Listing>/gi;
  let match;
  while ((match = listingRegex.exec(xmlText)) !== null) {
    listingMatches.push(match[0]);
  }
  
  const properties: PropertyFull[] = [];
  for (const listing of listingMatches) {
    const prop = parseVivaRealListing(listing);
    if (prop) properties.push(prop);
  }
  
  console.log("Parsed", properties.length, "rental properties");
  return properties;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    // Initialize Supabase client with service role for cache management
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Check for valid cache
    const { data: cacheData, error: cacheError } = await supabase
      .from("properties_cache")
      .select("*")
      .eq("id", "current")
      .gt("expires_at", new Date().toISOString())
      .single();

    if (!cacheError && cacheData) {
      // Return light version from cache for smaller payload (~80% reduction)
      const lightProperties = (cacheData.data as PropertyFull[]).map(toPropertyLight);
      console.log("Returning cached data (light), count:", cacheData.count);
      return new Response(
        JSON.stringify({ 
          success: true, 
          count: cacheData.count, 
          properties: lightProperties, 
          fetchedAt: cacheData.fetched_at,
          cached: true
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Cache miss or expired - fetch fresh data
    console.log("Cache miss, fetching fresh XML data...");
    const properties = await fetchAndParseXML();
    const now = new Date();
    const expiresAt = new Date(now.getTime() + 10 * 60 * 1000); // 10 minutes

    // Upsert cache
    const { error: upsertError } = await supabase
      .from("properties_cache")
      .upsert({
        id: "current",
        data: properties,
        count: properties.length,
        fetched_at: now.toISOString(),
        expires_at: expiresAt.toISOString(),
      });

    if (upsertError) {
      console.error("Failed to update cache:", upsertError);
      // Continue anyway - return the fresh data
    } else {
      console.log("Cache updated successfully");
    }

    // Return light version for smaller payload (~80% reduction)
    const lightProperties = properties.map(toPropertyLight);
    
    return new Response(
      JSON.stringify({ 
        success: true, 
        count: properties.length, 
        properties: lightProperties, 
        fetchedAt: now.toISOString(),
        cached: false
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    console.error("Error:", errorMessage);
    return new Response(
      JSON.stringify({ success: false, error: errorMessage, properties: [] }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
