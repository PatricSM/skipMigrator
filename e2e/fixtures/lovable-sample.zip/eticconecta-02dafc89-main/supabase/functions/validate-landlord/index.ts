import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Get authorization header
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(
        JSON.stringify({ authorized: false, error: "Token não fornecido" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Create Supabase clients
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    // User client for authentication
    const userClient = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    // Admin client for role management
    const adminClient = createClient(supabaseUrl, supabaseServiceKey);

    // Validate JWT and get user
    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: claimsError } = await userClient.auth.getUser(token);

    if (claimsError || !claimsData?.user) {
      console.error("JWT validation failed:", claimsError);
      return new Response(
        JSON.stringify({ authorized: false, error: "Token inválido" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const userId = claimsData.user.id;
    const userEmail = claimsData.user.email;

    console.log(`Validating landlord access for user: ${userId}`);

    // 1. Check if user already has locador role
    const { data: existingRole } = await adminClient
      .from("user_roles")
      .select("id")
      .eq("user_id", userId)
      .eq("role", "locador")
      .maybeSingle();

    if (existingRole) {
      console.log(`User ${userId} already has locador role`);
      return new Response(
        JSON.stringify({ authorized: true, reason: "existing_role" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // 2. Check if profile already has property_codes (synced by n8n previously)
    const { data: profileWithCodes } = await adminClient
      .from("profiles")
      .select("property_codes, codigo_locador, total_imoveis, phone, full_name")
      .eq("id", userId)
      .maybeSingle();

    if (profileWithCodes?.property_codes) {
      const codes = Array.isArray(profileWithCodes.property_codes) 
        ? profileWithCodes.property_codes 
        : [];
        
      if (codes.length > 0) {
        console.log(`User ${userId} has property_codes from CRM: ${codes.join(', ')}`);
        
        // Assign locador role
        const { error: roleError } = await adminClient
          .from("user_roles")
          .insert({ user_id: userId, role: "locador" });

        if (roleError && !roleError.message.includes('duplicate')) {
          console.error("Failed to assign role:", roleError);
          return new Response(
            JSON.stringify({ authorized: false, error: "Erro ao atribuir permissões" }),
            { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }

        return new Response(
          JSON.stringify({ 
            authorized: true, 
            reason: "crm_synced",
            propertyCodes: codes,
            totalImoveis: profileWithCodes.total_imoveis,
          }),
          { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    }

    // 3. Check if user owns any property in properties table
    const { data: ownedProperties } = await adminClient
      .from("properties")
      .select("id, code")
      .eq("owner_id", userId)
      .limit(1);

    if (ownedProperties && ownedProperties.length > 0) {
      console.log(`User ${userId} owns property: ${ownedProperties[0].code}`);
      
      // Assign locador role
      const { error: roleError } = await adminClient
        .from("user_roles")
        .insert({ user_id: userId, role: "locador" });

      if (roleError && !roleError.message.includes('duplicate')) {
        console.error("Failed to assign role:", roleError);
        return new Response(
          JSON.stringify({ authorized: false, error: "Erro ao atribuir permissões" }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      return new Response(
        JSON.stringify({ authorized: true, reason: "property_owner" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Use profile data already fetched
    const phone = profileWithCodes?.phone;
    const fullName = profileWithCodes?.full_name;

    // 4. Try CRM validation via n8n webhook
    const n8nWebhookUrl = Deno.env.get("N8N_VALIDATE_LANDLORD_WEBHOOK");

    if (!n8nWebhookUrl) {
      console.warn("N8N_VALIDATE_LANDLORD_WEBHOOK not configured, returning pending_approval");
      return new Response(
        JSON.stringify({
          authorized: false,
          error: "Aguarde aprovação do administrador. Entraremos em contato em breve.",
          pending_approval: true,
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!phone) {
      console.log(`User ${userId} has no phone number for CRM validation`);
      return new Response(
        JSON.stringify({
          authorized: false,
          error: "Telefone não cadastrado. Por favor, cadastre-se novamente com seu telefone para validação.",
        }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`Calling n8n webhook for CRM validation: ${phone}`);

    try {
      const webhookResponse = await fetch(n8nWebhookUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          phone,
          email: userEmail,
          userId,
          fullName,
        }),
      });

      if (!webhookResponse.ok) {
        console.error(`n8n webhook failed with status: ${webhookResponse.status}`);
        return new Response(
          JSON.stringify({
            authorized: false,
            error: "Erro ao validar com o CRM. Tente novamente mais tarde.",
          }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const crmResult = await webhookResponse.json();
      console.log(`CRM validation result:`, crmResult);

      if (crmResult.valid === true) {
        // Extract property codes from CRM response (flexible field names)
        const propertyCodes = crmResult.propertyCodes || crmResult.property_codes || 
                              (crmResult.propertyCode ? [crmResult.propertyCode] : []);
        const codigoLocador = crmResult.codigoLocador || crmResult.codigo_locador || null;
        const totalImoveis = crmResult.totalImoveis || crmResult.total_imoveis || propertyCodes.length;

        // Update profile with CRM data
        const { error: updateError } = await adminClient
          .from("profiles")
          .update({
            property_codes: propertyCodes,
            codigo_locador: codigoLocador,
            total_imoveis: totalImoveis,
            last_vista_sync_at: new Date().toISOString(),
            last_vista_sync_status: 'success',
          })
          .eq("id", userId);

        if (updateError) {
          console.error("Failed to update profile with CRM data:", updateError);
        }

        // Assign locador role
        const { error: roleError } = await adminClient
          .from("user_roles")
          .insert({ user_id: userId, role: "locador" });

        if (roleError && !roleError.message.includes('duplicate')) {
          console.error("Failed to assign role after CRM validation:", roleError);
          return new Response(
            JSON.stringify({ authorized: false, error: "Erro ao atribuir permissões" }),
            { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }

        console.log(`User ${userId} validated via CRM and granted locador role`);
        return new Response(
          JSON.stringify({
            authorized: true,
            reason: "crm_validated",
            propertyCodes,
            totalImoveis,
          }),
          { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    } catch (webhookError) {
      console.error("n8n webhook error:", webhookError);
      return new Response(
        JSON.stringify({
          authorized: false,
          error: "Erro ao conectar com o sistema de validação. Tente novamente.",
        }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Not authorized
    console.log(`User ${userId} not authorized - no matching criteria`);
    return new Response(
      JSON.stringify({
        authorized: false,
        error: "Você não está autorizado a acessar a área do proprietário. Entre em contato com a Etic Imóveis.",
      }),
      { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Unexpected error:", error);
    return new Response(
      JSON.stringify({ authorized: false, error: "Erro interno do servidor" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
