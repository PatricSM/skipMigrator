-- Fix RLS Policy Misconfiguration: Remove restrictive policies that block legitimate access
-- These RESTRICTIVE policies with USING(false) block ALL access including authenticated users
-- The existing PERMISSIVE policies already properly secure the tables

-- Drop restrictive "Deny anonymous access" policies
DROP POLICY IF EXISTS "Deny anonymous access to profiles" ON public.profiles;
DROP POLICY IF EXISTS "Deny anonymous access to landlord_data" ON public.landlord_data;
DROP POLICY IF EXISTS "Deny anonymous access to landlord_documents" ON public.landlord_documents;
DROP POLICY IF EXISTS "Deny anonymous access to rentals" ON public.rentals;
DROP POLICY IF EXISTS "Deny anonymous access to rental_events" ON public.rental_events;
DROP POLICY IF EXISTS "Deny anonymous access to properties" ON public.properties;
DROP POLICY IF EXISTS "Deny anonymous access to documents" ON public.documents;
DROP POLICY IF EXISTS "Deny anonymous access to property_invites" ON public.property_invites;