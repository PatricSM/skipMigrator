-- Atualizar funcao handle_new_user para incluir phone e user_type
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
  user_type text;
BEGIN
  user_type := NEW.raw_user_meta_data ->> 'user_type';
  
  -- Inserir perfil com telefone
  INSERT INTO public.profiles (id, full_name, email, phone)
  VALUES (
    NEW.id, 
    NEW.raw_user_meta_data ->> 'full_name', 
    NEW.email,
    NEW.raw_user_meta_data ->> 'phone'
  );
  
  -- Atribuir role 'locatario' apenas se NAO for locador
  -- Locadores serao validados pela edge function validate-landlord
  IF user_type IS NULL OR user_type != 'locador' THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'locatario');
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;