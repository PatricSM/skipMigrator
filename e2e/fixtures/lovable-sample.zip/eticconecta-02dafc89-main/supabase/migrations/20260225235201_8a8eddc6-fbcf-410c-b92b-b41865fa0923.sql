
-- Fix current_step from 1 to 2 for this rental
UPDATE rentals SET current_step = 2 WHERE id = '564907e4-fa47-417a-a4b9-86e374659bad';

-- Insert missing proposal_sent event
INSERT INTO rental_events (rental_id, event_type, description, idempotency_key, metadata)
VALUES (
  '564907e4-fa47-417a-a4b9-86e374659bad',
  'proposal_sent',
  'Proposta de locação enviada pelo locatário.',
  'proposal_sent_cycle_1',
  '{"source": "qa_fix", "note": "Evento criado retroativamente pela correção QA"}'::jsonb
);

-- Insert missing step_changed event (1 -> 2)
INSERT INTO rental_events (rental_id, event_type, description, idempotency_key, metadata)
VALUES (
  '564907e4-fa47-417a-a4b9-86e374659bad',
  'step_changed',
  'Etapa alterada de 1 (Proposta) para 2 (Aceite da Proposta).',
  'from_1_to_2_cycle_1_qa_fix',
  '{"fromStep": 1, "toStep": 2, "reason": "QA auto-fix: proposal_status=waiting_landlord_acceptance requer step 2", "source": "qa_fix"}'::jsonb
);
