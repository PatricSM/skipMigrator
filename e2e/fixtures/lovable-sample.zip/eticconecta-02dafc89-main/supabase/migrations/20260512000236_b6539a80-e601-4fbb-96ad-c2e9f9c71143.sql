UPDATE public.profiles
SET phone = '11999990000',
    phone_clean = '11999990000',
    phone_e164 = '+5511999990000',
    full_name = COALESCE(full_name, 'Marlon Musico')
WHERE email = 'marlon_musico@hotmail.com';

INSERT INTO public.user_roles (user_id, role)
SELECT id, 'locador'::app_role FROM public.profiles WHERE email = 'marlon_musico@hotmail.com'
ON CONFLICT (user_id, role) DO NOTHING;