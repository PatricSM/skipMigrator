-- Add landlord acceptance tracking fields
ALTER TABLE rentals ADD COLUMN IF NOT EXISTS landlord_accepted boolean DEFAULT false;
ALTER TABLE rentals ADD COLUMN IF NOT EXISTS landlord_accepted_at timestamp with time zone;
ALTER TABLE rentals ADD COLUMN IF NOT EXISTS docs_submitted_early boolean DEFAULT false;

-- Add comments for documentation
COMMENT ON COLUMN rentals.landlord_accepted IS 'Whether the landlord has accepted/confirmed the proposal';
COMMENT ON COLUMN rentals.landlord_accepted_at IS 'Timestamp when landlord accepted the proposal';
COMMENT ON COLUMN rentals.docs_submitted_early IS 'Whether tenant submitted docs early (before landlord acceptance in standard flow)';