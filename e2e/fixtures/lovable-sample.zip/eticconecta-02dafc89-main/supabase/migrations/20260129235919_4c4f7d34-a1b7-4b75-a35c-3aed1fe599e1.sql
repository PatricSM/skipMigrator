-- Add proposal_type column to rentals table
-- Values: 'standard' (counter-proposal) or 'direct' (accepted asking price)
ALTER TABLE rentals ADD COLUMN IF NOT EXISTS proposal_type text DEFAULT 'standard';

-- Add proposed_value column for counter-proposals
ALTER TABLE rentals ADD COLUMN IF NOT EXISTS proposed_value numeric;

-- Comments for documentation
COMMENT ON COLUMN rentals.proposal_type IS 'Type: standard (counter-proposal) or direct (accepted asking price)';
COMMENT ON COLUMN rentals.proposed_value IS 'Proposed value by tenant when proposal_type = standard';