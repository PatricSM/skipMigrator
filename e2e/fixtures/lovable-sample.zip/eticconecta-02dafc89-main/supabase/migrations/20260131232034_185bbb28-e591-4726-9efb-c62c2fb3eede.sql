-- ========================================
-- SECURITY HARDENING & LGPD COMPLIANCE
-- ========================================

-- 1. Habilitar RLS na tabela rental_steps
ALTER TABLE public.rental_steps ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read rental steps"
ON public.rental_steps FOR SELECT TO authenticated
USING (true);

CREATE POLICY "Admins can manage rental steps"
ON public.rental_steps FOR ALL
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- 2. Corrigir search_path das funcoes vulneraveis
CREATE OR REPLACE FUNCTION public.validate_phone()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
BEGIN
  IF NEW.phone !~ '^[0-9]{10,11}$' THEN
    RAISE EXCEPTION 'Telefone invalido. Use 10 ou 11 digitos.';
  END IF;
  RETURN NEW;
END;
$function$;

CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$function$;

CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$function$;

CREATE OR REPLACE FUNCTION public.format_phone_on_profile()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  cleaned_phone TEXT;
BEGIN
  IF (TG_OP = 'INSERT') OR 
     (TG_OP = 'UPDATE' AND (
       NEW.phone IS DISTINCT FROM OLD.phone OR
       NEW.phone_clean IS DISTINCT FROM OLD.phone_clean OR
       NEW.phone_e164 IS DISTINCT FROM OLD.phone_e164
     )) THEN
    
    IF NEW.phone_clean IS NOT NULL THEN
      cleaned_phone := regexp_replace(NEW.phone_clean, '[^0-9]', '', 'g');
    ELSIF NEW.phone IS NOT NULL THEN
      cleaned_phone := regexp_replace(NEW.phone, '[^0-9]', '', 'g');
    ELSIF NEW.phone_e164 IS NOT NULL THEN
      cleaned_phone := regexp_replace(NEW.phone_e164, '[^0-9]', '', 'g');
    ELSE
      RETURN NEW;
    END IF;
    
    IF LENGTH(cleaned_phone) >= 12 AND LEFT(cleaned_phone, 2) = '55' THEN
      cleaned_phone := SUBSTRING(cleaned_phone FROM 3);
    END IF;
    
    IF LENGTH(cleaned_phone) NOT BETWEEN 10 AND 11 THEN
      RAISE EXCEPTION 'Telefone invalido. Use 10 ou 11 digitos. Recebido: % (% digitos)', 
        cleaned_phone, LENGTH(cleaned_phone);
    END IF;
    
    NEW.phone := cleaned_phone;
    NEW.phone_clean := cleaned_phone;
    NEW.phone_e164 := '+55' || cleaned_phone;
    
  END IF;
  
  RETURN NEW;
END;
$function$;

CREATE OR REPLACE FUNCTION public.get_user_applications(user_id uuid)
RETURNS TABLE(id uuid, property_title text, status text, current_step text, created_at timestamp with time zone)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
BEGIN
  RETURN QUERY
  SELECT ra.id, p.title, ra.status, ra.current_step, ra.created_at
  FROM public.rental_applications ra
  JOIN public.properties p ON ra.property_id = p.id
  WHERE ra.tenant_id = user_id OR ra.second_tenant_id = user_id OR ra.owner_id = user_id;
END;
$function$;

-- ========================================
-- 3. TABELA DE AUDIT LOGS (LGPD)
-- ========================================

CREATE TABLE public.audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid,
  action text NOT NULL,
  table_name text NOT NULL,
  record_id uuid,
  old_data jsonb,
  new_data jsonb,
  ip_address inet,
  user_agent text,
  created_at timestamp with time zone DEFAULT now() NOT NULL
);

-- Habilitar RLS - somente insert permitido para usuarios
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

-- Politicas de RLS para audit_logs
CREATE POLICY "Users can insert audit logs"
ON public.audit_logs FOR INSERT TO authenticated
WITH CHECK (true);

CREATE POLICY "Admins can read all audit logs"
ON public.audit_logs FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Users can read own audit logs"
ON public.audit_logs FOR SELECT TO authenticated
USING (auth.uid() = user_id);

-- Funcao para registrar audit
CREATE OR REPLACE FUNCTION public.log_audit(
  p_action text,
  p_table_name text,
  p_record_id uuid DEFAULT NULL,
  p_old_data jsonb DEFAULT NULL,
  p_new_data jsonb DEFAULT NULL,
  p_ip_address text DEFAULT NULL,
  p_user_agent text DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  audit_id uuid;
BEGIN
  INSERT INTO public.audit_logs (
    user_id, action, table_name, record_id,
    old_data, new_data, ip_address, user_agent
  ) VALUES (
    auth.uid(), p_action, p_table_name, p_record_id,
    p_old_data, p_new_data, 
    CASE WHEN p_ip_address IS NOT NULL AND p_ip_address != 'unknown' THEN p_ip_address::inet ELSE NULL END, 
    p_user_agent
  )
  RETURNING id INTO audit_id;
  
  RETURN audit_id;
END;
$$;

-- Trigger automatico para tabelas sensiveis
CREATE OR REPLACE FUNCTION public.audit_trigger_fn()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    PERFORM public.log_audit('INSERT', TG_TABLE_NAME, NEW.id, NULL, to_jsonb(NEW));
  ELSIF TG_OP = 'UPDATE' THEN
    PERFORM public.log_audit('UPDATE', TG_TABLE_NAME, NEW.id, to_jsonb(OLD), to_jsonb(NEW));
  ELSIF TG_OP = 'DELETE' THEN
    PERFORM public.log_audit('DELETE', TG_TABLE_NAME, OLD.id, to_jsonb(OLD), NULL);
  END IF;
  RETURN COALESCE(NEW, OLD);
END;
$$;

-- Aplicar triggers nas tabelas sensiveis
CREATE TRIGGER audit_profiles_trigger
AFTER INSERT OR UPDATE OR DELETE ON public.profiles
FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

CREATE TRIGGER audit_documents_trigger
AFTER INSERT OR UPDATE OR DELETE ON public.documents
FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

CREATE TRIGGER audit_rentals_trigger
AFTER INSERT OR UPDATE OR DELETE ON public.rentals
FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();