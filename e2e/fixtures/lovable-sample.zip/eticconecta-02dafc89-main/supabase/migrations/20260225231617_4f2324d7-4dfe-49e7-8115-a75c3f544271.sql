
-- 1) Create proposal_author enum
CREATE TYPE public.proposal_author AS ENUM ('tenant', 'landlord');

-- 2) Create proposal_status_enum
CREATE TYPE public.proposal_status_enum AS ENUM ('pending', 'accepted', 'rejected', 'countered');

-- 3) Create rental_proposal_status enum
CREATE TYPE public.rental_proposal_status AS ENUM (
  'waiting_landlord_acceptance',
  'counter_proposal_pending',
  'proposal_accepted',
  'proposal_rejected'
);

-- 4) Create proposals table
CREATE TABLE public.proposals (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  rental_id uuid NOT NULL REFERENCES public.rentals(id) ON DELETE CASCADE,
  author proposal_author NOT NULL,
  rent_value numeric,
  deposit_value numeric,
  start_date date,
  notes text,
  status proposal_status_enum NOT NULL DEFAULT 'pending',
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- 5) Add proposal_status to rentals
ALTER TABLE public.rentals
  ADD COLUMN IF NOT EXISTS proposal_status rental_proposal_status DEFAULT 'waiting_landlord_acceptance';

-- 6) Add idempotency_key to rental_events
ALTER TABLE public.rental_events
  ADD COLUMN IF NOT EXISTS idempotency_key text;

-- Create unique index for idempotency
CREATE UNIQUE INDEX IF NOT EXISTS idx_rental_events_idempotency
  ON public.rental_events (rental_id, event_type, idempotency_key)
  WHERE idempotency_key IS NOT NULL;

-- 7) Add metadata column to rental_events for storing proposal details
ALTER TABLE public.rental_events
  ADD COLUMN IF NOT EXISTS metadata jsonb;

-- 8) Enable RLS on proposals
ALTER TABLE public.proposals ENABLE ROW LEVEL SECURITY;

-- Tenants can view proposals for their rentals
CREATE POLICY "Tenants can view own proposals"
  ON public.proposals FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM public.rentals r
    WHERE r.id = proposals.rental_id AND r.user_id = auth.uid()
  ));

-- Tenants can create proposals for their rentals
CREATE POLICY "Tenants can insert own proposals"
  ON public.proposals FOR INSERT
  WITH CHECK (
    author = 'tenant' AND
    EXISTS (
      SELECT 1 FROM public.rentals r
      WHERE r.id = proposals.rental_id AND r.user_id = auth.uid()
    )
  );

-- Tenants can update proposals (for accepting/rejecting counter-proposals)
CREATE POLICY "Tenants can update proposals on own rentals"
  ON public.proposals FOR UPDATE
  USING (EXISTS (
    SELECT 1 FROM public.rentals r
    WHERE r.id = proposals.rental_id AND r.user_id = auth.uid()
  ));

-- Landlords can view proposals for their properties
CREATE POLICY "Landlords can view proposals for their properties"
  ON public.proposals FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM public.rentals r
    JOIN public.properties p ON p.id = r.landlord_property_id
    WHERE r.id = proposals.rental_id AND p.owner_id = auth.uid()
  ));

-- Landlords can create counter-proposals
CREATE POLICY "Landlords can insert counter-proposals"
  ON public.proposals FOR INSERT
  WITH CHECK (
    author = 'landlord' AND
    EXISTS (
      SELECT 1 FROM public.rentals r
      JOIN public.properties p ON p.id = r.landlord_property_id
      WHERE r.id = proposals.rental_id AND p.owner_id = auth.uid()
    )
  );

-- Landlords can update proposals
CREATE POLICY "Landlords can update proposals for their properties"
  ON public.proposals FOR UPDATE
  USING (EXISTS (
    SELECT 1 FROM public.rentals r
    JOIN public.properties p ON p.id = r.landlord_property_id
    WHERE r.id = proposals.rental_id AND p.owner_id = auth.uid()
  ));

-- Admins full access
CREATE POLICY "Admins can manage all proposals"
  ON public.proposals FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- Admins can view all proposals
CREATE POLICY "Admins can view all proposals"
  ON public.proposals FOR SELECT
  USING (has_role(auth.uid(), 'admin'::app_role));

-- 9) Create index on proposals.rental_id
CREATE INDEX idx_proposals_rental_id ON public.proposals(rental_id);
