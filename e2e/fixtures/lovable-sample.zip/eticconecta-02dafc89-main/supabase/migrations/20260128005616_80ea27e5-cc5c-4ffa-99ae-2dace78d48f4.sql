-- =============================================
-- SECURITY FIX: Remove Test/Unused Tables
-- =============================================

-- Drop test table 'Testic' (not used in application)
DROP TABLE IF EXISTS "Testic";

-- Drop legacy table 'locacoes' with permissive policies (superseded by 'rentals')
DROP TABLE IF EXISTS "locacoes";

-- =============================================
-- SECURITY FIX: n8n_chat_histories - Add proper RLS
-- (External integration table - restrict direct user access)
-- =============================================

-- Drop overly permissive policies if they exist
DROP POLICY IF EXISTS "Permitir inserção pública" ON n8n_chat_histories;
DROP POLICY IF EXISTS "Permitir leitura própria" ON n8n_chat_histories;

-- Ensure RLS is enabled
ALTER TABLE n8n_chat_histories ENABLE ROW LEVEL SECURITY;

-- For n8n integration, we need service role access only
-- These policies restrict direct user access while allowing service role
CREATE POLICY "Deny direct user access to chat histories"
ON n8n_chat_histories FOR SELECT
TO authenticated
USING (false);

CREATE POLICY "Deny direct user insert to chat histories"
ON n8n_chat_histories FOR INSERT
TO authenticated
WITH CHECK (false);