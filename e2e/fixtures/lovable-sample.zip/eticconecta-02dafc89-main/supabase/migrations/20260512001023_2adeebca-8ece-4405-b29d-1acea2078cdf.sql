UPDATE public.rentals
SET landlord_action_required = true,
    rent_value = COALESCE(rent_value, proposed_value)
WHERE property_code IN ('CPY570','YAP303','GIAP344','JULAP0119');