
-- Add CHECK constraint on rentals.current_step (1-10)
ALTER TABLE public.rentals 
ADD CONSTRAINT rentals_current_step_range 
CHECK (current_step IS NULL OR (current_step >= 1 AND current_step <= 10));
