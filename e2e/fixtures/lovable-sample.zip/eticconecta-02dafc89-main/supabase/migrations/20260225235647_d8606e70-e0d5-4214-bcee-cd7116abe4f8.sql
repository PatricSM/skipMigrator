
-- Simulate landlord counter-proposal: insert proposal and update rental status
INSERT INTO proposals (rental_id, author, rent_value, deposit_value, notes, status)
VALUES (
  '564907e4-fa47-417a-a4b9-86e374659bad',
  'landlord',
  3200,
  6400,
  'Proponho R$ 3.200/mês com 2 meses de caução.',
  'pending'
);

-- Update rental to reflect counter-proposal state
UPDATE rentals SET 
  proposal_status = 'counter_proposal_pending'
WHERE id = '564907e4-fa47-417a-a4b9-86e374659bad';

-- Log the proposal_countered event
INSERT INTO rental_events (rental_id, event_type, description, idempotency_key, metadata)
VALUES (
  '564907e4-fa47-417a-a4b9-86e374659bad',
  'proposal_countered',
  'Contraproposta do locador: R$ 3.200/mês com 2 meses de caução.',
  'counter_sim_1',
  '{"rent_value": 3200, "deposit_value": 6400, "notes": "Proponho R$ 3.200/mês com 2 meses de caução.", "source": "simulation"}'::jsonb
);
