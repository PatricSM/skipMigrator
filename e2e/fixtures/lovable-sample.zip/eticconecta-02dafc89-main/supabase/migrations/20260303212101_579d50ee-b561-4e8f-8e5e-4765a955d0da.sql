
-- 1. rental_full_view: Make it security_invoker so it respects 
--    the calling user's RLS on underlying tables (rentals, profiles, landlord_data)
ALTER VIEW public.rental_full_view SET (security_invoker = true);

-- 2. properties_cache: Replace public SELECT with authenticated-only
DROP POLICY IF EXISTS "Anyone can read properties cache" ON public.properties_cache;
CREATE POLICY "Authenticated users can read properties cache"
  ON public.properties_cache
  FOR SELECT
  TO authenticated
  USING (true);

-- 3. document_types: Replace public SELECT with authenticated-only
DROP POLICY IF EXISTS "Anyone can read document types" ON public.document_types;
CREATE POLICY "Authenticated users can read document types"
  ON public.document_types
  FOR SELECT
  TO authenticated
  USING (true);
