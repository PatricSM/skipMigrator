UPDATE public.profiles
SET property_codes = '["JULAP0119","GIAP344","YAP303","CPY570","JOAP0011"]'::jsonb,
    total_imoveis = 5
WHERE email = 'marlon_musico@hotmail.com';