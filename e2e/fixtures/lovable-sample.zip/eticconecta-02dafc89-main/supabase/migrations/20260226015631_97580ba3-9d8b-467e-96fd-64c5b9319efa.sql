-- Fix search_path on format_brazilian_phone_e164 (linter warning)
CREATE OR REPLACE FUNCTION public.format_brazilian_phone_e164(phone_input text)
 RETURNS text
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path = public
AS $function$
DECLARE
    cleaned_phone TEXT;
BEGIN
    cleaned_phone := regexp_replace(coalesce(phone_input, ''), '[^0-9]', '', 'g');
    IF length(cleaned_phone) = 10 OR length(cleaned_phone) = 11 THEN
        RETURN '+55' || cleaned_phone;
    END IF;
    RETURN NULL;
END;
$function$;