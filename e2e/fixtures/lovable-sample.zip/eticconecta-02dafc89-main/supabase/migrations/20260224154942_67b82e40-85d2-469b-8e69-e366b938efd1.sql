
-- Storage policies for 'documents' bucket
-- Drop existing if any to avoid conflicts
DROP POLICY IF EXISTS "Allow authenticated upload" ON storage.objects;
DROP POLICY IF EXISTS "Allow authenticated select" ON storage.objects;
DROP POLICY IF EXISTS "Allow authenticated delete" ON storage.objects;

-- INSERT: authenticated users can upload to documents bucket
CREATE POLICY "Allow authenticated upload" ON storage.objects
FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'documents');

-- SELECT: authenticated users can read from documents bucket
CREATE POLICY "Allow authenticated select" ON storage.objects
FOR SELECT TO authenticated
USING (bucket_id = 'documents');

-- DELETE: authenticated users can delete from documents bucket
CREATE POLICY "Allow authenticated delete" ON storage.objects
FOR DELETE TO authenticated
USING (bucket_id = 'documents');
