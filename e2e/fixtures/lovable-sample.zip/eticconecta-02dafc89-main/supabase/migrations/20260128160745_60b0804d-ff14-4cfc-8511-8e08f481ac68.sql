-- Fix user_roles RLS: Drop the ineffective RESTRICTIVE policy and create a proper PERMISSIVE policy
-- that enforces the same restriction

-- Drop the existing RESTRICTIVE policy that may not block anonymous access effectively
DROP POLICY IF EXISTS "Deny anonymous access to user_roles" ON public.user_roles;

-- Create a proper policy that ensures only authenticated users can access their own roles
-- The existing "Users can view own roles" policy already handles authenticated access
-- We don't need a "deny anonymous" policy since ONLY permissive policies grant access
-- and anonymous users won't match any of the existing permissive SELECT policies

-- Note: The existing "Users can view own roles" policy with USING (auth.uid() = user_id)
-- already properly restricts access - anonymous users have auth.uid() = NULL which won't match any user_id