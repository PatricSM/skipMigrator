
-- Tabela inspections para vistoria de entrada (Etapas 8-10)
CREATE TABLE public.inspections (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  rental_id uuid NOT NULL REFERENCES public.rentals(id),
  scheduled_date date,
  scheduled_time text,
  location_notes text,
  report_url text,
  signature_url text,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'scheduled', 'completed', 'signed', 'cancelled')),
  signed_by_tenant_at timestamp with time zone,
  signed_by_landlord_at timestamp with time zone,
  keys_delivered_at timestamp with time zone,
  keys_delivered_by uuid,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Trigger para updated_at
CREATE TRIGGER update_inspections_updated_at
  BEFORE UPDATE ON public.inspections
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Index
CREATE INDEX idx_inspections_rental_id ON public.inspections(rental_id);

-- Enable RLS
ALTER TABLE public.inspections ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Admins can manage all inspections"
  ON public.inspections FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Tenants can view own inspections"
  ON public.inspections FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM rentals r WHERE r.id = inspections.rental_id AND r.user_id = auth.uid()
  ));

CREATE POLICY "Tenants can update own inspections"
  ON public.inspections FOR UPDATE
  USING (EXISTS (
    SELECT 1 FROM rentals r WHERE r.id = inspections.rental_id AND r.user_id = auth.uid()
  ));

CREATE POLICY "Tenants can insert inspections for own rentals"
  ON public.inspections FOR INSERT
  WITH CHECK (EXISTS (
    SELECT 1 FROM rentals r WHERE r.id = inspections.rental_id AND r.user_id = auth.uid()
  ));

CREATE POLICY "Landlords can view inspections for their properties"
  ON public.inspections FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM rentals r JOIN properties p ON p.id = r.landlord_property_id
    WHERE r.id = inspections.rental_id AND p.owner_id = auth.uid()
  ));

CREATE POLICY "Landlords can update inspections for their properties"
  ON public.inspections FOR UPDATE
  USING (EXISTS (
    SELECT 1 FROM rentals r JOIN properties p ON p.id = r.landlord_property_id
    WHERE r.id = inspections.rental_id AND p.owner_id = auth.uid()
  ));

CREATE POLICY "Landlords can insert inspections for their properties"
  ON public.inspections FOR INSERT
  WITH CHECK (EXISTS (
    SELECT 1 FROM rentals r JOIN properties p ON p.id = r.landlord_property_id
    WHERE r.id = inspections.rental_id AND p.owner_id = auth.uid()
  ));
