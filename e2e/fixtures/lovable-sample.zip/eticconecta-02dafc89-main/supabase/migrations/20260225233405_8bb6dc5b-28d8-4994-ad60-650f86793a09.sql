
-- Add documents_cycle column for tracking document reopen cycles
ALTER TABLE public.rentals ADD COLUMN IF NOT EXISTS documents_cycle integer NOT NULL DEFAULT 1;

-- Add unique index for idempotency on rental_events (if not exists)
CREATE UNIQUE INDEX IF NOT EXISTS idx_rental_events_idempotency 
ON public.rental_events (rental_id, event_type, idempotency_key) 
WHERE idempotency_key IS NOT NULL;
