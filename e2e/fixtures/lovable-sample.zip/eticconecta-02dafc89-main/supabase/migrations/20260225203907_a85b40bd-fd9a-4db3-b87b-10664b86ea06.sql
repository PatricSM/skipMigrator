-- Add documents_finalized_at to track explicit user finalization
ALTER TABLE public.rentals
ADD COLUMN documents_finalized_at timestamp with time zone DEFAULT NULL;