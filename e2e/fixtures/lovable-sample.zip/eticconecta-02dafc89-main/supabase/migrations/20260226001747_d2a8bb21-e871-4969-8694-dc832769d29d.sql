
-- Create contracts table for Step 6-7
CREATE TABLE public.contracts (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  rental_id uuid NOT NULL REFERENCES public.rentals(id) ON DELETE CASCADE,
  content text,
  preview_url text,
  signature_url text,
  status text NOT NULL DEFAULT 'generated' CHECK (status IN ('generated', 'pending_signature', 'signed', 'cancelled')),
  generated_by uuid,
  signed_by_tenant_at timestamp with time zone,
  signed_by_landlord_at timestamp with time zone,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.contracts ENABLE ROW LEVEL SECURITY;

-- RLS policies
CREATE POLICY "Admins can manage all contracts" ON public.contracts FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Tenants can view own contracts" ON public.contracts FOR SELECT
  USING (EXISTS (SELECT 1 FROM rentals r WHERE r.id = contracts.rental_id AND r.user_id = auth.uid()));

CREATE POLICY "Tenants can update own contracts" ON public.contracts FOR UPDATE
  USING (EXISTS (SELECT 1 FROM rentals r WHERE r.id = contracts.rental_id AND r.user_id = auth.uid()));

CREATE POLICY "Landlords can view contracts for their properties" ON public.contracts FOR SELECT
  USING (EXISTS (SELECT 1 FROM rentals r JOIN properties p ON p.id = r.landlord_property_id WHERE r.id = contracts.rental_id AND p.owner_id = auth.uid()));

CREATE POLICY "Landlords can update contracts for their properties" ON public.contracts FOR UPDATE
  USING (EXISTS (SELECT 1 FROM rentals r JOIN properties p ON p.id = r.landlord_property_id WHERE r.id = contracts.rental_id AND p.owner_id = auth.uid()));

-- Updated_at trigger
CREATE TRIGGER update_contracts_updated_at
  BEFORE UPDATE ON public.contracts
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Index
CREATE INDEX idx_contracts_rental_id ON public.contracts(rental_id);
