-- Cache table for properties from external XML feed
CREATE TABLE public.properties_cache (
  id TEXT PRIMARY KEY DEFAULT 'current',
  data JSONB NOT NULL,
  count INTEGER NOT NULL DEFAULT 0,
  fetched_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at TIMESTAMPTZ NOT NULL DEFAULT (now() + interval '10 minutes')
);

-- Allow public read access (property data is public)
ALTER TABLE public.properties_cache ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read properties cache"
  ON public.properties_cache
  FOR SELECT
  USING (true);

-- Only service role can write (edge function uses service role)
CREATE POLICY "Service role can manage cache"
  ON public.properties_cache
  FOR ALL
  USING (auth.role() = 'service_role')
  WITH CHECK (auth.role() = 'service_role');