
-- CRM-ready fields for future n8n integration
ALTER TABLE public.rentals
  ADD COLUMN IF NOT EXISTS crm_provider text,
  ADD COLUMN IF NOT EXISTS crm_deal_id text,
  ADD COLUMN IF NOT EXISTS crm_last_sync_at timestamptz;

-- Index for quick CRM lookups
CREATE INDEX IF NOT EXISTS idx_rentals_crm_deal_id ON public.rentals (crm_deal_id) WHERE crm_deal_id IS NOT NULL;
