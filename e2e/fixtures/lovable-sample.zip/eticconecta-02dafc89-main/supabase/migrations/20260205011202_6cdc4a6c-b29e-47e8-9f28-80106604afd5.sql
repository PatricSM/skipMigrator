-- Fix audit_logs RLS: Remove permissive INSERT policy that allows any authenticated user
-- Audit logs should only be writable by database triggers (service_role), not end users

-- Drop the overly permissive INSERT policy
DROP POLICY IF EXISTS "Users can insert audit logs" ON public.audit_logs;

-- Create a restrictive policy that only allows service_role to insert
-- Note: Database triggers run with service_role privileges and can bypass RLS
-- This policy ensures direct API calls from users cannot insert fake audit entries
CREATE POLICY "Only service role can insert audit logs"
ON public.audit_logs
FOR INSERT
TO authenticated
WITH CHECK (false);

-- Add comment explaining the security model
COMMENT ON TABLE public.audit_logs IS 'Immutable audit trail. Inserts only via database triggers (audit_trigger_fn). Direct user inserts are blocked by RLS.';