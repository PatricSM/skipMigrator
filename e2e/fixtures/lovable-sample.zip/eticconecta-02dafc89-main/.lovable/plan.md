# Plano: Criar PRD Completo do Sistema Etic Conecta

## Objetivo

Gerar um **PRD (Product Requirements Document)** oficial e completo do sistema, baseado em toda a documentação técnica já consolidada em `docs/DOCUMENTACAO_COMPLETA.md` (32 seções) e no código-fonte do projeto. O PRD servirá como documento de produto — diferente da documentação técnica — focando em **visão, personas, jornadas, requisitos funcionais e não-funcionais, métricas e roadmap**.

## Formato de entrega

- Arquivo Markdown: `docs/PRD_ETIC_CONECTA.md`
- Botão de download adicional na página `/download-docs` (já existente) para baixar o PRD em `.md`
- Ambos os documentos (Documentação Técnica + PRD) ficarão disponíveis lado a lado

## Estrutura do PRD (seções)

### 1. Sumário Executivo
- Visão do produto, proposta de valor, público-alvo, diferenciais

### 2. Contexto e Problema
- Dor do mercado de locação tradicional, oportunidades digitais

### 3. Visão e Objetivos do Produto
- Visão de longo prazo, objetivos estratégicos, KPIs principais

### 4. Personas e Perfis de Usuário
- **Locatário** (inquilino)
- **Locador** (proprietário)
- **Administrador** (equipe Etic)
- Necessidades, dores e ganhos de cada um

### 5. Jornadas do Usuário
- Jornada do Locatário (descoberta → cadastro → escolha → documentos → contrato → chaves)
- Jornada do Locador (cadastro → anúncio → recebimento de propostas → assinatura → entrega)
- Jornada do Admin (pipeline Kanban, validações, override)

### 6. Escopo Funcional (Requisitos Funcionais)
Mapeado a partir das funcionalidades implementadas:
- **RF-01** Autenticação multi-perfil (locatário, locador, admin)
- **RF-02** Cadastro e onboarding de locatário (10 etapas)
- **RF-03** Cadastro e validação de locador (via webhook n8n)
- **RF-04** Catálogo e busca de imóveis (filtros, integração VistaSoft)
- **RF-05** Sistema de propostas (locatário → locador)
- **RF-06** Upload e validação de documentos (magic byte, 10MB)
- **RF-07** Pipeline administrativo Kanban (stages configuráveis)
- **RF-08** Acompanhamento de locação em tempo real (Realtime)
- **RF-09** Notificações browser (step + evento)
- **RF-10** Sistema de convites de imóvel (token hash)
- **RF-11** Gamificação e progresso visual
- **RF-12** Matchmaker (quiz de perfil do locatário)
- **RF-13** Dashboards (locatário, locador, admin)
- **RF-14** Reautenticação para ações sensíveis (admin override)
- **RF-15** Segundo locatário e segundo locador
- **RF-16** Geração e assinatura de contrato
- **RF-17** Eventos e timeline de locação
- **RF-18** Integração CRM-ready (n8n / VistaSoft)

### 7. Requisitos Não-Funcionais
- **Segurança**: RLS em todas as tabelas, criptografia CPF (AES-256-GCM), rate limiting progressivo, anti-enumeração, session timeout 30 min, política de senha forte (14+ chars), magic byte em uploads
- **Performance**: Realtime, debounce, lazy loading, skeletons
- **Acessibilidade**: Semantic HTML, contraste, mobile-first
- **Compatibilidade**: Mobile + desktop responsivo
- **Observabilidade**: Audit logs, environment-aware logger
- **LGPD**: Portal de privacidade, criptografia de dados sensíveis

### 8. Arquitetura de Alto Nível (resumo)
- Stack (React 18, Vite, Tailwind, Supabase/Lovable Cloud)
- Edge Functions principais
- Integrações externas (n8n, VistaSoft)

### 9. Modelo de Dados (resumo)
- Entidades principais: profiles, user_roles, properties, rentals, rental_events, documents, landlord_data, pipeline_stages, property_invites, audit_logs, auth_rate_limits

### 10. Regras de Negócio Críticas
- Ciclo de 10 steps da locação
- Stages do pipeline admin
- Regras de pendência e rejeição
- Matriz de permissões por role
- Limites de documentos por tipo

### 11. Métricas de Sucesso (KPIs)
- Conversão por etapa do funil
- Tempo médio por stage
- Taxa de aprovação de documentos
- NPS (placeholder)
- Volume de propostas/contratos

### 12. Roadmap e Próximos Passos
- Integração CRM real (deal sync n8n)
- App mobile nativo
- Assinatura digital integrada (DocuSign / Clicksign)
- Pagamentos in-app (boleto, PIX)
- Score de crédito automatizado

### 13. Glossário
- Locatário, Locador, Step, Stage, Pipeline, Override, Pendência, Rejeição, Magic Byte, RLS, etc.

### 14. Anexos
- Referência cruzada para `DOCUMENTACAO_COMPLETA.md` (mapa de seções técnicas correspondentes)

## Arquivos a modificar

1. **Criar** `docs/PRD_ETIC_CONECTA.md` — Documento PRD completo (~1500 linhas)
2. **Editar** `src/pages/DownloadDocs.tsx` — Adicionar segundo botão "Baixar PRD (.md)" que importa e disponibiliza o novo arquivo

## Impacto

- Nenhuma alteração em banco de dados, edge functions, autenticação ou lógica de negócio
- Apenas criação de documento + ajuste de UI da página de download (1 botão extra)
- Os dois documentos (Técnico + PRD) serão complementares e baixáveis separadamente
