export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      admin_pipeline_stages: {
        Row: {
          color_key: string
          created_at: string
          id: string
          is_active: boolean
          name: string
          order_index: number
          updated_at: string
        }
        Insert: {
          color_key?: string
          created_at?: string
          id?: string
          is_active?: boolean
          name: string
          order_index: number
          updated_at?: string
        }
        Update: {
          color_key?: string
          created_at?: string
          id?: string
          is_active?: boolean
          name?: string
          order_index?: number
          updated_at?: string
        }
        Relationships: []
      }
      application_documents: {
        Row: {
          application_id: string | null
          created_at: string | null
          document_type_id: string | null
          file_path: string
          id: string
          rejection_reason: string | null
          status: string | null
          uploaded_by: string | null
        }
        Insert: {
          application_id?: string | null
          created_at?: string | null
          document_type_id?: string | null
          file_path: string
          id?: string
          rejection_reason?: string | null
          status?: string | null
          uploaded_by?: string | null
        }
        Update: {
          application_id?: string | null
          created_at?: string | null
          document_type_id?: string | null
          file_path?: string
          id?: string
          rejection_reason?: string | null
          status?: string | null
          uploaded_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "application_documents_application_id_fkey"
            columns: ["application_id"]
            isOneToOne: false
            referencedRelation: "rental_applications"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "application_documents_document_type_id_fkey"
            columns: ["document_type_id"]
            isOneToOne: false
            referencedRelation: "document_types"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "application_documents_uploaded_by_fkey"
            columns: ["uploaded_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      application_events: {
        Row: {
          application_id: string | null
          created_at: string | null
          created_by: string | null
          event_type: string | null
          from_step: string | null
          id: string
          note: string | null
          to_step: string | null
        }
        Insert: {
          application_id?: string | null
          created_at?: string | null
          created_by?: string | null
          event_type?: string | null
          from_step?: string | null
          id?: string
          note?: string | null
          to_step?: string | null
        }
        Update: {
          application_id?: string | null
          created_at?: string | null
          created_by?: string | null
          event_type?: string | null
          from_step?: string | null
          id?: string
          note?: string | null
          to_step?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "application_events_application_id_fkey"
            columns: ["application_id"]
            isOneToOne: false
            referencedRelation: "rental_applications"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "application_events_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      audit_logs: {
        Row: {
          action: string
          created_at: string
          id: string
          ip_address: unknown
          new_data: Json | null
          old_data: Json | null
          record_id: string | null
          table_name: string
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          action: string
          created_at?: string
          id?: string
          ip_address?: unknown
          new_data?: Json | null
          old_data?: Json | null
          record_id?: string | null
          table_name: string
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          action?: string
          created_at?: string
          id?: string
          ip_address?: unknown
          new_data?: Json | null
          old_data?: Json | null
          record_id?: string | null
          table_name?: string
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      auth_rate_limits: {
        Row: {
          action: string
          attempts: number
          blocked_until: string | null
          created_at: string
          first_attempt_at: string
          id: string
          identifier: string
          last_attempt_at: string
        }
        Insert: {
          action: string
          attempts?: number
          blocked_until?: string | null
          created_at?: string
          first_attempt_at?: string
          id?: string
          identifier: string
          last_attempt_at?: string
        }
        Update: {
          action?: string
          attempts?: number
          blocked_until?: string | null
          created_at?: string
          first_attempt_at?: string
          id?: string
          identifier?: string
          last_attempt_at?: string
        }
        Relationships: []
      }
      contracts: {
        Row: {
          content: string | null
          created_at: string
          generated_by: string | null
          id: string
          preview_url: string | null
          rental_id: string
          signature_url: string | null
          signed_by_landlord_at: string | null
          signed_by_tenant_at: string | null
          status: string
          updated_at: string
        }
        Insert: {
          content?: string | null
          created_at?: string
          generated_by?: string | null
          id?: string
          preview_url?: string | null
          rental_id: string
          signature_url?: string | null
          signed_by_landlord_at?: string | null
          signed_by_tenant_at?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          content?: string | null
          created_at?: string
          generated_by?: string | null
          id?: string
          preview_url?: string | null
          rental_id?: string
          signature_url?: string | null
          signed_by_landlord_at?: string | null
          signed_by_tenant_at?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "contracts_rental_id_fkey"
            columns: ["rental_id"]
            isOneToOne: false
            referencedRelation: "rental_full_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "contracts_rental_id_fkey"
            columns: ["rental_id"]
            isOneToOne: false
            referencedRelation: "rentals"
            referencedColumns: ["id"]
          },
        ]
      }
      document_types: {
        Row: {
          id: string
          is_required: boolean | null
          key: string
          label: string
          required_for_role: string | null
          required_step: string | null
        }
        Insert: {
          id?: string
          is_required?: boolean | null
          key: string
          label: string
          required_for_role?: string | null
          required_step?: string | null
        }
        Update: {
          id?: string
          is_required?: boolean | null
          key?: string
          label?: string
          required_for_role?: string | null
          required_step?: string | null
        }
        Relationships: []
      }
      documents: {
        Row: {
          created_at: string
          document_label: string | null
          document_type: string
          file_name: string
          file_path: string
          file_type: string
          id: string
          rental_id: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          status: string
          user_id: string
        }
        Insert: {
          created_at?: string
          document_label?: string | null
          document_type: string
          file_name: string
          file_path: string
          file_type: string
          id?: string
          rental_id?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          user_id: string
        }
        Update: {
          created_at?: string
          document_label?: string | null
          document_type?: string
          file_name?: string
          file_path?: string
          file_type?: string
          id?: string
          rental_id?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "documents_rental_id_fkey"
            columns: ["rental_id"]
            isOneToOne: false
            referencedRelation: "rental_full_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "documents_rental_id_fkey"
            columns: ["rental_id"]
            isOneToOne: false
            referencedRelation: "rentals"
            referencedColumns: ["id"]
          },
        ]
      }
      inspections: {
        Row: {
          created_at: string
          id: string
          keys_delivered_at: string | null
          keys_delivered_by: string | null
          location_notes: string | null
          rental_id: string
          report_url: string | null
          scheduled_date: string | null
          scheduled_time: string | null
          signature_url: string | null
          signed_by_landlord_at: string | null
          signed_by_tenant_at: string | null
          status: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          keys_delivered_at?: string | null
          keys_delivered_by?: string | null
          location_notes?: string | null
          rental_id: string
          report_url?: string | null
          scheduled_date?: string | null
          scheduled_time?: string | null
          signature_url?: string | null
          signed_by_landlord_at?: string | null
          signed_by_tenant_at?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          keys_delivered_at?: string | null
          keys_delivered_by?: string | null
          location_notes?: string | null
          rental_id?: string
          report_url?: string | null
          scheduled_date?: string | null
          scheduled_time?: string | null
          signature_url?: string | null
          signed_by_landlord_at?: string | null
          signed_by_tenant_at?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "inspections_rental_id_fkey"
            columns: ["rental_id"]
            isOneToOne: false
            referencedRelation: "rental_full_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "inspections_rental_id_fkey"
            columns: ["rental_id"]
            isOneToOne: false
            referencedRelation: "rentals"
            referencedColumns: ["id"]
          },
        ]
      }
      landlord_data: {
        Row: {
          bank_account: string | null
          bank_account_type: string | null
          bank_agency: string | null
          bank_name: string | null
          bills_responsible: string | null
          created_at: string
          email: string | null
          full_name: string | null
          has_second_landlord: boolean | null
          id: string
          landlord_id: string
          marital_status: string | null
          phone: string | null
          pix_key: string | null
          profession: string | null
          rental_id: string
          second_landlord_email: string | null
          second_landlord_marital_status: string | null
          second_landlord_name: string | null
          second_landlord_phone: string | null
          second_landlord_profession: string | null
          updated_at: string
        }
        Insert: {
          bank_account?: string | null
          bank_account_type?: string | null
          bank_agency?: string | null
          bank_name?: string | null
          bills_responsible?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          has_second_landlord?: boolean | null
          id?: string
          landlord_id: string
          marital_status?: string | null
          phone?: string | null
          pix_key?: string | null
          profession?: string | null
          rental_id: string
          second_landlord_email?: string | null
          second_landlord_marital_status?: string | null
          second_landlord_name?: string | null
          second_landlord_phone?: string | null
          second_landlord_profession?: string | null
          updated_at?: string
        }
        Update: {
          bank_account?: string | null
          bank_account_type?: string | null
          bank_agency?: string | null
          bank_name?: string | null
          bills_responsible?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          has_second_landlord?: boolean | null
          id?: string
          landlord_id?: string
          marital_status?: string | null
          phone?: string | null
          pix_key?: string | null
          profession?: string | null
          rental_id?: string
          second_landlord_email?: string | null
          second_landlord_marital_status?: string | null
          second_landlord_name?: string | null
          second_landlord_phone?: string | null
          second_landlord_profession?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "landlord_data_rental_id_fkey"
            columns: ["rental_id"]
            isOneToOne: true
            referencedRelation: "rental_full_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "landlord_data_rental_id_fkey"
            columns: ["rental_id"]
            isOneToOne: true
            referencedRelation: "rentals"
            referencedColumns: ["id"]
          },
        ]
      }
      landlord_documents: {
        Row: {
          created_at: string
          document_type: string
          file_name: string
          file_path: string
          file_type: string
          id: string
          landlord_id: string
          rental_id: string
          reviewed_at: string | null
          reviewed_by: string | null
          status: string
        }
        Insert: {
          created_at?: string
          document_type: string
          file_name: string
          file_path: string
          file_type: string
          id?: string
          landlord_id: string
          rental_id: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
        }
        Update: {
          created_at?: string
          document_type?: string
          file_name?: string
          file_path?: string
          file_type?: string
          id?: string
          landlord_id?: string
          rental_id?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "landlord_documents_rental_id_fkey"
            columns: ["rental_id"]
            isOneToOne: false
            referencedRelation: "rental_full_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "landlord_documents_rental_id_fkey"
            columns: ["rental_id"]
            isOneToOne: false
            referencedRelation: "rentals"
            referencedColumns: ["id"]
          },
        ]
      }
      n8n_chat_histories: {
        Row: {
          id: number
          message: Json
          session_id: string
        }
        Insert: {
          id?: number
          message: Json
          session_id: string
        }
        Update: {
          id?: number
          message?: Json
          session_id?: string
        }
        Relationships: []
      }
      notification_queue: {
        Row: {
          application_id: string | null
          channel: string | null
          created_at: string | null
          error_message: string | null
          id: string
          payload: Json | null
          provider_message_id: string | null
          recipient_profile_id: string | null
          sent_at: string | null
          status: string | null
          template_key: string | null
        }
        Insert: {
          application_id?: string | null
          channel?: string | null
          created_at?: string | null
          error_message?: string | null
          id?: string
          payload?: Json | null
          provider_message_id?: string | null
          recipient_profile_id?: string | null
          sent_at?: string | null
          status?: string | null
          template_key?: string | null
        }
        Update: {
          application_id?: string | null
          channel?: string | null
          created_at?: string | null
          error_message?: string | null
          id?: string
          payload?: Json | null
          provider_message_id?: string | null
          recipient_profile_id?: string | null
          sent_at?: string | null
          status?: string | null
          template_key?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "notification_queue_application_id_fkey"
            columns: ["application_id"]
            isOneToOne: false
            referencedRelation: "rental_applications"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "notification_queue_recipient_profile_id_fkey"
            columns: ["recipient_profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          birth_date: string | null
          codigo_locador: number | null
          cpf_encrypted: string | null
          created_at: string
          email: string | null
          full_name: string | null
          has_suspended_properties: boolean | null
          id: string
          is_onboarded: boolean | null
          is_politically_exposed: boolean | null
          last_vista_sync_at: string | null
          last_vista_sync_error: string | null
          last_vista_sync_status: string | null
          marital_status: string | null
          monthly_income: number | null
          nationality: string | null
          nationality_country: string | null
          nome_locador: string | null
          phone: string | null
          phone_clean: string | null
          phone_e164: string | null
          profession: string | null
          property_codes: Json | null
          role: string | null
          total_imoveis: number | null
          updated_at: string
          vista_codigo: string | null
        }
        Insert: {
          birth_date?: string | null
          codigo_locador?: number | null
          cpf_encrypted?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          has_suspended_properties?: boolean | null
          id: string
          is_onboarded?: boolean | null
          is_politically_exposed?: boolean | null
          last_vista_sync_at?: string | null
          last_vista_sync_error?: string | null
          last_vista_sync_status?: string | null
          marital_status?: string | null
          monthly_income?: number | null
          nationality?: string | null
          nationality_country?: string | null
          nome_locador?: string | null
          phone?: string | null
          phone_clean?: string | null
          phone_e164?: string | null
          profession?: string | null
          property_codes?: Json | null
          role?: string | null
          total_imoveis?: number | null
          updated_at?: string
          vista_codigo?: string | null
        }
        Update: {
          birth_date?: string | null
          codigo_locador?: number | null
          cpf_encrypted?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          has_suspended_properties?: boolean | null
          id?: string
          is_onboarded?: boolean | null
          is_politically_exposed?: boolean | null
          last_vista_sync_at?: string | null
          last_vista_sync_error?: string | null
          last_vista_sync_status?: string | null
          marital_status?: string | null
          monthly_income?: number | null
          nationality?: string | null
          nationality_country?: string | null
          nome_locador?: string | null
          phone?: string | null
          phone_clean?: string | null
          phone_e164?: string | null
          profession?: string | null
          property_codes?: Json | null
          role?: string | null
          total_imoveis?: number | null
          updated_at?: string
          vista_codigo?: string | null
        }
        Relationships: []
      }
      properties: {
        Row: {
          address: string
          code: string
          condo_fee: number | null
          created_at: string
          description: string | null
          has_condo: boolean | null
          id: string
          images: string[] | null
          iptu: number | null
          owner_id: string
          rent_value: number | null
          short_address: string
          status: string
          updated_at: string
        }
        Insert: {
          address: string
          code: string
          condo_fee?: number | null
          created_at?: string
          description?: string | null
          has_condo?: boolean | null
          id?: string
          images?: string[] | null
          iptu?: number | null
          owner_id: string
          rent_value?: number | null
          short_address: string
          status?: string
          updated_at?: string
        }
        Update: {
          address?: string
          code?: string
          condo_fee?: number | null
          created_at?: string
          description?: string | null
          has_condo?: boolean | null
          id?: string
          images?: string[] | null
          iptu?: number | null
          owner_id?: string
          rent_value?: number | null
          short_address?: string
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      properties_cache: {
        Row: {
          count: number
          data: Json
          expires_at: string
          fetched_at: string
          id: string
        }
        Insert: {
          count?: number
          data: Json
          expires_at?: string
          fetched_at?: string
          id?: string
        }
        Update: {
          count?: number
          data?: Json
          expires_at?: string
          fetched_at?: string
          id?: string
        }
        Relationships: []
      }
      property_invites: {
        Row: {
          created_at: string
          created_by: string
          expires_at: string
          id: string
          property_id: string
          revoked_at: string | null
          token_hash: string
          used_at: string | null
          used_by: string | null
        }
        Insert: {
          created_at?: string
          created_by: string
          expires_at: string
          id?: string
          property_id: string
          revoked_at?: string | null
          token_hash: string
          used_at?: string | null
          used_by?: string | null
        }
        Update: {
          created_at?: string
          created_by?: string
          expires_at?: string
          id?: string
          property_id?: string
          revoked_at?: string | null
          token_hash?: string
          used_at?: string | null
          used_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "property_invites_property_id_fkey"
            columns: ["property_id"]
            isOneToOne: false
            referencedRelation: "properties"
            referencedColumns: ["id"]
          },
        ]
      }
      proposals: {
        Row: {
          author: Database["public"]["Enums"]["proposal_author"]
          created_at: string
          deposit_value: number | null
          id: string
          notes: string | null
          rent_value: number | null
          rental_id: string
          start_date: string | null
          status: Database["public"]["Enums"]["proposal_status_enum"]
        }
        Insert: {
          author: Database["public"]["Enums"]["proposal_author"]
          created_at?: string
          deposit_value?: number | null
          id?: string
          notes?: string | null
          rent_value?: number | null
          rental_id: string
          start_date?: string | null
          status?: Database["public"]["Enums"]["proposal_status_enum"]
        }
        Update: {
          author?: Database["public"]["Enums"]["proposal_author"]
          created_at?: string
          deposit_value?: number | null
          id?: string
          notes?: string | null
          rent_value?: number | null
          rental_id?: string
          start_date?: string | null
          status?: Database["public"]["Enums"]["proposal_status_enum"]
        }
        Relationships: [
          {
            foreignKeyName: "proposals_rental_id_fkey"
            columns: ["rental_id"]
            isOneToOne: false
            referencedRelation: "rental_full_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "proposals_rental_id_fkey"
            columns: ["rental_id"]
            isOneToOne: false
            referencedRelation: "rentals"
            referencedColumns: ["id"]
          },
        ]
      }
      rental_applications: {
        Row: {
          created_at: string | null
          current_step: string | null
          id: string
          is_direct_rental: boolean | null
          owner_id: string | null
          property_id: string | null
          second_tenant_id: string | null
          status: string | null
          tenant_id: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          current_step?: string | null
          id?: string
          is_direct_rental?: boolean | null
          owner_id?: string | null
          property_id?: string | null
          second_tenant_id?: string | null
          status?: string | null
          tenant_id?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          current_step?: string | null
          id?: string
          is_direct_rental?: boolean | null
          owner_id?: string | null
          property_id?: string | null
          second_tenant_id?: string | null
          status?: string | null
          tenant_id?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "rental_applications_owner_id_fkey"
            columns: ["owner_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "rental_applications_property_id_fkey"
            columns: ["property_id"]
            isOneToOne: false
            referencedRelation: "properties"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "rental_applications_second_tenant_id_fkey"
            columns: ["second_tenant_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "rental_applications_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      rental_events: {
        Row: {
          created_at: string | null
          created_by: string | null
          description: string
          event_type: string
          id: string
          idempotency_key: string | null
          metadata: Json | null
          rental_id: string
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          description: string
          event_type: string
          id?: string
          idempotency_key?: string | null
          metadata?: Json | null
          rental_id: string
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          description?: string
          event_type?: string
          id?: string
          idempotency_key?: string | null
          metadata?: Json | null
          rental_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "rental_events_rental_id_fkey"
            columns: ["rental_id"]
            isOneToOne: false
            referencedRelation: "rental_full_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "rental_events_rental_id_fkey"
            columns: ["rental_id"]
            isOneToOne: false
            referencedRelation: "rentals"
            referencedColumns: ["id"]
          },
        ]
      }
      rental_steps: {
        Row: {
          created_at: string
          description: string | null
          is_active: boolean
          name: string
          responsible: string
          sla_hours: number | null
          step_number: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          is_active?: boolean
          name: string
          responsible?: string
          sla_hours?: number | null
          step_number: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          is_active?: boolean
          name?: string
          responsible?: string
          sla_hours?: number | null
          step_number?: number
          updated_at?: string
        }
        Relationships: []
      }
      rentals: {
        Row: {
          admin_stage: number
          admin_stage_entered_at: string
          admin_stage_id: string | null
          condo_fee: number | null
          contract_preview_url: string | null
          contract_sign_url: string | null
          created_at: string | null
          crm_deal_id: string | null
          crm_last_sync_at: string | null
          crm_provider: string | null
          current_step: number | null
          docs_submitted_early: boolean | null
          documents_cycle: number
          documents_finalized_at: string | null
          has_pending: boolean | null
          id: string
          iptu: number | null
          is_rejected: boolean | null
          landlord_accepted: boolean | null
          landlord_accepted_at: string | null
          landlord_action_required: boolean | null
          landlord_progress: number | null
          landlord_property_id: string | null
          pending_description: string | null
          pending_documents: Json | null
          pending_reason: string | null
          property_address: string
          property_code: string
          property_id: string
          proposal_status:
            | Database["public"]["Enums"]["rental_proposal_status"]
            | null
          proposal_type: string | null
          proposed_value: number | null
          protocol: string
          rejection_reason: string | null
          rent_value: number | null
          step_status: string | null
          steps_version: string | null
          tenant_status: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          admin_stage?: number
          admin_stage_entered_at?: string
          admin_stage_id?: string | null
          condo_fee?: number | null
          contract_preview_url?: string | null
          contract_sign_url?: string | null
          created_at?: string | null
          crm_deal_id?: string | null
          crm_last_sync_at?: string | null
          crm_provider?: string | null
          current_step?: number | null
          docs_submitted_early?: boolean | null
          documents_cycle?: number
          documents_finalized_at?: string | null
          has_pending?: boolean | null
          id?: string
          iptu?: number | null
          is_rejected?: boolean | null
          landlord_accepted?: boolean | null
          landlord_accepted_at?: string | null
          landlord_action_required?: boolean | null
          landlord_progress?: number | null
          landlord_property_id?: string | null
          pending_description?: string | null
          pending_documents?: Json | null
          pending_reason?: string | null
          property_address: string
          property_code: string
          property_id: string
          proposal_status?:
            | Database["public"]["Enums"]["rental_proposal_status"]
            | null
          proposal_type?: string | null
          proposed_value?: number | null
          protocol: string
          rejection_reason?: string | null
          rent_value?: number | null
          step_status?: string | null
          steps_version?: string | null
          tenant_status?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          admin_stage?: number
          admin_stage_entered_at?: string
          admin_stage_id?: string | null
          condo_fee?: number | null
          contract_preview_url?: string | null
          contract_sign_url?: string | null
          created_at?: string | null
          crm_deal_id?: string | null
          crm_last_sync_at?: string | null
          crm_provider?: string | null
          current_step?: number | null
          docs_submitted_early?: boolean | null
          documents_cycle?: number
          documents_finalized_at?: string | null
          has_pending?: boolean | null
          id?: string
          iptu?: number | null
          is_rejected?: boolean | null
          landlord_accepted?: boolean | null
          landlord_accepted_at?: string | null
          landlord_action_required?: boolean | null
          landlord_progress?: number | null
          landlord_property_id?: string | null
          pending_description?: string | null
          pending_documents?: Json | null
          pending_reason?: string | null
          property_address?: string
          property_code?: string
          property_id?: string
          proposal_status?:
            | Database["public"]["Enums"]["rental_proposal_status"]
            | null
          proposal_type?: string | null
          proposed_value?: number | null
          protocol?: string
          rejection_reason?: string | null
          rent_value?: number | null
          step_status?: string | null
          steps_version?: string | null
          tenant_status?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "rentals_admin_stage_id_fkey"
            columns: ["admin_stage_id"]
            isOneToOne: false
            referencedRelation: "admin_pipeline_stages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "rentals_landlord_property_id_fkey"
            columns: ["landlord_property_id"]
            isOneToOne: false
            referencedRelation: "properties"
            referencedColumns: ["id"]
          },
        ]
      }
      security_events: {
        Row: {
          created_at: string
          event_type: string
          id: string
          identifier_hash: string | null
          metadata: Json | null
        }
        Insert: {
          created_at?: string
          event_type: string
          id?: string
          identifier_hash?: string | null
          metadata?: Json | null
        }
        Update: {
          created_at?: string
          event_type?: string
          id?: string
          identifier_hash?: string | null
          metadata?: Json | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      rental_full_view: {
        Row: {
          admin_stage: number | null
          admin_stage_entered_at: string | null
          admin_stage_id: string | null
          bank_account: string | null
          bank_agency: string | null
          bank_name: string | null
          bills_responsible: string | null
          condo_fee: number | null
          contract_preview_url: string | null
          contract_sign_url: string | null
          created_at: string | null
          current_step: number | null
          event_count: number | null
          has_pending: boolean | null
          has_second_landlord: boolean | null
          id: string | null
          iptu: number | null
          is_rejected: boolean | null
          landlord_action_required: boolean | null
          landlord_doc_count: number | null
          landlord_email: string | null
          landlord_name: string | null
          landlord_phone: string | null
          landlord_progress: number | null
          landlord_property_id: string | null
          pending_description: string | null
          pending_documents: Json | null
          pending_reason: string | null
          pix_key: string | null
          property_address: string | null
          property_code: string | null
          protocol: string | null
          rejection_reason: string | null
          rent_value: number | null
          second_landlord_email: string | null
          second_landlord_name: string | null
          second_landlord_phone: string | null
          stage_color: string | null
          stage_name: string | null
          stage_order: number | null
          step_status: string | null
          tenant_birth_date: string | null
          tenant_cpf_encrypted: string | null
          tenant_doc_count: number | null
          tenant_email: string | null
          tenant_is_pep: boolean | null
          tenant_marital_status: string | null
          tenant_monthly_income: number | null
          tenant_name: string | null
          tenant_nationality: string | null
          tenant_phone: string | null
          tenant_profession: string | null
          tenant_status: string | null
          updated_at: string | null
        }
        Relationships: [
          {
            foreignKeyName: "rentals_admin_stage_id_fkey"
            columns: ["admin_stage_id"]
            isOneToOne: false
            referencedRelation: "admin_pipeline_stages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "rentals_landlord_property_id_fkey"
            columns: ["landlord_property_id"]
            isOneToOne: false
            referencedRelation: "properties"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Functions: {
      cleanup_old_rate_limits: { Args: never; Returns: undefined }
      format_brazilian_phone_e164: {
        Args: { phone_input: string }
        Returns: string
      }
      get_user_applications: {
        Args: { user_id: string }
        Returns: {
          created_at: string
          current_step: string
          id: string
          property_title: string
          status: string
        }[]
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      log_audit: {
        Args: {
          p_action: string
          p_ip_address?: string
          p_new_data?: Json
          p_old_data?: Json
          p_record_id?: string
          p_table_name: string
          p_user_agent?: string
        }
        Returns: string
      }
    }
    Enums: {
      app_role: "locatario" | "locador" | "admin"
      proposal_author: "tenant" | "landlord"
      proposal_status_enum: "pending" | "accepted" | "rejected" | "countered"
      rental_proposal_status:
        | "waiting_landlord_acceptance"
        | "counter_proposal_pending"
        | "proposal_accepted"
        | "proposal_rejected"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["locatario", "locador", "admin"],
      proposal_author: ["tenant", "landlord"],
      proposal_status_enum: ["pending", "accepted", "rejected", "countered"],
      rental_proposal_status: [
        "waiting_landlord_acceptance",
        "counter_proposal_pending",
        "proposal_accepted",
        "proposal_rejected",
      ],
    },
  },
} as const
