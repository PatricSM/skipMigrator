import React, { createContext, useEffect, useState, useCallback, useRef } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import type { Profile, AppRole } from '@/types';

interface RegisterOptions {
  phone?: string;
  userType?: 'locatario' | 'locador';
}

interface AuthContextType {
  user: User | null;
  session: Session | null;
  profile: Profile | null;
  roles: AppRole[];
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<{ error: Error | null }>;
  register: (email: string, password: string, fullName: string, options?: RegisterOptions) => Promise<{ error: Error | null; user: User | null }>;
  logout: () => Promise<void>;
  resetPassword: (email: string) => Promise<{ error: Error | null }>;
  updatePassword: (newPassword: string) => Promise<{ error: Error | null }>;
  hasRole: (role: AppRole) => boolean;
  isAdmin: boolean;
  isLandlord: boolean;
  isTenant: boolean;
  refreshProfile: () => Promise<void>;
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [roles, setRoles] = useState<AppRole[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const explicitLogoutRef = useRef<(() => void) | null>(null);

  const fetchProfile = useCallback(async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .maybeSingle();

      if (error) {
        console.error('Error fetching profile:', error);
        return null;
      }

      return data as Profile | null;
    } catch (err) {
      console.error('Error in fetchProfile:', err);
      return null;
    }
  }, []);

  const fetchRoles = useCallback(async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', userId);

      if (error) {
        console.error('Error fetching roles:', error);
        return [];
      }

      return (data?.map((r) => r.role) || []) as AppRole[];
    } catch (err) {
      console.error('Error in fetchRoles:', err);
      return [];
    }
  }, []);

  const refreshProfile = useCallback(async () => {
    if (!user) return;
    
    const [profileData, rolesData] = await Promise.all([
      fetchProfile(user.id),
      fetchRoles(user.id),
    ]);

    setProfile(profileData);
    setRoles(rolesData);
  }, [user, fetchProfile, fetchRoles]);

  const handleInvalidRefreshToken = useCallback(async () => {
    console.warn('Invalid Refresh Token detected - clearing session');
    
    // Mark as explicit so onAuthStateChange clears state
    explicitLogoutRef.current?.();
    
    // Limpar estado local primeiro
    setUser(null);
    setSession(null);
    setProfile(null);
    setRoles([]);
    setIsLoading(false);
    
    // Limpar sessão no Supabase (ignora erros pois já é inválida)
    try {
      await supabase.auth.signOut({ scope: 'local' });
    } catch (e) {
      console.warn('Error during signOut cleanup:', e);
    }
    
    // Limpar storage de forma genérica (sem depender do project id)
    Object.keys(localStorage)
      .filter(key => key.startsWith('sb-') && key.endsWith('-auth-token'))
      .forEach(key => localStorage.removeItem(key));
    
    // Toast informativo
    toast({
      title: "Sessão expirada",
      description: "Faça login novamente para continuar.",
      variant: "destructive",
    });
    
    // Redirecionar com base na rota atual, preservando redirect para retornar
    const path = window.location.pathname;
    const currentUrl = encodeURIComponent(path + window.location.search);
    if (path.startsWith('/locatario')) {
      window.location.href = `/locatario/login?redirect=${currentUrl}`;
    } else if (path.startsWith('/admin')) {
      window.location.href = '/login';
    } else if (path.startsWith('/locador')) {
      window.location.href = '/locador/auth';
    } else {
      window.location.href = `/locatario/login?redirect=${currentUrl}`;
    }
  }, []);

  useEffect(() => {
    let isExplicitLogout = false;

    // Set up auth state change listener FIRST
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, currentSession) => {
        // Track explicit logouts to distinguish from token refresh flickers
        if (event === 'SIGNED_OUT') {
          if (isExplicitLogout) {
            // Explicit logout — clear state immediately
            setSession(null);
            setUser(null);
            setProfile(null);
            setRoles([]);
            setIsLoading(false);
          }
          // Ignore non-explicit SIGNED_OUT (token refresh flicker)
          return;
        }

        setSession(currentSession);
        setUser(currentSession?.user ?? null);

        if (currentSession?.user) {
          // Use setTimeout to avoid potential deadlock with Supabase
          setTimeout(async () => {
            const [profileData, rolesData] = await Promise.all([
              fetchProfile(currentSession.user.id),
              fetchRoles(currentSession.user.id),
            ]);
            setProfile(profileData);
            setRoles(rolesData);
            setIsLoading(false);
          }, 0);
        } else {
          setProfile(null);
          setRoles([]);
          setIsLoading(false);
        }
      }
    );

    // THEN check for existing session
    supabase.auth.getSession().then(({ data: { session: existingSession }, error }) => {
      // Tratar erro de refresh token inválido
      if (error) {
        const errorCode = ((error as any)?.code || '').toLowerCase();
        const errorMessage = (error.message || '').toLowerCase();
        
        const isInvalidRefreshToken = 
          errorCode === 'refresh_token_not_found' ||
          errorCode === 'session_expired' ||
          errorMessage.includes('invalid refresh token') ||
          errorMessage.includes('refresh token not found') ||
          errorMessage.includes('session expired');
        
        if (isInvalidRefreshToken) {
          handleInvalidRefreshToken();
          return;
        }
        
        console.error('Error getting session:', error);
      }
      
      if (!existingSession) {
        setIsLoading(false);
      }
      // The onAuthStateChange will handle the session if it exists
    });

    // Expose the explicit logout flag setter
    explicitLogoutRef.current = () => { isExplicitLogout = true; };

    return () => {
      subscription.unsubscribe();
    };
  }, [fetchProfile, fetchRoles, handleInvalidRefreshToken]);

  const login = async (email: string, password: string) => {
    try {
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      return { error: error ? new Error(error.message) : null };
    } catch (err) {
      return { error: err as Error };
    }
  };

  const register = async (email: string, password: string, fullName: string, options?: RegisterOptions) => {
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: `${window.location.origin}/locatario/painel`,
          data: {
            full_name: fullName,
            phone: options?.phone,
            user_type: options?.userType,
          },
        },
      });

      return { 
        error: error ? new Error(error.message) : null,
        user: data?.user ?? null,
      };
    } catch (err) {
      return { error: err as Error, user: null };
    }
  };

  const logout = async () => {
    // Signal to onAuthStateChange that this is an explicit logout
    explicitLogoutRef.current?.();
    await supabase.auth.signOut();
    setUser(null);
    setSession(null);
    setProfile(null);
    setRoles([]);
  };

  const resetPassword = async (email: string) => {
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password`,
      });

      return { error: error ? new Error(error.message) : null };
    } catch (err) {
      return { error: err as Error };
    }
  };

  const updatePassword = async (newPassword: string) => {
    try {
      const { error } = await supabase.auth.updateUser({
        password: newPassword,
      });

      return { error: error ? new Error(error.message) : null };
    } catch (err) {
      return { error: err as Error };
    }
  };

  const hasRole = useCallback((role: AppRole) => {
    return roles.includes(role);
  }, [roles]);

  const value: AuthContextType = {
    user,
    session,
    profile,
    roles,
    isLoading,
    isAuthenticated: !!user,
    login,
    register,
    logout,
    resetPassword,
    updatePassword,
    hasRole,
    isAdmin: roles.includes('admin'),
    isLandlord: roles.includes('locador'),
    isTenant: roles.includes('locatario'),
    refreshProfile,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}
