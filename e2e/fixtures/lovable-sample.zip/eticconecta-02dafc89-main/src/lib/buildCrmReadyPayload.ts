import { supabase } from '@/integrations/supabase/client';

export interface CrmReadyPayload {
  rental: {
    id: string;
    protocol: string;
    current_step: number;
    step_status: string | null;
    proposal_status: string | null;
    tenant_status: string | null;
    is_rejected: boolean;
    property_code: string;
    property_address: string;
    rent_value: number | null;
    condo_fee: number | null;
    iptu: number | null;
    created_at: string | null;
    updated_at: string | null;
    crm_provider: string | null;
    crm_deal_id: string | null;
    crm_last_sync_at: string | null;
  };
  tenant: {
    full_name: string | null;
    email: string | null;
    phone: string | null;
    profession: string | null;
    marital_status: string | null;
  } | null;
  landlord: {
    full_name: string | null;
    email: string | null;
    phone: string | null;
    bank_name: string | null;
    pix_key: string | null;
  } | null;
  documents: {
    source: 'tenant' | 'landlord';
    document_type: string;
    file_name: string;
    file_path: string;
    bucket: string;
    status: string;
    created_at: string;
  }[];
  recent_events: {
    event_type: string;
    description: string;
    created_at: string | null;
  }[];
  links: {
    admin_detail: string;
    tenant_tracking: string;
  };
}

/**
 * Builds a consolidated JSON payload for future CRM (n8n) integration.
 * Does NOT call external services — returns data from Supabase only.
 */
export async function buildCrmReadyPayload(rentalId: string): Promise<CrmReadyPayload | null> {
  // 1. Rental
  const { data: rental } = await supabase
    .from('rentals')
    .select('id, protocol, current_step, step_status, proposal_status, tenant_status, is_rejected, property_code, property_address, rent_value, condo_fee, iptu, created_at, updated_at, user_id, crm_provider, crm_deal_id, crm_last_sync_at')
    .eq('id', rentalId)
    .maybeSingle();

  if (!rental) return null;

  // 2. Tenant profile
  const { data: tenant } = await supabase
    .from('profiles')
    .select('full_name, email, phone, profession, marital_status')
    .eq('id', rental.user_id)
    .maybeSingle();

  // 3. Landlord data
  const { data: landlord } = await supabase
    .from('landlord_data')
    .select('full_name, email, phone, bank_name, pix_key')
    .eq('rental_id', rentalId)
    .maybeSingle();

  // 4. Documents (tenant + landlord)
  const { data: tenantDocs } = await supabase
    .from('documents')
    .select('document_type, file_name, file_path, status, created_at')
    .eq('rental_id', rentalId)
    .order('created_at', { ascending: false });

  const { data: landlordDocs } = await supabase
    .from('landlord_documents')
    .select('document_type, file_name, file_path, status, created_at')
    .eq('rental_id', rentalId)
    .order('created_at', { ascending: false });

  const documents: CrmReadyPayload['documents'] = [
    ...(tenantDocs ?? []).map((d) => ({
      source: 'tenant' as const,
      document_type: d.document_type,
      file_name: d.file_name,
      file_path: d.file_path,
      bucket: 'documents',
      status: d.status,
      created_at: d.created_at,
    })),
    ...(landlordDocs ?? []).map((d) => ({
      source: 'landlord' as const,
      document_type: d.document_type,
      file_name: d.file_name,
      file_path: d.file_path,
      bucket: 'landlord-documents',
      status: d.status,
      created_at: d.created_at,
    })),
  ];

  // 5. Recent events (last 10)
  const { data: events } = await supabase
    .from('rental_events')
    .select('event_type, description, created_at')
    .eq('rental_id', rentalId)
    .order('created_at', { ascending: false })
    .limit(10);

  return {
    rental: {
      id: rental.id,
      protocol: rental.protocol,
      current_step: rental.current_step ?? 1,
      step_status: rental.step_status,
      proposal_status: rental.proposal_status,
      tenant_status: rental.tenant_status,
      is_rejected: rental.is_rejected ?? false,
      property_code: rental.property_code,
      property_address: rental.property_address,
      rent_value: rental.rent_value ? Number(rental.rent_value) : null,
      condo_fee: rental.condo_fee ? Number(rental.condo_fee) : null,
      iptu: rental.iptu ? Number(rental.iptu) : null,
      created_at: rental.created_at,
      updated_at: rental.updated_at,
      crm_provider: rental.crm_provider ?? null,
      crm_deal_id: rental.crm_deal_id ?? null,
      crm_last_sync_at: rental.crm_last_sync_at ?? null,
    },
    tenant: tenant ? {
      full_name: tenant.full_name,
      email: tenant.email,
      phone: tenant.phone,
      profession: tenant.profession,
      marital_status: tenant.marital_status,
    } : null,
    landlord: landlord ? {
      full_name: landlord.full_name,
      email: landlord.email,
      phone: landlord.phone,
      bank_name: landlord.bank_name,
      pix_key: landlord.pix_key,
    } : null,
    documents,
    recent_events: (events ?? []).map((e) => ({
      event_type: e.event_type,
      description: e.description,
      created_at: e.created_at,
    })),
    links: {
      admin_detail: `/admin/rentals/${rentalId}`,
      tenant_tracking: `/locatario/acompanhamento/${rentalId}`,
    },
  };
}
