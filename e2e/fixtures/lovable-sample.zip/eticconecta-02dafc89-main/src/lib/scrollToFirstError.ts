export function scrollToFirstError(container: HTMLElement | null) {
  if (!container) return;
  setTimeout(() => {
    const firstError = container.querySelector(
      '[class*="border-destructive"], .text-destructive'
    )?.closest('.space-y-2');
    if (firstError) {
      firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
      const input = firstError.querySelector('input, select, textarea') as HTMLElement;
      if (input) setTimeout(() => input.focus({ preventScroll: true }), 300);
    }
  }, 50);
}
