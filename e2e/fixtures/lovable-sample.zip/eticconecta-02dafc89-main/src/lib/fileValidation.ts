 import { supabase } from '@/integrations/supabase/client';
 
 // Allowed MIME types for document uploads
 const ALLOWED_TYPES = [
   'application/pdf',
   'image/jpeg',
   'image/png',
   'image/gif',
   'image/webp',
 ];
 
 // Maximum file size (10MB)
 const MAX_FILE_SIZE = 10 * 1024 * 1024;
 
 export interface FileValidationResult {
   valid: boolean;
   error?: string;
 }
 
 /**
  * Validates a file using the server-side validate-upload edge function.
  * This performs magic byte verification to ensure file content matches declared type.
  */
 export async function validateFileUpload(file: File): Promise<FileValidationResult> {
   // Client-side pre-validation (quick checks before server call)
   if (!file) {
     return { valid: false, error: 'Nenhum arquivo fornecido' };
   }
 
   if (file.size > MAX_FILE_SIZE) {
     return { valid: false, error: 'Arquivo muito grande (máximo 10MB)' };
   }
 
   if (!ALLOWED_TYPES.includes(file.type)) {
     return { 
       valid: false, 
       error: 'Tipo de arquivo não permitido. Use PDF, JPEG, PNG, GIF ou WebP.' 
     };
   }
 
   // Server-side validation with magic byte checking
   try {
     const formData = new FormData();
     formData.append('file', file);
     formData.append('type', file.type);
 
     const { data, error } = await supabase.functions.invoke('validate-upload', {
       body: formData,
     });
 
    if (error) {
      console.warn('Server validation unavailable, using client-side only:', error);
      return { valid: true }; // Fallback: client-side already validated
    }

    if (!data?.valid) {
      return { 
        valid: false, 
        error: data?.error || 'Conteúdo do arquivo inválido' 
      };
    }

    return { valid: true };
  } catch (err) {
    console.warn('Server validation failed, proceeding with client-side validation:', err);
    return { valid: true }; // Fallback: client-side already validated
  }
 }
 
 /**
  * Quick client-side validation only (for immediate feedback).
  * Should always be followed by server-side validation before upload.
  */
 export function quickValidateFile(file: File): FileValidationResult {
   if (!file) {
     return { valid: false, error: 'Nenhum arquivo fornecido' };
   }
 
   if (file.size > MAX_FILE_SIZE) {
     return { valid: false, error: 'Arquivo muito grande (máximo 10MB)' };
   }
 
   if (!ALLOWED_TYPES.includes(file.type)) {
     return { 
       valid: false, 
       error: 'Tipo de arquivo não permitido. Use PDF, JPEG, PNG, GIF ou WebP.' 
     };
   }
 
   return { valid: true };
 }