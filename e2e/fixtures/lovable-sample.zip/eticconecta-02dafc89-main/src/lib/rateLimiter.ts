import { supabase } from '@/integrations/supabase/client';

export interface RateLimitResult {
  allowed: boolean;
  blocked: boolean;
  remaining_seconds: number;
  attempts: number;
}

/**
 * Check rate limit before performing login or password reset.
 * Calls the check-rate-limit edge function.
 * Fails open (allows) on network errors to avoid blocking legitimate users.
 */
export async function checkRateLimit(
  identifier: string,
  action: 'login' | 'reset_password'
): Promise<RateLimitResult> {
  try {
    const { data, error } = await supabase.functions.invoke('check-rate-limit', {
      body: { identifier, action },
    });

    if (error || !data) {
      // Fail open
      return { allowed: true, blocked: false, remaining_seconds: 0, attempts: 0 };
    }

    return data as RateLimitResult;
  } catch {
    // Fail open
    return { allowed: true, blocked: false, remaining_seconds: 0, attempts: 0 };
  }
}

/**
 * Format remaining seconds for user display
 */
export function formatBlockTime(seconds: number): string {
  if (seconds >= 60) {
    const minutes = Math.ceil(seconds / 60);
    return `${minutes} minuto${minutes > 1 ? 's' : ''}`;
  }
  return `${seconds} segundo${seconds > 1 ? 's' : ''}`;
}
