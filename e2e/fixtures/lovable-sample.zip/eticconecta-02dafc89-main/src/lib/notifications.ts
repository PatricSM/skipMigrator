/**
 * Browser Notifications for rental step advances.
 * Uses the Web Notifications API for instant feedback.
 */

import { EVENT_LABELS } from '@/lib/proposalEvents';

const NOTIFICATION_PERMISSION_KEY = 'etic_notifications_enabled';

// ── Step-specific notification messages ──
const STEP_NOTIFICATIONS: Record<number, { title: string; body: string; icon?: string }> = {
  2: { title: '📋 Proposta em negociação', body: 'Há uma atualização na negociação da sua proposta.' },
  3: { title: '📄 Documentação', body: 'É hora de enviar seus documentos para análise.' },
  4: { title: '🔍 Análise de Ficha', body: 'Sua documentação está sendo analisada pela equipe.' },
  5: { title: '✅ Ficha Aprovada!', body: 'Sua ficha foi aprovada! Aguardando documentos do locador.' },
  6: { title: '📝 Contrato Emitido', body: 'O contrato de locação foi gerado. Revise e prepare-se para assinar.' },
  7: { title: '✍️ Assinatura do Contrato', body: 'O contrato está pronto para assinatura digital.' },
  8: { title: '🏠 Contrato Assinado!', body: 'Contrato assinado! Agora é hora de agendar a vistoria.' },
  9: { title: '📅 Vistoria Agendada', body: 'A vistoria foi agendada. Prepare-se para assinar o laudo.' },
  10: { title: '🎉 Quase lá!', body: 'Laudo assinado! A entrega das chaves está próxima.' },
};

const EVENT_NOTIFICATIONS: Record<string, { title: string; body: string }> = {
  proposal_accepted: { title: '🎉 Proposta Aceita!', body: 'Sua proposta foi aceita. O processo avança!' },
  proposal_rejected: { title: '❌ Proposta Rejeitada', body: 'Infelizmente sua proposta foi rejeitada.' },
  proposal_countered: { title: '💬 Contraproposta Recebida', body: 'O locador enviou uma contraproposta. Confira!' },
  counter_proposal_accepted: { title: '✅ Contraproposta Aceita', body: 'A contraproposta foi aceita!' },
  ficha_approved: { title: '✅ Ficha Aprovada!', body: 'Sua ficha cadastral foi aprovada pela equipe.' },
  ficha_rejected: { title: '❌ Ficha Reprovada', body: 'Sua ficha foi reprovada. Verifique os detalhes.' },
  contract_emitted: { title: '📝 Contrato Gerado', body: 'O contrato de locação foi emitido.' },
  contract_signed: { title: '✍️ Contrato Assinado', body: 'O contrato foi assinado por ambas as partes!' },
  inspection_scheduled: { title: '📅 Vistoria Agendada', body: 'A vistoria do imóvel foi agendada.' },
  inspection_signed: { title: '✅ Laudo Assinado', body: 'O laudo de vistoria foi assinado!' },
  keys_delivered: { title: '🔑 Chaves Entregues!', body: 'Parabéns! As chaves foram entregues. Bem-vindo ao seu novo lar!' },
};

// ── Permission Management ──

export function isNotificationSupported(): boolean {
  return 'Notification' in window;
}

export function getNotificationPermission(): NotificationPermission | 'unsupported' {
  if (!isNotificationSupported()) return 'unsupported';
  return Notification.permission;
}

export function isNotificationEnabled(): boolean {
  if (!isNotificationSupported()) return false;
  const stored = localStorage.getItem(NOTIFICATION_PERMISSION_KEY);
  return stored === 'true' && Notification.permission === 'granted';
}

export async function requestNotificationPermission(): Promise<boolean> {
  if (!isNotificationSupported()) return false;

  if (Notification.permission === 'granted') {
    localStorage.setItem(NOTIFICATION_PERMISSION_KEY, 'true');
    return true;
  }

  if (Notification.permission === 'denied') {
    return false;
  }

  const permission = await Notification.requestPermission();
  const granted = permission === 'granted';
  localStorage.setItem(NOTIFICATION_PERMISSION_KEY, String(granted));
  return granted;
}

export function disableNotifications(): void {
  localStorage.setItem(NOTIFICATION_PERMISSION_KEY, 'false');
}

// ── Notification Dispatchers ──

export function notifyStepChange(newStep: number): void {
  if (!isNotificationEnabled()) return;

  const config = STEP_NOTIFICATIONS[newStep];
  if (!config) return;

  try {
    new Notification(config.title, {
      body: config.body,
      icon: '/favicon.ico',
      badge: '/favicon.ico',
      tag: `step-${newStep}`,
    });
  } catch {
    // Silently fail if notification can't be shown
  }
}

export function notifyEvent(eventType: string): void {
  if (!isNotificationEnabled()) return;

  const config = EVENT_NOTIFICATIONS[eventType];
  if (!config) return;

  try {
    new Notification(config.title, {
      body: config.body,
      icon: '/favicon.ico',
      badge: '/favicon.ico',
      tag: `event-${eventType}`,
    });
  } catch {
    // Silently fail
  }
}

/**
 * Get a friendly label for an event type.
 */
export function getEventLabel(eventType: string): string {
  return EVENT_LABELS[eventType] || eventType;
}
