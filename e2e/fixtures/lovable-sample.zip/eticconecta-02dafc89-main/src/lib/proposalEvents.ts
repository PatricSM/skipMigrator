import { supabase } from '@/integrations/supabase/client';
import { logger } from '@/lib/logger';

// ── Event Type Catalog ──
export const PROPOSAL_EVENT_TYPES = {
  // Etapa 1
  proposal_created: 'proposal_created',
  proposal_sent: 'proposal_sent',
  // Etapa 2 – Negotiation
  proposal_countered: 'proposal_countered',
  counter_proposal_accepted: 'counter_proposal_accepted',
  counter_proposal_rejected: 'counter_proposal_rejected',
  proposal_accepted: 'proposal_accepted',
  proposal_rejected: 'proposal_rejected',
  // Etapa 3
  documents_ready_to_finalize: 'documents_ready_to_finalize',
  documents_finalized: 'documents_finalized',
  documents_reopened: 'documents_reopened',
  documents_uploaded: 'documents_uploaded',
  // Etapa 4
  ficha_analysis_started: 'ficha_analysis_started',
  ficha_analysis_completed: 'ficha_analysis_completed',
  ficha_approved: 'ficha_approved',
  ficha_rejected: 'ficha_rejected',
  // Etapa 5
  landlord_documents_sent: 'landlord_documents_sent',
  // Etapa 6
  contract_emitted: 'contract_emitted',
  // Etapa 7
  contract_signed: 'contract_signed',
  // Etapa 8
  inspection_scheduled: 'inspection_scheduled',
  // Etapa 9
  inspection_signed: 'inspection_signed',
  // Etapa 10
  keys_delivered: 'keys_delivered',
  // Utility
  step_changed: 'step_changed',
  second_tenant_added: 'second_tenant_added',
} as const;

export type ProposalEventType = keyof typeof PROPOSAL_EVENT_TYPES;

// ── Friendly labels for UI ──
export const EVENT_LABELS: Record<string, string> = {
  proposal_created: 'Proposta criada',
  proposal_sent: 'Proposta enviada',
  proposal_countered: 'Contraproposta enviada pelo locador',
  counter_proposal_accepted: 'Contraproposta aceita pelo locatário',
  counter_proposal_rejected: 'Contraproposta rejeitada pelo locatário',
  proposal_accepted: 'Proposta aceita — negociação concluída',
  proposal_rejected: 'Proposta rejeitada',
  documents_ready_to_finalize: 'Documentos prontos para finalização',
  documents_finalized: 'Documentação finalizada',
  documents_reopened: 'Documentação reaberta para edição',
  documents_uploaded: 'Documentos enviados',
  ficha_analysis_started: 'Análise de ficha iniciada',
  ficha_analysis_completed: 'Análise de ficha concluída',
  ficha_approved: 'Ficha aprovada',
  ficha_rejected: 'Ficha reprovada',
  landlord_documents_sent: 'Documentos do locador enviados',
  contract_emitted: 'Contrato emitido',
  contract_sent_for_signature: 'Contrato enviado para assinatura',
  contract_signed_by_tenant: 'Contrato assinado pelo locatário',
  contract_signed_by_landlord: 'Contrato assinado pelo locador',
  contract_signed: 'Contrato assinado por ambas as partes',
  inspection_scheduled: 'Vistoria agendada',
  inspection_signed_by_tenant: 'Laudo assinado pelo locatário',
  inspection_signed_by_landlord: 'Laudo assinado pelo locador',
  inspection_signed: 'Laudo de vistoria assinado por ambas as partes',
  keys_delivered: 'Chaves entregues',
  step_changed: 'Etapa alterada',
  second_tenant_added: 'Segundo locatário adicionado',
};

// ── Idempotent Event Logger ──
export async function logRentalEvent(params: {
  rentalId: string;
  eventType: string;
  description: string;
  idempotencyKey?: string;
  metadata?: Record<string, unknown>;
}): Promise<boolean> {
  const { rentalId, eventType, description, idempotencyKey, metadata } = params;

  try {
    const insertData: Record<string, unknown> = {
      rental_id: rentalId,
      event_type: eventType,
      description,
    };
    if (idempotencyKey) insertData.idempotency_key = idempotencyKey;
    if (metadata) insertData.metadata = metadata;

    const { error } = await supabase
      .from('rental_events')
      .insert(insertData as any);

    if (error) {
      // Idempotency conflict (unique constraint) — not an error
      if (error.code === '23505') {
        logger.info(`[EVENT_DEDUPED] ${eventType} for ${rentalId}`);
        return true;
      }
      logger.error('[EVENT] Insert error:', error);
      return false;
    }

    logger.info(`[EVENT_LOGGED] ${eventType} for ${rentalId}`);
    return true;
  } catch (err) {
    logger.error('[EVENT] Unexpected error:', err);
    return false;
  }
}

// ══════════════════════════════════════════════════════════════
// ── CENTRALIZED STEP TRANSITION ──
// All current_step changes MUST go through this function.
// ══════════════════════════════════════════════════════════════
export async function setRentalStepAndLog(params: {
  rentalId: string;
  newStep: number;
  reason: string;
  metadata?: Record<string, unknown>;
  /** Extra fields to update on rentals alongside current_step */
  extraUpdate?: Record<string, unknown>;
}): Promise<boolean> {
  const { rentalId, newStep, reason, metadata, extraUpdate } = params;

  // Fetch current step
  const { data: rental, error: fetchErr } = await supabase
    .from('rentals')
    .select('current_step, documents_cycle')
    .eq('id', rentalId)
    .maybeSingle();

  if (fetchErr || !rental) {
    logger.error('[STEP_CHANGE] Fetch error:', fetchErr);
    return false;
  }

  const fromStep = rental.current_step || 1;
  const cycle = rental.documents_cycle || 1;

  if (fromStep === newStep && !extraUpdate) {
    logger.info(`[STEP_CHANGE] No-op: already at step ${newStep}`);
    return true;
  }

  const updateData: Record<string, unknown> = {
    current_step: newStep,
    ...(extraUpdate || {}),
  };

  const { error: updateErr } = await supabase
    .from('rentals')
    .update(updateData as any)
    .eq('id', rentalId);

  if (updateErr) {
    logger.error('[STEP_CHANGE] Update error:', updateErr);
    return false;
  }

  const now = new Date();
  const idempKey = `from_${fromStep}_to_${newStep}_cycle_${cycle}_at_${now.getFullYear()}${String(now.getMonth()+1).padStart(2,'0')}${String(now.getDate()).padStart(2,'0')}${String(now.getHours()).padStart(2,'0')}${String(now.getMinutes()).padStart(2,'0')}`;

  await logRentalEvent({
    rentalId,
    eventType: 'step_changed',
    description: `Etapa alterada: ${fromStep} → ${newStep}. ${reason}`,
    idempotencyKey: idempKey,
    metadata: { fromStep, toStep: newStep, reason, ...(metadata || {}) },
  });

  logger.info('[STEP_CHANGE]', { rentalId, fromStep, toStep: newStep, reason });
  return true;
}

// ── Proposal Status Types ──
export type RentalProposalStatus =
  | 'waiting_landlord_acceptance'
  | 'counter_proposal_pending'
  | 'proposal_accepted'
  | 'proposal_rejected';

// ── Proposal Helpers ──

/**
 * Create a tenant's initial proposal and log events.
 */
export async function createTenantProposal(params: {
  rentalId: string;
  rentValue: number;
  depositValue?: number;
  startDate?: string;
  notes?: string;
}): Promise<boolean> {
  const { rentalId, rentValue, depositValue, startDate, notes } = params;

  const { error } = await supabase.from('proposals' as any).insert({
    rental_id: rentalId,
    author: 'tenant',
    rent_value: rentValue,
    deposit_value: depositValue || null,
    start_date: startDate || null,
    notes: notes || null,
    status: 'pending',
  });

  if (error) {
    logger.error('[PROPOSAL] Create tenant proposal error:', error);
    return false;
  }

  await logRentalEvent({
    rentalId,
    eventType: 'proposal_sent',
    description: `Proposta enviada pelo locatário: R$ ${rentValue.toLocaleString('pt-BR')}/mês`,
    idempotencyKey: `proposal_sent_${rentalId}`,
    metadata: { rent_value: rentValue, deposit_value: depositValue },
  });

  return true;
}

/**
 * Landlord sends a counter-proposal.
 */
export async function createCounterProposal(params: {
  rentalId: string;
  rentValue: number;
  depositValue?: number;
  startDate?: string;
  notes?: string;
}): Promise<boolean> {
  const { rentalId, rentValue, depositValue, startDate, notes } = params;

  // 1. Create proposal record
  const { error: proposalError } = await supabase.from('proposals' as any).insert({
    rental_id: rentalId,
    author: 'landlord',
    rent_value: rentValue,
    deposit_value: depositValue || null,
    start_date: startDate || null,
    notes: notes || null,
    status: 'pending',
  });

  if (proposalError) {
    logger.error('[PROPOSAL] Create counter-proposal error:', proposalError);
    return false;
  }

  // 2. Update rental status and ensure current_step=2
  await setRentalStepAndLog({
    rentalId,
    newStep: 2,
    reason: 'Contraproposta enviada pelo locador.',
    extraUpdate: { proposal_status: 'counter_proposal_pending' },
    metadata: { rent_value: rentValue, deposit_value: depositValue, notes },
  });

  // 3. Log event
  await logRentalEvent({
    rentalId,
    eventType: 'proposal_countered',
    description: `Contraproposta do locador: R$ ${rentValue.toLocaleString('pt-BR')}/mês${notes ? ` — ${notes}` : ''}`,
    idempotencyKey: `counter_${Date.now()}`,
    metadata: { rent_value: rentValue, deposit_value: depositValue, notes },
  });

  return true;
}

/**
 * Tenant accepts a counter-proposal.
 */
export async function acceptCounterProposal(params: {
  rentalId: string;
  proposalId: string;
}): Promise<boolean> {
  const { rentalId, proposalId } = params;

  // 1. Update proposal status
  const { error: proposalError } = await supabase
    .from('proposals' as any)
    .update({ status: 'accepted' })
    .eq('id', proposalId);

  if (proposalError) {
    logger.error('[PROPOSAL] Accept counter-proposal error:', proposalError);
    return false;
  }

  // 2. Update rental via centralized step function (step stays at 2)
  const stepSuccess = await setRentalStepAndLog({
    rentalId,
    newStep: 2,
    reason: 'Contraproposta aceita pelo locatário — aguardando documentação.',
    extraUpdate: {
      proposal_status: 'proposal_accepted',
      landlord_accepted: true,
      landlord_accepted_at: new Date().toISOString(),
    },
  });

  if (!stepSuccess) {
    logger.error('[PROPOSAL] Update rental for acceptance error');
    return false;
  }

  // 3. Log events
  await logRentalEvent({
    rentalId,
    eventType: 'counter_proposal_accepted',
    description: 'Locatário aceitou a contraproposta do locador.',
    idempotencyKey: `cp_accept_${proposalId}`,
  });

  await logRentalEvent({
    rentalId,
    eventType: 'proposal_accepted',
    description: 'Negociação concluída — proposta aceita.',
    idempotencyKey: `accepted_${proposalId}`,
  });

  return true;
}

/**
 * Tenant rejects a counter-proposal.
 */
export async function rejectCounterProposal(params: {
  rentalId: string;
  proposalId: string;
}): Promise<boolean> {
  const { rentalId, proposalId } = params;

  // 1. Update proposal status
  const { error: proposalError } = await supabase
    .from('proposals' as any)
    .update({ status: 'rejected' })
    .eq('id', proposalId);

  if (proposalError) {
    logger.error('[PROPOSAL] Reject counter-proposal error:', proposalError);
    return false;
  }

  // 2. Update rental via centralized step function
  const stepSuccess = await setRentalStepAndLog({
    rentalId,
    newStep: 2,
    reason: 'Contraproposta rejeitada pelo locatário — negociação encerrada.',
    extraUpdate: {
      proposal_status: 'proposal_rejected',
    },
  });

  if (!stepSuccess) {
    logger.error('[PROPOSAL] Update rental for rejection error');
    return false;
  }

  // 3. Log events
  await logRentalEvent({
    rentalId,
    eventType: 'counter_proposal_rejected',
    description: 'Locatário rejeitou a contraproposta do locador.',
    idempotencyKey: `cp_reject_${proposalId}`,
  });

  await logRentalEvent({
    rentalId,
    eventType: 'proposal_rejected',
    description: 'Negociação encerrada — proposta rejeitada.',
    idempotencyKey: `rejected_${proposalId}`,
  });

  return true;
}

/**
 * Fetch proposals for a rental.
 */
export interface ProposalRow {
  id: string;
  rental_id: string;
  author: 'tenant' | 'landlord';
  rent_value: number | null;
  deposit_value: number | null;
  start_date: string | null;
  notes: string | null;
  status: 'pending' | 'accepted' | 'rejected' | 'countered';
  created_at: string;
}

export async function fetchProposals(rentalId: string): Promise<ProposalRow[]> {
  const { data, error } = await (supabase as any)
    .from('proposals')
    .select('*')
    .eq('rental_id', rentalId)
    .order('created_at', { ascending: true });

  if (error) {
    logger.error('[PROPOSAL] Fetch proposals error:', error);
    return [];
  }

  return (data || []) as ProposalRow[];
}

// ── Contract Generation ──

/**
 * Generate a contract for a rental (Step 5 → 6).
 * Creates a contract record and advances to step 6.
 */
export async function emitContract(params: {
  rentalId: string;
  generatedBy?: string;
}): Promise<{ contractId: string; previewUrl: string } | null> {
  const { rentalId, generatedBy } = params;

  // Fetch rental + tenant + landlord data for contract content
  const { data: rental } = await supabase
    .from('rentals')
    .select('protocol, property_address, property_code, rent_value, condo_fee, iptu, user_id')
    .eq('id', rentalId)
    .maybeSingle();

  if (!rental) {
    logger.error('[CONTRACT] Rental not found:', rentalId);
    return null;
  }

  // Fetch accepted proposal
  const { data: proposal } = await (supabase as any)
    .from('proposals')
    .select('rent_value, deposit_value, start_date, notes')
    .eq('rental_id', rentalId)
    .eq('status', 'accepted')
    .order('created_at', { ascending: false })
    .limit(1)
    .maybeSingle();

  const rentValue = proposal?.rent_value || rental.rent_value || 0;
  const depositValue = proposal?.deposit_value || 0;

  // Generate preview URL (simulated — in production this would be a PDF service)
  const previewUrl = `https://uxfbydatvcyggzqjumqn.supabase.co/storage/v1/object/public/documents/contracts/${rentalId}/preview.pdf`;
  const signatureUrl = `https://uxfbydatvcyggzqjumqn.supabase.co/storage/v1/object/public/documents/contracts/${rentalId}/sign`;

  // Generate contract content from template
  const contractContent = generateContractContent({
    protocol: rental.protocol,
    propertyAddress: rental.property_address,
    propertyCode: rental.property_code,
    rentValue,
    depositValue,
    condoFee: rental.condo_fee ? Number(rental.condo_fee) : 0,
    iptu: rental.iptu ? Number(rental.iptu) : 0,
    startDate: proposal?.start_date || null,
  });

  // Insert contract record
  const { data: contract, error: insertErr } = await (supabase as any)
    .from('contracts')
    .insert({
      rental_id: rentalId,
      content: contractContent,
      preview_url: previewUrl,
      signature_url: signatureUrl,
      status: 'generated',
      generated_by: generatedBy || null,
    })
    .select('id')
    .single();

  if (insertErr) {
    logger.error('[CONTRACT] Insert error:', insertErr);
    return null;
  }

  // Update rental with contract URLs
  const stepSuccess = await setRentalStepAndLog({
    rentalId,
    newStep: 6,
    reason: 'Contrato emitido — aguardando revisão e assinatura.',
    extraUpdate: {
      contract_preview_url: previewUrl,
      contract_sign_url: signatureUrl,
    },
  });

  if (!stepSuccess) {
    logger.error('[CONTRACT] Step transition failed');
    return null;
  }

  // Log event
  await logRentalEvent({
    rentalId,
    eventType: 'contract_emitted',
    description: `Contrato emitido. Protocolo ${rental.protocol}. Aluguel: R$ ${rentValue.toLocaleString('pt-BR')}/mês.`,
    idempotencyKey: `contract_emitted_${rentalId}`,
    metadata: { contractId: contract.id, rentValue, depositValue },
  });

  logger.info('[CONTRACT_EMITTED]', { rentalId, contractId: contract.id });
  return { contractId: contract.id, previewUrl };
}

/**
 * Send contract for digital signature (Step 6 → 7).
 */
export async function sendContractForSignature(rentalId: string): Promise<boolean> {
  // Update contract status
  const { error: updateErr } = await (supabase as any)
    .from('contracts')
    .update({ status: 'pending_signature' })
    .eq('rental_id', rentalId)
    .eq('status', 'generated');

  if (updateErr) {
    logger.error('[CONTRACT] Update status error:', updateErr);
    return false;
  }

  const stepSuccess = await setRentalStepAndLog({
    rentalId,
    newStep: 7,
    reason: 'Contrato enviado para assinatura digital.',
  });

  if (!stepSuccess) return false;

  await logRentalEvent({
    rentalId,
    eventType: 'contract_sent_for_signature',
    description: 'Contrato enviado para assinatura digital das partes.',
    idempotencyKey: `contract_sent_sign_${rentalId}`,
  });

  return true;
}

/**
 * Record a party's signature on the contract.
 */
export async function signContract(params: {
  rentalId: string;
  signerRole: 'tenant' | 'landlord';
}): Promise<boolean> {
  const { rentalId, signerRole } = params;

  const updateField = signerRole === 'tenant' 
    ? { signed_by_tenant_at: new Date().toISOString() }
    : { signed_by_landlord_at: new Date().toISOString() };

  const { error: signErr } = await (supabase as any)
    .from('contracts')
    .update(updateField)
    .eq('rental_id', rentalId);

  if (signErr) {
    logger.error('[CONTRACT] Sign error:', signErr);
    return false;
  }

  await logRentalEvent({
    rentalId,
    eventType: `contract_signed_by_${signerRole}`,
    description: `Contrato assinado pelo ${signerRole === 'tenant' ? 'locatário' : 'locador'}.`,
    idempotencyKey: `contract_signed_${signerRole}_${rentalId}`,
  });

  // Check if both parties signed
  const { data: contract } = await (supabase as any)
    .from('contracts')
    .select('signed_by_tenant_at, signed_by_landlord_at')
    .eq('rental_id', rentalId)
    .maybeSingle();

  if (contract?.signed_by_tenant_at && contract?.signed_by_landlord_at) {
    // Both signed — advance to step 8
    await (supabase as any)
      .from('contracts')
      .update({ status: 'signed' })
      .eq('rental_id', rentalId);

    await setRentalStepAndLog({
      rentalId,
      newStep: 8,
      reason: 'Contrato assinado por ambas as partes — agendamento de vistoria.',
    });

    await logRentalEvent({
      rentalId,
      eventType: 'contract_signed',
      description: 'Contrato assinado por ambas as partes.',
      idempotencyKey: `contract_signed_both_${rentalId}`,
    });
  }

  return true;
}

/**
 * Fetch contract for a rental.
 */
export interface ContractRow {
  id: string;
  rental_id: string;
  preview_url: string | null;
  signature_url: string | null;
  status: string;
  signed_by_tenant_at: string | null;
  signed_by_landlord_at: string | null;
  created_at: string;
}

export async function fetchContract(rentalId: string): Promise<ContractRow | null> {
  const { data, error } = await (supabase as any)
    .from('contracts')
    .select('*')
    .eq('rental_id', rentalId)
    .order('created_at', { ascending: false })
    .limit(1)
    .maybeSingle();

  if (error) {
    logger.error('[CONTRACT] Fetch error:', error);
    return null;
  }
  return data as ContractRow | null;
}

// ── Contract Template ──
function generateContractContent(params: {
  protocol: string;
  propertyAddress: string;
  propertyCode: string;
  rentValue: number;
  depositValue: number;
  condoFee: number;
  iptu: number;
  startDate: string | null;
}): string {
  const { protocol, propertyAddress, propertyCode, rentValue, depositValue, condoFee, iptu, startDate } = params;
  const fmt = (v: number) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(v);
  const total = rentValue + condoFee + iptu;

  return `
CONTRATO DE LOCAÇÃO RESIDENCIAL
Protocolo: ${protocol}
═══════════════════════════════════════

IMÓVEL: ${propertyAddress} (Cód. ${propertyCode})

VALORES:
• Aluguel mensal: ${fmt(rentValue)}
• Condomínio: ${fmt(condoFee)}
• IPTU: ${fmt(iptu)}
• Total mensal: ${fmt(total)}
• Depósito caução: ${fmt(depositValue)}

DATA DE INÍCIO: ${startDate || 'A definir'}

═══════════════════════════════════════
Este contrato está sujeito às cláusulas padrão da Etic Imóveis.
Documento gerado automaticamente. Assinatura digital pendente.
  `.trim();
}

// ── Inspection Helpers ──

export interface InspectionRow {
  id: string;
  rental_id: string;
  scheduled_date: string | null;
  scheduled_time: string | null;
  location_notes: string | null;
  report_url: string | null;
  signature_url: string | null;
  status: string;
  signed_by_tenant_at: string | null;
  signed_by_landlord_at: string | null;
  keys_delivered_at: string | null;
  keys_delivered_by: string | null;
  created_at: string;
}

export async function fetchInspection(rentalId: string): Promise<InspectionRow | null> {
  const { data, error } = await (supabase as any)
    .from('inspections')
    .select('*')
    .eq('rental_id', rentalId)
    .order('created_at', { ascending: false })
    .limit(1)
    .maybeSingle();

  if (error) {
    logger.error('[INSPECTION] Fetch error:', error);
    return null;
  }
  return data as InspectionRow | null;
}

/**
 * Schedule an inspection (Step 8).
 */
export async function scheduleInspection(params: {
  rentalId: string;
  date: string;
  time: string;
  locationNotes?: string;
}): Promise<InspectionRow | null> {
  const { rentalId, date, time, locationNotes } = params;

  // Check if inspection already exists
  const existing = await fetchInspection(rentalId);
  if (existing && existing.status !== 'cancelled') {
    // Update existing
    const { error } = await (supabase as any)
      .from('inspections')
      .update({
        scheduled_date: date,
        scheduled_time: time,
        location_notes: locationNotes || null,
        status: 'scheduled',
      })
      .eq('id', existing.id);

    if (error) {
      logger.error('[INSPECTION] Update error:', error);
      return null;
    }
  } else {
    // Create new
    const { error } = await (supabase as any)
      .from('inspections')
      .insert({
        rental_id: rentalId,
        scheduled_date: date,
        scheduled_time: time,
        location_notes: locationNotes || null,
        status: 'scheduled',
      });

    if (error) {
      logger.error('[INSPECTION] Insert error:', error);
      return null;
    }
  }

  await logRentalEvent({
    rentalId,
    eventType: 'inspection_scheduled',
    description: `Vistoria agendada para ${date} às ${time}.`,
    idempotencyKey: `inspection_scheduled_${rentalId}_${date}`,
    metadata: { date, time, locationNotes },
  });

  // Advance to step 9 (inspection done → sign report)
  await setRentalStepAndLog({
    rentalId,
    newStep: 9,
    reason: `Vistoria agendada para ${date} às ${time}.`,
  });

  const result = await fetchInspection(rentalId);
  return result;
}

/**
 * Sign inspection report.
 */
export async function signInspectionReport(params: {
  rentalId: string;
  signerRole: 'tenant' | 'landlord';
}): Promise<boolean> {
  const { rentalId, signerRole } = params;

  const inspection = await fetchInspection(rentalId);
  if (!inspection) {
    logger.error('[INSPECTION] Not found for signing:', rentalId);
    return false;
  }

  const updateField = signerRole === 'tenant'
    ? { signed_by_tenant_at: new Date().toISOString() }
    : { signed_by_landlord_at: new Date().toISOString() };

  const { error } = await (supabase as any)
    .from('inspections')
    .update(updateField)
    .eq('id', inspection.id);

  if (error) {
    logger.error('[INSPECTION] Sign error:', error);
    return false;
  }

  await logRentalEvent({
    rentalId,
    eventType: `inspection_signed_by_${signerRole}`,
    description: `Laudo de vistoria assinado pelo ${signerRole === 'tenant' ? 'locatário' : 'locador'}.`,
    idempotencyKey: `inspection_signed_${signerRole}_${rentalId}`,
  });

  // Check if both signed
  const updated = await fetchInspection(rentalId);
  if (updated?.signed_by_tenant_at && updated?.signed_by_landlord_at) {
    await (supabase as any)
      .from('inspections')
      .update({ status: 'signed' })
      .eq('id', inspection.id);

    await logRentalEvent({
      rentalId,
      eventType: 'inspection_signed',
      description: 'Laudo de vistoria assinado por ambas as partes.',
      idempotencyKey: `inspection_signed_both_${rentalId}`,
    });

    await setRentalStepAndLog({
      rentalId,
      newStep: 10,
      reason: 'Laudo de vistoria assinado — entrega das chaves.',
    });
  }

  return true;
}

/**
 * Deliver keys (Step 10 → completed).
 */
export async function deliverKeys(params: {
  rentalId: string;
  deliveredBy?: string;
}): Promise<boolean> {
  const { rentalId, deliveredBy } = params;

  const inspection = await fetchInspection(rentalId);
  if (inspection) {
    await (supabase as any)
      .from('inspections')
      .update({
        keys_delivered_at: new Date().toISOString(),
        keys_delivered_by: deliveredBy || null,
      })
      .eq('id', inspection.id);
  }

  await logRentalEvent({
    rentalId,
    eventType: 'keys_delivered',
    description: 'Chaves entregues ao locatário. Processo concluído!',
    idempotencyKey: `keys_delivered_${rentalId}`,
  });

  // Mark rental as completed
  await (supabase as any)
    .from('rentals')
    .update({ step_status: 'completed', tenant_status: 'active' })
    .eq('id', rentalId);

  logger.info('[KEYS_DELIVERED]', { rentalId });
  return true;
}

// ── QA Consistency Checker ──
export interface QACheck {
  label: string;
  ok: boolean;
  fixAction?: string;
}

export function runConsistencyChecks(params: {
  currentStep: number;
  proposalStatus: string;
  documentsFinalizedAt: Date | undefined;
  documentsCycle: number;
  missingTypes: string[];
  events: { eventType: string }[];
  proposals: ProposalRow[];
  isRejected: boolean;
}): QACheck[] {
  const { currentStep, proposalStatus, documentsFinalizedAt, missingTypes, events, proposals, isRejected } = params;
  const checks: QACheck[] = [];
  const eventTypes = events.map(e => e.eventType);

  // 1. proposal_sent or proposal_created must exist
  checks.push({
    label: 'proposal_sent ou proposal_created existe',
    ok: eventTypes.includes('proposal_sent') || eventTypes.includes('proposal_created') || eventTypes.includes('proposal_awaiting_landlord'),
  });

  // 2. Step consistency with proposal_status
  if (proposalStatus === 'waiting_landlord_acceptance' && currentStep > 2 && !isRejected) {
    checks.push({
      label: 'proposal_status=waiting mas step>2 — inconsistente',
      ok: false,
      fixAction: 'set_step_2',
    });
  }

  if ((proposalStatus === 'counter_proposal_pending') && currentStep !== 2) {
    checks.push({
      label: 'proposal_status=counter_proposal_pending mas step≠2',
      ok: false,
      fixAction: 'set_step_2',
    });
  }

  // 3. Counter-proposal event coverage
  if (proposalStatus === 'counter_proposal_pending') {
    checks.push({
      label: 'proposal_countered existe',
      ok: eventTypes.includes('proposal_countered'),
    });
  }

  if (proposalStatus === 'proposal_accepted' && proposals.some(p => p.author === 'landlord')) {
    checks.push({
      label: 'counter_proposal_accepted existe (após contraproposta)',
      ok: eventTypes.includes('counter_proposal_accepted'),
    });
  }

  if (proposalStatus === 'proposal_accepted') {
    checks.push({
      label: 'proposal_accepted existe',
      ok: eventTypes.includes('proposal_accepted'),
    });
  }

  if (proposalStatus === 'proposal_rejected') {
    checks.push({
      label: 'proposal_rejected existe',
      ok: eventTypes.includes('counter_proposal_rejected') || eventTypes.includes('proposal_rejected'),
    });
  }

  // 4. Document coverage
  if (missingTypes.length === 0 && !documentsFinalizedAt) {
    checks.push({
      label: 'documents_ready_to_finalize registrado',
      ok: eventTypes.includes('documents_ready_to_finalize') || eventTypes.includes('documents_uploaded') || eventTypes.includes('documents_completed'),
    });
  }

  if (documentsFinalizedAt) {
    checks.push({
      label: 'documents_finalized existe',
      ok: eventTypes.includes('documents_finalized'),
    });
  }

  // 5. Step >= 3 should have proposal_accepted
  if (currentStep >= 3 && !isRejected) {
    checks.push({
      label: 'step≥3 implica proposal_accepted ou docs finalizados',
      ok: proposalStatus === 'proposal_accepted' || !!documentsFinalizedAt || eventTypes.includes('proposal_accepted') || eventTypes.includes('documents_completed'),
    });
  }

  // 6. Step >= 4 should have documents_finalized
  if (currentStep >= 4 && !isRejected) {
    checks.push({
      label: 'step≥4 implica documents_finalized',
      ok: !!documentsFinalizedAt || eventTypes.includes('documents_finalized'),
    });
  }

  // 7. step_changed events
  if (currentStep >= 2) {
    checks.push({
      label: 'step_changed eventos existem',
      ok: eventTypes.includes('step_changed') || currentStep <= 2,
    });
  }

  // 8. Proposal_status != accepted but step >= 3
  if (currentStep >= 3 && proposalStatus !== 'proposal_accepted' && !isRejected) {
    const hasDirect = eventTypes.includes('documents_completed') || eventTypes.includes('documents_finalized');
    if (!hasDirect) {
      checks.push({
        label: 'step≥3 sem proposal_accepted — possível inconsistência',
        ok: false,
        fixAction: 'set_step_2',
      });
    }
  }

  // 9. documents_cycle > 1 should have documents_reopened
  if (params.documentsCycle > 1) {
    checks.push({
      label: 'documents_reopened existe (ciclo > 1)',
      ok: eventTypes.includes('documents_reopened'),
    });
  }

  // 10. Step >= 5 should have ficha_analysis_completed AND ficha_approved
  if (currentStep >= 5 && !isRejected) {
    checks.push({
      label: 'step≥5 implica ficha_analysis_completed',
      ok: eventTypes.includes('ficha_analysis_completed'),
    });
    checks.push({
      label: 'step≥5 implica ficha_approved',
      ok: eventTypes.includes('ficha_approved'),
    });
  }

  // 11. Step >= 6 should have landlord_documents_sent
  if (currentStep >= 6 && !isRejected) {
    checks.push({
      label: 'step≥6 implica landlord_documents_sent',
      ok: eventTypes.includes('landlord_documents_sent'),
    });
  }

  // 12. Step >= 6 should have contract_emitted
  if (currentStep >= 6 && !isRejected) {
    checks.push({
      label: 'step≥6 implica contract_emitted',
      ok: eventTypes.includes('contract_emitted'),
    });
  }

  // 13. Step >= 7 should have contract_sent_for_signature
  if (currentStep >= 7 && !isRejected) {
    checks.push({
      label: 'step≥7 implica contract_sent_for_signature',
      ok: eventTypes.includes('contract_sent_for_signature'),
    });
  }

  // 14. Step >= 8 should have contract_signed
  if (currentStep >= 8 && !isRejected) {
    checks.push({
      label: 'step≥8 implica contract_signed',
      ok: eventTypes.includes('contract_signed'),
    });
  }

  // 15. Step >= 9 should have inspection_scheduled
  if (currentStep >= 9 && !isRejected) {
    checks.push({
      label: 'step≥9 implica inspection_scheduled',
      ok: eventTypes.includes('inspection_scheduled'),
    });
  }

  // 16. Step >= 10 should have inspection_signed
  if (currentStep >= 10 && !isRejected) {
    checks.push({
      label: 'step=10 implica inspection_signed',
      ok: eventTypes.includes('inspection_signed'),
    });
  }

  // 17. Step = 10 MUST have keys_delivered
  if (currentStep === 10 && !isRejected) {
    checks.push({
      label: 'step=10 implica keys_delivered',
      ok: eventTypes.includes('keys_delivered'),
    });
  }

  // 18. Rejected ficha should have ficha_rejected event
  if (isRejected && eventTypes.includes('ficha_analysis_completed')) {
    checks.push({
      label: 'ficha reprovada tem evento ficha_rejected',
      ok: eventTypes.includes('ficha_rejected'),
    });
  }

  return checks;
}

// ── QA Auto-Correction ──
export async function qaFixCurrentStep(rentalId: string, targetStep: number, reason: string): Promise<boolean> {
  return setRentalStepAndLog({
    rentalId,
    newStep: targetStep,
    reason: `[QA_FIX] ${reason}`,
    metadata: { qa_fix: true },
  });
}
