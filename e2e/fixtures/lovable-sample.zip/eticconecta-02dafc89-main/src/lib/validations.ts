import { z } from 'zod';
import { isValidCPF, isValidPhone } from './masks';
import { strongPasswordSchema } from './passwordPolicy';

// Login Schema - password min is low because we validate strength on registration, not login
export const loginSchema = z.object({
  email: z
    .string()
    .min(1, 'E-mail é obrigatório')
    .email('E-mail inválido'),
  password: z
    .string()
    .min(1, 'Senha é obrigatória'),
});

export type LoginFormData = z.infer<typeof loginSchema>;

// Register Schema - uses strong password policy
export const registerSchema = z.object({
  fullName: z
    .string()
    .min(1, 'Nome completo é obrigatório')
    .min(3, 'Nome deve ter no mínimo 3 caracteres'),
  email: z
    .string()
    .min(1, 'E-mail é obrigatório')
    .email('E-mail inválido'),
  phone: z
    .string()
    .min(1, 'Telefone é obrigatório')
    .refine((val) => isValidPhone(val), 'Telefone inválido'),
  password: strongPasswordSchema,
  confirmPassword: z
    .string()
    .min(1, 'Confirmação de senha é obrigatória'),
}).refine((data) => data.password === data.confirmPassword, {
  message: 'As senhas não coincidem',
  path: ['confirmPassword'],
});

export type RegisterFormData = z.infer<typeof registerSchema>;

// Property Data Schema (Step 1)
export const propertyDataSchema = z.object({
  propertyCode: z
    .string()
    .min(1, 'Código do imóvel é obrigatório'),
  propertyAddress: z
    .string()
    .min(1, 'Endereço é obrigatório')
    .min(10, 'Endereço deve ser mais detalhado'),
  rentValue: z
    .number({ required_error: 'Valor do aluguel é obrigatório' })
    .positive('Valor deve ser positivo'),
  condoFee: z
    .number()
    .nonnegative('Valor não pode ser negativo')
    .optional(),
  iptu: z
    .number()
    .nonnegative('Valor não pode ser negativo')
    .optional(),
});

export type PropertyDataForm = z.infer<typeof propertyDataSchema>;

// Personal Data Schema (Step 2)
export const personalDataSchema = z.object({
  fullName: z
    .string()
    .min(1, 'Nome completo é obrigatório')
    .min(3, 'Nome deve ter no mínimo 3 caracteres'),
  email: z
    .string()
    .min(1, 'E-mail é obrigatório')
    .email('E-mail inválido'),
  phone: z
    .string()
    .min(1, 'Telefone é obrigatório')
    .refine((val) => isValidPhone(val), 'Telefone inválido'),
  cpf: z
    .string()
    .min(1, 'CPF é obrigatório')
    .refine((val) => isValidCPF(val), 'CPF inválido'),
  birthDate: z
    .string()
    .min(1, 'Data de nascimento é obrigatória'),
  nationality: z
    .string()
    .min(1, 'Nacionalidade é obrigatória'),
  maritalStatus: z
    .string()
    .min(1, 'Estado civil é obrigatório'),
  profession: z
    .string()
    .min(1, 'Profissão é obrigatória'),
  monthlyIncome: z
    .number({ required_error: 'Renda mensal é obrigatória' })
    .positive('Renda deve ser positiva'),
  isPoliticallyExposed: z
    .boolean()
    .default(false),
});

export type PersonalDataForm = z.infer<typeof personalDataSchema>;

// Landlord Data Schema
export const landlordDataSchema = z.object({
  fullName: z
    .string()
    .min(1, 'Nome completo é obrigatório'),
  email: z
    .string()
    .min(1, 'E-mail é obrigatório')
    .email('E-mail inválido'),
  phone: z
    .string()
    .min(1, 'Telefone é obrigatório')
    .refine((val) => isValidPhone(val), 'Telefone inválido'),
  maritalStatus: z
    .string()
    .min(1, 'Estado civil é obrigatório'),
  profession: z
    .string()
    .min(1, 'Profissão é obrigatória'),
  hasSecondLandlord: z
    .boolean()
    .default(false),
  secondLandlordName: z
    .string()
    .optional(),
  secondLandlordEmail: z
    .string()
    .email('E-mail inválido')
    .optional()
    .or(z.literal('')),
  secondLandlordPhone: z
    .string()
    .optional(),
  bankName: z
    .string()
    .min(1, 'Nome do banco é obrigatório'),
  bankAgency: z
    .string()
    .min(1, 'Agência é obrigatória'),
  bankAccount: z
    .string()
    .min(1, 'Conta é obrigatória'),
  bankAccountType: z
    .string()
    .min(1, 'Tipo de conta é obrigatório'),
  pixKey: z
    .string()
    .optional(),
  billsResponsible: z
    .string()
    .min(1, 'Responsável pelas contas é obrigatório'),
});

export type LandlordDataForm = z.infer<typeof landlordDataSchema>;

// Marital Status Options
export const maritalStatusOptions = [
  { value: 'solteiro', label: 'Solteiro(a)' },
  { value: 'casado', label: 'Casado(a)' },
  { value: 'divorciado', label: 'Divorciado(a)' },
  { value: 'viuvo', label: 'Viúvo(a)' },
  { value: 'uniao_estavel', label: 'União Estável' },
];

// Bank Account Type Options
export const bankAccountTypeOptions = [
  { value: 'corrente', label: 'Conta Corrente' },
  { value: 'poupanca', label: 'Conta Poupança' },
];

// Nationality Options
export const nationalityOptions = [
  { value: 'brasileiro', label: 'Brasileiro(a)' },
  { value: 'estrangeiro', label: 'Estrangeiro(a)' },
];

// Sanitize redirect URL to prevent open redirect attacks
export function sanitizeRedirect(url: string | null | undefined, fallback = '/locatario/painel'): string {
  if (!url || typeof url !== 'string') return fallback;
  const decoded = url.startsWith('%2F') ? decodeURIComponent(url) : url;
  // Only allow internal paths starting with / but not //
  if (decoded.startsWith('/') && !decoded.startsWith('//')) return decoded;
  return fallback;
}
