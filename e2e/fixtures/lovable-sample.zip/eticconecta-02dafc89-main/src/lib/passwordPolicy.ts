import { z } from 'zod';

/**
 * Common passwords list (top 50 most common).
 * Checking client-side before sending to Supabase.
 */
const COMMON_PASSWORDS = new Set([
  'password', '123456', '12345678', '123456789', '1234567890',
  'qwerty', 'abc123', 'password1', 'iloveyou', 'sunshine',
  'princess', 'admin', 'welcome', 'monkey', 'dragon',
  'master', 'letmein', 'login', 'football', 'shadow',
  'trustno1', 'batman', '111111', 'access', 'hello',
  'charlie', 'donald', 'password123', 'senha', 'senha123',
  'mudar123', 'trocar123', 'brasil', 'flamengo', 'palmeiras',
  'corinthians', 'santos', 'amor', 'jesus', 'deus',
  'familia', 'felicidade', 'saudade', 'futebol', 'campeao',
  'abcdef', 'qwerty123', '1q2w3e4r', 'passw0rd', 'p@ssword',
]);

/**
 * Count how many character classes are present:
 * uppercase, lowercase, digit, special
 */
function countCharClasses(password: string): number {
  let count = 0;
  if (/[a-z]/.test(password)) count++;
  if (/[A-Z]/.test(password)) count++;
  if (/\d/.test(password)) count++;
  if (/[^A-Za-z0-9]/.test(password)) count++;
  return count;
}

/**
 * Strong password Zod schema:
 * - Min 14 chars
 * - At least 3 of 4 character classes (upper, lower, digit, special)
 * - Not in common passwords list
 */
export const strongPasswordSchema = z
  .string()
  .min(14, 'A senha deve ter no mínimo 14 caracteres')
  .refine(
    (pw) => countCharClasses(pw) >= 3,
    'Use pelo menos 3 tipos: maiúsculas, minúsculas, números e caracteres especiais'
  )
  .refine(
    (pw) => !COMMON_PASSWORDS.has(pw.toLowerCase()),
    'Esta senha é muito comum. Escolha uma senha mais segura.'
  );

/**
 * Password strength hint text for UI display
 */
export const PASSWORD_HINT = 'Mín. 14 caracteres, com pelo menos 3 tipos: maiúsculas, minúsculas, números ou especiais (!@#$...)';

/**
 * Check password strength and return detailed feedback
 */
export function getPasswordStrength(password: string): {
  score: number; // 0-4
  label: string;
  color: string;
} {
  if (!password) return { score: 0, label: '', color: '' };
  
  let score = 0;
  if (password.length >= 8) score++;
  if (password.length >= 14) score++;
  if (countCharClasses(password) >= 3) score++;
  if (password.length >= 20 && countCharClasses(password) === 4) score++;

  const labels: Record<number, { label: string; color: string }> = {
    0: { label: 'Muito fraca', color: 'text-destructive' },
    1: { label: 'Fraca', color: 'text-destructive' },
    2: { label: 'Razoável', color: 'text-yellow-600' },
    3: { label: 'Forte', color: 'text-green-600' },
    4: { label: 'Muito forte', color: 'text-green-700' },
  };

  return { score, ...labels[score] };
}
