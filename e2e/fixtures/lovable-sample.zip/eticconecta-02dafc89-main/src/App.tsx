import { lazy, Suspense } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate, useParams, useLocation } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { ProtectedRoute } from "@/components/auth/ProtectedRoute";
import { AdminRoute } from "@/components/auth/AdminRoute";
import { LocadorRoute } from "@/components/auth/LocadorRoute";
import { LocadorLayout } from "@/components/locador/LocadorLayout";
import { PageSkeleton } from "@/components/layout/PageSkeleton";

// Eagerly loaded pages (critical path)
import LocatarioLanding from "./pages/locatario/Landing";
import LocatarioLogin from "./pages/locatario/Login";
import LocatarioRegister from "./pages/locatario/Register";
import NotFound from "./pages/NotFound";

// Lazy loaded pages for code splitting (TTI < 3.5s optimization)
const SelecionarImovel = lazy(() => import("./pages/SelecionarImovel"));
const EnviarDocumentos = lazy(() => import("./pages/EnviarDocumentos"));
const EnviarDocumentosPendentes = lazy(() => import("./pages/EnviarDocumentosPendentes"));
const SegundoLocatario = lazy(() => import("./pages/SegundoLocatario"));
const EnvioSucesso = lazy(() => import("./pages/EnvioSucesso"));
const Acompanhamento = lazy(() => import("./pages/Acompanhamento"));
const IniciarLocacaoDireta = lazy(() => import("./pages/IniciarLocacaoDireta"));
const TenantDashboard = lazy(() => import("./pages/tenant/TenantDashboard"));
const MeuCadastro = lazy(() => import("./pages/tenant/MeuCadastro"));
const PortalPrivacidade = lazy(() => import("./pages/PortalPrivacidade"));
const EscolherTipoProposta = lazy(() => import("./pages/locatario/EscolherTipoProposta"));
const AnunciarImovel = lazy(() => import("./pages/AnunciarImovel"));

// Admin pages (heavy with charts - always lazy load)
const Admin = lazy(() => import("./pages/Admin"));
const PropertyInvitesAdmin = lazy(() => import("./pages/admin/PropertyInvites"));
const MapaProduto = lazy(() => import("./pages/admin/MapaProduto"));
const AdminRentalsList = lazy(() => import("./pages/admin/AdminRentalsList"));
const AdminRentalDetail = lazy(() => import("./pages/admin/AdminRentalDetail"));
const SecurityDashboard = lazy(() => import("./pages/admin/SecurityDashboard"));
const Forbidden = lazy(() => import("./pages/Forbidden"));

// Locador pages
const LocadorAuth = lazy(() => import("./pages/locador/Auth"));
const LocadorHome = lazy(() => import("./pages/locador/Home"));
const LocadorPropostas = lazy(() => import("./pages/locador/Propostas"));
const PropostaDetalhe = lazy(() => import("./pages/locador/PropostaDetalhe"));
const LocadorImoveis = lazy(() => import("./pages/locador/Imoveis"));
const ImovelForm = lazy(() => import("./pages/locador/ImovelForm"));
const LocadorAjuda = lazy(() => import("./pages/locador/Ajuda"));
const LocadorAnunciar = lazy(() => import("./pages/locador/Anunciar"));

// Utility pages
const Auth = lazy(() => import("./pages/Auth"));
const AcceptInvite = lazy(() => import("./pages/AcceptInvite"));
const DownloadDocs = lazy(() => import("./pages/DownloadDocs"));

const VerifiqueEmail = lazy(() => import("./pages/locatario/VerifiqueEmail"));

const queryClient = new QueryClient();

// Component to properly redirect legacy routes with dynamic params
function RedirectWithParams({ to }: { to: string }) {
  const params = useParams();
  const location = useLocation();
  let finalPath = to;
  
  // Substitute dynamic params
  Object.entries(params).forEach(([key, value]) => {
    if (value) {
      finalPath = finalPath.replace(`:${key}`, value);
    }
  });
  
  // Remove optional param placeholders that weren't matched
  finalPath = finalPath.replace(/\/:\w+\?/g, '');
  finalPath = finalPath.replace(/:\w+\?/g, '');
  
  return <Navigate to={finalPath} state={location.state} replace />;
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            {/* Root redirects to locatario landing */}
            <Route path="/" element={<Navigate to="/locatario" replace />} />
            <Route path="/download-docs" element={
              <Suspense fallback={<PageSkeleton />}>
                <DownloadDocs />
              </Suspense>
            } />

            {/* Locatario routes */}
            <Route path="/locatario" element={<LocatarioLanding />} />
            <Route path="/locatario/login" element={<LocatarioLogin />} />
            <Route path="/locatario/register" element={<LocatarioRegister />} />
            <Route path="/locatario/verifique-email" element={
              <Suspense fallback={<PageSkeleton />}>
                <VerifiqueEmail />
              </Suspense>
            } />
            <Route path="/locatario/selecionar-imovel" element={
              <Suspense fallback={<PageSkeleton variant="list" />}>
                <SelecionarImovel />
              </Suspense>
            } />
            <Route path="/locatario/escolher-tipo-proposta/:id" element={
              <Suspense fallback={<PageSkeleton variant="form" />}>
                <EscolherTipoProposta />
              </Suspense>
            } />
            <Route
              path="/locatario/enviar-documentos/:id"
              element={
                <ProtectedRoute>
                  <Suspense fallback={<PageSkeleton variant="form" />}>
                    <EnviarDocumentos />
                  </Suspense>
                </ProtectedRoute>
              }
            />
            <Route
              path="/locatario/enviar-documentos/:id/segundo-locatario"
              element={
                <ProtectedRoute>
                  <Suspense fallback={<PageSkeleton variant="form" />}>
                    <SegundoLocatario />
                  </Suspense>
                </ProtectedRoute>
              }
            />
            <Route
              path="/locatario/envio-sucesso/:id"
              element={
                <ProtectedRoute>
                  <Suspense fallback={<PageSkeleton />}>
                    <EnvioSucesso />
                  </Suspense>
                </ProtectedRoute>
              }
            />
            <Route
              path="/locatario/enviar-documentos-pendentes/:id"
              element={
                <ProtectedRoute>
                  <Suspense fallback={<PageSkeleton variant="form" />}>
                    <EnviarDocumentosPendentes />
                  </Suspense>
                </ProtectedRoute>
              }
            />
            <Route
              path="/locatario/acompanhamento/:id?"
              element={
                <ProtectedRoute>
                  <Suspense fallback={<PageSkeleton variant="dashboard" />}>
                    <Acompanhamento />
                  </Suspense>
                </ProtectedRoute>
              }
            />
            <Route
              path="/locatario/iniciar-locacao-direta"
              element={
                <Suspense fallback={<PageSkeleton variant="form" />}>
                  <IniciarLocacaoDireta />
                </Suspense>
              }
            />
            <Route
              path="/locatario/segundo-locatario"
              element={
                <ProtectedRoute>
                  <Suspense fallback={<PageSkeleton variant="form" />}>
                    <SegundoLocatario />
                  </Suspense>
                </ProtectedRoute>
              }
            />
            <Route
              path="/locatario/painel"
              element={
                <ProtectedRoute>
                  <Suspense fallback={<PageSkeleton variant="dashboard" />}>
                    <TenantDashboard />
                  </Suspense>
                </ProtectedRoute>
              }
            />
            <Route
              path="/locatario/meu-cadastro"
              element={
                <ProtectedRoute>
                  <Suspense fallback={<PageSkeleton variant="form" />}>
                    <MeuCadastro />
                  </Suspense>
                </ProtectedRoute>
              }
            />
            {/* Public Anunciar Imovel page */}
            <Route path="/anunciar-imovel" element={
              <Suspense fallback={<PageSkeleton variant="form" />}>
                <AnunciarImovel />
              </Suspense>
            } />

            <Route
              path="/privacidade"
              element={
                <Suspense fallback={<PageSkeleton />}>
                  <PortalPrivacidade />
                </Suspense>
              }
            />

            {/* Locador routes */}
            <Route path="/locador/auth" element={
              <Suspense fallback={<PageSkeleton />}>
                <LocadorAuth />
              </Suspense>
            } />
            <Route path="/locador" element={<LocadorRoute><LocadorLayout /></LocadorRoute>}>
              <Route index element={<Navigate to="/locador/home" replace />} />
              <Route path="home" element={
                <Suspense fallback={<PageSkeleton variant="dashboard" />}>
                  <LocadorHome />
                </Suspense>
              } />
              <Route path="propostas" element={
                <Suspense fallback={<PageSkeleton variant="list" />}>
                  <LocadorPropostas />
                </Suspense>
              } />
              <Route path="proposta/:protocolo" element={
                <Suspense fallback={<PageSkeleton variant="form" />}>
                  <PropostaDetalhe />
                </Suspense>
              } />
              <Route path="imoveis" element={
                <Suspense fallback={<PageSkeleton variant="list" />}>
                  <LocadorImoveis />
                </Suspense>
              } />
              <Route path="imovel/:id" element={
                <Suspense fallback={<PageSkeleton variant="form" />}>
                  <ImovelForm />
                </Suspense>
              } />
              <Route path="anunciar" element={
                <Suspense fallback={<PageSkeleton variant="form" />}>
                  <LocadorAnunciar />
                </Suspense>
              } />
              <Route path="ajuda" element={
                <Suspense fallback={<PageSkeleton />}>
                  <LocadorAjuda />
                </Suspense>
              } />
            </Route>

            {/* Admin routes */}
            <Route
              path="/admin"
              element={
                <AdminRoute>
                  <Suspense fallback={<PageSkeleton variant="dashboard" />}>
                    <Admin />
                  </Suspense>
                </AdminRoute>
              }
            />
            <Route
              path="/admin/rentals"
              element={
                <AdminRoute>
                  <Suspense fallback={<PageSkeleton variant="list" />}>
                    <AdminRentalsList />
                  </Suspense>
                </AdminRoute>
              }
            />
            <Route
              path="/admin/rentals/:rentalId"
              element={
                <AdminRoute>
                  <Suspense fallback={<PageSkeleton variant="form" />}>
                    <AdminRentalDetail />
                  </Suspense>
                </AdminRoute>
              }
            />
            <Route
              path="/admin/security"
              element={
                <AdminRoute>
                  <Suspense fallback={<PageSkeleton variant="list" />}>
                    <SecurityDashboard />
                  </Suspense>
                </AdminRoute>
              }
            />
            <Route
              path="/admin/invites"
              element={
                <AdminRoute>
                  <Suspense fallback={<PageSkeleton variant="list" />}>
                    <PropertyInvitesAdmin />
                  </Suspense>
                </AdminRoute>
              }
            />

            <Route
              path="/mapa"
              element={
                <AdminRoute>
                  <Suspense fallback={<PageSkeleton />}>
                    <MapaProduto />
                  </Suspense>
                </AdminRoute>
              }
            />

            {/* Access denied */}
            <Route path="/forbidden" element={
              <Suspense fallback={<PageSkeleton />}>
                <Forbidden />
              </Suspense>
            } />

            {/* Utility routes */}
            <Route path="/convite/:token" element={
              <Suspense fallback={<PageSkeleton />}>
                <AcceptInvite />
              </Suspense>
            } />

            {/* Legacy redirects for backwards compatibility */}
            <Route path="/auth" element={
              <Suspense fallback={<PageSkeleton />}>
                <Auth />
              </Suspense>
            } />
            <Route path="/login" element={<Navigate to="/locatario/login" replace />} />
            <Route path="/cadastro" element={<Navigate to="/locatario/register" replace />} />
            <Route path="/selecionar-imovel" element={<Navigate to="/locatario/selecionar-imovel" replace />} />
            <Route path="/enviar-documentos/:id" element={<RedirectWithParams to="/locatario/escolher-tipo-proposta/:id" />} />
            <Route path="/acompanhamento/:id" element={<RedirectWithParams to="/locatario/acompanhamento/:id" />} />
            <Route path="/acompanhamento" element={<Navigate to="/locatario/acompanhamento" replace />} />

            {/* Legacy Auth page for password reset flow */}
            <Route path="/reset-password" element={
              <Suspense fallback={<PageSkeleton />}>
                <Auth />
              </Suspense>
            } />

            {/* Catch-all 404 */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
