import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Download, Trash2, FileText, Shield, User, Mail, ChevronLeft, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Link, useNavigate } from "react-router-dom";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function PortalPrivacidade() {
  const { user, profile } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [isDownloading, setIsDownloading] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  // DPO contact info - can be configured via environment or database
  const dpoInfo = {
    name: "Encarregado de Proteção de Dados",
    email: "dpo@eticimoveis.com.br",
    address: "Rua da Mooca, 2000 - Mooca, São Paulo - SP",
  };

  const handleDownloadData = async () => {
    if (!user) return;
    
    setIsDownloading(true);
    try {
      // Fetch user profile
      const { data: profileData } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();

      // Fetch user documents metadata (not actual files)
      const { data: documentsData } = await supabase
        .from('documents')
        .select('id, document_type, file_name, status, created_at')
        .eq('user_id', user.id);

      // Fetch user rentals
      const { data: rentalsData } = await supabase
        .from('rentals')
        .select('id, protocol, property_code, property_address, current_step, created_at, updated_at')
        .eq('user_id', user.id);

      // Prepare export data
      const exportData = {
        exportDate: new Date().toISOString(),
        userData: {
          id: user.id,
          email: user.email,
          createdAt: user.created_at,
        },
        profile: profileData ? {
          fullName: profileData.full_name,
          email: profileData.email,
          phone: profileData.phone,
          birthDate: profileData.birth_date,
          nationality: profileData.nationality,
          maritalStatus: profileData.marital_status,
          profession: profileData.profession,
          createdAt: profileData.created_at,
          updatedAt: profileData.updated_at,
        } : null,
        documents: documentsData?.map(doc => ({
          type: doc.document_type,
          fileName: doc.file_name,
          status: doc.status,
          createdAt: doc.created_at,
        })) || [],
        rentals: rentalsData?.map(rental => ({
          protocol: rental.protocol,
          propertyCode: rental.property_code,
          propertyAddress: rental.property_address,
          currentStep: rental.current_step,
          createdAt: rental.created_at,
          updatedAt: rental.updated_at,
        })) || [],
      };

      // Create and download JSON file
      const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `meus-dados-etic-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      toast({
        title: "Download concluído",
        description: "Seus dados foram exportados com sucesso.",
      });
    } catch (error) {
      console.error('Error downloading data:', error);
      toast({
        title: "Erro ao exportar",
        description: "Não foi possível exportar seus dados. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsDownloading(false);
    }
  };

  const handleDeleteRequest = async () => {
    if (!user) return;

    setIsDeleting(true);
    try {
      // Create deletion request record (admin will process)
      // For now, we'll send an email notification via audit log
      await supabase.rpc('log_audit', {
        p_action: 'DELETION_REQUEST',
        p_table_name: 'profiles',
        p_record_id: user.id,
        p_new_data: {
          requestDate: new Date().toISOString(),
          userEmail: user.email,
          userName: profile?.full_name,
        },
      });

      toast({
        title: "Solicitação enviada",
        description: "Sua solicitação de exclusão foi registrada. Entraremos em contato em até 15 dias úteis.",
      });
    } catch (error) {
      console.error('Error requesting deletion:', error);
      toast({
        title: "Erro ao solicitar",
        description: "Não foi possível registrar sua solicitação. Tente novamente ou entre em contato com o DPO.",
        variant: "destructive",
      });
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
              <ChevronLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-xl font-semibold">Portal de Privacidade</h1>
              <p className="text-sm text-muted-foreground">LGPD - Lei Geral de Proteção de Dados</p>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Introduction */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              Seus Direitos sob a LGPD
            </CardTitle>
            <CardDescription>
              A Lei Geral de Proteção de Dados (Lei nº 13.709/2018) garante a você direitos sobre seus dados pessoais.
            </CardDescription>
          </CardHeader>
          <CardContent className="prose prose-sm dark:prose-invert">
            <p>
              Na Etic Imóveis, tratamos seus dados com total transparência e segurança. 
              Aqui você pode exercer seus direitos de:
            </p>
            <ul className="list-disc list-inside space-y-1 text-muted-foreground">
              <li><strong>Portabilidade:</strong> Baixar todos os seus dados em formato estruturado</li>
              <li><strong>Esquecimento:</strong> Solicitar a exclusão definitiva de seus dados</li>
              <li><strong>Acesso:</strong> Consultar quais dados possuímos sobre você</li>
              <li><strong>Informação:</strong> Saber como seus dados são utilizados</li>
            </ul>
          </CardContent>
        </Card>

        {/* Actions Grid */}
        <div className="grid gap-6 md:grid-cols-2 mb-6">
          {/* Download Data */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Download className="h-5 w-5" />
                Baixar Meus Dados
              </CardTitle>
              <CardDescription>
                Exporte todos os seus dados pessoais em formato JSON
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Você receberá um arquivo com seu perfil, histórico de documentos e locações.
              </p>
              <Button 
                onClick={handleDownloadData} 
                disabled={isDownloading}
                className="w-full"
              >
                {isDownloading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Preparando...
                  </>
                ) : (
                  <>
                    <Download className="mr-2 h-4 w-4" />
                    Baixar Meus Dados
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Delete Request */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Trash2 className="h-5 w-5" />
                Direito ao Esquecimento
              </CardTitle>
              <CardDescription>
                Solicite a exclusão definitiva de todos os seus dados
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Após a solicitação, seus dados serão removidos em até 15 dias úteis.
              </p>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="destructive" className="w-full">
                    <Trash2 className="mr-2 h-4 w-4" />
                    Solicitar Exclusão
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Confirmar Exclusão de Dados</AlertDialogTitle>
                    <AlertDialogDescription>
                      Esta ação é irreversível. Ao confirmar, você solicita a exclusão definitiva de:
                      <ul className="list-disc list-inside mt-2 space-y-1">
                        <li>Seu perfil e dados pessoais</li>
                        <li>Documentos enviados</li>
                        <li>Histórico de locações</li>
                      </ul>
                      <p className="mt-2 font-medium">
                        Dados necessários para obrigações legais podem ser retidos conforme legislação.
                      </p>
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancelar</AlertDialogCancel>
                    <AlertDialogAction 
                      onClick={handleDeleteRequest}
                      className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                      disabled={isDeleting}
                    >
                      {isDeleting ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Enviando...
                        </>
                      ) : (
                        "Confirmar Exclusão"
                      )}
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </CardContent>
          </Card>
        </div>

        {/* Terms and Policies */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <FileText className="h-5 w-5" />
              Termos e Políticas
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Link 
              to="/locador/ajuda#termos" 
              className="flex items-center justify-between p-3 rounded-lg border hover:bg-accent transition-colors"
            >
              <div className="flex items-center gap-3">
                <FileText className="h-5 w-5 text-muted-foreground" />
                <span>Termos de Uso</span>
              </div>
              <ChevronLeft className="h-4 w-4 rotate-180 text-muted-foreground" />
            </Link>
            <Link 
              to="/locador/ajuda#lgpd" 
              className="flex items-center justify-between p-3 rounded-lg border hover:bg-accent transition-colors"
            >
              <div className="flex items-center gap-3">
                <Shield className="h-5 w-5 text-muted-foreground" />
                <span>Política de Privacidade (LGPD)</span>
              </div>
              <ChevronLeft className="h-4 w-4 rotate-180 text-muted-foreground" />
            </Link>
          </CardContent>
        </Card>

        {/* DPO Contact */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <User className="h-5 w-5" />
              Encarregado de Proteção de Dados (DPO)
            </CardTitle>
            <CardDescription>
              Para dúvidas ou solicitações relacionadas à LGPD
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <User className="h-4 w-4 text-muted-foreground" />
                <span>{dpoInfo.name}</span>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="h-4 w-4 text-muted-foreground" />
                <a 
                  href={`mailto:${dpoInfo.email}`} 
                  className="text-primary hover:underline"
                >
                  {dpoInfo.email}
                </a>
              </div>
              <Separator className="my-3" />
              <p className="text-sm text-muted-foreground">
                O DPO é responsável por receber reclamações e comunicações dos titulares de dados, 
                prestar esclarecimentos e adotar providências, além de orientar funcionários e 
                contratados sobre as práticas de proteção de dados pessoais.
              </p>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
