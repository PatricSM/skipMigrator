import { useState, useCallback, useRef, useEffect } from "react";
import { useParams, Link, useNavigate, useLocation, useSearchParams } from "react-router-dom";
import {
  ChevronLeft, Upload, Loader2, Check, Clock, User, DollarSign,
  FileText, Users, ArrowDown, AlertTriangle, CheckCircle2, ExternalLink, MapPin, Edit2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { DocFileEntry } from "@/components/rental/DocumentUpload";
import { TenantDocumentsUploader, areRequiredDocsComplete } from "@/components/documents/TenantDocumentsUploader";
import { PersonalDataForm } from "@/components/rental/PersonalDataForm";
import { IncomeDataForm } from "@/components/rental/IncomeDataForm";
import { GamificationProgress } from "@/components/rental/GamificationProgress";
import { TenantData, initialTenantData } from "@/types/rental";
import {
  validatePersonalData, validateIncomeData, validateIdentityFields, validateCivilFields,
  hasErrors, ValidationErrors, getFirstErrorStep, getMissingDocuments, getMissingDocumentTypes,
} from "@/utils/formValidation";
import { REQUIRED_DOC_TYPES, DOC_TYPE_LABELS } from "@/types/documentLimits";
import { scrollToFirstError } from "@/lib/scrollToFirstError";
import { AppHeader } from "@/components/layout/AppHeader";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel,
  AlertDialogContent, AlertDialogDescription, AlertDialogFooter,
  AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { setRentalStepAndLog, logRentalEvent } from "@/lib/proposalEvents";

// Sub-step definitions for the wizard
// 0 = overview, 1 = identity, 2 = civil, 3 = income, 4 = documents, 5 = 2nd tenant
type SubStep = 0 | 1 | 2 | 3 | 4 | 5;

const SUB_STEP_META: Record<number, { title: string; description: string; icon: typeof User }> = {
  1: { title: "Identificação", description: "Nome, e-mail e telefone", icon: User },
  2: { title: "Dados Civis", description: "Nascimento, CPF, nacionalidade e estado civil", icon: User },
  3: { title: "Financeiro", description: "Profissão e renda", icon: DollarSign },
  4: { title: "Documentos", description: "Envie seus documentos", icon: FileText },
  5: { title: "2º Locatário", description: "Defina se haverá outro locatário", icon: Users },
};

export default function EnviarDocumentosPendentes() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const [searchParams] = useSearchParams();
  const { user, profile } = useAuth();
  const { toast } = useToast();

  const navState = location.state as {
    proposalType?: 'direct' | 'standard';
    proposedValue?: number;
    sendDocs?: boolean;
    secondTenantData?: TenantData;
    secondTenantDocuments?: DocFileEntry[];
    secondTenantSaved?: boolean;
    mainTenantData?: TenantData;
    mainTenantDocuments?: DocFileEntry[];
  } | null;

  const proposalType = navState?.proposalType || 'standard';
  const proposedValue = navState?.proposedValue || null;
  const sendDocs = navState?.sendDocs !== false;

  // Wizard sub-step state
  const [subStep, setSubStep] = useState<SubStep>(0);
  const [slideDirection, setSlideDirection] = useState<'left' | 'right'>('left');
  const [showStepCheck, setShowStepCheck] = useState(false);

  // Form state
  const [tenantData, setTenantData] = useState<TenantData>(() => ({
    ...initialTenantData,
    email: profile?.email || '',
    fullName: profile?.full_name || '',
    phone: profile?.phone || '',
    ...(navState?.mainTenantData || {}),
  }));
  const [docFiles, setDocFiles] = useState<DocFileEntry[]>(
    (navState?.mainTenantDocuments as DocFileEntry[]) || []
  );
  const [hasSecondTenant, setHasSecondTenant] = useState<"no" | "yes">("no");
  const [secondTenantData, setSecondTenantData] = useState<TenantData>(
    navState?.secondTenantData || initialTenantData
  );
  const [secondTenantDocuments, setSecondTenantDocuments] = useState<DocFileEntry[]>(
    (navState?.secondTenantDocuments as DocFileEntry[]) || []
  );
  const [secondTenantSaved, setSecondTenantSaved] = useState(navState?.secondTenantSaved || false);
  const [errors, setErrors] = useState<ValidationErrors>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showScrollIndicator, setShowScrollIndicator] = useState(false);
  const [isResolving, setIsResolving] = useState(true);
  const [secondTenantNavigating, setSecondTenantNavigating] = useState(false);

  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // Property data
  const [propertyData, setPropertyData] = useState<{
    image: string; code: string; address: string; neighborhood: string;
    streetName: string; rentValue: number | null; condoFee: number | null; iptu: number | null;
  } | null>(null);

  // Load profile data
  useEffect(() => {
    if (profile) {
      setTenantData(prev => ({
        ...prev,
        email: prev.email || profile.email || '',
        fullName: prev.fullName || profile.full_name || '',
        phone: prev.phone || profile.phone || '',
        birthDate: prev.birthDate || profile.birth_date || '',
        nationality: prev.nationality || profile.nationality || 'Brasileira',
        nationalityCountry: prev.nationalityCountry || profile.nationality_country || '',
        maritalStatus: prev.maritalStatus || profile.marital_status || '',
        profession: prev.profession || profile.profession || '',
        monthlyIncome: prev.monthlyIncome || (profile.monthly_income ? String(profile.monthly_income) : ''),
        isPoliticallyExposed: prev.isPoliticallyExposed || profile.is_politically_exposed || false,
      }));
    }
  }, [profile]);

  // Handle returned state from second tenant page
  useEffect(() => {
    if (navState?.mainTenantData) {
      setTenantData(prev => ({
        ...prev,
        ...navState.mainTenantData,
        email: (navState.mainTenantData as TenantData).email || prev.email,
        phone: (navState.mainTenantData as TenantData).phone || prev.phone,
      }));
    }
    if (navState?.secondTenantSaved) {
      setHasSecondTenant("yes");
      setSecondTenantSaved(true);
      if (navState.secondTenantData) setSecondTenantData(navState.secondTenantData);
      if (navState.secondTenantDocuments) setSecondTenantDocuments(navState.secondTenantDocuments);
      // Go to step 5 to show the saved summary
      setSubStep(5);
    }
  }, []);

  // Load property data
  useEffect(() => {
    const loadPropertyData = async () => {
      if (!id) return;
      try {
        const { data: rental } = await supabase
          .from('rentals').select('property_code').eq('id', id).single();
        if (!rental?.property_code) return;
        const { data } = await supabase.functions.invoke<{
          success: boolean;
          properties: Array<{
            id: string; code: string; address: string; neighborhood: string;
            streetName: string; price: number; condoFee: number; iptu: number;
            image: string; images: string[];
          }>;
        }>("fetch-properties");
        if (data?.success && data.properties) {
          const prop = data.properties.find(p => p.code === rental.property_code);
          if (prop) {
            setPropertyData({
              image: prop.image || prop.images[0], code: prop.code, address: prop.address,
              neighborhood: prop.neighborhood, streetName: prop.streetName,
              rentValue: prop.price, condoFee: prop.condoFee, iptu: prop.iptu,
            });
          }
        }
      } catch (e) { console.warn('Could not load property data:', e); }
    };
    loadPropertyData();
  }, [id]);

  // Pulse focus on first input when sub-step changes
  useEffect(() => {
    if (subStep === 0) return;
    const container = scrollContainerRef.current;
    if (!container) return;
    const timer = setTimeout(() => {
      const firstInput = container.querySelector('input:not([type="hidden"]), select, textarea') as HTMLElement;
      if (firstInput) {
        firstInput.classList.add('animate-pulse-border');
        setTimeout(() => firstInput?.classList.remove('animate-pulse-border'), 6500);
      }
    }, 350);
    return () => clearTimeout(timer);
  }, [subStep]);

  // Scroll indicator
  useEffect(() => {
    const container = scrollContainerRef.current;
    if (!container) return;
    const checkScroll = () => {
      const { scrollTop, scrollHeight, clientHeight } = container;
      setShowScrollIndicator(!((scrollTop + clientHeight) >= scrollHeight - 20) && scrollHeight > clientHeight);
    };
    checkScroll();
    container.addEventListener('scroll', checkScroll);
    return () => container.removeEventListener('scroll', checkScroll);
  }, [subStep]);

  // Completion checks
  const identityComplete = !hasErrors(validateIdentityFields(tenantData));
  const civilComplete = !hasErrors(validateCivilFields(tenantData));
  const personalComplete = identityComplete && civilComplete;
  const incomeComplete = !hasErrors(validateIncomeData(tenantData));
  const documentsComplete = REQUIRED_DOC_TYPES.every(type =>
    docFiles.some(f => f.type === type && f.status === 'uploaded')
  );
  const secondTenantComplete = hasSecondTenant === "no" || secondTenantSaved;
  const canSubmit = personalComplete && incomeComplete && secondTenantComplete;

  // Sub-step completion map (5 steps now)
  const subStepComplete: Record<number, boolean> = {
    1: identityComplete,
    2: civilComplete,
    3: incomeComplete,
    4: documentsComplete,
    5: secondTenantComplete,
  };

  const totalSubSteps = 5;
  const completedSubSteps = [1, 2, 3, 4, 5].filter(s => subStepComplete[s]).length;
  const wizardProgress = (completedSubSteps / totalSubSteps) * 100;

  // Navigation helpers
  const goToSubStep = (step: SubStep, direction: 'left' | 'right' = 'left') => {
    setSlideDirection(direction);
    setSubStep(step);
    scrollContainerRef.current?.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const shakeFirstError = () => {
    setTimeout(() => {
      const el = scrollContainerRef.current?.querySelector('[class*="border-destructive"]')?.closest('.space-y-2');
      if (el) { el.classList.add('animate-shake'); setTimeout(() => el.classList.remove('animate-shake'), 600); }
    }, 100);
  };

  const showCheckAndAdvance = (nextStep: SubStep) => {
    setShowStepCheck(true);
    setTimeout(() => {
      setShowStepCheck(false);
      goToSubStep(nextStep);
    }, 500);
  };

  const goNextSubStep = () => {
    if (subStep === 0) {
      goToSubStep(1);
      return;
    }

    // Validate current sub-step
    if (subStep === 1) {
      const errs = validateIdentityFields(tenantData);
      if (hasErrors(errs)) {
        setErrors(errs);
        scrollToFirstError(scrollContainerRef.current);
        shakeFirstError();
        toast({ title: "Campos obrigatórios", description: "Preencha nome, e-mail e telefone.", variant: "destructive" });
        return;
      }
      setErrors({});
      showCheckAndAdvance(2);
    } else if (subStep === 2) {
      const errs = validateCivilFields(tenantData);
      if (hasErrors(errs)) {
        setErrors(errs);
        scrollToFirstError(scrollContainerRef.current);
        shakeFirstError();
        toast({ title: "Campos obrigatórios", description: "Preencha todos os dados civis.", variant: "destructive" });
        return;
      }
      setErrors({});
      showCheckAndAdvance(3);
    } else if (subStep === 3) {
      const errs = validateIncomeData(tenantData);
      if (hasErrors(errs)) {
        setErrors(errs);
        scrollToFirstError(scrollContainerRef.current);
        shakeFirstError();
        toast({ title: "Campos obrigatórios", description: "Preencha profissão e renda.", variant: "destructive" });
        return;
      }
      setErrors({});
      showCheckAndAdvance(4);
    } else if (subStep === 4) {
      // Documents step → advance to 2nd tenant step
      showCheckAndAdvance(5);
    } else if (subStep === 5) {
      // 2nd tenant step: if user selected "yes" but hasn't saved, auto-navigate to the form
      if (hasSecondTenant === "yes" && !secondTenantSaved) {
        // Auto-navigate directly to the 2nd tenant wizard — no hidden button dependency
        handleAddSecondTenant();
        return;
      }
      // Ready to submit — but check for pending docs first
    }
  };

  const goPreviousSubStep = () => {
    if (subStep > 1) goToSubStep((subStep - 1) as SubStep, 'right');
    else if (subStep === 1) goToSubStep(0, 'right');
  };

  // Navigate to second tenant page
  const handleAddSecondTenant = () => {
    setSecondTenantNavigating(true);
    // Small delay for button transition
    setTimeout(() => {
      navigate(`/locatario/enviar-documentos/${id}/segundo-locatario`, {
        state: {
          tenantData: secondTenantData,
          documents: secondTenantDocuments,
          mainTenantData: tenantData,
          mainTenantDocuments: docFiles,
          proposalType, proposedValue, sendDocs,
        },
      });
    }, 150);
  };

  // ─── Submit handler ───────────────────────────────────────────
  const handleSubmit = async (forceSubmit = false) => {
    if (!id) {
      toast({ title: "Aguarde", description: "Aguarde carregar a proposta.", variant: "destructive" });
      return;
    }
    if (!user) return;

    const identityCount = docFiles.filter(f => f.type === 'identity' && f.status === 'uploaded').length;
    const incomeCount = docFiles.filter(f => f.type === 'income' && f.status === 'uploaded').length;
    const residenceCount = docFiles.filter(f => f.type === 'residence' && f.status === 'uploaded').length;
    const canFinalize = identityCount > 0 && incomeCount > 0 && residenceCount > 0;

    if (!forceSubmit && !canFinalize) {
      toast({
        title: "Documentos obrigatórios faltando",
        description: "Envie RG/CNH, Comprovante de Renda e Comprovante de Residência.",
        variant: "destructive",
      });
      return;
    }

    const personalErrors = validatePersonalData(tenantData);
    const incomeErrors = validateIncomeData(tenantData);
    const allErrors = { ...personalErrors, ...incomeErrors };

    if (hasErrors(allErrors)) {
      setErrors(allErrors);
      if (hasErrors(validateIdentityFields(tenantData))) { goToSubStep(1); }
      else if (hasErrors(validateCivilFields(tenantData))) { goToSubStep(2); }
      else if (hasErrors(validateIncomeData(tenantData))) { goToSubStep(3); }
      setTimeout(() => scrollToFirstError(scrollContainerRef.current), 100);
      toast({ title: "Dados incompletos", description: "Preencha todos os campos obrigatórios.", variant: "destructive" });
      return;
    }

    setIsSubmitting(true);
    (document.activeElement as HTMLElement)?.blur?.();

    try {
      const pendingDocTypes = getMissingDocumentTypes(docFiles as any);
      const hasPending = pendingDocTypes.length > 0;
      const incomeValue = parseFloat(tenantData.monthlyIncome.replace(/\./g, '').replace(',', '.')) || 0;

      let propertyAddress = propertyData?.address || `Imóvel ${id}`;
      let rentValue: number | null = propertyData?.rentValue || null;
      let condoFee: number | null = propertyData?.condoFee || null;
      let iptu: number | null = propertyData?.iptu || null;

      if (!propertyData) {
        try {
          const { data: rental } = await supabase.from('rentals').select('property_code, property_address').eq('id', id).single();
          if (rental) {
            propertyAddress = rental.property_address || propertyAddress;
            const { data: propData } = await supabase.functions.invoke<{ success: boolean; properties: { code: string; address: string; price: number; condoFee: number; iptu: number }[] }>("fetch-properties");
            if (propData?.success && propData.properties) {
              const prop = propData.properties.find(p => p.code === rental.property_code);
              if (prop) { propertyAddress = prop.address || propertyAddress; rentValue = prop.price || null; condoFee = prop.condoFee || null; iptu = prop.iptu || null; }
            }
          }
        } catch (e) { console.warn('Could not fetch property data:', e); }
      }

      const isDirect = proposalType === 'direct';
      const isStandardWait = proposalType === 'standard' && !sendDocs;
      const isStandardWithDocs = proposalType === 'standard' && sendDocs;

      let initialStep = 2;
      let tenantStatusValue = 'proposal_created';
      let docsSubmittedEarlyValue = false;

      if (isDirect) {
        initialStep = 3;
        tenantStatusValue = hasPending ? 'priority_pending_docs' : 'priority_submission';
      } else if (isStandardWait) {
        initialStep = 2;
        tenantStatusValue = 'awaiting_landlord';
      } else if (isStandardWithDocs) {
        initialStep = 2;
        tenantStatusValue = hasPending ? 'docs_submitted_early_pending' : 'docs_submitted_early';
        docsSubmittedEarlyValue = !hasPending;
      }

      const stepSuccess = await setRentalStepAndLog({
        rentalId: id!,
        newStep: initialStep,
        reason: isDirect
          ? 'Proposta direta enviada — documentação em andamento.'
          : isStandardWithDocs
            ? 'Proposta padrão com docs enviada — aguardando aceite do locador.'
            : 'Proposta padrão enviada — aguardando aceite do locador.',
        extraUpdate: {
          has_pending: hasPending,
          pending_documents: isStandardWait ? [] : pendingDocTypes,
          pending_reason: hasPending && !isStandardWait ? 'Documentos faltando' : null,
          pending_description: hasPending && !isStandardWait ? `Faltam: ${getMissingDocuments(docFiles as any).join(', ')}` : null,
          step_status: hasPending ? 'pending' : 'in_progress',
          tenant_status: tenantStatusValue,
          proposal_type: proposalType,
          proposed_value: proposedValue,
          rent_value: rentValue ?? undefined,
          condo_fee: condoFee ?? undefined,
          iptu: iptu ?? undefined,
          property_address: propertyAddress,
          landlord_accepted: false,
          landlord_action_required: true,
          docs_submitted_early: docsSubmittedEarlyValue,
        },
      });

      if (!stepSuccess) throw new Error('Failed to update rental via setRentalStepAndLog');

      await supabase.from('profiles').update({
        full_name: tenantData.fullName, email: tenantData.email, phone: tenantData.phone,
        birth_date: tenantData.birthDate, nationality: tenantData.nationality,
        nationality_country: tenantData.nationalityCountry || null,
        marital_status: tenantData.maritalStatus, profession: tenantData.profession,
        monthly_income: incomeValue, is_politically_exposed: tenantData.isPoliticallyExposed,
      }).eq('id', user.id);

      try {
        const eventType = (forceSubmit || hasPending) ? 'documents_updated_pending' : 'documents_completed';
        const eventDescription = (forceSubmit || hasPending)
          ? `Documentos atualizados - Ainda faltam: ${getMissingDocuments(docFiles as any).join(', ')}`
          : 'Documentação completa - Todos os documentos foram enviados';
        await logRentalEvent({ rentalId: id!, eventType, description: eventDescription, idempotencyKey: `${eventType}_${id}_${Date.now()}` });
      } catch (eventError) { console.error('Event creation error:', eventError); }

      toast({
        title: hasPending ? "Ficha enviada com pendências" : "Documentos enviados!",
        description: hasPending
          ? "Sua ficha foi enviada, mas você ainda precisa enviar alguns documentos."
          : "Sua ficha foi enviada com sucesso. Acompanhe o status pelo painel.",
      });

      navigate(`/locatario/acompanhamento/${id}`, { replace: true });
    } catch (error) {
      console.error('[SUBMIT_UI] error:', error);
      toast({ title: "Erro ao enviar", description: "Ocorreu um erro. Tente novamente.", variant: "destructive" });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Missing docs for inline alert
  const currentMissingTypes = REQUIRED_DOC_TYPES.filter(
    type => !docFiles.some(f => f.type === type && f.status === 'uploaded')
  );
  const uploadedCount = docFiles.filter(d => d.status === 'uploaded').length;

  // Missing fields counter for current sub-step
  const missingFieldsCount = (() => {
    if (subStep === 1) return Object.keys(validateIdentityFields(tenantData)).length;
    if (subStep === 2) return Object.keys(validateCivilFields(tenantData)).length;
    if (subStep === 3) return Object.keys(validateIncomeData(tenantData)).length;
    if (subStep === 4) return currentMissingTypes.length;
    if (subStep === 5) return hasSecondTenant === "yes" && !secondTenantSaved ? 1 : 0;
    return 0;
  })();

  // ─── Render ───────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <AppHeader onBack={() => {
        (document.activeElement as HTMLElement)?.blur?.();
        const returnTo = searchParams.get('returnTo');
        if (returnTo) { window.location.assign(window.location.origin + decodeURIComponent(returnTo)); }
        else { navigate('/locatario/painel'); }
      }} />

      {/* Property Info Card */}
      {propertyData && (
        <div className="border-b bg-card px-4 py-3">
          <div className="container max-w-lg mx-auto">
            <div className="flex gap-3 rounded-lg overflow-hidden">
              <div className="w-20 h-20 bg-muted shrink-0 rounded-lg overflow-hidden">
                <img
                  src={propertyData.image} alt={propertyData.code}
                  className="w-full h-full object-cover"
                  onError={(e) => { e.currentTarget.src = "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=400&h=300&fit=crop"; }}
                />
              </div>
              <div className="flex-1 min-w-0">
                <a href={`https://www.eticimoveis.com.br/imovel/${propertyData.code}`} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-xs font-medium text-primary hover:underline">
                  {propertyData.code}<ExternalLink className="h-3 w-3" />
                </a>
                <p className="text-sm text-foreground flex items-center gap-1 mt-0.5 line-clamp-1">
                  <MapPin className="h-3 w-3 text-muted-foreground shrink-0" />
                  <span>{propertyData.neighborhood}{propertyData.streetName && propertyData.streetName !== "Rua não informada" ? ` - ${propertyData.streetName}` : ''}</span>
                </p>
                <div className="flex gap-3 mt-1.5 text-xs">
                  <div><span className="text-muted-foreground">Aluguel: </span><span className="font-medium">{propertyData.rentValue ? `R$ ${propertyData.rentValue.toLocaleString("pt-BR")}` : "-"}</span></div>
                  {propertyData.condoFee && propertyData.condoFee > 0 && (<div><span className="text-muted-foreground">Cond: </span><span className="font-medium">R$ {propertyData.condoFee.toLocaleString("pt-BR")}</span></div>)}
                  {propertyData.iptu && propertyData.iptu > 0 && (<div><span className="text-muted-foreground">IPTU: </span><span className="font-medium">R$ {propertyData.iptu.toLocaleString("pt-BR")}</span></div>)}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Dynamic Header: Full progress at sub-step 0, compact otherwise */}
      {subStep === 0 ? (
        <div className="border-b bg-muted/30 px-4 py-4">
          <div className="container max-w-lg mx-auto">
            <GamificationProgress
              personalComplete={personalComplete}
              incomeComplete={incomeComplete}
              documentsComplete={documentsComplete}
              secondTenantComplete={secondTenantComplete}
              hasSecondTenant={hasSecondTenant === "yes"}
              currentStep="personal"
              onStepClick={(stepId) => {
                if (stepId === 'personal') goToSubStep(1);
                else if (stepId === 'income') goToSubStep(3);
                else if (stepId === 'documents') goToSubStep(4);
                else if (stepId === 'secondTenant') goToSubStep(5);
              }}
            />
          </div>
        </div>
      ) : (
        /* Compact progress header */
        <div className="border-b bg-muted/30 px-4 py-2.5 sticky top-14 z-40">
          <div className="container max-w-lg mx-auto">
            <div className="flex items-center gap-3">
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-medium text-foreground">
                    Etapa {subStep} de {totalSubSteps}
                  </span>
                  <span className="text-xs font-bold text-primary">
                    {Math.round(wizardProgress)}%
                  </span>
                </div>
                <Progress value={wizardProgress} className="h-1.5" />
              </div>
              {/* Mini step dots */}
              <div className="flex gap-1.5">
                {[1, 2, 3, 4, 5].map(s => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => goToSubStep(s as SubStep)}
                    className={cn(
                      "w-2.5 h-2.5 rounded-full transition-all",
                      subStepComplete[s] ? "bg-step-complete" :
                      subStep === s ? "bg-primary" : "bg-muted-foreground/30"
                    )}
                    aria-label={`Etapa ${s}`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Sub-step title (when in wizard mode) */}
      {subStep > 0 && (
        <div className="px-4 py-3 border-b">
          <div className="container max-w-lg mx-auto">
            <div className="flex items-center gap-3">
              <div className={cn(
                "w-9 h-9 rounded-full flex items-center justify-center shrink-0",
                subStepComplete[subStep] ? "bg-step-complete text-step-complete-foreground" : "bg-primary text-primary-foreground"
              )}>
                {subStepComplete[subStep] ? <Check className="h-4 w-4" /> : (() => {
                  const Icon = SUB_STEP_META[subStep].icon;
                  return <Icon className="h-4 w-4" />;
                })()}
              </div>
              <div>
                <h1 className="text-base font-semibold">{SUB_STEP_META[subStep].title}</h1>
                <p className="text-xs text-muted-foreground">{SUB_STEP_META[subStep].description}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Step completion check overlay */}
      {showStepCheck && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-background/60 backdrop-blur-sm">
          <div className="animate-step-check w-20 h-20 rounded-full bg-step-complete flex items-center justify-center">
            <Check className="h-10 w-10 text-step-complete-foreground" />
          </div>
        </div>
      )}

      {/* Form Content */}
      <div className="flex-1 overflow-hidden relative">
        <div
          ref={scrollContainerRef}
          className="h-full overflow-y-auto px-4 py-6 pb-32"
        >
          <div className="container max-w-lg mx-auto">
            {/* Sub-step 0: Overview / starting screen */}
            {subStep === 0 && (
              <div className="space-y-4 animate-fade-in-up">
                <div className="text-center space-y-2 py-4">
                  <h2 className="text-xl font-bold text-foreground">Preencha sua ficha</h2>
                  <p className="text-sm text-muted-foreground">
                    São 5 etapas rápidas. Vamos começar!
                  </p>
                </div>
                {/* Sub-step cards */}
                {[1, 2, 3, 4, 5].map(s => {
                  const meta = SUB_STEP_META[s];
                  const Icon = meta.icon;
                  const done = subStepComplete[s];
                  return (
                    <button
                      key={s}
                      type="button"
                      onClick={() => goToSubStep(s as SubStep)}
                      className={cn(
                        "w-full rounded-xl border p-4 text-left transition-all flex items-center gap-4",
                        done ? "border-step-complete/40 bg-step-complete/5" : "border-border hover:border-primary/30 hover:bg-primary/5"
                      )}
                    >
                      <div className={cn(
                        "w-10 h-10 rounded-full flex items-center justify-center shrink-0",
                        done ? "bg-step-complete text-step-complete-foreground" : "bg-primary/10 text-primary"
                      )}>
                        {done ? <Check className="h-5 w-5" /> : <Icon className="h-5 w-5" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-foreground text-sm">{meta.title}</p>
                        <p className="text-xs text-muted-foreground">{meta.description}</p>
                      </div>
                      {!done && (
                        <ChevronLeft className="h-4 w-4 text-muted-foreground rotate-180 shrink-0" />
                      )}
                    </button>
                  );
                })}
              </div>
            )}

            {/* Sub-step 1: Identity */}
            {subStep === 1 && (
              <div key="sub1" className={cn(
                slideDirection === 'left' ? 'animate-slide-in-left' : 'animate-slide-in-right'
              )}>
                <PersonalDataForm data={tenantData} onChange={setTenantData} errors={errors} section="identity" />
              </div>
            )}

            {/* Sub-step 2: Civil */}
            {subStep === 2 && (
              <div key="sub2" className={cn(
                slideDirection === 'left' ? 'animate-slide-in-left' : 'animate-slide-in-right'
              )}>
                <PersonalDataForm data={tenantData} onChange={setTenantData} errors={errors} section="civil" />
              </div>
            )}

            {/* Sub-step 3: Income */}
            {subStep === 3 && (
              <div key="sub3" className={cn(
                slideDirection === 'left' ? 'animate-slide-in-left' : 'animate-slide-in-right'
              )}>
                <IncomeDataForm data={tenantData} onChange={setTenantData} errors={errors} />
              </div>
            )}

            {/* Sub-step 4: Documents ONLY */}
            {subStep === 4 && (
              <div key="sub4" className={cn(
                slideDirection === 'left' ? 'animate-slide-in-left' : 'animate-slide-in-right'
              )}>
                {/* Tenant 1 label when 2nd tenant exists */}
                {hasSecondTenant === "yes" && (
                  <div className="flex items-center gap-2 mb-3">
                    <Badge variant="outline" className="text-xs font-semibold border-primary/40 text-primary">
                      <User className="h-3 w-3 mr-1" />Locatário 1
                    </Badge>
                    <span className="text-sm text-muted-foreground">— Seus documentos</span>
                  </div>
                )}

                <TenantDocumentsUploader
                  identifier={id || ''}
                  identifierType="rental_id"
                  initialDocFiles={docFiles}
                  onDocFilesChange={setDocFiles}
                  onRentalResolved={(_rid, resolving) => setIsResolving(resolving)}
                  compact
                />

                {currentMissingTypes.length > 0 && uploadedCount > 0 && (
                  <div className="p-3 mt-4 bg-destructive/10 border border-destructive/20 rounded-lg">
                    <p className="text-sm font-medium text-destructive mb-1">
                      Ainda faltam documentos obrigatórios{hasSecondTenant === "yes" ? " do Locatário 1" : ""}:
                    </p>
                    <ul className="list-disc list-inside space-y-0.5">
                      {currentMissingTypes.map(type => (
                        <li key={type} className="text-xs text-destructive/80">{DOC_TYPE_LABELS[type]?.label || type}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Tenant 2 pending docs summary (if already added) */}
                {hasSecondTenant === "yes" && secondTenantSaved && (
                  <div className="mt-6 pt-4 border-t border-border">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge variant="outline" className="text-xs font-semibold border-primary/40 text-primary">
                        <Users className="h-3 w-3 mr-1" />Locatário 2
                      </Badge>
                      <span className="text-xs text-muted-foreground">Documentos</span>
                    </div>
                    {(() => {
                      const t2Missing = REQUIRED_DOC_TYPES.filter(
                        type => !secondTenantDocuments.some(f => f.type === type && f.status === 'uploaded')
                      );
                      return t2Missing.length > 0 ? (
                        <p className="text-xs text-amber-600">
                          Faltam: {t2Missing.map(t => DOC_TYPE_LABELS[t]?.label || t).join(', ')}
                        </p>
                      ) : (
                        <p className="text-xs text-step-complete">Documentos completos ✓</p>
                      );
                    })()}
                  </div>
                )}
              </div>
            )}

            {/* Sub-step 5: 2nd Tenant (dedicated step) */}
            {subStep === 5 && (
              <div key="sub5" className={cn(
                "space-y-6",
                slideDirection === 'left' ? 'animate-slide-in-left' : 'animate-slide-in-right'
              )}>
                <div className="text-center space-y-2">
                  <h2 className="text-lg font-bold text-foreground">Haverá outro locatário?</h2>
                  <p className="text-sm text-muted-foreground">
                    Se mais de uma pessoa assinará o contrato, adicione o 2º locatário.
                  </p>
                </div>

                {/* Card-based selection */}
                <div className="grid gap-3" id="second-tenant-section">
                  <button
                    type="button"
                    onClick={() => { setHasSecondTenant("no"); setSecondTenantSaved(false); }}
                    className={cn(
                      "w-full rounded-xl border-2 p-5 text-left transition-all",
                      hasSecondTenant === "no" ? "border-primary bg-primary/5 shadow-sm" : "border-border hover:border-muted-foreground/30"
                    )}
                  >
                    <div className="flex items-center gap-4">
                      <div className={cn("w-12 h-12 rounded-xl flex items-center justify-center shrink-0", hasSecondTenant === "no" ? "bg-primary/15 text-primary" : "bg-muted text-muted-foreground")}>
                        <User className="h-6 w-6" />
                      </div>
                      <div className="flex-1">
                        <p className="font-semibold text-foreground">Somente eu</p>
                        <p className="text-xs text-muted-foreground mt-0.5">Apenas 1 locatário no contrato</p>
                      </div>
                      {hasSecondTenant === "no" && (
                        <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center shrink-0">
                          <Check className="h-4 w-4 text-primary-foreground" />
                        </div>
                      )}
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setHasSecondTenant("yes")}
                    className={cn(
                      "w-full rounded-xl border-2 p-5 text-left transition-all",
                      hasSecondTenant === "yes" ? "border-primary bg-primary/5 shadow-sm" : "border-border hover:border-muted-foreground/30"
                    )}
                  >
                    <div className="flex items-center gap-4">
                      <div className={cn("w-12 h-12 rounded-xl flex items-center justify-center shrink-0", hasSecondTenant === "yes" ? "bg-primary/15 text-primary" : "bg-muted text-muted-foreground")}>
                        <Users className="h-6 w-6" />
                      </div>
                      <div className="flex-1">
                        <p className="font-semibold text-foreground">Adicionar 2º locatário</p>
                        <p className="text-xs text-muted-foreground mt-0.5">Outra pessoa assinará o contrato</p>
                      </div>
                      {hasSecondTenant === "yes" && (
                        <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center shrink-0">
                          <Check className="h-4 w-4 text-primary-foreground" />
                        </div>
                      )}
                    </div>
                  </button>
                </div>

                {hasSecondTenant === "no" && (
                  <p className="text-xs text-muted-foreground text-center">
                    Você pode alterar essa escolha a qualquer momento.
                  </p>
                )}

                {/* 2nd Tenant Registration Section */}
                {hasSecondTenant === "yes" && (
                  <div className="rounded-xl border border-border bg-card overflow-hidden animate-fade-in-up">
                    <div className="px-5 py-4 border-b bg-muted/30">
                      <h4 className="font-semibold text-foreground flex items-center gap-2">
                        <Users className="h-4 w-4 text-primary" />Locatário 2 — Cadastro
                      </h4>
                      <p className="text-xs text-muted-foreground mt-1">
                        Mesmos dados e documentos do Locatário 1.
                      </p>
                    </div>
                    <div className="p-5 space-y-4">
                      {secondTenantSaved ? (
                        /* Saved summary */
                        <div className="space-y-4">
                          <div className="flex items-center gap-3 p-4 rounded-xl border border-step-complete/30 bg-step-complete/5">
                            <div className="w-10 h-10 rounded-full bg-step-complete/20 flex items-center justify-center shrink-0 animate-check-pop">
                              <Check className="h-5 w-5 text-step-complete" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="font-medium text-foreground truncate">{secondTenantData.fullName || "2º Locatário"}</p>
                              <div className="flex flex-wrap gap-1.5 mt-1.5">
                                <Badge variant="secondary" className="text-[10px]">Dados OK</Badge>
                                <Badge variant="secondary" className="text-[10px]">
                                  {secondTenantDocuments.filter(d => d.status === 'uploaded').length} docs
                                </Badge>
                              </div>
                            </div>
                          </div>
                          <Button
                            variant="outline"
                            className="w-full min-h-[44px] gap-2 text-sm font-medium"
                            onClick={handleAddSecondTenant}
                            disabled={secondTenantNavigating}
                          >
                            {secondTenantNavigating ? (
                              <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                              <Edit2 className="h-4 w-4" />
                            )}
                            Revisar cadastro do Locatário 2
                          </Button>
                        </div>
                      ) : (
                        /* Not yet started / in progress */
                        <div className="space-y-4">
                          {secondTenantData.fullName && (
                            <div className="p-4 rounded-xl border border-amber-500/30 bg-amber-500/5">
                              <p className="text-sm font-medium text-foreground">{secondTenantData.fullName}</p>
                              <p className="text-xs text-amber-600 mt-0.5">Cadastro em andamento — conclua para liberar o envio.</p>
                            </div>
                          )}
                          <Button
                            className="w-full min-h-[48px] text-sm font-semibold gap-2"
                            onClick={handleAddSecondTenant}
                            disabled={secondTenantNavigating}
                          >
                            {secondTenantNavigating ? (
                              <>
                                <Loader2 className="h-4 w-4 animate-spin" />
                                Abrindo...
                              </>
                            ) : (
                              <>
                                <Users className="h-4 w-4" />
                                {secondTenantData.fullName ? "Continuar cadastro do Locatário 2" : "Iniciar cadastro do Locatário 2"}
                              </>
                            )}
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Scroll Indicator */}
        {showScrollIndicator && subStep > 0 && (
          <div className="absolute bottom-28 left-0 right-0 h-20 bg-gradient-to-t from-background to-transparent pointer-events-none flex items-end justify-center pb-2">
            <div className="animate-bounce">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                <ArrowDown className="h-4 w-4 text-primary" />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Fixed Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-background/95 backdrop-blur-sm border-t border-border z-50">
        <div className="container max-w-lg mx-auto">
          {subStep === 0 ? (
            /* Overview: single CTA + returnTo link */
            <div className="space-y-2">
              <Button size="lg" className="w-full h-14 text-base font-semibold gap-2" onClick={() => goToSubStep(1)}>
                Começar preenchimento
                <ChevronLeft className="h-5 w-5 rotate-180" />
              </Button>
              {searchParams.get('returnTo') && (
                <button
                  type="button"
                  className="w-full text-xs text-muted-foreground hover:text-foreground text-center transition-colors"
                  onClick={() => {
                    const returnTo = searchParams.get('returnTo');
                    if (returnTo) window.location.assign(window.location.origin + decodeURIComponent(returnTo));
                  }}
                >
                  ← Voltar para acompanhamento
                </button>
              )}
            </div>
          ) : subStep === 5 && canSubmit ? (
            /* Last sub-step with submit — show pending docs summary if any */
            <div className="space-y-2">
              {/* Pending docs summary before submit */}
              {(() => {
                const t1Missing = currentMissingTypes;
                const t2Missing = hasSecondTenant === "yes" && secondTenantSaved
                  ? REQUIRED_DOC_TYPES.filter(type => !secondTenantDocuments.some(f => f.type === type && f.status === 'uploaded'))
                  : [];
                const hasMissing = t1Missing.length > 0 || t2Missing.length > 0;

                if (!hasMissing) return null;

                return (
                  <details className="group">
                    <summary className="text-xs text-amber-600 cursor-pointer hover:underline">
                      ⚠ {t1Missing.length + t2Missing.length} documento(s) pendente(s) — ver detalhes
                    </summary>
                    <div className="mt-2 p-3 rounded-lg border border-amber-500/30 bg-amber-500/5 space-y-2 animate-accordion-down">
                      {t1Missing.length > 0 && (
                        <div>
                          <Badge variant="outline" className="text-[10px] font-semibold border-primary/40 text-primary mb-1">Locatário 1</Badge>
                          <ul className="list-disc list-inside">
                            {t1Missing.map(t => (
                              <li key={t} className="text-xs text-muted-foreground">{DOC_TYPE_LABELS[t]?.label || t}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                      {t2Missing.length > 0 && (
                        <div>
                          <Badge variant="outline" className="text-[10px] font-semibold border-primary/40 text-primary mb-1">Locatário 2</Badge>
                          <ul className="list-disc list-inside">
                            {t2Missing.map(t => (
                              <li key={t} className="text-xs text-muted-foreground">{DOC_TYPE_LABELS[t]?.label || t}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                      <p className="text-[11px] text-muted-foreground">
                        Você poderá complementar depois no Acompanhamento.
                      </p>
                    </div>
                  </details>
                );
              })()}

              {/* Primary CTA */}
              {documentsComplete ? (
                <Button
                  size="lg"
                  className="w-full min-h-[56px] text-base font-semibold"
                  disabled={isSubmitting}
                  onClick={() => handleSubmit(false)}
                >
                  {isSubmitting ? (
                    <><Loader2 className="mr-2 h-5 w-5 animate-spin" />Enviando...</>
                  ) : (
                    <><CheckCircle2 className="mr-2 h-5 w-5" />Finalizar Envio</>
                  )}
                </Button>
              ) : (
                <>
                  <Button
                    size="lg"
                    className="w-full min-h-[56px] text-base font-semibold"
                    onClick={() => goToSubStep(4)}
                  >
                    <Upload className="mr-2 h-5 w-5" />Enviar documentos agora
                  </Button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="outline" size="lg" className="w-full min-h-[48px] text-sm" disabled={isSubmitting}>
                        <Clock className="mr-2 h-4 w-4" />Enviar mesmo assim (com pendências)
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Enviar com pendências?</AlertDialogTitle>
                        <AlertDialogDescription>
                          Seus dados serão enviados e os documentos já anexados serão mantidos. Você poderá complementar os documentos pendentes depois pelo Acompanhamento.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Voltar</AlertDialogCancel>
                        <AlertDialogAction onClick={() => handleSubmit(true)}>Enviar com pendências</AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </>
              )}
            </div>
          ) : (
            /* Navigation buttons — Back + Next */
            <div className="space-y-2">
              <div className="flex gap-3">
                {subStep > 1 && (
                  <Button variant="outline" size="lg" onClick={goPreviousSubStep} className="h-14 px-4">
                    <ChevronLeft className="h-5 w-5" />
                  </Button>
                )}
                {subStep === 1 && searchParams.get('returnTo') && (
                  <Button
                    variant="outline"
                    size="lg"
                    onClick={() => {
                      const returnTo = searchParams.get('returnTo');
                      if (returnTo) window.location.assign(window.location.origin + decodeURIComponent(returnTo));
                      else goPreviousSubStep();
                    }}
                    className="h-14 px-4"
                  >
                    <ChevronLeft className="h-5 w-5" />
                  </Button>
                )}
                {subStep === 1 && !searchParams.get('returnTo') && (
                  <Button variant="outline" size="lg" onClick={goPreviousSubStep} className="h-14 px-4">
                    <ChevronLeft className="h-5 w-5" />
                  </Button>
                )}
                <Button size="lg" className="flex-1 h-14 text-base font-semibold" onClick={goNextSubStep}>
                  {subStep === 5 && hasSecondTenant === "yes" && !secondTenantSaved
                    ? "Preencher dados do Locatário 2"
                    : subStep === 5 ? "Revisar e Enviar" : "Continuar"}
                </Button>
              </div>
              {searchParams.get('returnTo') && (
                <button
                  type="button"
                  className="w-full text-[11px] text-muted-foreground hover:text-foreground text-center transition-colors"
                  onClick={() => {
                    const returnTo = searchParams.get('returnTo');
                    if (returnTo) window.location.assign(window.location.origin + decodeURIComponent(returnTo));
                  }}
                >
                  ← Voltar para acompanhamento
                </button>
              )}
            </div>
          )}
          {subStep > 0 && (
            <p className="text-xs text-muted-foreground text-center mt-2">
              Etapa {subStep} de {totalSubSteps}
            </p>
          )}
          {subStep > 0 && missingFieldsCount > 0 && (
            <p className="text-xs text-amber-600 text-center mt-1">
              {subStep === 5 && hasSecondTenant === "yes" && !secondTenantSaved
                ? "Complete o cadastro do 2º locatário para enviar"
                : `Faltam ${missingFieldsCount} campo${missingFieldsCount > 1 ? 's' : ''} obrigatório${missingFieldsCount > 1 ? 's' : ''}`
              }
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
