import { useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { LayoutDashboard, BarChart3, Link2, LogOut, Home, Map as MapIcon, List, Search } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { AdminRentalModal } from "@/components/admin/AdminRentalModal";
import { AnalyticsDashboard } from "@/components/admin/AnalyticsDashboard";
import { useAdminRentals, type AdminRentalWithProfile } from "@/hooks/useAdminRentals";
import { useAdminPipelineStages } from "@/hooks/useAdminPipelineStages";
import { AdminKanbanBoard } from "@/components/admin/AdminKanbanBoard";
import { AdminPropertyModal } from "@/components/admin/AdminPropertyModal";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const STEP_LABELS: Record<number, string> = {
  1: 'Proposta', 2: 'Negociação', 3: 'Docs locatário', 4: 'Triagem',
  5: 'Análise', 6: 'Contrato', 7: 'Assinatura', 8: 'Assinado',
  9: 'Vistoria', 10: 'Chaves',
};

export default function Admin() {
  const [activeTab, setActiveTab] = useState("operacional");
  const navigate = useNavigate();
  const { logout } = useAuth();
  const [isSigningOut, setIsSigningOut] = useState(false);

  const { rentals, loading, error, refetch } = useAdminRentals();
  const { stages, stageById, loading: stagesLoading, refetch: refetchStages } = useAdminPipelineStages();
  const [selectedRental, setSelectedRental] = useState<AdminRentalWithProfile | null>(null);
  const [propertyOpen, setPropertyOpen] = useState(false);
  const [selectedPropertyRental, setSelectedPropertyRental] = useState<AdminRentalWithProfile | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  // Step counts for dashboard
  const stepCounts = useMemo(() => {
    const counts: Record<number, number> = {};
    for (let i = 1; i <= 10; i++) counts[i] = 0;
    rentals.forEach(r => {
      const step = Math.min(10, Math.max(1, (r as any).current_step ?? 1));
      counts[step] = (counts[step] ?? 0) + 1;
    });
    return counts;
  }, [rentals]);

  const stageCounts = useMemo(() => {
    const countsByStageId = new Map<string, number>();
    stages.forEach((s) => countsByStageId.set(s.id, 0));

    for (const r of rentals) {
      const stageId = r.admin_stage_id ?? null;
      if (stageId && countsByStageId.has(stageId)) {
        countsByStageId.set(stageId, (countsByStageId.get(stageId) ?? 0) + 1);
        continue;
      }
      const fallback = stages.find((s) => s.order_index === Number(r.admin_stage ?? 1)) ?? stages[0];
      if (fallback) countsByStageId.set(fallback.id, (countsByStageId.get(fallback.id) ?? 0) + 1);
    }

    return countsByStageId;
  }, [rentals, stages]);

  const handleSignOut = async () => {
    if (isSigningOut) return;
    setIsSigningOut(true);
    try {
      await logout();
      navigate("/auth", { replace: true });
    } finally {
      setIsSigningOut(false);
    }
  };

  const handleMoveStage = async (rentalId: string, fromStageId: string, toStageId: string) => {
    const toOrder = stageById.get(toStageId)?.order_index ?? 1;
    const fromOrder = stageById.get(fromStageId)?.order_index;

    const { error: updateError } = await supabase
      .from("rentals")
      .update({ admin_stage_id: toStageId, admin_stage: toOrder })
      .eq("id", rentalId);
    if (updateError) throw updateError;

    const fromLabel = stageById.get(fromStageId)?.name ?? (fromOrder ? `Etapa ${fromOrder}` : "Etapa");
    const toLabel = stageById.get(toStageId)?.name ?? `Etapa ${toOrder}`;
    const { error: eventError } = await supabase.from("rental_events").insert({
      rental_id: rentalId,
      event_type: "stage_change",
      description: `Moveu a ficha de "${fromLabel}" para "${toLabel}"`,
    });
    if (eventError) throw eventError;
    toast.success("Etapa atualizada");
    refetch();
    refetchStages();
  };

  const dashboardData = useMemo(() => {
    const funnelData = stages.map((s) => {
      const count = stageCounts.get(s.id) ?? 0;
      const total = rentals.length || 1;
      return {
        stageId: s.id,
        label: s.name,
        count,
        percentage: Math.round((count / total) * 100),
      };
    });

    const stageTimeData: any[] = [];
    const monthlyData: any[] = [];
    const rejectionData: any[] = [];

    return { funnelData, stageTimeData, monthlyData, rejectionData };
  }, [stages, stageCounts, rentals.length]);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-6">
              <Link to="/" className="flex items-center gap-2">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <span className="text-primary-foreground font-bold">E</span>
                </div>
                <span className="font-bold text-lg">Etic Admin</span>
              </Link>
              
              {/* Tabs no Header */}
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList>
                  <TabsTrigger value="operacional" className="gap-2">
                    <LayoutDashboard className="h-4 w-4" />
                    Operacional
                  </TabsTrigger>
                  <TabsTrigger value="analytics" className="gap-2">
                    <BarChart3 className="h-4 w-4" />
                    Analytics
                  </TabsTrigger>
                </TabsList>
              </Tabs>
            </div>

            <div className="flex items-center gap-3">
              <Button variant="outline" size="sm" asChild>
                <Link to="/mapa">
                  <MapIcon className="mr-2 h-4 w-4" />
                  Mapa do Produto
                </Link>
              </Button>
              <Button variant="outline" size="sm" asChild>
                <Link to="/selecionar-imovel">
                  <Home className="mr-2 h-4 w-4" />
                  Selecionar Imóvel
                </Link>
              </Button>
              <Button variant="outline" size="sm" asChild>
                <Link to="/admin/invites">
                  <Link2 className="mr-2 h-4 w-4" />
                  Convites
                </Link>
              </Button>
              <Button variant="ghost" size="sm" onClick={handleSignOut} disabled={isSigningOut}>
                <LogOut className="mr-2 h-4 w-4" />
                {isSigningOut ? "Saindo..." : "Sair"}
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {activeTab === "operacional" ? (
          <div>
            <div className="mb-6">
              <h1 className="text-3xl font-bold">Gestão de Fichas de Locação</h1>
              <p className="text-muted-foreground mt-1">
                Acompanhe e gerencie todas as propostas de locação em andamento.
              </p>
            </div>

            {/* Step counters (1-10) */}
            <div className="grid grid-cols-5 sm:grid-cols-10 gap-2 mb-6">
              {Array.from({ length: 10 }, (_, i) => i + 1).map(step => (
                <Card key={step} className="text-center cursor-pointer hover:shadow-md transition-shadow" onClick={() => navigate(`/admin/rentals?step=${step}`)}>
                  <CardContent className="p-2">
                    <p className="text-lg font-bold">{stepCounts[step]}</p>
                    <p className="text-[10px] text-muted-foreground leading-tight">{STEP_LABELS[step]}</p>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Quick search & links */}
            <div className="flex flex-wrap gap-3 mb-6">
              <div className="relative flex-1 min-w-[200px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar protocolo ou ID..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="pl-9"
                  onKeyDown={e => {
                    if (e.key === 'Enter' && searchQuery.trim()) {
                      navigate(`/admin/rentals?search=${encodeURIComponent(searchQuery.trim())}`);
                    }
                  }}
                />
              </div>
              <Button variant="outline" size="sm" asChild>
                <Link to="/admin/rentals"><List className="mr-2 h-4 w-4" />Lista completa</Link>
              </Button>
            </div>

            {error && (
              <div className="text-center py-8 text-destructive">
                <p>{error}</p>
                <Button variant="outline" className="mt-4" onClick={() => refetch()}>
                  Tentar novamente
                </Button>
              </div>
            )}

            {loading || stagesLoading ? (
              <div className="text-center py-12 text-muted-foreground">
                <p>Carregando propostas...</p>
              </div>
            ) : (
              <AdminKanbanBoard
                rentals={rentals}
                stages={stages}
                onCardClick={(r) => setSelectedRental(r)}
                onOpenProperty={(r) => {
                  setSelectedPropertyRental(r);
                  setPropertyOpen(true);
                }}
                onMoveStage={handleMoveStage}
              />
            )}
          </div>
        ) : (
          <div>
            <div className="mb-8">
              <h1 className="text-3xl font-bold">Analytics & Business Intelligence</h1>
              <p className="text-muted-foreground mt-1">
                Métricas de desempenho, funil de vendas e análise de conversão.
              </p>
            </div>

            <AnalyticsDashboard
              counts={{
                received: rentals.length,
                analysis: rentals.filter((r) => !r.is_rejected).length,
                approved: stageCounts.get(stages[stages.length - 1]?.id ?? "") ?? 0,
                rejected: rentals.filter((r) => !!r.is_rejected).length,
              }}
              funnelData={dashboardData.funnelData}
              stageTimeData={dashboardData.stageTimeData}
              rejectionData={dashboardData.rejectionData}
              monthlyData={dashboardData.monthlyData}
              onKpiClick={() => setActiveTab("operacional")}
              onStageClick={() => setActiveTab("operacional")}
            />
          </div>
        )}
      </main>

      <AdminRentalModal
        rental={selectedRental}
        open={!!selectedRental}
        onOpenChange={(o) => !o && setSelectedRental(null)}
        onUpdated={refetch}
      />

      <AdminPropertyModal
        open={propertyOpen}
        onOpenChange={setPropertyOpen}
        property={selectedPropertyRental?.property}
        fallbackAddress={selectedPropertyRental?.property_address}
      />
    </div>
  );
}
