import { Link } from "react-router-dom";
import { ShieldX, Home } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Forbidden() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-background to-muted/30">
      <div className="text-center space-y-6 px-4">
        <div className="flex justify-center">
          <ShieldX className="h-20 w-20 text-destructive/60" />
        </div>
        <h1 className="text-4xl font-bold text-foreground">Acesso negado</h1>
        <p className="text-muted-foreground max-w-md mx-auto">
          Você não tem permissão para acessar esta página.
          Se acredita que isso é um erro, entre em contato com o administrador.
        </p>
        <Button asChild size="lg">
          <Link to="/">
            <Home className="mr-2 h-4 w-4" />
            Voltar ao início
          </Link>
        </Button>
      </div>
    </div>
  );
}
