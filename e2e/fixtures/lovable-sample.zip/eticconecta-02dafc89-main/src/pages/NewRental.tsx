import { Link } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Building2, ArrowLeft, FileText } from 'lucide-react';

export default function NewRental() {
  const { profile, logout } = useAuth();

  return (
    <div className="min-h-screen bg-secondary/30">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Building2 className="h-6 w-6 text-primary" />
            <span className="text-lg font-semibold">Etic Imóveis</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground">
              {profile?.full_name || 'Usuário'}
            </span>
            <Button variant="outline" size="sm" onClick={logout}>
              Sair
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        <div className="mb-8">
          <Button variant="ghost" size="sm" asChild className="mb-4">
            <Link to="/minhas-locacoes">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Voltar
            </Link>
          </Button>
          <h1 className="text-3xl font-bold">Nova Proposta de Locação</h1>
          <p className="text-muted-foreground">
            Preencha os dados abaixo para iniciar sua proposta
          </p>
        </div>

        {/* Stepper Placeholder */}
        <Card className="animate-fade-in">
          <CardHeader>
            <div className="flex items-center gap-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-primary-foreground">
                1
              </div>
              <div>
                <CardTitle>Dados do Imóvel</CardTitle>
                <CardDescription>
                  Informe o código e endereço do imóvel desejado
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center justify-center py-12">
              <div className="mb-4 rounded-full bg-secondary p-4">
                <FileText className="h-8 w-8 text-muted-foreground" />
              </div>
              <p className="text-center text-muted-foreground">
                Formulário multi-step será implementado aqui.
                <br />
                Etapas: Dados do Imóvel → Dados Pessoais → Documentos → Revisão
              </p>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
