import { useParams, Link } from "react-router-dom";
import { CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function EnvioSucesso() {
  const { id } = useParams<{ id: string }>();

  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="text-center max-w-md mx-auto px-4">
        <CheckCircle className="mx-auto h-16 w-16 text-green-500 mb-6" />
        <h1 className="text-3xl font-bold mb-4">Documentos Enviados!</h1>
        <p className="text-muted-foreground mb-8">
          Seus documentos foram enviados com sucesso. Você receberá uma notificação quando a análise for concluída.
        </p>
        <div className="space-y-3">
          <Button asChild className="w-full">
            <Link to={`/acompanhamento/${id}`}>Acompanhar status</Link>
          </Button>
          <Button variant="outline" asChild className="w-full">
            <Link to="/">Voltar ao início</Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
