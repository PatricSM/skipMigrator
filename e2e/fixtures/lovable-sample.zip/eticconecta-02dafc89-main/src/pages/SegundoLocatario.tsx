import { useState, useRef, useEffect } from "react";
import { useParams, useNavigate, useLocation } from "react-router-dom";
import { ChevronLeft, User, DollarSign, FileText, Check, ArrowDown, Trophy, Zap, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Progress } from "@/components/ui/progress";
import { PersonalDataForm } from "@/components/rental/PersonalDataForm";
import { IncomeDataForm } from "@/components/rental/IncomeDataForm";
import { DocumentUpload, DocFileEntry } from "@/components/rental/DocumentUpload";
import { TenantData, DocumentUploadState, initialTenantData } from "@/types/rental";
import {
  validatePersonalData, validateIncomeData, validateIdentityFields, validateCivilFields,
  hasErrors, ValidationErrors,
} from "@/utils/formValidation";
import { useDocumentUpload } from "@/hooks/useDocumentUpload";
import { cn } from "@/lib/utils";
import { DOCUMENT_LIMITS, DOC_TYPE_LABELS, DOC_MICROCOPY, REQUIRED_DOC_TYPES } from "@/types/documentLimits";
import { scrollToFirstError } from "@/lib/scrollToFirstError";

type SubStep = 0 | 1 | 2 | 3 | 4;

const SUB_STEP_META: Record<number, { title: string; description: string; icon: typeof User }> = {
  1: { title: "Identificação", description: "Nome, e-mail e telefone do 2º locatário", icon: User },
  2: { title: "Dados Civis", description: "Nascimento, CPF, nacionalidade e estado civil", icon: User },
  3: { title: "Financeiro", description: "Profissão e renda", icon: DollarSign },
  4: { title: "Documentos", description: "Envie os documentos do 2º locatário", icon: FileText },
};

export default function SegundoLocatario() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();
  const { uploadDocument, removeDocument, retryDocument, uploading } = useDocumentUpload();

  const passedData = location.state as {
    tenantData?: TenantData;
    documents?: DocumentUploadState[];
    mainTenantData?: TenantData;
    mainTenantDocuments?: DocumentUploadState[];
    proposalType?: 'direct' | 'standard';
    proposedValue?: number;
    sendDocs?: boolean;
  } | null;

  const [subStep, setSubStep] = useState<SubStep>(0);
  const [slideDirection, setSlideDirection] = useState<'left' | 'right'>('left');
  const [showStepCheck, setShowStepCheck] = useState(false);

  const [tenantData, setTenantData] = useState<TenantData>(
    passedData?.tenantData || initialTenantData
  );
  const [documents, setDocuments] = useState<DocFileEntry[]>(
    (passedData?.documents as unknown as DocFileEntry[]) || []
  );
  const [errors, setErrors] = useState<ValidationErrors>({});
  const [showScrollIndicator, setShowScrollIndicator] = useState(false);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // Pulse focus
  useEffect(() => {
    if (subStep === 0) return;
    const container = scrollContainerRef.current;
    if (!container) return;
    const timer = setTimeout(() => {
      const firstInput = container.querySelector('input:not([type="hidden"]), select, textarea') as HTMLElement;
      if (firstInput) {
        firstInput.classList.add('animate-pulse-border');
        setTimeout(() => firstInput?.classList.remove('animate-pulse-border'), 6500);
      }
    }, 350);
    return () => clearTimeout(timer);
  }, [subStep]);

  // Scroll indicator
  useEffect(() => {
    const container = scrollContainerRef.current;
    if (!container) return;
    const checkScroll = () => {
      const { scrollTop, scrollHeight, clientHeight } = container;
      setShowScrollIndicator(!((scrollTop + clientHeight) >= scrollHeight - 20) && scrollHeight > clientHeight);
    };
    checkScroll();
    container.addEventListener('scroll', checkScroll);
    return () => container.removeEventListener('scroll', checkScroll);
  }, [subStep]);

  // Completion checks
  const identityComplete = !hasErrors(validateIdentityFields(tenantData));
  const civilComplete = !hasErrors(validateCivilFields(tenantData));
  const personalComplete = identityComplete && civilComplete;
  const incomeComplete = !hasErrors(validateIncomeData(tenantData));
  const documentsComplete = REQUIRED_DOC_TYPES.every(type =>
    documents.some(f => f.type === type && f.status === 'uploaded')
  );
  const canSave = personalComplete && incomeComplete;
  const allComplete = personalComplete && incomeComplete && documentsComplete;

  const subStepComplete: Record<number, boolean> = {
    1: identityComplete,
    2: civilComplete,
    3: incomeComplete,
    4: documentsComplete,
  };

  const totalSubSteps = 4;
  const completedSubSteps = [1, 2, 3, 4].filter(s => subStepComplete[s]).length;
  const wizardProgress = (completedSubSteps / totalSubSteps) * 100;

  const goToSubStep = (step: SubStep, direction: 'left' | 'right' = 'left') => {
    setSlideDirection(direction);
    setSubStep(step);
    scrollContainerRef.current?.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const shakeFirstError = () => {
    setTimeout(() => {
      const el = scrollContainerRef.current?.querySelector('[class*="border-destructive"]')?.closest('.space-y-2');
      if (el) { el.classList.add('animate-shake'); setTimeout(() => el.classList.remove('animate-shake'), 600); }
    }, 100);
  };

  const showCheckAndAdvance = (nextStep: SubStep) => {
    setShowStepCheck(true);
    setTimeout(() => {
      setShowStepCheck(false);
      goToSubStep(nextStep);
    }, 500);
  };

  const goNextSubStep = () => {
    if (subStep === 0) { goToSubStep(1); return; }

    if (subStep === 1) {
      const errs = validateIdentityFields(tenantData);
      if (hasErrors(errs)) { setErrors(errs); scrollToFirstError(scrollContainerRef.current); shakeFirstError(); toast({ title: "Campos obrigatórios", description: "Preencha nome, e-mail e telefone.", variant: "destructive" }); return; }
      setErrors({}); showCheckAndAdvance(2);
    } else if (subStep === 2) {
      const errs = validateCivilFields(tenantData);
      if (hasErrors(errs)) { setErrors(errs); scrollToFirstError(scrollContainerRef.current); shakeFirstError(); toast({ title: "Campos obrigatórios", description: "Preencha todos os dados civis.", variant: "destructive" }); return; }
      setErrors({}); showCheckAndAdvance(3);
    } else if (subStep === 3) {
      const errs = validateIncomeData(tenantData);
      if (hasErrors(errs)) { setErrors(errs); scrollToFirstError(scrollContainerRef.current); shakeFirstError(); toast({ title: "Campos obrigatórios", description: "Preencha profissão e renda.", variant: "destructive" }); return; }
      setErrors({}); showCheckAndAdvance(4);
    }
  };

  const goPreviousSubStep = () => {
    if (subStep > 1) goToSubStep((subStep - 1) as SubStep, 'right');
    else if (subStep === 1) goToSubStep(0, 'right');
  };

  // Document handlers
  const handleDocUpload = (docType: string, files: File[], documentLabel?: string) => {
    const currentCount = documents.filter(f => f.type === docType && (f.status === 'uploaded' || f.status === 'uploading')).length;
    const limit = DOCUMENT_LIMITS[docType] ?? 1;
    const remaining = limit - currentCount;
    if (remaining <= 0) { toast({ title: "Limite atingido", description: `Limite de ${limit} arquivo(s) atingido.`, variant: "destructive" }); return; }

    const filesToUpload = files.slice(0, remaining);
    if (filesToUpload.length < files.length) {
      toast({ title: "Limite parcial", description: `Enviando apenas ${filesToUpload.length} de ${files.length}.` });
    }

    for (const file of filesToUpload) {
      const newId = crypto.randomUUID();
      const newEntry: DocFileEntry = { id: newId, type: docType, status: 'uploading', fileName: file.name, documentLabel, progress: 0 };
      setDocuments(prev => [...prev, newEntry]);

      const setAdapter = (fn: React.SetStateAction<DocumentUploadState[]>) => {
        setDocuments(prev => {
          if (typeof fn === 'function') {
            const asDUS = prev.map(f => ({ id: f.id, type: f.type as DocumentUploadState['type'], label: DOC_TYPE_LABELS[f.type]?.label || f.type, description: DOC_TYPE_LABELS[f.type]?.description || '', status: f.status, progress: f.progress, fileName: f.fileName, fileUrl: f.fileUrl, errorMessage: f.errorMessage, documentLabel: f.documentLabel }));
            const result = fn(asDUS);
            return result.map(r => ({ id: r.id, type: r.type, status: r.status, fileName: r.fileName, fileUrl: r.fileUrl, documentLabel: r.documentLabel, progress: r.progress, errorMessage: r.errorMessage }));
          }
          return prev;
        });
      };
      uploadDocument(newId, file, docType, setAdapter as any, undefined, documentLabel);
    }
  };

  const handleDocRemove = (fileId: string) => {
    const file = documents.find(f => f.id === fileId);
    if (file) {
      removeDocument(fileId, file.fileUrl, ((fn: any) => {
        setDocuments(prev => {
          if (typeof fn === 'function') {
            const asDUS = prev.map(f => ({ id: f.id, type: f.type as DocumentUploadState['type'], label: DOC_TYPE_LABELS[f.type]?.label || f.type, description: DOC_TYPE_LABELS[f.type]?.description || '', status: f.status, progress: f.progress, fileName: f.fileName, fileUrl: f.fileUrl, errorMessage: f.errorMessage, documentLabel: f.documentLabel }));
            const result = fn(asDUS);
            return result.filter((r: any) => r.status !== 'empty' || r.fileUrl).map((r: any) => ({ id: r.id, type: r.type, status: r.status, fileName: r.fileName, fileUrl: r.fileUrl, documentLabel: r.documentLabel, progress: r.progress, errorMessage: r.errorMessage }));
          }
          return prev;
        });
      }) as any);
    }
  };

  const handleDocRetry = (fileId: string) => { setDocuments(prev => prev.filter(f => f.id !== fileId)); };

  const handleSave = () => {
    const hasPendingDocs = !documentsComplete;
    navigate(`/locatario/enviar-documentos/${id}`, {
      state: {
        secondTenantData: tenantData, secondTenantDocuments: documents, secondTenantSaved: true, secondTenantHasPendingDocs: hasPendingDocs,
        mainTenantData: passedData?.mainTenantData, mainTenantDocuments: passedData?.mainTenantDocuments,
        proposalType: passedData?.proposalType, proposedValue: passedData?.proposedValue, sendDocs: passedData?.sendDocs,
      },
      replace: true,
    });
    toast({ title: hasPendingDocs ? "Dados salvos (docs pendentes)" : "Dados salvos", description: hasPendingDocs ? "Documentos serão solicitados posteriormente." : "Dados do 2º locatário salvos com sucesso." });
  };

  const handleCancel = () => {
    navigate(`/locatario/enviar-documentos/${id}`, {
      state: { mainTenantData: passedData?.mainTenantData, mainTenantDocuments: passedData?.mainTenantDocuments, proposalType: passedData?.proposalType, proposedValue: passedData?.proposedValue, sendDocs: passedData?.sendDocs },
      replace: true,
    });
  };

  // Missing fields counter
  const currentMissingDocTypes = REQUIRED_DOC_TYPES.filter(type => !documents.some(f => f.type === type && f.status === 'uploaded'));
  const missingFieldsCount = (() => {
    if (subStep === 1) return Object.keys(validateIdentityFields(tenantData)).length;
    if (subStep === 2) return Object.keys(validateCivilFields(tenantData)).length;
    if (subStep === 3) return Object.keys(validateIncomeData(tenantData)).length;
    if (subStep === 4) return currentMissingDocTypes.length;
    return 0;
  })();

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-14">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-sm">E</span>
              </div>
              <span className="font-bold text-base hidden sm:inline">Etic Imóveis</span>
            </div>
            <Button variant="ghost" size="sm" onClick={handleCancel}>
              <ChevronLeft className="mr-1 h-4 w-4" />Voltar
            </Button>
          </div>
        </div>
      </header>

      {/* Dynamic Header */}
      {subStep === 0 ? (
        <div className="border-b bg-muted/30 px-4 py-4">
          <div className="container max-w-lg mx-auto space-y-4">
            <div className="flex items-center gap-3">
              <div className={cn("w-10 h-10 rounded-full flex items-center justify-center", allComplete ? "bg-step-complete text-step-complete-foreground" : "bg-primary/10 text-primary")}>
                {allComplete ? <Trophy className="h-5 w-5" /> : <Zap className="h-5 w-5" />}
              </div>
              <div>
                <h2 className="font-semibold text-foreground">2º Locatário</h2>
                <p className="text-xs text-muted-foreground">{allComplete ? "Dados completos!" : `${completedSubSteps}/4 etapas concluídas`}</p>
              </div>
            </div>
            <Progress value={wizardProgress} className="h-2" />
          </div>
        </div>
      ) : (
        <div className="border-b bg-muted/30 px-4 py-2.5 sticky top-14 z-40">
          <div className="container max-w-lg mx-auto">
            <div className="flex items-center gap-3">
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-medium text-foreground">Etapa {subStep} de {totalSubSteps}</span>
                  <span className="text-xs font-bold text-primary">{Math.round(wizardProgress)}%</span>
                </div>
                <Progress value={wizardProgress} className="h-1.5" />
              </div>
              <div className="flex gap-1.5">
                {[1, 2, 3, 4].map(s => (
                  <button key={s} type="button" onClick={() => goToSubStep(s as SubStep)}
                    className={cn("w-2.5 h-2.5 rounded-full transition-all", subStepComplete[s] ? "bg-step-complete" : subStep === s ? "bg-primary" : "bg-muted-foreground/30")}
                    aria-label={`Etapa ${s}`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Sub-step title */}
      {subStep > 0 && (
        <div className="px-4 py-3 border-b">
          <div className="container max-w-lg mx-auto">
            <div className="flex items-center gap-3">
              <div className={cn("w-9 h-9 rounded-full flex items-center justify-center shrink-0", subStepComplete[subStep] ? "bg-step-complete text-step-complete-foreground" : "bg-primary text-primary-foreground")}>
                {subStepComplete[subStep] ? <Check className="h-4 w-4" /> : (() => { const Icon = SUB_STEP_META[subStep].icon; return <Icon className="h-4 w-4" />; })()}
              </div>
              <div>
                <h1 className="text-base font-semibold">{SUB_STEP_META[subStep].title}</h1>
                <p className="text-xs text-muted-foreground">{SUB_STEP_META[subStep].description}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Step check overlay */}
      {showStepCheck && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-background/60 backdrop-blur-sm">
          <div className="animate-step-check w-20 h-20 rounded-full bg-step-complete flex items-center justify-center">
            <Check className="h-10 w-10 text-step-complete-foreground" />
          </div>
        </div>
      )}

      {/* Form Content */}
      <div className="flex-1 overflow-hidden relative">
        <div ref={scrollContainerRef} className="h-full overflow-y-auto px-4 py-6 pb-32">
          <div className="container max-w-lg mx-auto">
            {/* Overview */}
            {subStep === 0 && (
              <div className="space-y-4 animate-fade-in-up">
                <div className="text-center space-y-2 py-4">
                  <h2 className="text-xl font-bold text-foreground">Dados do Locatário 2</h2>
                  <p className="text-sm text-muted-foreground">Mesmos dados do locatário principal. São 4 etapas rápidas.</p>
                </div>
                {[1, 2, 3, 4].map(s => {
                  const meta = SUB_STEP_META[s];
                  const Icon = meta.icon;
                  const done = subStepComplete[s];
                  return (
                    <button key={s} type="button" onClick={() => goToSubStep(s as SubStep)}
                      className={cn("w-full rounded-xl border p-4 text-left transition-all flex items-center gap-4", done ? "border-step-complete/40 bg-step-complete/5" : "border-border hover:border-primary/30 hover:bg-primary/5")}>
                      <div className={cn("w-10 h-10 rounded-full flex items-center justify-center shrink-0", done ? "bg-step-complete text-step-complete-foreground" : "bg-primary/10 text-primary")}>
                        {done ? <Check className="h-5 w-5" /> : <Icon className="h-5 w-5" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-foreground text-sm">{meta.title}</p>
                        <p className="text-xs text-muted-foreground">{meta.description}</p>
                      </div>
                      {!done && <ChevronLeft className="h-4 w-4 text-muted-foreground rotate-180 shrink-0" />}
                    </button>
                  );
                })}
              </div>
            )}

            {subStep === 1 && (
              <div className={cn(slideDirection === 'left' ? 'animate-slide-in-left' : 'animate-slide-in-right')}>
                <PersonalDataForm data={tenantData} onChange={setTenantData} prefix="second-" errors={errors} section="identity" />
              </div>
            )}
            {subStep === 2 && (
              <div className={cn(slideDirection === 'left' ? 'animate-slide-in-left' : 'animate-slide-in-right')}>
                <PersonalDataForm data={tenantData} onChange={setTenantData} prefix="second-" errors={errors} section="civil" />
              </div>
            )}
            {subStep === 3 && (
              <div className={cn(slideDirection === 'left' ? 'animate-slide-in-left' : 'animate-slide-in-right')}>
                <IncomeDataForm data={tenantData} onChange={setTenantData} prefix="second-" errors={errors} />
              </div>
            )}
            {subStep === 4 && (
              <div className={cn("space-y-4", slideDirection === 'left' ? 'animate-slide-in-left' : 'animate-slide-in-right')}>
                {(['identity', 'income', 'residence', 'other'] as const).map((docType) => {
                  const info = DOC_TYPE_LABELS[docType];
                  return (
                    <DocumentUpload key={docType} docType={docType} label={info.label} description={info.description}
                      microcopy={DOC_MICROCOPY[docType] || undefined} files={documents.filter(f => f.type === docType)}
                      maxFiles={DOCUMENT_LIMITS[docType]} onUpload={(files, label) => handleDocUpload(docType, files, label)}
                      onRemove={(fileId) => handleDocRemove(fileId)} onRetry={(fileId) => handleDocRetry(fileId)}
                      showLabelInput={docType === 'other'}
                    />
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {showScrollIndicator && subStep > 0 && (
          <div className="absolute bottom-28 left-0 right-0 h-20 bg-gradient-to-t from-background to-transparent pointer-events-none flex items-end justify-center pb-2">
            <div className="animate-bounce">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                <ArrowDown className="h-4 w-4 text-primary" />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Fixed Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-background/95 backdrop-blur-sm border-t border-border z-50">
        <div className="container max-w-lg mx-auto">
          {subStep === 0 ? (
            <Button size="lg" className="w-full h-14 text-base font-semibold gap-2" onClick={() => goToSubStep(1)}>
              Começar preenchimento
              <ChevronLeft className="h-5 w-5 rotate-180" />
            </Button>
          ) : subStep === 4 && canSave ? (
            <div className="space-y-2">
              <Button size="lg"
                className={cn("w-full h-14 text-base font-semibold gap-2", !allComplete && "bg-amber-600 hover:bg-amber-700")}
                onClick={handleSave}>
                {allComplete ? (<><Check className="h-5 w-5" />Salvar 2º Locatário</>) : (<><AlertTriangle className="h-5 w-5" />Salvar (Docs Pendentes)</>)}
              </Button>
              {!allComplete && <p className="text-xs text-amber-600 text-center">Os documentos pendentes serão solicitados posteriormente.</p>}
            </div>
          ) : (
            <div className="flex gap-3">
              <Button variant="outline" size="lg" onClick={goPreviousSubStep} className="h-14">
                <ChevronLeft className="h-5 w-5" />
              </Button>
              <Button size="lg" className="flex-1 h-14 text-base font-semibold" onClick={goNextSubStep} disabled={uploading}>
                {subStep === 4 ? "Revisar" : "Continuar"}
              </Button>
            </div>
          )}
          {subStep > 0 && (
            <p className="text-xs text-muted-foreground text-center mt-2">
              Etapa {subStep} de {totalSubSteps} • 2º Locatário
            </p>
          )}
          {subStep > 0 && missingFieldsCount > 0 && (
            <p className="text-xs text-amber-600 text-center mt-1">
              Faltam {missingFieldsCount} campo{missingFieldsCount > 1 ? 's' : ''} obrigatório{missingFieldsCount > 1 ? 's' : ''}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}