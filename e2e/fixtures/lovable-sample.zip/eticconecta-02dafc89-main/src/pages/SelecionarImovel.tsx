import { useState, useEffect, useMemo, useDeferredValue, useRef, useCallback, memo } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, MapPin, Bed, Bath, Square, ChevronRight, Copy, Check, RefreshCw, Home, Car, X, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useProperties, Property } from "@/hooks/useProperties";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { PropertyFilters } from "@/components/property/PropertyFilters";
import { AppHeader } from "@/components/layout/AppHeader";
import { PropertyImageCarousel } from "@/components/property/PropertyImageCarousel";

const propertyTypeTranslations: Record<string, string> = {
  "residential / apartment": "Apartamento",
  "residential / home": "Casa",
  "residential / house": "Casa",
  "residential / condo": "Condomínio",
  "residential / flat": "Flat",
  "residential / studio": "Studio",
  "residential / loft": "Loft",
  "residential / penthouse": "Cobertura",
  "residential / townhouse": "Sobrado",
  "commercial / office": "Sala Comercial",
  "commercial / store": "Loja",
  "apartment": "Apartamento",
  "house": "Casa",
  "home": "Casa",
  "studio": "Studio",
};

function translatePropertyType(type: string): string {
  const normalized = type.toLowerCase().trim();
  return propertyTypeTranslations[normalized] || type;
}

export default function SelecionarImovel() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const [searchTerm, setSearchTerm] = useState("");
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  
  // Infinite scroll state
  const [visibleCount, setVisibleCount] = useState(20);
  const loadMoreRef = useRef<HTMLDivElement>(null);
  
  // Advanced filters state
  const [minBedrooms, setMinBedrooms] = useState<number | null>(null);
  const [minParkingSpaces, setMinParkingSpaces] = useState<number | null>(null);
  const [priceRange, setPriceRange] = useState<[number, number]>([1000, 20000]);
  
  // Fixed price range for filter (1000 to 20000+)
  const minPropertyPrice = 1000;
  const maxPropertyPrice = 20000;
  
  // Get filter params from URL
  const bairroFilter = searchParams.get("bairro");
  const codigoFilter = searchParams.get("codigo");
  const buscaFilter = searchParams.get("busca");
  
  const { data: properties = [], isLoading, error, refetch, isFetching } = useProperties();
  
  // Defer filter values to prevent blocking UI during filtering (INP optimization)
  const deferredSearchTerm = useDeferredValue(searchTerm);
  const deferredMinBedrooms = useDeferredValue(minBedrooms);
  const deferredMinParkingSpaces = useDeferredValue(minParkingSpaces);
  const deferredPriceRange = useDeferredValue(priceRange);
  // Initialize search term from URL params
  useEffect(() => {
    if (codigoFilter) {
      setSearchTerm(codigoFilter);
    } else if (buscaFilter) {
      setSearchTerm(buscaFilter);
    }
  }, [codigoFilter, buscaFilter]);

  // Memoized handlers for stable references
  const handleCopyLink = useCallback((e: React.MouseEvent, propertyCode: string) => {
    e.stopPropagation();
    const link = `${window.location.origin}/enviar-documentos/${propertyCode}`;
    navigator.clipboard.writeText(link);
    setCopiedCode(propertyCode);
    toast.success("Link copiado!");
    setTimeout(() => setCopiedCode(null), 2000);
  }, []);

  // Use deferred values for filtering to avoid blocking UI
  const filteredProperties = useMemo(() => properties.filter((property) => {
    // Apply neighborhood filter from URL
    if (bairroFilter && property.neighborhood.toLowerCase() !== bairroFilter.toLowerCase()) {
      return false;
    }
    
    // Apply code filter from URL
    if (codigoFilter && !property.code.toLowerCase().includes(codigoFilter.toLowerCase())) {
      return false;
    }
    
    // Apply search term filter (using deferred value)
    if (deferredSearchTerm) {
      const matchesSearch = 
        property.title.toLowerCase().includes(deferredSearchTerm.toLowerCase()) ||
        property.streetName.toLowerCase().includes(deferredSearchTerm.toLowerCase()) ||
        property.code.toLowerCase().includes(deferredSearchTerm.toLowerCase()) ||
        property.neighborhood.toLowerCase().includes(deferredSearchTerm.toLowerCase());
      if (!matchesSearch) return false;
    }
    
    // Apply bedrooms filter (using deferred value)
    if (deferredMinBedrooms !== null && (property.bedrooms || 0) < deferredMinBedrooms) {
      return false;
    }
    
    // Apply parking spaces filter (using deferred value)
    if (deferredMinParkingSpaces !== null && (property.parkingSpaces || 0) < deferredMinParkingSpaces) {
      return false;
    }
    
    // Apply price filter (using deferred value, 20000 means 20000+, so no upper limit)
    const propertyPrice = property.price || 0;
    if (propertyPrice < deferredPriceRange[0]) {
      return false;
    }
    // Only filter by max if it's below the max (20000+ means no upper limit)
    if (deferredPriceRange[1] < maxPropertyPrice && propertyPrice > deferredPriceRange[1]) {
      return false;
    }
    
    return true;
  }), [properties, bairroFilter, codigoFilter, deferredSearchTerm, deferredMinBedrooms, deferredMinParkingSpaces, deferredPriceRange, maxPropertyPrice]);

  // Visible properties with infinite scroll (client-side pagination)
  const visibleProperties = useMemo(
    () => filteredProperties.slice(0, visibleCount),
    [filteredProperties, visibleCount]
  );

  // Reset visible count when filters change
  useEffect(() => {
    setVisibleCount(20);
  }, [deferredSearchTerm, deferredMinBedrooms, deferredMinParkingSpaces, deferredPriceRange, bairroFilter, codigoFilter]);

  // Infinite scroll observer
  useEffect(() => {
    const el = loadMoreRef.current;
    if (!el) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && visibleCount < filteredProperties.length) {
          setVisibleCount(prev => Math.min(prev + 20, filteredProperties.length));
        }
      },
      { rootMargin: '400px' }
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, [visibleCount, filteredProperties.length]);

  const clearUrlFilters = () => {
    setSearchParams({});
    setSearchTerm("");
  };

  const clearAdvancedFilters = () => {
    setMinBedrooms(null);
    setMinParkingSpaces(null);
    setPriceRange([minPropertyPrice, maxPropertyPrice]);
  };

  const hasUrlFilters = bairroFilter || codigoFilter || buscaFilter;
  const hasAdvancedFilters = minBedrooms !== null || minParkingSpaces !== null || priceRange[0] > minPropertyPrice || priceRange[1] < maxPropertyPrice;

  const handleSelectProperty = (propertyCode: string) => {
    navigate(`/locatario/escolher-tipo-proposta/${propertyCode}`);
  };

  const formatPrice = (price: number) => {
    if (!price) return "Consulte";
    return `R$ ${price.toLocaleString("pt-BR")}`;
  };

  return (
    <div className="min-h-screen bg-background">
      <AppHeader />

      {/* Progress indicator */}
      <div className="border-b bg-muted/30">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-2 text-sm">
            <span className="flex items-center justify-center w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs font-medium">
              1
            </span>
            <span className="font-medium">Selecionar imóvel</span>
            <ChevronRight className="h-4 w-4 text-muted-foreground" />
            <span className="flex items-center justify-center w-6 h-6 rounded-full bg-muted text-muted-foreground text-xs font-medium">
              2
            </span>
            <span className="text-muted-foreground">Enviar documentos</span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="text-3xl font-bold">Selecione o imóvel desejado</h1>
            <p className="text-muted-foreground mt-1">
              {isLoading 
                ? "Carregando imóveis disponíveis..." 
                : `${filteredProperties.length} imóveis ${hasUrlFilters || hasAdvancedFilters ? 'encontrados' : 'disponíveis para locação'}`}
            </p>
          </div>
          <Button variant="outline" onClick={() => refetch()} disabled={isFetching}>
            <RefreshCw className={`mr-2 h-4 w-4 ${isFetching ? "animate-spin" : ""}`} />
            Atualizar
          </Button>
        </div>

        {/* URL Filters (bairro, código, busca) */}
        {hasUrlFilters && (
          <div className="flex flex-wrap items-center gap-2 mb-4">
            <span className="text-sm text-muted-foreground">Filtros ativos:</span>
            {bairroFilter && (
              <Badge variant="secondary" className="flex items-center gap-1">
                <MapPin className="h-3 w-3" />
                {bairroFilter}
                <button
                  onClick={() => {
                    const newParams = new URLSearchParams(searchParams);
                    newParams.delete("bairro");
                    setSearchParams(newParams);
                  }}
                  className="ml-1 hover:text-destructive"
                >
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            )}
            {codigoFilter && (
              <Badge variant="secondary" className="flex items-center gap-1">
                Código: {codigoFilter}
                <button
                  onClick={() => {
                    const newParams = new URLSearchParams(searchParams);
                    newParams.delete("codigo");
                    setSearchParams(newParams);
                    setSearchTerm("");
                  }}
                  className="ml-1 hover:text-destructive"
                >
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            )}
            {buscaFilter && (
              <Badge variant="secondary" className="flex items-center gap-1">
                Busca: "{buscaFilter}"
                <button
                  onClick={() => {
                    const newParams = new URLSearchParams(searchParams);
                    newParams.delete("busca");
                    setSearchParams(newParams);
                    setSearchTerm("");
                  }}
                  className="ml-1 hover:text-destructive"
                >
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            )}
            <Button variant="ghost" size="sm" onClick={clearUrlFilters}>
              Limpar todos
            </Button>
          </div>
        )}

        {/* Advanced Filters Badges */}
        {hasAdvancedFilters && (
          <div className="flex flex-wrap items-center gap-2 mb-4">
            <span className="text-sm text-muted-foreground">Filtros avançados:</span>
            {minBedrooms !== null && (
              <Badge variant="outline" className="flex items-center gap-1">
                <Bed className="h-3 w-3" />
                {minBedrooms}+ quartos
                <button
                  onClick={() => setMinBedrooms(null)}
                  className="ml-1 hover:text-destructive"
                >
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            )}
            {minParkingSpaces !== null && (
              <Badge variant="outline" className="flex items-center gap-1">
                <Car className="h-3 w-3" />
                {minParkingSpaces}+ vagas
                <button
                  onClick={() => setMinParkingSpaces(null)}
                  className="ml-1 hover:text-destructive"
                >
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            )}
            {(priceRange[0] > minPropertyPrice || priceRange[1] < maxPropertyPrice) && (
              <Badge variant="outline" className="flex items-center gap-1">
                R$ {priceRange[0].toLocaleString("pt-BR")} - R$ {priceRange[1].toLocaleString("pt-BR")}{priceRange[1] >= maxPropertyPrice ? "+" : ""}
                <button
                  onClick={() => setPriceRange([minPropertyPrice, maxPropertyPrice])}
                  className="ml-1 hover:text-destructive"
                >
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            )}
          </div>
        )}

        {/* Search */}
        <div className="relative mb-4">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Buscar por endereço, bairro ou código..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="h-12 pl-12"
          />
        </div>

        {/* Advanced Filters */}
        <PropertyFilters
          bedrooms={minBedrooms}
          onBedroomsChange={setMinBedrooms}
          parkingSpaces={minParkingSpaces}
          onParkingSpacesChange={setMinParkingSpaces}
          priceRange={priceRange}
          onPriceRangeChange={setPriceRange}
          minPropertyPrice={minPropertyPrice}
          maxPropertyPrice={maxPropertyPrice}
          onClearFilters={clearAdvancedFilters}
        />

        {/* Error State */}
        {error && (
          <div className="text-center py-12">
            <p className="text-destructive mb-4">Erro ao carregar imóveis: {error.message}</p>
            <Button onClick={() => refetch()}>
              <RefreshCw className="mr-2 h-4 w-4" />
              Tentar novamente
            </Button>
          </div>
        )}

        {/* Loading State */}
        {isLoading && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="rounded-xl border overflow-hidden">
                <Skeleton className="h-48 w-full" />
                <div className="p-4 space-y-3">
                  <Skeleton className="h-4 w-20" />
                  <Skeleton className="h-5 w-full" />
                  <div className="flex gap-4">
                    <Skeleton className="h-4 w-12" />
                    <Skeleton className="h-4 w-12" />
                    <Skeleton className="h-4 w-16" />
                  </div>
                  <Skeleton className="h-10 w-full" />
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Properties Grid */}
        {!isLoading && !error && (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {visibleProperties.map((property) => (
                <MemoizedPropertyCard
                  key={property.id}
                  property={property}
                  copiedCode={copiedCode}
                  onSelect={() => handleSelectProperty(property.code)}
                  onCopyLink={(e) => handleCopyLink(e, property.code)}
                  formatPrice={formatPrice}
                />
              ))}
            </div>

            {/* Load more trigger for infinite scroll */}
            {visibleCount < filteredProperties.length && (
              <div ref={loadMoreRef} className="py-8 flex justify-center">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Carregando mais imóveis...
                </div>
              </div>
            )}

            {/* End of list indicator */}
            {visibleCount >= filteredProperties.length && filteredProperties.length > 20 && (
              <p className="text-center text-muted-foreground py-4">
                Mostrando todos os {filteredProperties.length} imóveis
              </p>
            )}
          </>
        )}

        {!isLoading && !error && filteredProperties.length === 0 && properties.length > 0 && (
          <div className="text-center py-12">
            <Home className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-muted-foreground">Nenhum imóvel encontrado para "{searchTerm}".</p>
            <Button variant="outline" onClick={() => setSearchTerm("")} className="mt-4">
              Limpar busca
            </Button>
          </div>
        )}
      </main>
    </div>
  );
}

interface PropertyCardProps {
  property: Property;
  copiedCode: string | null;
  onSelect: () => void;
  onCopyLink: (e: React.MouseEvent) => void;
  formatPrice: (price: number) => string;
}

function PropertyCard({ property, copiedCode, onSelect, onCopyLink, formatPrice }: PropertyCardProps) {
  const translatedType = translatePropertyType(property.title);
  
  // Use images3 array if available, fallback to single image
  const carouselImages = property.images3?.length > 0 
    ? property.images3 
    : [property.image];

  return (
    <div
      className="rounded-xl border bg-card overflow-hidden hover:shadow-lg transition-all cursor-pointer"
      onClick={onSelect}
    >
      {/* Image Carousel with explicit dimensions for CLS prevention */}
      <div className="relative aspect-[4/3] overflow-hidden bg-muted">
        <PropertyImageCarousel
          images={carouselImages}
          alt={property.title}
          code={property.code}
          price={`${formatPrice(property.price)}/mês`}
        />
      </div>

      {/* Content */}
      <div className="p-4 space-y-3">
        <span className="text-xs font-medium text-primary uppercase tracking-wide">
          {translatedType}
        </span>
        
        <div className="flex items-start gap-2 text-sm">
          <MapPin className="h-4 w-4 text-muted-foreground shrink-0 mt-0.5" />
          <span className="line-clamp-2">
            {property.neighborhood}
            {property.streetName && property.streetName !== "Rua não informada" 
              ? ` - ${property.streetName}` 
              : ''}
          </span>
        </div>

        <div className="flex items-center gap-4 text-sm text-muted-foreground flex-wrap">
          {property.bedrooms > 0 && (
            <span className="flex items-center gap-1" title="Dormitórios">
              <Bed className="h-4 w-4" />
              {property.bedrooms}
            </span>
          )}
          {property.suites > 0 && (
            <span className="flex items-center gap-1 text-primary" title="Suítes">
              <Bed className="h-4 w-4" />
              {property.suites} suíte{property.suites > 1 ? 's' : ''}
            </span>
          )}
          {property.bathrooms > 0 && (
            <span className="flex items-center gap-1" title="Banheiros">
              <Bath className="h-4 w-4" />
              {property.bathrooms}
            </span>
          )}
          {property.area > 0 && (
            <span className="flex items-center gap-1" title="Área útil">
              <Square className="h-4 w-4" />
              {property.area}m²
            </span>
          )}
          {property.parkingSpaces > 0 && (
            <span className="flex items-center gap-1" title="Vagas">
              <Car className="h-4 w-4" />
              {property.parkingSpaces}
            </span>
          )}
        </div>

        {(property.condoFee > 0 || property.iptu > 0) && (
          <div className="flex gap-3 text-xs text-muted-foreground">
            {property.condoFee > 0 && (
              <span>Cond: R$ {property.condoFee.toLocaleString("pt-BR")}</span>
            )}
            {property.iptu > 0 && (
              <span>IPTU: R$ {property.iptu.toLocaleString("pt-BR")}</span>
            )}
          </div>
        )}

        <div className="flex gap-2 pt-2">
          <Button
            className="flex-1"
            onClick={(e) => {
              e.stopPropagation();
              onSelect();
            }}
          >
            Iniciar locação
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={onCopyLink}
            title="Copiar link"
          >
            {copiedCode === property.code ? (
              <Check className="h-4 w-4" />
            ) : (
              <Copy className="h-4 w-4" />
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}

// Memoized PropertyCard for better performance with infinite scroll
const MemoizedPropertyCard = memo(PropertyCard);
