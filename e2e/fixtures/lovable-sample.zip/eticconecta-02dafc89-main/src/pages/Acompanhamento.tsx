import { useState, useRef, useEffect } from "react";
import { useParams, Link, useNavigate, useSearchParams } from "react-router-dom";
import {
  Clock,
  AlertTriangle,
  FileText,
  Upload,
  CheckCircle2,
  MessageCircle,
  Building,
  Calendar,
  Key,
  Pen,
  ClipboardCheck,
  FileCheck,
  ChevronDown,
  ChevronUp,
  ExternalLink,
  MapPin,
  Flame,
  Loader2,
  Check,
  X,
  BookOpen,
  Download,
  ThumbsUp,
  Handshake,
  ShieldAlert,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useRentalTracking, finalizeDocumentSubmission, createDocumentUploadEvent, reopenDocumentSubmission } from "@/hooks/useRentalTracking";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { AppHeader } from "@/components/layout/AppHeader";
import { Home } from "lucide-react";
import { areRequiredDocsComplete } from "@/components/documents/TenantDocumentsUploader";
import { DocFileEntry } from "@/components/rental/DocumentUpload";
import { REQUIRED_DOC_TYPES, DOC_TYPE_LABELS } from "@/types/documentLimits";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  acceptCounterProposal,
  rejectCounterProposal,
  fetchProposals,
  EVENT_LABELS,
  runConsistencyChecks,
  qaFixCurrentStep,
  signContract,
  fetchContract,
  signInspectionReport,
  fetchInspection,
  type ProposalRow,
  type ContractRow,
  type InspectionRow,
} from "@/lib/proposalEvents";

// Timeline steps with SLA information - 10 steps
const TIMELINE_STEPS = [
  {
    step: 1,
    title: "Proposta",
    description: "Envio da proposta de locação.",
    icon: FileText,
    sla: "Imediato",
    action: null,
    responsible: "locatario",
  },
  {
    step: 2,
    title: "Aceite da Proposta",
    description: "O locador/admin analisa e aceita sua proposta.",
    icon: ThumbsUp,
    sla: "24 horas",
    action: "Aguarde o aceite do locador.",
    responsible: "locador",
    showLandlordStatus: true,
  },
  {
    step: 3,
    title: "Documentação",
    description: "Envie seus dados e documentos para análise.",
    icon: Upload,
    sla: "Depende de você",
    action: null,
    responsible: "locatario",
  },
  {
    step: 4,
    title: "Análise da Ficha",
    description: "Nossa equipe está analisando sua documentação.",
    icon: ClipboardCheck,
    sla: "24 horas úteis",
    action: "Aguarde a análise da equipe Etic.",
    responsible: "admin",
  },
  {
    step: 5,
    title: "Documentos do Locador",
    description: "Locador envia os documentos do imóvel.",
    icon: Building,
    sla: "24 horas",
    action: "Aguarde o locador enviar a documentação.",
    responsible: "locador",
  },
  {
    step: 6,
    title: "Emissão do Contrato",
    description: "Preparamos o contrato de locação.",
    icon: FileCheck,
    sla: "24 horas",
    action: "Aguarde a emissão do contrato.",
    responsible: "admin",
  },
  {
    step: 7,
    title: "Assinatura do Contrato",
    description: "Contrato pronto para assinatura eletrônica.",
    icon: Pen,
    sla: "Depende das partes",
    action: "Assine o contrato digitalmente quando disponível.",
    responsible: "todos",
  },
  {
    step: 8,
    title: "Agendamento de Vistoria",
    description: "Marcamos a vistoria do imóvel.",
    icon: Calendar,
    sla: "Você agenda",
    action: "Agende a vistoria de entrada do imóvel.",
    responsible: "locatario",
  },
  {
    step: 9,
    title: "Assinatura de Vistoria",
    description: "Assine o laudo de vistoria.",
    icon: ClipboardCheck,
    sla: "Depende das partes",
    action: "Revise e assine o laudo de vistoria.",
    responsible: "todos",
  },
  {
    step: 10,
    title: "Entrega das Chaves",
    description: "Receba as chaves do seu novo lar!",
    icon: Key,
    sla: "Finalizado",
    action: "Compareça ao local combinado para retirar as chaves.",
    responsible: "todos",
  },
];

function formatCurrency(value: number | null): string {
  if (value === null || value === undefined) return "-";
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(value);
}

export default function Acompanhamento() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  console.log('[ACOMP_INIT] rentalId', { rentalIdFromUrl: id });
  const { rental, events, loading, error, refetch } = useRentalTracking(id);
  const { user, profile } = useAuth();
  const { toast } = useToast();
  const [searchParams] = useSearchParams();
  const isQA = searchParams.get('qa') === '1';
  const [expandedStep, setExpandedStep] = useState<number | null>(null);
  const [showAllSteps, setShowAllSteps] = useState(false);
  const [finalizing, setFinalizing] = useState(false);

  // Counter-proposal state
  const [proposals, setProposals] = useState<ProposalRow[]>([]);
  const [counterLoading, setCounterLoading] = useState(false);

  // Contract state
  const [contractData, setContractData] = useState<ContractRow | null>(null);
  const [signingContract, setSigningContract] = useState(false);

  // Inspection state
  const [inspectionData, setInspectionData] = useState<InspectionRow | null>(null);
  const [signingInspection, setSigningInspection] = useState(false);

  // Direct document state — fetched from Supabase, no hidden uploader dependency
  const [docFiles, setDocFiles] = useState<DocFileEntry[]>([]);
  const [docsLoaded, setDocsLoaded] = useState(false);
  // Optimistic local finalized state — set immediately on successful finalization
  const [localFinalized, setLocalFinalized] = useState(false);

  // Direct fetch of documents for this rental — source of truth, no circular dependency
  useEffect(() => {
    if (!id || !user) return;
    const fetchDocs = async () => {
      console.log('[ACOMP_DOCS] fetching directly', { rentalId: id, userId: user.id });
      const { data, error: fetchErr } = await supabase
        .from('documents')
        .select('id, document_type, file_name, file_path, status')
        .eq('rental_id', id)
        .eq('user_id', user.id);
      if (fetchErr) {
        console.error('[ACOMP_DOCS] fetch error', fetchErr);
      } else {
        const mapped: DocFileEntry[] = (data || []).map(d => ({
          id: d.id,
          type: d.document_type,
          file: null as any,
          status: 'uploaded' as const,
          url: d.file_path,
          fileName: d.file_name,
        }));
        console.log('[ACOMP_DOCS] fetched', { rentalId: id, count: mapped.length });
        setDocFiles(mapped);
      }
      setDocsLoaded(true);
    };
    fetchDocs();
  }, [id, user, rental?.updatedAt]);

  // Fetch proposals for this rental
  useEffect(() => {
    if (!id) return;
    fetchProposals(id).then(setProposals);
  }, [id, rental?.proposalStatus]);

  // Fetch contract data
  useEffect(() => {
    if (!id || !rental || rental.currentStep < 6) return;
    fetchContract(id).then(setContractData);
  }, [id, rental?.currentStep]);

  // Fetch inspection data
  useEffect(() => {
    if (!id || !rental || rental.currentStep < 8) return;
    fetchInspection(id).then(setInspectionData);
  }, [id, rental?.currentStep]);

  // Real-time notification toasts for step advances
  const prevStepRef = useRef<number | null>(null);
  useEffect(() => {
    if (!rental) return;
    const prev = prevStepRef.current;
    prevStepRef.current = rental.currentStep;
    if (prev === null) return; // first load
    if (rental.currentStep === prev) return;

    if (rental.currentStep === 5 && prev === 4) {
      toast({ title: "🎉 Ficha aprovada!", description: "Aguarde o envio dos documentos do locador." });
    } else if (rental.currentStep === 6 && prev === 5) {
      toast({ title: "📄 Contrato em emissão", description: "O contrato está sendo preparado." });
    } else if (rental.currentStep === 7) {
      toast({ title: "✍️ Contrato pronto!", description: "Acesse para assinar o contrato digitalmente." });
    } else if (rental.currentStep === 8) {
      toast({ title: "✅ Contrato assinado!", description: "Próximo passo: agendamento de vistoria." });
    } else if (rental.currentStep === 9) {
      toast({ title: "📋 Vistoria agendada!", description: "Revise e assine o laudo de vistoria." });
    } else if (rental.currentStep === 10) {
      toast({ title: "🔑 Quase lá!", description: "As chaves estão prontas para retirada." });
    }
  }, [rental?.currentStep, toast]);

  // Tenant signs contract
  const handleTenantSign = async () => {
    if (!id || signingContract) return;
    setSigningContract(true);
    try {
      const success = await signContract({ rentalId: id, signerRole: 'tenant' });
      if (success) {
        toast({ title: "Contrato assinado!", description: "Sua assinatura foi registrada com sucesso." });
        await refetch();
        fetchContract(id).then(setContractData);
      } else {
        toast({ title: "Erro", description: "Não foi possível registrar a assinatura.", variant: "destructive" });
      }
    } finally {
      setSigningContract(false);
    }
  };

  // Tenant signs inspection report
  const handleTenantSignInspection = async () => {
    if (!id || signingInspection) return;
    setSigningInspection(true);
    try {
      const success = await signInspectionReport({ rentalId: id, signerRole: 'tenant' });
      if (success) {
        toast({ title: "Laudo assinado!", description: "Sua assinatura no laudo de vistoria foi registrada." });
        await refetch();
        fetchInspection(id).then(setInspectionData);
      } else {
        toast({ title: "Erro", description: "Não foi possível assinar o laudo.", variant: "destructive" });
      }
    } finally {
      setSigningInspection(false);
    }
  };


  // Parse pending documents from rental (DB fallback only)
  const pendingDocuments = rental?.hasPending && rental?.pendingDocuments ? (rental.pendingDocuments as string[]) : [];

  // Calculate currently missing required doc types from ACTUAL documents (source of truth)
  const currentMissingTypes = REQUIRED_DOC_TYPES.filter(
    type => !docFiles.some(f => f.type === type && f.status === 'uploaded')
  );

  const allRequiredComplete = areRequiredDocsComplete(docFiles);
  const uploadedCount = docFiles.filter(d => d.status === 'uploaded').length;

  // Explicit finalization state from DB OR optimistic local state
  const docsFinalized = localFinalized || !!rental?.documentsFinalizedAt;
  const docsReadyToFinalize = currentMissingTypes.length === 0 && !docsFinalized && docFiles.some(f => f.status === 'uploaded');

  // Diagnostic logs
  useEffect(() => {
    if (docsLoaded) {
      console.log('[DOCS_STATE]', {
        rentalId: id,
        missingTypes: currentMissingTypes,
        docsReadyToFinalize,
        docsFinalized,
      });
    }
  }, [docFiles, docsLoaded, docsFinalized]);

  // Visibility diagnostic
  useEffect(() => {
    console.log('[ACOMP_FINALIZED] Calculated docsFinalized:', docsFinalized, 'from documents_finalized_at:', rental?.documentsFinalizedAt);
  }, [docsFinalized, rental?.documentsFinalizedAt]);

  // Real pending = docs actually missing (source of truth from direct fetch)
  const hasRealPendingDocs = docsLoaded
    ? (currentMissingTypes.length > 0 && !docsFinalized)
    : (rental?.hasPending === true);

  console.log('[ACOMP_RENDER] docsFinalized:', docsFinalized, 'uploadedCount:', uploadedCount);

  // All pending docs uploaded check
  const allPendingDocsUploaded =
    pendingDocuments.length > 0 &&
    pendingDocuments.every((type) => docFiles.some(f => f.type === type && f.status === 'uploaded'));

  // Handle finalize click — only allowed when all required docs are present
  const handleFinalizeClick = () => {
    console.log('[FINALIZE] handleFinalizeClick called', { rentalId: id, docsFinalized, missingCount: currentMissingTypes.length });
    if (currentMissingTypes.length > 0) {
      toast({
        title: "Documentos faltando",
        description: `Ainda faltam: ${currentMissingTypes.map(t => DOC_TYPE_LABELS[t]?.label || t).join(', ')}.`,
        variant: "destructive",
      });
      return;
    }
    doFinalize();
  };

  // Actually finalize — only called when all required docs are present
  const doFinalize = async () => {
    if (!id || finalizing) return;
    setFinalizing(true);
    console.log('[FINALIZE] Starting update for rentalId:', id, 'current docsFinalized:', docsFinalized);
    try {
      const success = await finalizeDocumentSubmission(id);
      console.log('[FINALIZE] finalizeDocumentSubmission result:', success);
      if (!success) throw new Error("Failed to finalize");
      
      // Optimistic UI update — immediately hide upload section
      setLocalFinalized(true);
      console.log('[FINALIZE] Optimistic localFinalized set to true');
      // Verify in DB
      const { data: verifyData } = await supabase
        .from('rentals')
        .select('documents_finalized_at')
        .eq('id', id)
        .maybeSingle();
      console.log('[FINALIZE] DB verification:', { documents_finalized_at: verifyData?.documents_finalized_at });
      
      toast({
        title: "Documentos finalizados!",
        description: "Sua documentação está em análise. Prazo máximo: 24 horas úteis.",
      });
      await refetch();
      // Re-fetch docs to update docsFinalized state
      if (user) {
        const { data } = await supabase
          .from('documents')
          .select('id, document_type, file_name, file_path, status')
          .eq('rental_id', id)
          .eq('user_id', user.id);
        if (data) {
          setDocFiles(data.map(d => ({
            id: d.id, type: d.document_type, file: null as any,
            status: 'uploaded' as const, url: d.file_path, fileName: d.file_name,
          })));
        }
      }
    } catch (err) {
      console.error("Error finalizing:", err);
      toast({ title: "Erro", description: "Não foi possível finalizar o envio.", variant: "destructive" });
    } finally {
      setFinalizing(false);
    }
  };

  // Save progress with pending state
  const handleSaveLater = async () => {
    if (!id || finalizing) return;
    setFinalizing(true);
    try {
      console.log('[DOCS] finalizeLater saved', { rentalId: id, pending_documents: currentMissingTypes });
      const success = await finalizeDocumentSubmission(id, currentMissingTypes);
      if (!success) throw new Error("Failed to save");
      toast({ title: "Progresso salvo!", description: "Você pode continuar o envio depois." });
      await refetch();
    } catch (err) {
      console.error("Error saving progress:", err);
      toast({ title: "Erro", description: "Não foi possível salvar o progresso.", variant: "destructive" });
    } finally {
      setFinalizing(false);
    }
  };

  // Counter-proposal handlers
  const pendingCounterProposal = proposals.find(
    p => p.author === 'landlord' && p.status === 'pending'
  );

  const handleAcceptCounter = async () => {
    if (!id || !pendingCounterProposal) return;
    setCounterLoading(true);
    try {
      const success = await acceptCounterProposal({
        rentalId: id,
        proposalId: pendingCounterProposal.id,
      });
      if (success) {
        toast({ title: "Contraproposta aceita!", description: "A negociação foi concluída com sucesso." });
        await refetch();
        fetchProposals(id).then(setProposals);
      } else {
        toast({ title: "Erro", description: "Não foi possível aceitar a contraproposta.", variant: "destructive" });
      }
    } finally {
      setCounterLoading(false);
    }
  };

  const handleRejectCounter = async () => {
    if (!id || !pendingCounterProposal) return;
    setCounterLoading(true);
    try {
      const success = await rejectCounterProposal({
        rentalId: id,
        proposalId: pendingCounterProposal.id,
      });
      if (success) {
        toast({ title: "Contraproposta rejeitada", description: "A negociação foi encerrada." });
        await refetch();
        fetchProposals(id).then(setProposals);
      } else {
        toast({ title: "Erro", description: "Não foi possível rejeitar a contraproposta.", variant: "destructive" });
      }
    } finally {
      setCounterLoading(false);
    }
  };

  // WhatsApp message builder
  const buildWhatsAppMessage = () => {
    const name = profile?.full_name || "Cliente";
    const protocol = rental?.protocol || "N/A";
    const message = `Olá! Sou ${name}, protocolo ${protocol}. Gostaria de mais informações sobre minha proposta de locação.`;
    return encodeURIComponent(message);
  };

  const whatsappUrl = `https://wa.me/5511970932722?text=${buildWhatsAppMessage()}`;

  const toggleStep = (step: number) => {
    setExpandedStep(expandedStep === step ? null : step);
  };

  // Property link
  const propertyLink = rental?.propertyCode ? `https://www.eticimoveis.com.br/imovel/${rental.propertyCode}` : null;

  // Using imported DOC_TYPE_LABELS for consistent readable names

  return (
    <div className="min-h-screen bg-background">
      <AppHeader />

      <main className="container mx-auto px-4 py-4">
        <div className="max-w-2xl mx-auto">
          {loading && (
            <div className="space-y-4 mt-6">
              <Skeleton className="h-32 w-full" />
              <Skeleton className="h-48 w-full" />
            </div>
          )}

          {error && (
            <div className="text-center py-12">
              <p className="text-destructive">{error}</p>
            </div>
          )}

          {/* Doc state now fetched directly via useEffect — no hidden uploader needed */}

          {!loading && !error && rental && (
            <div className="space-y-3">
              {/* Protocol row */}
              <div className="flex items-center justify-between">
                <p className="font-mono text-xs text-muted-foreground">Protocolo {rental.protocol}</p>
                <Badge variant="outline" className="text-[10px]">
                  {rental.currentStep}/10
                </Badge>
              </div>

              {/* Hero Status Card */}
              <Card className="border-primary/20">
                <CardContent className="p-3 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {(() => {
                        const StepIcon = TIMELINE_STEPS.find(s => s.step === rental.currentStep)?.icon || FileText;
                        return (
                          <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                            <StepIcon className="h-4 w-4 text-primary" />
                          </div>
                        );
                      })()}
                      <div>
                        <p className="text-sm font-semibold text-foreground">
                          {TIMELINE_STEPS.find(s => s.step === rental.currentStep)?.title || ''}
                        </p>
                        <p className="text-[10px] text-muted-foreground">
                          Etapa {rental.currentStep} de 10
                        </p>
                      </div>
                    </div>
                    <span className="text-lg font-bold text-primary">
                      {Math.round(((Math.max(0, rental.currentStep - 1)) / 10) * 100)}%
                    </span>
                  </div>
                  <Progress value={((Math.max(0, rental.currentStep - 1)) / 10) * 100} className="h-1.5" />

                  {/* Next action — 1 line */}
                  {rental.currentStep < 10 && (() => {
                    const currentStepData = TIMELINE_STEPS.find(s => s.step === rental.currentStep);
                    const nextStepData = TIMELINE_STEPS.find(s => s.step === rental.currentStep + 1);
                    // Derive a clear action string
                    const actionText = hasRealPendingDocs && !docsFinalized
                      ? `Enviar ${currentMissingTypes.length} documento${currentMissingTypes.length !== 1 ? 's' : ''} pendente${currentMissingTypes.length !== 1 ? 's' : ''}`
                      : docsReadyToFinalize
                        ? 'Finalizar envio de documentos'
                        : currentStepData?.action || (nextStepData ? `Próximo: ${nextStepData.title}` : null);
                    return actionText ? (
                      <p className={cn(
                        "text-xs font-medium pt-0.5",
                        hasRealPendingDocs && !docsFinalized ? "text-amber-600" : "text-muted-foreground"
                      )}>
                        👉 {actionText}
                      </p>
                    ) : null;
                  })()}
                </CardContent>
              </Card>

              {/* Property Card - Always visible */}
              <Card className="overflow-hidden">
                <div className="flex flex-row">
                  {rental.propertyImage && (
                    <div className="w-24 sm:w-36 shrink-0">
                      <img
                        src={rental.propertyImage}
                        alt={rental.propertyCode}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}
                  <CardContent className="flex-1 p-3">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        {propertyLink ? (
                          <a
                            href={propertyLink}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-1.5 text-primary hover:underline"
                          >
                            <Badge variant="outline" className="cursor-pointer">
                              {rental.propertyCode}
                              <ExternalLink className="h-3 w-3 ml-1" />
                            </Badge>
                          </a>
                        ) : (
                          <Badge variant="outline">{rental.propertyCode}</Badge>
                        )}
                        <p className="font-medium text-foreground flex items-center gap-1.5 mt-2 text-sm">
                          <MapPin className="h-4 w-4 text-muted-foreground shrink-0" />
                          {rental.propertyAddress}
                        </p>
                      </div>
                    </div>
                    {/* Property Values — responsive grid, hide empty */}
                    {(rental.rentValue || rental.condoFee || rental.iptu) && (
                      <div className={cn(
                        "grid gap-2 mt-3",
                        [rental.rentValue, rental.condoFee, rental.iptu].filter(Boolean).length <= 2
                          ? "grid-cols-2" : "grid-cols-3"
                      )}>
                        {rental.rentValue != null && rental.rentValue > 0 && (
                          <div className="p-2 bg-muted/50 rounded-lg text-center">
                            <p className="text-[10px] text-muted-foreground uppercase">Aluguel</p>
                            <p className="font-semibold text-xs whitespace-nowrap tabular-nums">{formatCurrency(rental.rentValue)}</p>
                          </div>
                        )}
                        {rental.condoFee != null && rental.condoFee > 0 && (
                          <div className="p-2 bg-muted/50 rounded-lg text-center">
                            <p className="text-[10px] text-muted-foreground uppercase">Cond.</p>
                            <p className="font-semibold text-xs whitespace-nowrap tabular-nums">{formatCurrency(rental.condoFee)}</p>
                          </div>
                        )}
                        {rental.iptu != null && rental.iptu > 0 && (
                          <div className="p-2 bg-muted/50 rounded-lg text-center">
                            <p className="text-[10px] text-muted-foreground uppercase">IPTU</p>
                            <p className="font-semibold text-xs whitespace-nowrap tabular-nums">{formatCurrency(rental.iptu)}</p>
                          </div>
                        )}
                      </div>
                    )}
                  </CardContent>
                </div>
              </Card>

              {/* Proposal Rejection Card */}
              {rental.isRejected && (
                <Card className="border-2 border-destructive/50 bg-destructive/5">
                  <CardContent className="p-6">
                    <div className="flex flex-col items-center text-center space-y-4">
                      <div className="w-16 h-16 rounded-full bg-destructive/10 flex items-center justify-center">
                        <X className="h-8 w-8 text-destructive" />
                      </div>
                      <div className="space-y-2">
                        <h3 className="font-bold text-lg text-destructive">Proposta Não Aceita</h3>
                        {rental.rejectionReason === 'property_rented' ? (
                          <>
                            <p className="text-sm text-muted-foreground">Este imóvel foi locado por outro inquilino.</p>
                            <p className="text-xs text-muted-foreground">Continue sua busca e encontre outras opções disponíveis.</p>
                          </>
                        ) : (
                          <>
                            <p className="text-sm text-muted-foreground">Sua proposta foi rejeitada pelo locador.</p>
                            <p className="text-xs text-muted-foreground">Você pode melhorar sua oferta ou procurar outro imóvel.</p>
                          </>
                        )}
                      </div>
                      <div className="flex flex-col sm:flex-row gap-3 w-full">
                        <Button variant="outline" className="flex-1" onClick={() => navigate('/selecionar-imovel')}>
                          <Home className="h-4 w-4 mr-2" />
                          Procurar outros imóveis
                        </Button>
                        {rental.rejectionReason !== 'property_rented' && (
                          <Button className="flex-1" onClick={() => navigate(`/locatario/escolher-tipo-proposta/${rental.propertyCode}`)}>
                            Melhorar minha proposta
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Docs Submitted Early Info Card */}
              {rental.docsSubmittedEarly && rental.currentStep === 2 && !hasRealPendingDocs && (
                <Card className="border-primary/30 bg-primary/5">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                        <FileText className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium text-sm">Documentos já enviados!</p>
                        <p className="text-xs text-muted-foreground">
                          Sua documentação está em análise. Enquanto isso, aguardamos o aceite do locador.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Urgency Indicator - Only show if >= 2 proposals on same property */}
              {(rental.proposalCount || 0) >= 2 && (
                <div className="flex items-center gap-3 p-3 bg-gradient-to-r from-orange-500/10 to-red-500/10 rounded-lg border border-orange-500/20">
                  <div className="w-10 h-10 rounded-full bg-orange-500/20 flex items-center justify-center shrink-0">
                    <Flame className="h-5 w-5 text-orange-500" />
                  </div>
                  <div>
                    <p className="font-medium text-sm text-foreground">Imóvel muito procurado</p>
                    <p className="text-xs text-muted-foreground">
                      Este imóvel possui {rental.proposalCount} propostas ativas. Finalize sua proposta o quanto antes!
                    </p>
                  </div>
                </div>
              )}

              {/* Counter-Proposal Alert — Dynamic Step 2 */}
              {rental.proposalStatus === 'counter_proposal_pending' && pendingCounterProposal && (
                <Card className="border-2 border-amber-500/50 bg-amber-500/5">
                  <CardContent className="p-4 space-y-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-amber-500/10 flex items-center justify-center shrink-0">
                        <Handshake className="h-5 w-5 text-amber-600" />
                      </div>
                      <div>
                        <p className="font-semibold text-sm text-amber-700">Contraproposta Recebida</p>
                        <p className="text-xs text-muted-foreground">O locador enviou uma contraproposta. Responda para continuar.</p>
                      </div>
                    </div>
                    {/* Counter-proposal details */}
                    <div className="bg-background rounded-lg border p-3 space-y-2">
                      {pendingCounterProposal.rent_value && (
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Aluguel proposto:</span>
                          <span className="font-semibold">{formatCurrency(pendingCounterProposal.rent_value)}/mês</span>
                        </div>
                      )}
                      {pendingCounterProposal.deposit_value && (
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Depósito/Caução:</span>
                          <span className="font-semibold">{formatCurrency(pendingCounterProposal.deposit_value)}</span>
                        </div>
                      )}
                      {pendingCounterProposal.notes && (
                        <div className="text-sm">
                          <span className="text-muted-foreground">Observações: </span>
                          <span>{pendingCounterProposal.notes}</span>
                        </div>
                      )}
                      <p className="text-[10px] text-muted-foreground">
                        Recebida em {format(new Date(pendingCounterProposal.created_at), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                      </p>
                    </div>
                    {/* Action buttons */}
                    <div className="flex gap-2">
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button className="flex-1 gap-2" disabled={counterLoading}>
                            <Check className="h-4 w-4" />
                            Aceitar
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Aceitar contraproposta?</AlertDialogTitle>
                            <AlertDialogDescription>
                              Ao aceitar, a negociação será concluída e o processo avançará para a etapa de documentação.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancelar</AlertDialogCancel>
                            <AlertDialogAction onClick={handleAcceptCounter}>Confirmar</AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="destructive" className="flex-1 gap-2" disabled={counterLoading}>
                            <X className="h-4 w-4" />
                            Rejeitar
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Rejeitar contraproposta?</AlertDialogTitle>
                            <AlertDialogDescription>
                              Ao rejeitar, a negociação será encerrada. Você poderá buscar outros imóveis.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancelar</AlertDialogCancel>
                            <AlertDialogAction onClick={handleRejectCounter} className="bg-destructive hover:bg-destructive/90">Rejeitar</AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Proposal Accepted Card */}
              {rental.proposalStatus === 'proposal_accepted' && rental.currentStep <= 2 && (
                <Card className="border-step-complete/30 bg-step-complete/5">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-step-complete/10 flex items-center justify-center shrink-0">
                        <CheckCircle2 className="h-5 w-5 text-step-complete" />
                      </div>
                      <div>
                        <p className="font-medium text-sm text-step-complete">Proposta aceita!</p>
                        <p className="text-xs text-muted-foreground">
                          A negociação foi concluída. Aguarde o avanço para a próxima etapa.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Inspection Card — Steps 8-9: Show inspection status and sign button */}
              {rental.currentStep >= 8 && !rental.isRejected && (
                <Card className={cn(
                  "border-2",
                  rental.currentStep === 9 && inspectionData && !inspectionData.signed_by_tenant_at
                    ? "border-primary/50 bg-primary/5"
                    : inspectionData?.signed_by_tenant_at
                      ? "border-step-complete/30 bg-step-complete/5"
                      : "border-muted"
                )}>
                  <CardContent className="p-4 space-y-3">
                    <div className="flex items-center gap-3">
                      <div className={cn(
                        "w-10 h-10 rounded-full flex items-center justify-center shrink-0",
                        inspectionData?.signed_by_tenant_at ? "bg-step-complete/10" : "bg-primary/10"
                      )}>
                        {rental.currentStep === 8 ? (
                          <Calendar className={cn("h-5 w-5", "text-primary")} />
                        ) : (
                          <ClipboardCheck className={cn("h-5 w-5", inspectionData?.signed_by_tenant_at ? "text-step-complete" : "text-primary")} />
                        )}
                      </div>
                      <div>
                        <p className={cn(
                          "font-semibold text-sm",
                          inspectionData?.signed_by_tenant_at ? "text-step-complete" : "text-foreground"
                        )}>
                          {rental.currentStep === 8 ? "Agendamento de Vistoria" :
                           inspectionData?.signed_by_tenant_at ? "Laudo assinado" :
                           "Assine o laudo de vistoria"}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {rental.currentStep === 8
                            ? (inspectionData?.scheduled_date
                              ? `Vistoria agendada para ${inspectionData.scheduled_date} às ${inspectionData.scheduled_time || 'horário a confirmar'}.`
                              : "Aguardando agendamento da vistoria pelo locador.")
                            : inspectionData?.signed_by_tenant_at
                              ? `Assinado. ${inspectionData.signed_by_landlord_at ? "Locador também assinou." : "Aguardando assinatura do locador."}`
                              : "O laudo de vistoria está pronto para sua assinatura."}
                        </p>
                      </div>
                    </div>

                    {/* Inspection details */}
                    {inspectionData?.scheduled_date && (
                      <div className="p-3 bg-muted/50 rounded-lg space-y-1.5">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-muted-foreground">Data:</span>
                          <span className="font-medium">{inspectionData.scheduled_date}</span>
                        </div>
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-muted-foreground">Horário:</span>
                          <span className="font-medium">{inspectionData.scheduled_time || '-'}</span>
                        </div>
                        {inspectionData.location_notes && (
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-muted-foreground">Obs:</span>
                            <span className="font-medium">{inspectionData.location_notes}</span>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Signature status for step 9 */}
                    {rental.currentStep >= 9 && inspectionData && (
                      <div className="p-3 bg-muted/50 rounded-lg space-y-1.5">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-muted-foreground">Sua assinatura:</span>
                          {inspectionData.signed_by_tenant_at ? (
                            <Badge className="bg-sla-ok/20 text-sla-ok border-sla-ok/30 text-[10px]">Assinado ✓</Badge>
                          ) : (
                            <Badge variant="secondary" className="text-[10px]">Pendente</Badge>
                          )}
                        </div>
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-muted-foreground">Assinatura do locador:</span>
                          {inspectionData.signed_by_landlord_at ? (
                            <Badge className="bg-sla-ok/20 text-sla-ok border-sla-ok/30 text-[10px]">Assinado ✓</Badge>
                          ) : (
                            <Badge variant="secondary" className="text-[10px]">Pendente</Badge>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Sign button for step 9 */}
                    {rental.currentStep === 9 && inspectionData && !inspectionData.signed_by_tenant_at && (
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button className="w-full gap-2" disabled={signingInspection}>
                            {signingInspection ? <Loader2 className="h-4 w-4 animate-spin" /> : <Pen className="h-4 w-4" />}
                            Assinar Laudo de Vistoria
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Assinar laudo de vistoria?</AlertDialogTitle>
                            <AlertDialogDescription>
                              Ao confirmar, sua assinatura será registrada no laudo de vistoria do imóvel.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancelar</AlertDialogCancel>
                            <AlertDialogAction onClick={handleTenantSignInspection}>
                              Confirmar Assinatura
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    )}
                  </CardContent>
                </Card>
              )}

              {/* Keys Delivery Card — Step 10 */}
              {rental.currentStep >= 10 && !rental.isRejected && (
                <Card className="border-2 border-step-complete/50 bg-step-complete/5">
                  <CardContent className="p-6">
                    <div className="flex flex-col items-center text-center space-y-3">
                      <div className="w-16 h-16 rounded-full bg-step-complete/10 flex items-center justify-center">
                        <Key className="h-8 w-8 text-step-complete" />
                      </div>
                      <div className="space-y-1">
                        <h3 className="font-bold text-lg text-step-complete">
                          {inspectionData?.keys_delivered_at ? "🎉 Chaves entregues!" : "Chaves prontas para retirada!"}
                        </h3>
                        <p className="text-sm text-muted-foreground">
                          {inspectionData?.keys_delivered_at
                            ? "Parabéns! O processo de locação foi concluído. Bem-vindo ao seu novo lar!"
                            : "Compareça ao local combinado para retirar as chaves do seu novo lar."}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}


              {/* Contract Card — Steps 6-7: Show contract status and sign button */}
              {rental.currentStep >= 6 && contractData && !rental.isRejected && (
                <Card className={cn(
                  "border-2",
                  rental.currentStep === 7 && !contractData.signed_by_tenant_at
                    ? "border-primary/50 bg-primary/5"
                    : contractData.signed_by_tenant_at
                      ? "border-step-complete/30 bg-step-complete/5"
                      : "border-muted"
                )}>
                  <CardContent className="p-4 space-y-3">
                    <div className="flex items-center gap-3">
                      <div className={cn(
                        "w-10 h-10 rounded-full flex items-center justify-center shrink-0",
                        contractData.signed_by_tenant_at ? "bg-step-complete/10" : "bg-primary/10"
                      )}>
                        <Pen className={cn("h-5 w-5", contractData.signed_by_tenant_at ? "text-step-complete" : "text-primary")} />
                      </div>
                      <div>
                        <p className={cn(
                          "font-semibold text-sm",
                          contractData.signed_by_tenant_at ? "text-step-complete" : "text-foreground"
                        )}>
                          {rental.currentStep === 6 ? "Contrato em emissão" :
                           contractData.signed_by_tenant_at ? "Contrato assinado" :
                           "Assine seu contrato"}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {rental.currentStep === 6
                            ? "O contrato está sendo preparado. Você será notificado quando estiver pronto para assinatura."
                            : contractData.signed_by_tenant_at
                              ? `Assinado em ${format(new Date(contractData.signed_by_tenant_at), "dd/MM 'às' HH:mm", { locale: ptBR })}. ${contractData.signed_by_landlord_at ? "Locador também assinou." : "Aguardando assinatura do locador."}`
                              : "O contrato está pronto para sua assinatura digital."}
                        </p>
                      </div>
                    </div>

                    {/* Signature status */}
                    {rental.currentStep >= 7 && (
                      <div className="p-3 bg-muted/50 rounded-lg space-y-1.5">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-muted-foreground">Sua assinatura:</span>
                          {contractData.signed_by_tenant_at ? (
                            <Badge className="bg-sla-ok/20 text-sla-ok border-sla-ok/30 text-[10px]">Assinado ✓</Badge>
                          ) : (
                            <Badge variant="secondary" className="text-[10px]">Pendente</Badge>
                          )}
                        </div>
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-muted-foreground">Assinatura do locador:</span>
                          {contractData.signed_by_landlord_at ? (
                            <Badge className="bg-sla-ok/20 text-sla-ok border-sla-ok/30 text-[10px]">Assinado ✓</Badge>
                          ) : (
                            <Badge variant="secondary" className="text-[10px]">Pendente</Badge>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Preview button */}
                    {rental.contractPreviewUrl && (
                      <Button variant="outline" size="sm" className="w-full gap-2" onClick={() => window.open(rental.contractPreviewUrl, '_blank')}>
                        <Download className="h-4 w-4" />
                        Visualizar Contrato
                      </Button>
                    )}

                    {/* Sign button */}
                    {rental.currentStep === 7 && !contractData.signed_by_tenant_at && (
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button className="w-full gap-2" disabled={signingContract}>
                            {signingContract ? <Loader2 className="h-4 w-4 animate-spin" /> : <Pen className="h-4 w-4" />}
                            Assinar Contrato
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Assinar contrato de locação?</AlertDialogTitle>
                            <AlertDialogDescription>
                              Ao confirmar, sua assinatura digital será registrada. Certifique-se de ter revisado o contrato antes de assinar.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancelar</AlertDialogCancel>
                            <AlertDialogAction onClick={handleTenantSign}>
                              Confirmar Assinatura
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    )}
                  </CardContent>
                </Card>
              )}

              {(() => {
                const showPendingCTA = hasRealPendingDocs && !rental.isRejected && !docsFinalized;
                const showReadyCTA = docsReadyToFinalize && !rental.isRejected;
                
                if (showReadyCTA) {
                  return (
                    <Alert className="border-primary/40 bg-primary/5">
                      <CheckCircle2 className="h-5 w-5 text-primary" />
                      <AlertDescription className="space-y-2">
                        <p className="font-semibold text-sm text-primary">Documentos prontos para finalização</p>
                        <p className="text-xs text-muted-foreground">
                          Todos os documentos obrigatórios foram enviados. Clique abaixo para finalizar o envio.
                        </p>
                        <Button
                          size="sm"
                          className="gap-2"
                          onClick={handleFinalizeClick}
                          disabled={finalizing}
                        >
                          {finalizing ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle2 className="h-4 w-4" />}
                          Finalizar Envio
                        </Button>
                      </AlertDescription>
                    </Alert>
                  );
                }

                if (!showPendingCTA) return null;

                // Build a clear per-person pending list
                const t1Missing = currentMissingTypes;
                const totalPending = t1Missing.length;

                return (
                  <Card className="border-amber-500/30 bg-amber-500/5 animate-pulse-border" style={{ animationIterationCount: 1 }}>
                    <CardContent className="p-4 space-y-3">
                      {/* Summary header */}
                      <div className="flex items-center gap-2">
                        <AlertTriangle className="h-5 w-5 text-amber-600 shrink-0" />
                        <div>
                          <p className="font-semibold text-sm text-foreground">
                            {totalPending === 1 ? '1 documento pendente' : `${totalPending} documentos pendentes`}
                          </p>
                          <p className="text-xs text-muted-foreground">Envie para dar continuidade à análise.</p>
                        </div>
                      </div>

                      {/* Per-person breakdown — max 3 visible, rest in expandable */}
                      {t1Missing.length > 0 && (
                        <div className="space-y-1">
                          <div className="flex items-center gap-1.5">
                            <Badge variant="outline" className="text-[10px] font-semibold border-primary/40 text-primary px-1.5 py-0">
                              Locatário 1
                            </Badge>
                          </div>
                          <ul className="space-y-1 ml-1">
                            {t1Missing.slice(0, 3).map(type => (
                              <li key={type} className="flex items-center gap-2 text-xs">
                                <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0" />
                                <span className="text-foreground">{DOC_TYPE_LABELS[type]?.label || type}</span>
                                {REQUIRED_DOC_TYPES.includes(type) && (
                                  <Badge variant="secondary" className="text-[9px] px-1 py-0 h-3.5">Obrigatório</Badge>
                                )}
                              </li>
                            ))}
                          </ul>
                          {t1Missing.length > 3 && (
                            <details className="group ml-1">
                              <summary className="text-[11px] text-primary cursor-pointer hover:underline transition-colors">
                                Ver todas as pendências ({t1Missing.length})
                              </summary>
                              <ul className="mt-1 space-y-1 animate-accordion-down">
                                {t1Missing.slice(3).map(type => (
                                  <li key={type} className="flex items-center gap-2 text-xs">
                                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0" />
                                    <span className="text-foreground">{DOC_TYPE_LABELS[type]?.label || type}</span>
                                    {REQUIRED_DOC_TYPES.includes(type) && (
                                      <Badge variant="secondary" className="text-[9px] px-1 py-0 h-3.5">Obrigatório</Badge>
                                    )}
                                  </li>
                                ))}
                              </ul>
                            </details>
                          )}
                        </div>
                      )}

                      {/* Sent docs accordion */}
                      {uploadedCount > 0 && (
                        <details className="group">
                          <summary className="text-xs text-muted-foreground cursor-pointer hover:text-foreground transition-colors">
                            Ver {uploadedCount} documento{uploadedCount > 1 ? 's' : ''} já enviado{uploadedCount > 1 ? 's' : ''} ▾
                          </summary>
                          <ul className="mt-1.5 space-y-1 ml-1">
                            {docFiles.filter(f => f.status === 'uploaded').map(f => (
                              <li key={f.id} className="flex items-center gap-2 text-xs text-muted-foreground">
                                <CheckCircle2 className="h-3 w-3 text-step-complete shrink-0" />
                                <span>{DOC_TYPE_LABELS[f.type]?.label || f.type}</span>
                                {f.fileName && <span className="truncate text-[10px]">({f.fileName})</span>}
                              </li>
                            ))}
                          </ul>
                        </details>
                      )}

                      {/* Action CTA — hidden on mobile (sticky version below) */}
                      <div className="hidden sm:flex flex-col gap-1.5">
                        <Button
                          size="sm"
                          className="w-full gap-2"
                          onClick={() => navigate(`/locatario/enviar-documentos/${id}?returnTo=${encodeURIComponent('/locatario/acompanhamento/' + id)}`)}
                        >
                          <Upload className="h-4 w-4" />
                          Enviar documentos agora
                        </Button>
                        <p className="text-[10px] text-muted-foreground text-center">Você poderá voltar aqui depois.</p>
                      </div>
                    </CardContent>
                  </Card>
                );
              })()}

              {/* Sticky CTA for mobile — only when pending docs */}
              {hasRealPendingDocs && !rental.isRejected && !docsFinalized && (
                <div
                  className="fixed bottom-0 left-0 right-0 p-3 bg-background/95 backdrop-blur-sm border-t border-border z-50 sm:hidden"
                  style={{ paddingBottom: 'max(0.75rem, env(safe-area-inset-bottom))' }}
                >
                  <div className="container max-w-2xl mx-auto">
                    <Button
                      className="w-full gap-2 h-12 text-sm font-semibold"
                      onClick={() => navigate(`/locatario/enviar-documentos/${id}?returnTo=${encodeURIComponent('/locatario/acompanhamento/' + id)}`)}
                    >
                      <Upload className="h-4 w-4" />
                      Enviar documentos agora
                    </Button>
                    <p className="text-[10px] text-muted-foreground text-center mt-1">Você poderá voltar aqui depois.</p>
                  </div>
                </div>
              )}

              {/* Finalized Documents Summary */}
              {docsFinalized && (() => {
                console.log('[ACOMP_UI] Hiding upload list because docsFinalized is true');
                return (
                  <Card className="border-step-complete/30 bg-step-complete/5">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-step-complete/10 flex items-center justify-center shrink-0">
                          <CheckCircle2 className="h-5 w-5 text-step-complete" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium text-sm text-step-complete">Documentos enviados com sucesso</p>
                          <p className="text-xs text-muted-foreground">Sua documentação está em análise pela equipe Etic.</p>
                        </div>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        className="mt-3 gap-2"
                        onClick={async () => {
                          if (!id) return;
                          const success = await reopenDocumentSubmission(id);
                          if (success) {
                            setLocalFinalized(false);
                            toast({ title: "Modo de edição", description: "Você pode alterar seus documentos." });
                            await refetch();
                            navigate(`/locatario/enviar-documentos-pendentes/${id}`);
                          } else {
                            toast({ title: "Erro", description: "Não foi possível reabrir a edição.", variant: "destructive" });
                          }
                        }}
                      >
                        <Pen className="h-3.5 w-3.5" />
                        Editar documentos
                      </Button>
                    </CardContent>
                  </Card>
                );
              })()}


              {/* Timeline Steps — compact: show prev/current/next only */}
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <h2 className="font-semibold text-sm">Etapas do Processo</h2>
                  <button
                    className="text-[10px] text-primary font-medium"
                    onClick={() => setShowAllSteps(v => !v)}
                  >
                    {showAllSteps ? 'Mostrar menos' : `Ver todas (${TIMELINE_STEPS.length})`}
                  </button>
                </div>

                <div className="space-y-0">
                  {TIMELINE_STEPS.filter(step => {
                    if (showAllSteps) return true;
                    const diff = step.step - rental.currentStep;
                    return diff >= -1 && diff <= 1;
                  }).map((step, index, filteredSteps) => {
                    const isCompleted = step.step < rental.currentStep;
                    const isCurrent = step.step === rental.currentStep;
                    const isFuture = step.step > rental.currentStep;
                    const isExpanded = expandedStep === step.step;
                    const StepIcon = step.icon;

                    // Check if this is step 2 (Proposal Acceptance) and the proposal was rejected
                    const isProposalRejected = rental.isRejected && step.step === 2;

                    // Check if this is the documents step with pending docs - show RED
                    const isDocumentsStepPending = step.step === 3 && hasRealPendingDocs && !docsFinalized && (isCurrent || (rental.currentStep >= 3));
                    // Step 3 finalized state
                    const isDocumentsStepFinalized = step.step === 3 && docsFinalized;
                    // Step 3 ready to finalize
                    const isDocumentsStepReady = step.step === 3 && docsReadyToFinalize && !docsFinalized;

                    // Check if documents were submitted early (show check on step 3 even if at step 2)
                    const docsSubmittedEarly = rental.docsSubmittedEarly && step.step === 3;
                    const showDocsEarlyComplete = docsSubmittedEarly && rental.currentStep === 2 && !hasRealPendingDocs;

                    // Check if this is step 2 and we need to show landlord status
                    const showLandlordStatus = (step as any).showLandlordStatus &&
                      (rental.proposalType === 'direct' || rental.currentStep >= 2);

                    return (
                      <div key={step.step} className="relative">
                        {/* Connector Line */}
                        {index < filteredSteps.length - 1 && (
                          <div
                            className={cn(
                              "absolute left-4 top-10 w-0.5 h-full -translate-x-1/2 z-0",
                              isCompleted || showDocsEarlyComplete || isDocumentsStepFinalized ? "bg-step-complete" : "bg-muted"
                            )}
                          />
                        )}

                        {/* Step Button */}
                        <button
                          className={cn(
                            "relative z-10 w-full flex items-start gap-3 py-2.5 text-left transition-all",
                            (isCurrent || isCompleted || isDocumentsStepFinalized || isDocumentsStepReady || isDocumentsStepPending) && "cursor-pointer hover:bg-muted/30 rounded-lg px-1"
                          )}
                          onClick={() => toggleStep(step.step)}
                          disabled={isFuture && !showDocsEarlyComplete && !isDocumentsStepFinalized && !isDocumentsStepReady && !isDocumentsStepPending}
                        >
                          {/* Step Icon Circle */}
                          <div
                            className={cn(
                              "w-8 h-8 rounded-full flex items-center justify-center shrink-0 transition-all",
                              isCompleted || showDocsEarlyComplete || isDocumentsStepFinalized
                                ? "bg-step-complete text-white"
                                : isProposalRejected
                                  ? "bg-destructive text-white"
                                  : isDocumentsStepPending && !showDocsEarlyComplete
                                    ? "bg-destructive/10 text-destructive border-2 border-destructive/30"
                                    : isDocumentsStepReady
                                      ? "bg-primary/10 text-primary border-2 border-primary/30"
                                      : isCurrent
                                        ? "bg-primary text-primary-foreground"
                                        : "bg-muted text-muted-foreground"
                            )}
                          >
                            {isCompleted || showDocsEarlyComplete || isDocumentsStepFinalized ? (
                              <Check className="h-4 w-4" />
                            ) : isProposalRejected ? (
                              <X className="h-4 w-4" />
                            ) : (
                              <StepIcon className="h-4 w-4" />
                            )}
                          </div>

                          {/* Step Content */}
                          <div className="flex-1 min-w-0 pt-0.5">
                            <div className="flex items-center justify-between gap-2">
                              <p
                              className={cn(
                                  "font-medium text-sm",
                                  isCompleted || showDocsEarlyComplete || isDocumentsStepFinalized
                                    ? "text-step-complete"
                                    : isProposalRejected
                                      ? "text-destructive"
                                      : isDocumentsStepPending && !showDocsEarlyComplete
                                        ? "text-destructive"
                                        : isDocumentsStepReady
                                          ? "text-primary"
                                          : isCurrent
                                            ? "text-foreground"
                                            : "text-muted-foreground"
                                )}
                              >
                              {step.title}
                              </p>
                              {/* Status badges */}
                              {isCurrent && step.step !== 3 && (
                                <Badge className="text-[10px] px-1.5 py-0 h-4 shrink-0 bg-primary text-primary-foreground border-0">
                                  Atual
                                </Badge>
                              )}
                              {step.step === rental.currentStep + 1 && !isCurrent && (
                                <span className="text-[10px] text-muted-foreground shrink-0">Próximo</span>
                              )}
                              {step.step === 3 && docsFinalized && (
                                <Badge className="text-[10px] px-1.5 py-0 h-4 shrink-0 bg-step-complete text-white border-0">
                                  Finalizado
                                </Badge>
                              )}
                              {step.step === 3 && !docsFinalized && docsReadyToFinalize && (
                                <Badge className="text-[10px] px-1.5 py-0 h-4 shrink-0 bg-primary text-primary-foreground border-0">
                                  Pronto
                                </Badge>
                              )}
                              {isDocumentsStepPending && !showDocsEarlyComplete && !docsFinalized && !docsReadyToFinalize && (
                                <Badge variant="destructive" className="text-[10px] px-1.5 py-0 h-4 shrink-0">
                                  Pendente
                                </Badge>
                              )}
                              {(isCurrent || isCompleted || showDocsEarlyComplete) && (
                                isExpanded ? (
                                  <ChevronUp className="h-4 w-4 text-muted-foreground shrink-0" />
                                ) : (
                                  <ChevronDown className="h-4 w-4 text-muted-foreground shrink-0" />
                                )
                              )}
                            </div>
                            <p className="text-xs text-muted-foreground">
                              {isProposalRejected
                                ? (rental.rejectionReason === 'property_rented'
                                  ? "Este imóvel foi locado por outro inquilino."
                                  : "Sua proposta foi rejeitada pelo locador.")
                                : isDocumentsStepFinalized
                                  ? "Documentação finalizada e em análise."
                                  : isDocumentsStepReady
                                    ? "Todos os documentos enviados. Finalize o envio."
                                    : isDocumentsStepPending && !showDocsEarlyComplete
                                      ? "Faltam documentos para completar o envio."
                                      : step.description}
                            </p>

                            {/* CTA button inside step 3 when pending */}
                            {isDocumentsStepPending && !showDocsEarlyComplete && isExpanded && (
                              <Button
                                size="sm"
                                variant="default"
                                className="mt-2 gap-2"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  navigate(`/locatario/enviar-documentos/${id}?returnTo=${encodeURIComponent('/locatario/acompanhamento/' + id)}`);
                                }}
                              >
                                <Upload className="h-4 w-4" />
                                Enviar documentos
                              </Button>
                            )}
                            {/* Ready to finalize CTA inside step 3 */}
                            {isDocumentsStepReady && isExpanded && (
                              <Button
                                size="sm"
                                className="mt-2 gap-2"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleFinalizeClick();
                                }}
                                disabled={finalizing}
                              >
                                {finalizing ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle2 className="h-4 w-4" />}
                                Finalizar Envio
                              </Button>
                            )}
                            {/* Finalized docs message inside step 3 */}
                            {isDocumentsStepFinalized && isExpanded && (
                              <div className="space-y-2 mt-2">
                                <div className="flex items-center gap-2 p-2 bg-step-complete/10 rounded-lg">
                                  <CheckCircle2 className="h-4 w-4 text-step-complete" />
                                  <span className="text-xs text-step-complete font-medium">
                                    Documentação finalizada. Em análise.
                                  </span>
                                </div>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="gap-2"
                                  onClick={async (e) => {
                                    e.stopPropagation();
                                    if (!id) return;
                                    const success = await reopenDocumentSubmission(id);
                                    if (success) {
                                      setLocalFinalized(false);
                                      toast({ title: "Modo de edição", description: "Você pode alterar seus documentos." });
                                      await refetch();
                                      navigate(`/locatario/enviar-documentos-pendentes/${id}`);
                                    } else {
                                      toast({ title: "Erro", description: "Não foi possível reabrir a edição.", variant: "destructive" });
                                    }
                                  }}
                                >
                                  <Pen className="h-3.5 w-3.5" />
                                  Editar documentos
                                </Button>
                              </div>
                            )}

                            {/* Landlord Status Indicator for Step 2 — dynamic based on proposalStatus */}
                            {showLandlordStatus && (isCurrent || isCompleted || rental.proposalType === 'direct') && (
                              <div className={cn(
                                "flex items-center gap-2 mt-2 p-2 rounded-lg",
                                rental.proposalStatus === 'proposal_accepted' || rental.landlordAccepted
                                  ? "bg-step-complete/10"
                                  : rental.proposalStatus === 'counter_proposal_pending'
                                    ? "bg-amber-500/10 border border-amber-500/20"
                                    : rental.proposalStatus === 'proposal_rejected'
                                      ? "bg-destructive/10"
                                      : "bg-amber-500/10"
                              )}>
                                {rental.proposalStatus === 'proposal_accepted' || rental.landlordAccepted ? (
                                  <>
                                    <CheckCircle2 className="h-4 w-4 text-step-complete" />
                                    <span className="text-xs text-step-complete font-medium">
                                      Proposta aceita — negociação concluída
                                    </span>
                                  </>
                                ) : rental.proposalStatus === 'counter_proposal_pending' ? (
                                  <>
                                    <Handshake className="h-4 w-4 text-amber-600" />
                                    <span className="text-xs text-amber-700 font-medium">
                                      Contraproposta recebida — Ação necessária
                                    </span>
                                  </>
                                ) : rental.proposalStatus === 'proposal_rejected' ? (
                                  <>
                                    <X className="h-4 w-4 text-destructive" />
                                    <span className="text-xs text-destructive font-medium">
                                      Proposta rejeitada
                                    </span>
                                  </>
                                ) : (
                                  <>
                                    <Clock className="h-4 w-4 text-amber-600" />
                                    <span className="text-xs text-amber-700">
                                      {rental.proposalType === 'direct'
                                        ? "Aguardando confirmação de disponibilidade do locador"
                                        : "Aguardando aceite do locador"}
                                    </span>
                                  </>
                                )}
                              </div>
                            )}

                            {/* Early Docs Submitted Message */}
                            {showDocsEarlyComplete && (
                              <div className="flex items-center gap-2 mt-2 p-2 bg-primary/5 rounded-lg">
                                <FileText className="h-4 w-4 text-primary" />
                                <span className="text-xs text-primary font-medium">
                                  Documentos enviados! Análise em até 24h úteis.
                                </span>
                              </div>
                            )}

                            {/* Expanded Content */}
                            {isExpanded && (
                              <div className="mt-2 pt-2 border-t space-y-2">
                                <div className="flex items-center gap-2 text-xs">
                                  <Clock className="h-3 w-3 text-muted-foreground" />
                                  <span className="text-muted-foreground">Prazo:</span>
                                  <span className="font-medium">{step.sla}</span>
                                </div>
                                {step.action && (isCurrent || isCompleted) && (
                                  <div className="p-2 bg-background rounded-lg border">
                                    <p className="text-xs">
                                      <span className="font-medium">O que fazer: </span>
                                      {step.action}
                                    </p>
                                  </div>
                                )}

                                {/* Step 3 inline CTA — navigate to dedicated upload page */}
                                {step.step === 3 && hasRealPendingDocs && (
                                  <div className="mt-2 p-3 bg-primary/5 rounded-lg border border-primary/20">
                                    <p className="text-xs text-muted-foreground mb-2">
                                      {rental.tenantStatus?.includes('docs_submitted')
                                        ? "Envie os documentos pendentes na página de envio."
                                        : "Preencha sua ficha e envie os documentos na página dedicada."}
                                    </p>
                                    <Button
                                      size="sm"
                                      className="w-full gap-2"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        navigate(rental.tenantStatus?.includes('docs_submitted')
                                          ? `/locatario/enviar-documentos/${id}?returnTo=${encodeURIComponent('/locatario/acompanhamento/' + id)}`
                                          : `/locatario/enviar-documentos/${rental.propertyCode}?returnTo=${encodeURIComponent('/locatario/acompanhamento/' + id)}`
                                        );
                                      }}
                                    >
                                      <Upload className="h-4 w-4" />
                                      {rental.tenantStatus?.includes('docs_submitted') ? 'Enviar documentos' : 'Preencher ficha completa'}
                                    </Button>
                                  </div>
                                )}

                                {isFuture && !showDocsEarlyComplete && step.step !== 3 && (
                                  <p className="text-[10px] text-muted-foreground italic">
                                    Etapa liberada após conclusão das anteriores.
                                  </p>
                                )}
                              </div>
                            )}
                          </div>
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Documents and Links Section */}
              <Card>
                <CardHeader className="pb-2 pt-4">
                  <div className="flex items-center gap-2">
                    <BookOpen className="h-5 w-5 text-primary" />
                    <CardTitle className="text-base">Documentos e Links</CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="pb-4 space-y-3">
                  {/* Manual do Locatário */}
                  <a
                    href="https://drive.google.com/file/d/1Ex1Ip-7HPrd--Whdfv0-lYtX21P2ueqm/view?usp=sharing"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 p-3 rounded-lg border hover:bg-muted/50 transition-colors group"
                  >
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                      <BookOpen className="h-5 w-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm text-foreground">Manual do Locatário</p>
                      <p className="text-xs text-muted-foreground">Tudo sobre seus direitos e deveres</p>
                    </div>
                    <ExternalLink className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
                  </a>

                  {/* Contrato de Locação */}
                  <div
                    className={cn(
                      "flex items-center gap-3 p-3 rounded-lg border",
                      rental.contractPreviewUrl
                        ? "hover:bg-muted/50 transition-colors cursor-pointer"
                        : "opacity-50 cursor-not-allowed"
                    )}
                    onClick={() => {
                      if (rental.contractPreviewUrl) {
                        window.open(rental.contractPreviewUrl, '_blank');
                      }
                    }}
                  >
                    <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center shrink-0">
                      <Download className="h-5 w-5 text-muted-foreground" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm text-foreground">Contrato de Locação</p>
                      <p className="text-xs text-muted-foreground">
                        {rental.contractPreviewUrl
                          ? "Visualize a prévia do contrato"
                          : "Disponível após emissão do contrato"}
                      </p>
                    </div>
                    {rental.contractPreviewUrl && (
                      <ExternalLink className="h-4 w-4 text-muted-foreground" />
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Event History */}
              {events.length > 0 && (
                <Card>
                  <CardHeader className="pb-2 pt-4">
                    <CardTitle className="text-base">Histórico de Eventos</CardTitle>
                  </CardHeader>
                  <CardContent className="pb-4">
                    <div className="space-y-0 relative">
                      {events.map((event, index) => {
                        const isRejectionEvent =
                          event.eventType === 'proposal_rejected' ||
                          event.eventType === 'property_rented';

                        return (
                          <div key={event.id} className="relative flex gap-3 pb-3">
                            {index < events.length - 1 && (
                              <div className={cn(
                                "absolute left-1.5 top-5 w-0.5 h-full -translate-x-1/2",
                                isRejectionEvent ? "bg-destructive" : "bg-muted"
                              )} />
                            )}

                            <div className={cn(
                              "w-3 h-3 rounded-full shrink-0 mt-0.5 z-10",
                              isRejectionEvent ? "bg-destructive" : "bg-primary"
                            )} />

                            <div className="flex-1 min-w-0">
                              <p className={cn(
                                "font-medium text-xs",
                                isRejectionEvent ? "text-destructive" : "text-foreground"
                              )}>
                                {event.description}
                              </p>
                              <p className="text-[10px] text-muted-foreground mt-0.5">
                                {format(event.createdAt, "dd 'de' MMMM 'às' HH:mm", { locale: ptBR })}
                              </p>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* QA Panel — only visible with ?qa=1 */}
              {isQA && (
                <Card className="border-2 border-dashed border-muted-foreground/30">
                  <CardHeader className="pb-2 pt-4">
                    <div className="flex items-center gap-2">
                      <ShieldAlert className="h-5 w-5 text-muted-foreground" />
                      <CardTitle className="text-base text-muted-foreground">Painel QA</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent className="pb-4 space-y-3 text-xs font-mono">
                    {/* Core State */}
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <p className="font-semibold text-foreground mb-1">rentalId</p>
                        <p className="text-muted-foreground break-all text-[10px]">{rental.id}</p>
                      </div>
                      <div>
                        <p className="font-semibold text-foreground mb-1">current_step</p>
                        <Badge variant="outline">{rental.currentStep}</Badge>
                      </div>
                      <div>
                        <p className="font-semibold text-foreground mb-1">proposal_status</p>
                        <Badge variant="outline">{rental.proposalStatus || 'N/A'}</Badge>
                      </div>
                      <div>
                        <p className="font-semibold text-foreground mb-1">documents_finalized_at</p>
                        <Badge variant="outline">{rental.documentsFinalizedAt ? format(rental.documentsFinalizedAt, 'dd/MM HH:mm') : 'null'}</Badge>
                      </div>
                      <div>
                        <p className="font-semibold text-foreground mb-1">documents_cycle</p>
                        <Badge variant="outline">{rental.documentsCycle || 1}</Badge>
                      </div>
                      <div>
                        <p className="font-semibold text-foreground mb-1">missingTypes</p>
                        <Badge variant={currentMissingTypes.length === 0 ? 'default' : 'destructive'} className="text-[10px]">
                          {currentMissingTypes.length === 0 ? 'Nenhum' : currentMissingTypes.join(', ')}
                        </Badge>
                      </div>
                    </div>

                    {/* Proposals list */}
                    <div>
                      <p className="font-semibold text-foreground mb-1">Ofertas ({proposals.length})</p>
                      {proposals.length === 0 ? (
                        <p className="text-muted-foreground">Nenhuma oferta registrada</p>
                      ) : (
                        <div className="space-y-1">
                          {proposals.map(p => (
                            <div key={p.id} className="flex items-center gap-2 p-1 bg-muted/50 rounded">
                              <Badge variant={p.author === 'tenant' ? 'default' : 'secondary'} className="text-[10px]">
                                {p.author}
                              </Badge>
                              <span>{p.rent_value ? formatCurrency(p.rent_value) : '-'}</span>
                              <Badge variant="outline" className="text-[10px]">{p.status}</Badge>
                              <span className="text-muted-foreground">{format(new Date(p.created_at), 'dd/MM HH:mm')}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Last 30 events */}
                    <div>
                      <p className="font-semibold text-foreground mb-1">Últimos eventos ({events.length})</p>
                      <div className="space-y-0.5 max-h-60 overflow-y-auto">
                        {events.slice(-30).map(e => (
                          <div key={e.id} className="flex gap-2 text-[10px]">
                            <Badge variant="outline" className="text-[9px] shrink-0">{e.eventType}</Badge>
                            <span className="truncate">{e.description}</span>
                            <span className="text-muted-foreground shrink-0">{format(e.createdAt, 'HH:mm')}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Coverage OK */}
                    <div>
                      <p className="font-semibold text-foreground mb-1">Cobertura OK?</p>
                      {(() => {
                        const checks = runConsistencyChecks({
                          currentStep: rental.currentStep,
                          proposalStatus: rental.proposalStatus || 'waiting_landlord_acceptance',
                          documentsFinalizedAt: rental.documentsFinalizedAt,
                          documentsCycle: rental.documentsCycle || 1,
                          missingTypes: currentMissingTypes,
                          events,
                          proposals,
                          isRejected: rental.isRejected,
                        });

                        const allOk = checks.every(c => c.ok);
                        if (import.meta.env.DEV) console.log('[QA_COVERAGE]', { rentalId: rental.id, ok: allOk, missing: checks.filter(c => !c.ok).map(c => c.label) });

                        return (
                          <div className="space-y-1">
                            {checks.map((c, i) => (
                              <div key={i} className="flex items-center gap-2">
                                {c.ok ? (
                                  <CheckCircle2 className="h-3 w-3 text-step-complete" />
                                ) : (
                                  <X className="h-3 w-3 text-destructive" />
                                )}
                                <span className={c.ok ? 'text-step-complete' : 'text-destructive'}>{c.label}</span>
                                {!c.ok && c.fixAction === 'set_step_2' && import.meta.env.DEV && (
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    className="h-5 text-[9px] px-1.5"
                                    onClick={async () => {
                                      const ok = await qaFixCurrentStep(rental.id, 2, 'Corrigido via QA: step inconsistente com proposal_status');
                                      if (ok) {
                                        toast({ title: 'Corrigido', description: 'current_step atualizado para 2.' });
                                        await refetch();
                                      }
                                    }}
                                  >
                                    Corrigir → step 2
                                  </Button>
                                )}
                              </div>
                            ))}
                            <div className="pt-1 border-t mt-2">
                              <Badge variant={allOk ? 'default' : 'destructive'}>
                                {allOk ? '✅ Cobertura OK' : '❌ Inconsistências detectadas'}
                              </Badge>
                            </div>
                          </div>
                        );
                      })()}
                    </div>

                    {/* QA Auto-correction buttons — DEV only */}
                    {import.meta.env.DEV && (
                      <div className="border-t pt-2 space-y-2">
                        <p className="font-semibold text-foreground">Ações QA (DEV only)</p>
                        <div className="flex gap-2 flex-wrap">
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-[10px] h-6"
                            onClick={async () => {
                              const checks = runConsistencyChecks({
                                currentStep: rental.currentStep,
                                proposalStatus: rental.proposalStatus || 'waiting_landlord_acceptance',
                                documentsFinalizedAt: rental.documentsFinalizedAt,
                                documentsCycle: rental.documentsCycle || 1,
                                missingTypes: currentMissingTypes,
                                events,
                                proposals,
                                isRejected: rental.isRejected,
                              });
                              const fixes = checks.filter(c => !c.ok && c.fixAction);
                              if (fixes.length === 0) {
                                toast({ title: 'Nenhuma correção necessária' });
                                return;
                              }
                              for (const fix of fixes) {
                                if (fix.fixAction === 'set_step_2') {
                                  await qaFixCurrentStep(rental.id, 2, fix.label);
                                }
                              }
                              toast({ title: 'Correções aplicadas', description: `${fixes.length} correção(ões)` });
                              await refetch();
                            }}
                          >
                            Recalcular e corrigir step
                          </Button>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}

              {/* WhatsApp Button — desktop inline */}
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="hidden sm:flex items-center justify-center gap-3 w-full p-3 bg-[#25D366] hover:bg-[#22c35e] text-white rounded-xl font-medium transition-colors text-sm"
              >
                <MessageCircle className="h-5 w-5" />
                Falar com a Etic via WhatsApp
              </a>

              {/* Safe bottom padding for sticky CTA / FAB */}
              <div className="h-28 sm:h-0" aria-hidden="true" />
            </div>
          )}

          {/* WhatsApp FAB — mobile only */}
          {rental && !rental.isRejected && (
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className={cn(
                "fixed z-50 sm:hidden w-14 h-14 rounded-full bg-[#25D366] text-white flex items-center justify-center shadow-lg",
                "active:scale-95 transition-transform",
                hasRealPendingDocs && !docsFinalized ? "bottom-[88px] right-4" : "bottom-6 right-4"
              )}
              style={{ marginBottom: 'env(safe-area-inset-bottom)' }}
              aria-label="WhatsApp"
            >
              <MessageCircle className="h-6 w-6" />
            </a>
          )}

          {!loading && !error && !rental && (
            <div className="text-center py-12">
              <Home className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground mb-4">Nenhuma proposta encontrada.</p>
              <Button asChild>
                <Link to="/selecionar-imovel">Iniciar nova proposta</Link>
              </Button>
            </div>
          )}
        </div>
      </main>

    </div>
  );
}