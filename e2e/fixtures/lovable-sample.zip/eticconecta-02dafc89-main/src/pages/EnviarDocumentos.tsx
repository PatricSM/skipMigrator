import { useState, useEffect } from "react";
import { useParams, useNavigate, useLocation, useSearchParams } from "react-router-dom";
import { Loader2, AlertTriangle } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { generateProtocol } from "@/hooks/useRentalTracking";
import { Button } from "@/components/ui/button";

/**
 * Pure resolver page: resolves propertyCode → rentalId (UUID),
 * then immediately redirects to /locatario/enviar-documentos-pendentes/{rentalId}.
 * No forms, no uploads, no submit buttons.
 */
export default function EnviarDocumentos() {
  const { id: propertyCode } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const [searchParams] = useSearchParams();
  const { user, isLoading: authLoading } = useAuth();

  const [error, setError] = useState<string | null>(null);
  const [resolving, setResolving] = useState(true);

  // Extract navigation state to forward
  const navState = location.state as {
    proposalType?: 'direct' | 'standard';
    proposedValue?: number;
    sendDocs?: boolean;
    secondTenantData?: unknown;
    secondTenantDocuments?: unknown;
    secondTenantSaved?: boolean;
    mainTenantData?: unknown;
    mainTenantDocuments?: unknown;
  } | null;

  const proposalType = navState?.proposalType || 'standard';
  const proposedValue = navState?.proposedValue || null;
  const sendDocs = navState?.sendDocs !== false;

  useEffect(() => {
    if (authLoading) return;
    if (!user?.id || !propertyCode) {
      setResolving(false);
      setError("Usuário não autenticado ou código de imóvel ausente.");
      return;
    }

    let cancelled = false;

    const resolve = async () => {
      console.log('[FLOW] PropertyCode detected, resolving rentalId...', { propertyCode });

      try {
        // 1. Look for existing rental for this user + property_code
        const { data: existing, error: fetchErr } = await supabase
          .from('rentals')
          .select('id')
          .eq('property_code', propertyCode)
          .eq('user_id', user.id)
          .order('created_at', { ascending: false })
          .limit(1)
          .maybeSingle();

        if (fetchErr) throw fetchErr;

        let rentalId: string;

        if (existing) {
          rentalId = existing.id;
          console.log('[FLOW] Existing rental found:', rentalId);
        } else {
          // 2. Fetch property data for the draft
          let propertyAddress = `Imóvel ${propertyCode}`;
          let propertyId = propertyCode;

          try {
            const { data: propData } = await supabase.functions.invoke<{
              success: boolean;
              properties: Array<{ id: string; code: string; address: string }>;
            }>("fetch-properties");

            if (propData?.success && propData.properties) {
              const prop = propData.properties.find(p => p.code === propertyCode);
              if (prop) {
                propertyAddress = prop.address || propertyAddress;
                propertyId = prop.id || propertyCode;
              }
            }
          } catch (e) {
            console.warn('[FLOW] Could not fetch property data for draft:', e);
          }

          // 3. Create draft rental
          const protocol = generateProtocol(propertyCode);
          const { data: created, error: insertErr } = await supabase
            .from('rentals')
            .insert({
              user_id: user.id,
              property_id: propertyId,
              property_code: propertyCode,
              property_address: propertyAddress,
              protocol,
              current_step: 1,
              step_status: 'pending',
              tenant_status: 'draft',
              proposal_type: proposalType,
              proposed_value: proposedValue,
            })
            .select('id')
            .single();

          if (insertErr) throw insertErr;
          rentalId = created.id;
          console.log('[FLOW] Draft rental created:', rentalId);
        }

        if (cancelled) return;

        // 4. Build redirect target preserving returnTo if present
        const returnTo = searchParams.get('returnTo');
        let target = `/locatario/enviar-documentos-pendentes/${rentalId}`;
        if (returnTo) {
          target += `?returnTo=${encodeURIComponent(returnTo)}`;
        }

        console.log('[FLOW] Redirecting to UUID route:', target);
        navigate(target, {
          replace: true,
          state: {
            ...navState,
            proposalType,
            proposedValue,
            sendDocs,
          },
        });
      } catch (err) {
        console.error('[FLOW] Error resolving rentalId:', err);
        if (!cancelled) {
          setError("Não foi possível carregar a proposta. Tente novamente.");
          setResolving(false);
        }
      }
    };

    resolve();
    return () => { cancelled = true; };
  }, [user?.id, propertyCode, authLoading]);

  // Loading state
  if (resolving || authLoading) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center gap-4">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
        <p className="text-muted-foreground text-sm">Carregando proposta...</p>
      </div>
    );
  }

  // Error state
  if (error) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center gap-4 p-4">
        <AlertTriangle className="h-10 w-10 text-destructive" />
        <p className="text-foreground font-medium text-center">{error}</p>
        <Button variant="outline" onClick={() => navigate('/locatario/painel')}>
          Voltar ao Painel
        </Button>
      </div>
    );
  }

  return null;
}
