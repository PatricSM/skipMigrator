import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Building, MessageCircle, X, ImagePlus } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { maskPhone, maskCurrencyInput } from "@/lib/masks";
import { AppHeader } from "@/components/layout/AppHeader";

const TIPOS_IMOVEL = [
  { value: "apartamento", label: "Apartamento" },
  { value: "casa_terrea", label: "Casa Térrea" },
  { value: "sobrado", label: "Sobrado" },
  { value: "casa_condominio", label: "Casa em Condomínio" },
  { value: "terreno", label: "Terreno" },
  { value: "sala_comercial", label: "Sala Comercial" },
  { value: "galpao", label: "Galpão" },
];

const TIPOS_SEM_CONDOMINIO = ["casa_terrea", "sobrado", "galpao", "terreno"];

export default function AnunciarImovel() {
  const { user, profile } = useAuth();
  
  // Contact info (only shown if not logged in)
  const [nome, setNome] = useState(profile?.full_name || "");
  const [telefone, setTelefone] = useState(profile?.phone || "");
  
  // Property info
  const [interesse, setInteresse] = useState<string>("");
  const [tipoImovel, setTipoImovel] = useState<string>("");
  const [valorVenda, setValorVenda] = useState("");
  const [valorAluguel, setValorAluguel] = useState("");
  const [valorIptu, setValorIptu] = useState("");
  const [iptuIsento, setIptuIsento] = useState(false);
  const [valorCondominio, setValorCondominio] = useState("");
  
  // Address
  const [rua, setRua] = useState("");
  const [numero, setNumero] = useState("");
  const [complemento, setComplemento] = useState("");
  
  // Details
  const [metragem, setMetragem] = useState("");
  const [vagas, setVagas] = useState("");
  const [informacoes, setInformacoes] = useState("");
  
  // Photos
  const [enviarFotos, setEnviarFotos] = useState<"sim" | "nao">("nao");
  const [fotos, setFotos] = useState<File[]>([]);
  
  const mostrarCondominio = tipoImovel && !TIPOS_SEM_CONDOMINIO.includes(tipoImovel);
  const mostrarVenda = interesse === "venda" || interesse === "venda_aluguel";
  const mostrarAluguel = interesse === "aluguel" || interesse === "venda_aluguel";
  
  const handleFotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      const newFiles = Array.from(files).slice(0, 20 - fotos.length);
      setFotos(prev => [...prev, ...newFiles].slice(0, 20));
    }
  };
  
  const removeFoto = (index: number) => {
    setFotos(prev => prev.filter((_, i) => i !== index));
  };
  
  const getTipoLabel = () => {
    const tipo = TIPOS_IMOVEL.find(t => t.value === tipoImovel);
    return tipo?.label || tipoImovel;
  };
  
  const getInteresseLabel = () => {
    if (interesse === "venda") return "Venda";
    if (interesse === "aluguel") return "Aluguel";
    if (interesse === "venda_aluguel") return "Venda e Aluguel";
    return "";
  };
  
  const gerarMensagemWhatsApp = () => {
    const nomeCliente = nome || profile?.full_name || "Cliente";
    
    let mensagem = `Olá! Sou ${nomeCliente} e quero anunciar um imóvel com a Etic.\n\n`;
    
    if (interesse) mensagem += `*Interesse:* ${getInteresseLabel()}\n`;
    if (tipoImovel) mensagem += `*Tipo:* ${getTipoLabel()}\n`;
    if (rua) mensagem += `*Endereço:* ${rua}${numero ? `, ${numero}` : ""}${complemento ? ` - ${complemento}` : ""}\n`;
    if (metragem) mensagem += `*Metragem:* ${metragem}m²\n`;
    if (vagas) mensagem += `*Vagas:* ${vagas}\n`;
    
    if (mostrarVenda && valorVenda) mensagem += `*Valor de Venda:* R$ ${valorVenda}\n`;
    if (mostrarAluguel && valorAluguel) mensagem += `*Valor de Aluguel:* R$ ${valorAluguel}\n`;
    
    if (iptuIsento) {
      mensagem += `*IPTU:* Isento\n`;
    } else if (valorIptu) {
      mensagem += `*IPTU:* R$ ${valorIptu}\n`;
    }
    
    if (mostrarCondominio && valorCondominio) {
      mensagem += `*Condomínio:* R$ ${valorCondominio}\n`;
    }
    
    if (informacoes) {
      mensagem += `\n*Informações adicionais:*\n${informacoes}\n`;
    }
    
    if (enviarFotos === "sim" && fotos.length > 0) {
      mensagem += `\n📷 Tenho ${fotos.length} foto(s) para enviar.\n`;
    } else if (enviarFotos === "nao") {
      mensagem += `\n📷 Solicito que a Etic tire as fotos.\n`;
    }
    
    mensagem += `\nAguardo contato de um especialista.`;
    
    return `https://wa.me/5511970932722?text=${encodeURIComponent(mensagem)}`;
  };
  
  const isFormValid = () => {
    const hasContactInfo = user || (nome && telefone);
    const hasBasicInfo = interesse && tipoImovel && rua && numero && metragem;
    const hasValues = (mostrarVenda ? valorVenda : true) && (mostrarAluguel ? valorAluguel : true);
    return hasContactInfo && hasBasicInfo && hasValues;
  };

  return (
    <div className="min-h-screen bg-background">
      <AppHeader />

      <main className="container mx-auto px-4 py-6 max-w-2xl">
        {/* Title */}
        <div className="text-center mb-6">
          <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
            <Building className="h-8 w-8 text-primary" />
          </div>
          <h1 className="text-2xl font-bold text-foreground">Anuncie seu imóvel</h1>
          <p className="text-muted-foreground mt-2">
            Cadastre os dados do seu imóvel e um especialista entrará em contato.
          </p>
        </div>

        <div className="space-y-6">
          {/* Contact Info (if not logged in) */}
          {!user && (
            <Card>
              <CardHeader className="pb-4">
                <CardTitle className="text-lg">Seus dados de contato</CardTitle>
                <CardDescription>Para que possamos entrar em contato</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="nome">Nome completo *</Label>
                  <Input
                    id="nome"
                    value={nome}
                    onChange={(e) => setNome(e.target.value)}
                    placeholder="Seu nome"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="telefone">Telefone *</Label>
                  <Input
                    id="telefone"
                    value={telefone}
                    onChange={(e) => setTelefone(maskPhone(e.target.value))}
                    placeholder="(11) 99999-9999"
                  />
                </div>
              </CardContent>
            </Card>
          )}

          {/* Property Type */}
          <Card>
            <CardHeader className="pb-4">
              <CardTitle className="text-lg">Sobre o imóvel</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Interesse *</Label>
                <Select value={interesse} onValueChange={setInteresse}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="venda">Venda</SelectItem>
                    <SelectItem value="aluguel">Aluguel</SelectItem>
                    <SelectItem value="venda_aluguel">Venda e Aluguel</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label>Tipo do imóvel *</Label>
                <Select value={tipoImovel} onValueChange={setTipoImovel}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    {TIPOS_IMOVEL.map((tipo) => (
                      <SelectItem key={tipo.value} value={tipo.value}>
                        {tipo.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="metragem">Metragem (m²) *</Label>
                  <Input
                    id="metragem"
                    type="number"
                    value={metragem}
                    onChange={(e) => setMetragem(e.target.value)}
                    placeholder="Ex: 80"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="vagas">Número de vagas</Label>
                  <Input
                    id="vagas"
                    type="number"
                    value={vagas}
                    onChange={(e) => setVagas(e.target.value)}
                    placeholder="Ex: 2"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Values */}
          <Card>
            <CardHeader className="pb-4">
              <CardTitle className="text-lg">Valores</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {mostrarVenda && (
                <div className="space-y-2">
                  <Label htmlFor="valorVenda">Valor de venda *</Label>
                  <Input
                    id="valorVenda"
                    value={valorVenda}
                    onChange={(e) => setValorVenda(maskCurrencyInput(e.target.value))}
                    placeholder="R$ 0,00"
                  />
                </div>
              )}
              
              {mostrarAluguel && (
                <div className="space-y-2">
                  <Label htmlFor="valorAluguel">Valor do aluguel *</Label>
                  <Input
                    id="valorAluguel"
                    value={valorAluguel}
                    onChange={(e) => setValorAluguel(maskCurrencyInput(e.target.value))}
                    placeholder="R$ 0,00"
                  />
                </div>
              )}
              
              <div className="space-y-2">
                <Label htmlFor="valorIptu">Valor do IPTU</Label>
                <div className="flex items-center gap-4">
                  <Input
                    id="valorIptu"
                    value={valorIptu}
                    onChange={(e) => setValorIptu(maskCurrencyInput(e.target.value))}
                    placeholder="R$ 0,00"
                    disabled={iptuIsento}
                    className="flex-1"
                  />
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="iptuIsento"
                      checked={iptuIsento}
                      onCheckedChange={(checked) => {
                        setIptuIsento(checked === true);
                        if (checked) setValorIptu("");
                      }}
                    />
                    <Label htmlFor="iptuIsento" className="text-sm cursor-pointer">
                      Isento
                    </Label>
                  </div>
                </div>
              </div>
              
              {mostrarCondominio && (
                <div className="space-y-2">
                  <Label htmlFor="valorCondominio">Valor do condomínio</Label>
                  <Input
                    id="valorCondominio"
                    value={valorCondominio}
                    onChange={(e) => setValorCondominio(maskCurrencyInput(e.target.value))}
                    placeholder="R$ 0,00"
                  />
                </div>
              )}
            </CardContent>
          </Card>

          {/* Address */}
          <Card>
            <CardHeader className="pb-4">
              <CardTitle className="text-lg">Endereço</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="rua">Rua *</Label>
                <Input
                  id="rua"
                  value={rua}
                  onChange={(e) => setRua(e.target.value)}
                  placeholder="Nome da rua"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="numero">Número *</Label>
                  <Input
                    id="numero"
                    value={numero}
                    onChange={(e) => setNumero(e.target.value)}
                    placeholder="Ex: 123"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="complemento">Complemento</Label>
                  <Input
                    id="complemento"
                    value={complemento}
                    onChange={(e) => setComplemento(e.target.value)}
                    placeholder="Apto, bloco..."
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Additional Info */}
          <Card>
            <CardHeader className="pb-4">
              <CardTitle className="text-lg">Informações adicionais</CardTitle>
              <CardDescription>Descreva as principais características do seu imóvel</CardDescription>
            </CardHeader>
            <CardContent>
              <Textarea
                value={informacoes}
                onChange={(e) => setInformacoes(e.target.value)}
                placeholder="Ex: 3 quartos (1 suíte), sala ampla, varanda gourmet, armários embutidos..."
                rows={4}
              />
            </CardContent>
          </Card>

          {/* Photos */}
          <Card>
            <CardHeader className="pb-4">
              <CardTitle className="text-lg">Fotos do imóvel</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <RadioGroup
                value={enviarFotos}
                onValueChange={(value) => setEnviarFotos(value as "sim" | "nao")}
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="sim" id="fotos-sim" />
                  <Label htmlFor="fotos-sim" className="cursor-pointer">
                    Quero adicionar fotos agora
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="nao" id="fotos-nao" />
                  <Label htmlFor="fotos-nao" className="cursor-pointer">
                    Solicitar que a Etic tire as fotos
                  </Label>
                </div>
              </RadioGroup>
              
              {enviarFotos === "sim" && (
                <div className="space-y-4">
                  <p className="text-sm text-muted-foreground">
                    Adicione até 20 fotos do seu imóvel
                  </p>
                  
                  {/* Photo Grid */}
                  <div className="grid grid-cols-4 gap-2">
                    {fotos.map((foto, index) => (
                      <div key={index} className="relative aspect-square rounded-lg overflow-hidden bg-muted">
                        <img
                          src={URL.createObjectURL(foto)}
                          alt={`Foto ${index + 1}`}
                          className="w-full h-full object-cover"
                        />
                        <button
                          onClick={() => removeFoto(index)}
                          className="absolute top-1 right-1 w-5 h-5 bg-destructive text-destructive-foreground rounded-full flex items-center justify-center"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </div>
                    ))}
                    
                    {fotos.length < 20 && (
                      <label className="aspect-square rounded-lg border-2 border-dashed border-muted-foreground/30 flex flex-col items-center justify-center cursor-pointer hover:border-primary/50 transition-colors">
                        <ImagePlus className="h-6 w-6 text-muted-foreground" />
                        <span className="text-xs text-muted-foreground mt-1">Adicionar</span>
                        <input
                          type="file"
                          accept="image/*"
                          multiple
                          onChange={handleFotoUpload}
                          className="hidden"
                        />
                      </label>
                    )}
                  </div>
                  
                  <p className="text-xs text-muted-foreground">
                    {fotos.length}/20 fotos adicionadas
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Submit Button */}
          <div className="space-y-4 pb-8">
            <Button 
              size="lg" 
              className="w-full" 
              asChild
              disabled={!isFormValid()}
            >
              <a href={gerarMensagemWhatsApp()} target="_blank" rel="noopener noreferrer">
                <MessageCircle className="mr-2 h-5 w-5" />
                Enviar via WhatsApp
              </a>
            </Button>
            
            <p className="text-center text-sm text-muted-foreground">
              Prefere falar diretamente?{" "}
              <a 
                href="https://wa.me/5511970932722" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-primary hover:underline"
              >
                Clique aqui
              </a>
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}
