import { useLandlordDashboard } from "@/hooks/useLandlordDashboard";
import { useToast } from "@/hooks/use-toast";
// supabase import removed — all updates go through setRentalStepAndLog
import { ProposalCard } from "@/components/locador/dashboard/ProposalCard";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent } from "@/components/ui/card";
import { FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { createCounterProposal, logRentalEvent, setRentalStepAndLog } from "@/lib/proposalEvents";

export default function LocadorPropostas() {
  const { proposals, isLoading } = useLandlordDashboard();
  const { toast } = useToast();
  const [filter, setFilter] = useState<'all' | 'urgent' | 'pending'>('all');

  const handleAcceptProposal = async (proposalId: string) => {
    try {
      // Use setRentalStepAndLog to keep step at 2 but update proposal_status consistently
      const success = await setRentalStepAndLog({
        rentalId: proposalId,
        newStep: 2,
        reason: 'Proposta aceita pelo locador — aguardando documentação do locatário.',
        extraUpdate: {
          landlord_action_required: false,
          landlord_accepted: true,
          landlord_accepted_at: new Date().toISOString(),
          proposal_status: 'proposal_accepted',
        },
      });

      if (!success) throw new Error('Failed to update rental');

      // Log event with idempotency
      await logRentalEvent({
        rentalId: proposalId,
        eventType: 'proposal_accepted',
        description: 'Proposta aceita pelo locador.',
        idempotencyKey: `accept_${proposalId}`,
      });

      toast({
        title: "Proposta Aceita!",
        description: "O locatário será notificado automaticamente.",
      });
    } catch (error) {
      console.error('Error accepting proposal:', error);
      toast({
        title: "Erro ao aceitar proposta",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      });
    }
  };

  const handleRejectProposal = async (proposalId: string, reason: string, details?: string) => {
    try {
      const success = await setRentalStepAndLog({
        rentalId: proposalId,
        newStep: 2,
        reason: `Proposta rejeitada pelo locador. Motivo: ${reason}`,
        extraUpdate: {
          is_rejected: true,
          rejection_reason: reason,
          proposal_status: 'proposal_rejected',
        },
      });

      if (!success) throw new Error('Failed to update rental');

      await logRentalEvent({
        rentalId: proposalId,
        eventType: 'proposal_rejected',
        description: `Proposta rejeitada pelo locador. Motivo: ${reason}${details ? ` — ${details}` : ''}`,
        idempotencyKey: `reject_${proposalId}`,
      });

      toast({ title: "Proposta recusada", description: "O locatário foi notificado." });
    } catch (error) {
      console.error('Error rejecting proposal:', error);
      toast({ title: "Erro", description: "Tente novamente.", variant: "destructive" });
    }
  };

  const handleCounterProposal = async (proposalId: string, newValue: number) => {
    try {
      const success = await createCounterProposal({
        rentalId: proposalId,
        rentValue: newValue,
      });

      if (!success) throw new Error('Failed');

      toast({
        title: "Contraproposta enviada!",
        description: "O locatário será notificado para responder.",
      });
    } catch (error) {
      console.error('Error sending counter-proposal:', error);
      toast({ title: "Erro", description: "Não foi possível enviar a contraproposta.", variant: "destructive" });
    }
  };

  const filteredProposals = proposals.filter(p => {
    if (filter === 'urgent') return p.isUrgent && !p.respondedAt;
    if (filter === 'pending') return !p.respondedAt;
    return true;
  });

  const urgentCount = proposals.filter(p => p.isUrgent && !p.respondedAt).length;
  const pendingCount = proposals.filter(p => !p.respondedAt).length;

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="space-y-2">
          <Skeleton className="h-8 w-64" />
          <Skeleton className="h-4 w-96" />
        </div>
        <div className="flex gap-2">
          <Skeleton className="h-9 w-24" />
          <Skeleton className="h-9 w-24" />
          <Skeleton className="h-9 w-24" />
        </div>
        <Skeleton className="h-48" />
        <Skeleton className="h-48" />
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-5xl">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">
          Propostas de Locação
        </h1>
        <p className="text-muted-foreground">
          Acompanhe e responda às propostas dos seus imóveis
        </p>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-2 flex-wrap">
        <Button
          variant={filter === 'all' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setFilter('all')}
        >
          Todas ({proposals.length})
        </Button>
        <Button
          variant={filter === 'urgent' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setFilter('urgent')}
          className={cn(
            urgentCount > 0 && filter !== 'urgent' && "border-destructive/50 text-destructive"
          )}
        >
          Urgentes ({urgentCount})
        </Button>
        <Button
          variant={filter === 'pending' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setFilter('pending')}
        >
          Pendentes ({pendingCount})
        </Button>
      </div>

      {/* Proposals List */}
      {filteredProposals.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">
              {filter === 'all' 
                ? 'Nenhuma proposta encontrada.' 
                : `Nenhuma proposta ${filter === 'urgent' ? 'urgente' : 'pendente'}.`}
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {filteredProposals.map(proposal => (
            <ProposalCard 
              key={proposal.id} 
              proposal={proposal}
              onAccept={handleAcceptProposal}
              onReject={handleRejectProposal}
              onCounterProposal={handleCounterProposal}
            />
          ))}
        </div>
      )}
    </div>
  );
}
