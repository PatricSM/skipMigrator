import { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Eye, EyeOff, Mail, Lock, ArrowLeft, Loader2, Phone, User, CheckCircle2, Info } from "lucide-react";
import { ForgotPasswordDialog } from "@/components/auth/ForgotPasswordDialog";
import { maskPhone } from "@/lib/masks";

const LOCADOR_HOME_ROUTE = "/locador/home";

type ValidateResult = {
  authorized: boolean;
  reason?: string;
  error?: string;
  pending_approval?: boolean;
  is_network_error?: boolean;
  n8n_status?: number;
  n8n_body?: any;
};

const normalizePhoneDigits = (raw: string) => {
  let digits = (raw || "").replace(/\D/g, "");
  if (digits.startsWith("55") && digits.length >= 12) digits = digits.substring(2);
  return digits;
};

export default function LocadorAuth() {
  const navigate = useNavigate();
  const { login, register, logout, isLoading: authLoading, refreshProfile } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    const hashParams = new URLSearchParams(window.location.hash.substring(1));
    const type = hashParams.get("type");
    const accessToken = hashParams.get("access_token");

    if (type === "recovery" && accessToken) {
      navigate(`/reset-password${window.location.hash}`, { replace: true });
    }
  }, [navigate]);

  const [isRegistering, setIsRegistering] = useState(false);
  const [loading, setLoading] = useState(false);
  const [validating, setValidating] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");

  /**
   * ✅ SEMPRE envia body { user_id, telefone, email, full_name } para Edge Function
   */
  const validateLandlord = async (args: {
    userId: string;
    phoneDigits: string;
    email?: string;
    fullName?: string;
    showSyncToast?: boolean;
  }): Promise<ValidateResult> => {
    const { userId, phoneDigits, email = "", fullName = "" } = args;
    const showSyncToast = Boolean(args.showSyncToast);

    try {
      const telefone = normalizePhoneDigits(phoneDigits);

      if (!userId) {
        return { authorized: false, error: "Usuário não autenticado (sem userId).", is_network_error: false };
      }

      if (!telefone || telefone.length < 10 || telefone.length > 11) {
        return {
          authorized: false,
          error: "Telefone inválido para validação (use DDD + número).",
          is_network_error: false,
        };
      }

      if (showSyncToast) {
        toast({
          title: "Sincronizando imóveis...",
          description: "Verificando seus imóveis no VistaSoft.",
        });
      }

      console.log("validate-landlord payload:", { user_id: userId, telefone, email, full_name: fullName });

      const { data, error } = await supabase.functions.invoke("validate-landlord", {
        body: {
          user_id: userId,
          telefone,
          email,
          full_name: fullName,
        },
      });

      console.log("validate-landlord response:", { data, error });

      if (error) {
        const errorMessage = (error as any)?.message?.toLowerCase?.() || "";
        const contextMessage = (error as any)?.context?.message?.toLowerCase?.() || "";
        const errorName = (error as any)?.name?.toLowerCase?.() || "";

        const isNetworkError =
          errorMessage.includes("failed to fetch") ||
          errorMessage.includes("failed to send") ||
          errorMessage.includes("network") ||
          contextMessage.includes("failed to fetch") ||
          errorName.includes("fetcherror") ||
          errorName.includes("typeerror");

        return {
          authorized: false,
          error: isNetworkError
            ? "Não foi possível conectar ao servidor. Verifique sua conexão e se há bloqueadores de anúncios ativos."
            : "Erro ao validar acesso. Tente novamente.",
          is_network_error: isNetworkError,
        };
      }

      return (data || { authorized: false, error: "Resposta vazia da validação" }) as ValidateResult;
    } catch (err) {
      console.error("Validation error:", err);
      return {
        authorized: false,
        error: "Erro inesperado ao validar acesso.",
        is_network_error: true,
      };
    } finally {
      setValidating(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!email || !password) {
      toast({
        title: "Erro",
        description: "Preencha todos os campos",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);

    const { error } = await login(email, password);

    if (error) {
      setLoading(false);

      let title = "Erro ao entrar";
      let message = "Email ou senha incorretos";

      if (error.message?.includes("Email not confirmed")) {
        title = "Email não confirmado";
        message = "Verifique sua caixa de entrada e clique no link de confirmação enviado para seu email.";
      } else if (error.message?.includes("security purposes") || error.message?.includes("rate limit")) {
        title = "Aguarde um momento";
        message = "Por segurança, aguarde alguns segundos antes de tentar novamente.";
      } else if (error.message?.includes("Invalid login credentials")) {
        message = "Email ou senha incorretos. Verifique seus dados e tente novamente.";
      }

      toast({ title, description: message, variant: "destructive" });
      return;
    }

    // ✅ userId após login
    const { data: userData } = await supabase.auth.getUser();
    const userId = userData?.user?.id;

    if (!userId) {
      setLoading(false);
      toast({
        title: "Erro",
        description: "Não foi possível obter seu usuário após login. Tente novamente.",
        variant: "destructive",
      });
      return;
    }

    // ✅ buscar telefone E full_name do profile
    const { data: profileData, error: profileErr } = await supabase
      .from("profiles")
      .select("phone_e164, phone, full_name") // ✅ adicionado full_name
      .eq("id", userId)
      .single();

    if (profileErr) {
      setLoading(false);
      toast({
        title: "Erro",
        description: "Não foi possível ler seu perfil. Tente novamente.",
        variant: "destructive",
      });
      return;
    }

    const phoneDigitsFromProfile = normalizePhoneDigits(profileData?.phone_e164 || profileData?.phone || "");

    if (!phoneDigitsFromProfile) {
      setLoading(false);
      toast({
        title: "Telefone não encontrado",
        description: "Seu telefone não está cadastrado no perfil. Cadastre novamente ou fale com a administradora.",
        variant: "destructive",
      });
      await logout();
      return;
    }

    // ✅ chama Edge Function com nome e email
    setValidating(true);
    const validation = await validateLandlord({
      userId,
      phoneDigits: phoneDigitsFromProfile,
      email, // ✅ do estado do form
      fullName: profileData?.full_name || "", // ✅ do profile
      showSyncToast: true,
    });

    if (!validation.authorized) {
      setLoading(false);

      // ✅ Não deslogar em casos de aprovação pendente (fluxo normal) ou falha de rede (tentativa novamente)
      if (validation.pending_approval) {
        toast({
          title: "Aguardando aprovação",
          description: validation.error || "Seu acesso está em análise. Entraremos em contato em breve.",
        });
        return;
      }

      if (validation.is_network_error) {
        toast({
          title: "Erro de conexão",
          description: validation.error || "Não foi possível validar agora. Tente novamente em alguns instantes.",
        });
        return;
      }

      // Se não autorizou (negação real), desloga e mostra motivo
      await logout();
      toast({
        title: "Acesso não liberado",
        description: validation.error || "Seu acesso ainda não foi liberado pelo administrador.",
        variant: "destructive",
      });
      return;
    }

    await refreshProfile();

    setLoading(false);
    toast({
      title: "Acesso autorizado",
      description: "Bem-vindo!",
    });

    navigate(LOCADOR_HOME_ROUTE, { replace: true });
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!email || !password || !fullName || !phone) {
      toast({
        title: "Erro",
        description: "Preencha todos os campos",
        variant: "destructive",
      });
      return;
    }

    // Strong password validation
    try {
      const { strongPasswordSchema } = await import('@/lib/passwordPolicy');
      strongPasswordSchema.parse(password);
    } catch (err: any) {
      const message = err?.errors?.[0]?.message || 'Senha não atende aos requisitos de segurança';
      toast({
        title: "Senha insegura",
        description: message,
        variant: "destructive",
      });
      return;
    }

    const phoneDigits = normalizePhoneDigits(phone);
    if (phoneDigits.length < 10 || phoneDigits.length > 11) {
      toast({
        title: "Erro",
        description: "Telefone inválido. Use DDD + número (10 ou 11 dígitos).",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);

    // registra com telefone limpo
    const { error } = await register(email, password, fullName, {
      phone: phoneDigits,
      userType: "locador",
    });

    if (error) {
      setLoading(false);

      let title = "Erro ao criar conta";
      let message = error.message || "Não foi possível criar sua conta. Tente novamente.";

      if (
        error.message?.includes("security purposes") ||
        error.message?.includes("rate limit") ||
        error.message?.includes("For security purposes")
      ) {
        title = "Aguarde um momento";
        message =
          "Por segurança, aguarde alguns segundos antes de tentar novamente. Se você já criou uma conta, verifique seu email.";
      } else if (
        error.message?.includes("User already registered") ||
        error.message?.includes("already been registered")
      ) {
        title = "Email já cadastrado";
        message = "Este email já está cadastrado. Clique em 'Já tem uma conta? Entrar' para fazer login.";
      } else if (
        error.message?.toLowerCase().includes("weak_password") ||
        error.message?.includes("Password is known to be weak") ||
        (error.message?.includes("password") && error.message?.includes("weak"))
      ) {
        title = "Senha muito fraca";
        message = "Use uma senha mais forte com no mínimo 8 caracteres, incluindo letras e números.";
      } else if (error.message?.includes("invalid") && error.message?.includes("email")) {
        title = "Email inválido";
        message = "O email informado não é válido. Verifique e tente novamente.";
      }

      toast({ title, description: message, variant: "destructive" });
      return;
    }

    // como há confirmação por email, não garantimos sessão aqui
    setLoading(false);
    toast({
      title: "Conta criada",
      description: "Verifique seu email para confirmar a conta. Depois, faça login para validar o acesso.",
    });
    setIsRegistering(false);
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/30">
      <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="h-4 w-4" />
            Voltar ao início
          </Link>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 flex flex-col items-center gap-6">
        <div className="w-full max-w-md">
          <div className="text-center mb-6">
            <Link to="/" className="inline-flex items-center gap-2">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-xl">E</span>
              </div>
              <span className="text-2xl font-bold">Área do Proprietário</span>
            </Link>
          </div>

          <Card className="border-primary/20 bg-primary/5 mb-6">
            <CardContent className="pt-4">
              <div className="flex items-start gap-3">
                <Info className="h-5 w-5 text-primary mt-0.5 shrink-0" />
                <div className="space-y-2 text-sm">
                  <p className="font-medium text-foreground">Para acessar, você precisa:</p>
                  <ul className="space-y-1.5 text-muted-foreground">
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="h-4 w-4 text-primary" />
                      Ter recebido um convite do administrador
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-xs font-medium text-muted-foreground">OU</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="h-4 w-4 text-primary" />
                      Ser proprietário de imóvel em nossa base
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-xs font-medium text-muted-foreground">OU</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="h-4 w-4 text-primary" />
                      Ter telefone cadastrado no CRM da Etic
                    </li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-xl">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">{isRegistering ? "Criar Conta" : "Entrar"}</CardTitle>
              <CardDescription>
                {isRegistering ? "Cadastre-se para acessar a área do proprietário" : "Acesse sua área de proprietário"}
              </CardDescription>
            </CardHeader>

            <CardContent>
              <form onSubmit={isRegistering ? handleRegister : handleLogin} className="space-y-4">
                {isRegistering && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="fullName">Nome Completo</Label>
                      <div className="relative">
                        <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="fullName"
                          type="text"
                          placeholder="Seu nome completo"
                          value={fullName}
                          onChange={(e) => setFullName(e.target.value)}
                          className="pl-10"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="phone">Telefone</Label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="phone"
                          type="tel"
                          placeholder="(11) 99999-9999"
                          value={phone}
                          onChange={(e) => setPhone(maskPhone(e.target.value))}
                          className="pl-10"
                        />
                      </div>
                      <p className="text-xs text-muted-foreground">
                        O telefone será usado para validar seu vínculo como proprietário
                      </p>
                    </div>
                  </>
                )}

                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="seu@email.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password">Senha</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      placeholder={isRegistering ? "Mínimo 8 caracteres" : "••••••••"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="pl-10 pr-10"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>

                <Button type="submit" className="w-full" size="lg" disabled={loading || validating}>
                  {loading || validating ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      {validating ? "Verificando autorização..." : isRegistering ? "Criando conta..." : "Entrando..."}
                    </>
                  ) : isRegistering ? (
                    "Criar Conta"
                  ) : (
                    "Entrar"
                  )}
                </Button>
              </form>

              <div className="mt-4 text-center">
                <button
                  type="button"
                  onClick={() => {
                    setIsRegistering(!isRegistering);
                    setPassword("");
                  }}
                  className="text-sm text-primary hover:underline"
                >
                  {isRegistering ? "Já tem uma conta? Entrar" : "Não tem conta? Criar conta"}
                </button>
              </div>
            </CardContent>
          </Card>

          {!isRegistering && (
            <div className="text-center mt-4">
              <ForgotPasswordDialog />
            </div>
          )}

          <p className="text-center text-sm text-muted-foreground mt-4">
            Acesso exclusivo para proprietários autorizados.
            <br />
            <Link to="/auth" className="underline hover:text-foreground">
              É locatário? Acesse aqui
            </Link>
          </p>
        </div>
      </main>
    </div>
  );
}
