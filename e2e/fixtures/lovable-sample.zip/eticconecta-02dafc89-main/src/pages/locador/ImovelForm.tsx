import { useParams, Link } from "react-router-dom";
import { ChevronLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function ImovelForm() {
  const { id } = useParams<{ id: string }>();

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" asChild>
          <Link to="/locador/imoveis">
            <ChevronLeft className="h-4 w-4" />
          </Link>
        </Button>
        <div>
          <h1 className="text-3xl font-bold">
            {id === "novo" ? "Novo Imóvel" : "Editar Imóvel"}
          </h1>
          <p className="text-muted-foreground mt-1">
            {id === "novo" ? "Cadastre um novo imóvel" : "Edite as informações do imóvel"}
          </p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Informações do Imóvel</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            Formulário será implementado aqui.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
