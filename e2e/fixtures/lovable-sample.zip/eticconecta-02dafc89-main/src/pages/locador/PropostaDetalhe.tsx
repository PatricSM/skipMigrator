import { useParams, Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { ChevronLeft, User, Building, FileCheck, ClipboardCheck, Upload, Check, X, Loader2, Download, Eye, AlertTriangle, Pen, Calendar, Key } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { RentalJourneyStepper } from "@/components/locador/dashboard/RentalJourneyStepper";
import { setRentalStepAndLog, logRentalEvent, EVENT_LABELS, emitContract, sendContractForSignature, signContract, fetchContract, scheduleInspection, signInspectionReport, deliverKeys, fetchInspection, type ContractRow, type InspectionRow } from "@/lib/proposalEvents";
import { DOCUMENT_TYPES, type LandlordDocumentType } from "@/types/landlord";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";

interface RentalData {
  id: string;
  protocol: string;
  property_code: string;
  property_address: string;
  rent_value: number | null;
  condo_fee: number | null;
  iptu: number | null;
  current_step: number;
  proposal_status: string | null;
  is_rejected: boolean;
  landlord_property_id: string | null;
  documents_finalized_at: string | null;
  tenant_status: string | null;
  step_status: string | null;
  user_id: string;
}

interface TenantProfile {
  full_name: string | null;
  email: string | null;
  phone: string | null;
  monthly_income: number | null;
  profession: string | null;
  marital_status: string | null;
  birth_date: string | null;
}

interface DocRow {
  id: string;
  document_type: string;
  file_name: string;
  file_path: string;
  status: string;
  created_at: string;
}

interface EventRow {
  id: string;
  event_type: string;
  description: string;
  created_at: string | null;
}

const FICHA_REJECTION_REASONS = [
  'Renda insuficiente',
  'Documentação incompleta',
  'Restrição cadastral',
  'Informações inconsistentes',
  'Outro motivo',
] as const;

const LANDLORD_DOC_TYPES: { key: LandlordDocumentType; label: string; required: boolean }[] = [
  { key: 'documento_pessoal', label: DOCUMENT_TYPES.documento_pessoal, required: true },
  { key: 'comprovante_residencia', label: DOCUMENT_TYPES.comprovante_residencia, required: true },
  { key: 'comprovante_titularidade', label: DOCUMENT_TYPES.comprovante_titularidade, required: true },
  { key: 'boleto_iptu', label: DOCUMENT_TYPES.boleto_iptu, required: true },
  { key: 'boleto_condominio', label: DOCUMENT_TYPES.boleto_condominio, required: false },
  { key: 'contas_consumo', label: DOCUMENT_TYPES.contas_consumo, required: false },
];

function formatCurrency(value: number | null): string {
  if (value === null || value === undefined) return "-";
  return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(value);
}

export default function PropostaDetalhe() {
  const { protocolo } = useParams<{ protocolo: string }>();
  const { user } = useAuth();
  const { toast } = useToast();

  const [rental, setRental] = useState<RentalData | null>(null);
  const [tenant, setTenant] = useState<TenantProfile | null>(null);
  const [tenantDocs, setTenantDocs] = useState<DocRow[]>([]);
  const [landlordDocs, setLandlordDocs] = useState<DocRow[]>([]);
  const [events, setEvents] = useState<EventRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);

  // Reject modal
  const [rejectDialogOpen, setRejectDialogOpen] = useState(false);
  const [rejectReason, setRejectReason] = useState("");
  const [rejectDetails, setRejectDetails] = useState("");

  // Landlord doc upload
  const [uploading, setUploading] = useState<string | null>(null);

  // Contract state
  const [contract, setContract] = useState<ContractRow | null>(null);

  // Inspection state
  const [inspection, setInspection] = useState<InspectionRow | null>(null);
  const [inspectionDate, setInspectionDate] = useState("");
  const [inspectionTime, setInspectionTime] = useState("");
  const [inspectionNotes, setInspectionNotes] = useState("");

  // Fetch rental by protocol (which is actually rentalId from route)
  useEffect(() => {
    if (!protocolo || !user) return;
    loadData();
  }, [protocolo, user]);

  const loadData = async () => {
    setLoading(true);
    try {
      // Try by protocol first, then by ID
      let rentalData: RentalData | null = null;

      const { data: byProtocol } = await supabase
        .from('rentals')
        .select('id, protocol, property_code, property_address, rent_value, condo_fee, iptu, current_step, proposal_status, is_rejected, landlord_property_id, documents_finalized_at, tenant_status, step_status, user_id')
        .eq('protocol', protocolo!)
        .maybeSingle();

      if (byProtocol) {
        rentalData = byProtocol as RentalData;
      } else {
        const { data: byId } = await supabase
          .from('rentals')
          .select('id, protocol, property_code, property_address, rent_value, condo_fee, iptu, current_step, proposal_status, is_rejected, landlord_property_id, documents_finalized_at, tenant_status, step_status, user_id')
          .eq('id', protocolo!)
          .maybeSingle();
        if (byId) rentalData = byId as RentalData;
      }

      if (!rentalData) {
        setLoading(false);
        return;
      }

      setRental(rentalData);

      // Fetch tenant profile, documents, landlord documents, events, contract in parallel
      const [tenantRes, tenantDocsRes, landlordDocsRes, eventsRes, contractData, inspectionData] = await Promise.all([
        supabase.from('profiles').select('full_name, email, phone, monthly_income, profession, marital_status, birth_date').eq('id', rentalData.user_id).maybeSingle(),
        supabase.from('documents').select('id, document_type, file_name, file_path, status, created_at').eq('rental_id', rentalData.id).order('created_at', { ascending: false }),
        supabase.from('landlord_documents').select('id, document_type, file_name, file_path, status, created_at').eq('rental_id', rentalData.id).order('created_at', { ascending: false }),
        supabase.from('rental_events').select('id, event_type, description, created_at').eq('rental_id', rentalData.id).order('created_at', { ascending: false }),
        fetchContract(rentalData.id),
        fetchInspection(rentalData.id),
      ]);

      setTenant(tenantRes.data as TenantProfile | null);
      setTenantDocs((tenantDocsRes.data || []) as DocRow[]);
      setLandlordDocs((landlordDocsRes.data || []) as DocRow[]);
      setEvents((eventsRes.data || []) as EventRow[]);
      setContract(contractData);
      setInspection(inspectionData);
    } catch (err) {
      console.error('[PROPOSTA_DETALHE] load error:', err);
    } finally {
      setLoading(false);
    }
  };

  // ── Approve Ficha (Step 4 → 5) ──
  const handleApproveFicha = async () => {
    if (!rental || actionLoading) return;
    setActionLoading(true);
    try {
      // Log ficha_analysis_completed
      await logRentalEvent({
        rentalId: rental.id,
        eventType: 'ficha_analysis_completed',
        description: 'Análise da ficha concluída.',
        idempotencyKey: `ficha_completed_${rental.id}`,
      });

      // Log ficha_approved
      await logRentalEvent({
        rentalId: rental.id,
        eventType: 'ficha_approved',
        description: 'Ficha do locatário aprovada pelo locador.',
        idempotencyKey: `ficha_approved_${rental.id}`,
      });

      // Advance to step 5
      const success = await setRentalStepAndLog({
        rentalId: rental.id,
        newStep: 5,
        reason: 'Ficha aprovada — aguardando documentos do locador.',
        extraUpdate: {
          tenant_status: 'approved',
        },
      });

      if (!success) throw new Error('Failed to advance step');

      toast({ title: "Ficha aprovada!", description: "Agora envie os documentos do imóvel para continuar." });
      await loadData();
    } catch (err) {
      console.error('[FICHA] Approve error:', err);
      toast({ title: "Erro", description: "Não foi possível aprovar a ficha.", variant: "destructive" });
    } finally {
      setActionLoading(false);
    }
  };

  // ── Reject Ficha ──
  const handleRejectFicha = async () => {
    if (!rental || !rejectReason || actionLoading) return;
    setActionLoading(true);
    try {
      await logRentalEvent({
        rentalId: rental.id,
        eventType: 'ficha_analysis_completed',
        description: 'Análise da ficha concluída.',
        idempotencyKey: `ficha_completed_${rental.id}`,
      });

      await logRentalEvent({
        rentalId: rental.id,
        eventType: 'ficha_rejected',
        description: `Ficha reprovada. Motivo: ${rejectReason}${rejectDetails ? ` — ${rejectDetails}` : ''}`,
        idempotencyKey: `ficha_rejected_${rental.id}`,
        metadata: { reason: rejectReason, details: rejectDetails },
      });

      const success = await setRentalStepAndLog({
        rentalId: rental.id,
        newStep: rental.current_step,
        reason: `Ficha reprovada. Motivo: ${rejectReason}`,
        extraUpdate: {
          is_rejected: true,
          rejection_reason: rejectReason,
          tenant_status: 'rejected',
        },
      });

      if (!success) throw new Error('Failed');

      toast({ title: "Ficha reprovada", description: "O locatário será notificado." });
      setRejectDialogOpen(false);
      setRejectReason("");
      setRejectDetails("");
      await loadData();
    } catch (err) {
      console.error('[FICHA] Reject error:', err);
      toast({ title: "Erro", description: "Não foi possível reprovar a ficha.", variant: "destructive" });
    } finally {
      setActionLoading(false);
    }
  };

  // ── Upload landlord document ──
  const handleLandlordDocUpload = async (docType: string, file: File) => {
    if (!rental || !user) return;
    setUploading(docType);
    try {
      const ext = file.name.split('.').pop();
      const filePath = `landlord/${rental.id}/${docType}/${crypto.randomUUID()}.${ext}`;

      const { error: uploadErr } = await supabase.storage
        .from('landlord-documents')
        .upload(filePath, file);

      if (uploadErr) throw uploadErr;

      const { error: dbErr } = await supabase
        .from('landlord_documents')
        .insert({
          landlord_id: user.id,
          rental_id: rental.id,
          document_type: docType,
          file_name: file.name,
          file_path: filePath,
          file_type: file.type,
        });

      if (dbErr) throw dbErr;

      toast({ title: "Documento enviado!", description: file.name });
      await loadData();
    } catch (err) {
      console.error('[LANDLORD_DOC] Upload error:', err);
      toast({ title: "Erro no upload", description: "Tente novamente.", variant: "destructive" });
    } finally {
      setUploading(null);
    }
  };

  // ── Finalize landlord documents (Step 5 → 6) ──
  const handleFinalizeLandlordDocs = async () => {
    if (!rental || actionLoading) return;
    setActionLoading(true);
    try {
      await logRentalEvent({
        rentalId: rental.id,
        eventType: 'landlord_documents_sent',
        description: 'Documentos do locador enviados e finalizados.',
        idempotencyKey: `landlord_docs_sent_${rental.id}`,
      });

      const success = await setRentalStepAndLog({
        rentalId: rental.id,
        newStep: 6,
        reason: 'Documentos do locador enviados — aguardando emissão do contrato.',
        extraUpdate: {
          landlord_progress: 100,
        },
      });

      if (!success) throw new Error('Failed');

      toast({ title: "Documentos finalizados!", description: "O contrato será emitido em até 24 horas." });
      await loadData();
    } catch (err) {
      console.error('[LANDLORD_DOCS] Finalize error:', err);
      toast({ title: "Erro", description: "Não foi possível finalizar.", variant: "destructive" });
    } finally {
      setActionLoading(false);
    }
  };

  // Required landlord docs uploaded check
  const requiredLandlordDocTypes = LANDLORD_DOC_TYPES.filter(d => d.required).map(d => d.key);
  const allRequiredLandlordDocsUploaded = requiredLandlordDocTypes.every(
    type => landlordDocs.some(d => d.document_type === type)
  );

  // ── Emit Contract (Step 6) ──
  const handleEmitContract = async () => {
    if (!rental || actionLoading) return;
    setActionLoading(true);
    try {
      const result = await emitContract({
        rentalId: rental.id,
        generatedBy: user?.id,
      });
      if (!result) throw new Error('Failed to emit contract');
      toast({ title: "Contrato emitido!", description: "O contrato está disponível para revisão antes do envio para assinatura." });
      await loadData();
    } catch (err) {
      console.error('[CONTRACT] Emit error:', err);
      toast({ title: "Erro", description: "Não foi possível emitir o contrato.", variant: "destructive" });
    } finally {
      setActionLoading(false);
    }
  };

  // ── Send for Signature (Step 6 → 7) ──
  const handleSendForSignature = async () => {
    if (!rental || actionLoading) return;
    setActionLoading(true);
    try {
      const success = await sendContractForSignature(rental.id);
      if (!success) throw new Error('Failed');
      toast({ title: "Contrato enviado para assinatura!", description: "As partes receberão o link para assinar digitalmente." });
      await loadData();
    } catch (err) {
      console.error('[CONTRACT] Send for signature error:', err);
      toast({ title: "Erro", description: "Não foi possível enviar para assinatura.", variant: "destructive" });
    } finally {
      setActionLoading(false);
    }
  };

  // ── Landlord Signs Contract ──
  const handleLandlordSign = async () => {
    if (!rental || actionLoading) return;
    setActionLoading(true);
    try {
      const success = await signContract({ rentalId: rental.id, signerRole: 'landlord' });
      if (!success) throw new Error('Failed');
      toast({ title: "Contrato assinado!", description: "Sua assinatura foi registrada." });
      await loadData();
    } catch (err) {
      console.error('[CONTRACT] Landlord sign error:', err);
      toast({ title: "Erro", description: "Não foi possível registrar a assinatura.", variant: "destructive" });
    } finally {
      setActionLoading(false);
    }
  };

  const isStep4 = rental?.current_step === 4 && !rental?.is_rejected;
  const isStep5 = rental?.current_step === 5 && !rental?.is_rejected;
  const isStep6 = rental?.current_step === 6 && !rental?.is_rejected;
  const isStep7 = rental?.current_step === 7 && !rental?.is_rejected;
  const isStep8 = rental?.current_step === 8 && !rental?.is_rejected;
  const isStep9 = rental?.current_step === 9 && !rental?.is_rejected;
  const isStep10 = rental?.current_step === 10 && !rental?.is_rejected;

  if (loading) {
    return (
      <div className="space-y-6 max-w-3xl">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-48" />
        <Skeleton className="h-48" />
      </div>
    );
  }

  if (!rental) {
    return (
      <div className="space-y-6 max-w-3xl">
        <Button variant="ghost" size="icon" asChild>
          <Link to="/locador/propostas"><ChevronLeft className="h-4 w-4" /></Link>
        </Button>
        <Card>
          <CardContent className="py-12 text-center">
            <p className="text-muted-foreground">Proposta não encontrada.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-3xl">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" asChild>
          <Link to="/locador/propostas"><ChevronLeft className="h-4 w-4" /></Link>
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-foreground">
            Proposta {rental.protocol}
          </h1>
          <p className="text-muted-foreground text-sm">
            {rental.property_address} · <Badge variant="outline" className="font-mono text-xs">{rental.property_code}</Badge>
          </p>
        </div>
      </div>

      {/* Journey Stepper */}
      <RentalJourneyStepper currentStep={rental.current_step} />

      {/* Property Details */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Building className="h-4 w-4" />
            Detalhes do Imóvel
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4 text-sm">
            <div>
              <p className="text-muted-foreground">Aluguel</p>
              <p className="font-semibold">{formatCurrency(rental.rent_value)}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Condomínio</p>
              <p className="font-semibold">{formatCurrency(rental.condo_fee)}</p>
            </div>
            <div>
              <p className="text-muted-foreground">IPTU</p>
              <p className="font-semibold">{formatCurrency(rental.iptu)}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tenant Info */}
      {tenant && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <User className="h-4 w-4" />
              Dados do Locatário
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div>
                <p className="text-muted-foreground">Nome</p>
                <p className="font-medium">{tenant.full_name || '-'}</p>
              </div>
              <div>
                <p className="text-muted-foreground">E-mail</p>
                <p className="font-medium">{tenant.email || '-'}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Telefone</p>
                <p className="font-medium">{tenant.phone || '-'}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Renda</p>
                <p className="font-medium">{formatCurrency(tenant.monthly_income)}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Profissão</p>
                <p className="font-medium">{tenant.profession || '-'}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Estado Civil</p>
                <p className="font-medium">{tenant.marital_status || '-'}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Tenant Documents */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <FileCheck className="h-4 w-4" />
            Documentos do Locatário ({tenantDocs.length})
          </CardTitle>
          {rental.documents_finalized_at && (
            <Badge className="w-fit bg-sla-ok/20 text-sla-ok border-sla-ok/30">
              Documentação finalizada
            </Badge>
          )}
        </CardHeader>
        <CardContent>
          {tenantDocs.length === 0 ? (
            <p className="text-muted-foreground text-sm">Nenhum documento enviado pelo locatário.</p>
          ) : (
            <div className="space-y-2">
              {tenantDocs.map(doc => (
                <div key={doc.id} className="flex items-center justify-between p-2 bg-muted/50 rounded-lg">
                  <div className="flex items-center gap-2 min-w-0">
                    <FileCheck className="h-4 w-4 text-muted-foreground shrink-0" />
                    <div className="min-w-0">
                      <p className="text-sm font-medium truncate">{doc.file_name}</p>
                      <p className="text-xs text-muted-foreground">{doc.document_type}</p>
                    </div>
                  </div>
                  <Badge variant={doc.status === 'pending' ? 'secondary' : doc.status === 'approved' ? 'default' : 'destructive'} className="text-xs shrink-0">
                    {doc.status === 'pending' ? 'Pendente' : doc.status === 'approved' ? 'Aprovado' : 'Rejeitado'}
                  </Badge>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* ── STEP 4: Ficha Analysis Actions ── */}
      {isStep4 && (
        <Card className="border-primary/30 bg-primary/5">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <ClipboardCheck className="h-4 w-4" />
              Análise da Ficha — Etapa 4
            </CardTitle>
            <CardDescription>
              Revise os dados e documentos do locatário acima e tome sua decisão.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-3">
              {/* Approve */}
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button className="bg-sla-ok hover:bg-sla-ok/90 text-white gap-2" disabled={actionLoading}>
                    <Check className="h-4 w-4" />
                    {actionLoading ? 'Processando...' : 'Aprovar Ficha'}
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Confirmar aprovação da ficha</AlertDialogTitle>
                    <AlertDialogDescription>
                      Ao aprovar, o processo avança para a Etapa 5 (Documentos do Locador). Você precisará enviar os documentos do imóvel.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancelar</AlertDialogCancel>
                    <AlertDialogAction onClick={handleApproveFicha} className="bg-sla-ok hover:bg-sla-ok/90">
                      Confirmar Aprovação
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>

              {/* Reject */}
              <Dialog open={rejectDialogOpen} onOpenChange={setRejectDialogOpen}>
                <Button variant="destructive" className="gap-2" onClick={() => setRejectDialogOpen(true)} disabled={actionLoading}>
                  <X className="h-4 w-4" />
                  Reprovar Ficha
                </Button>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Motivo da Reprovação</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <RadioGroup value={rejectReason} onValueChange={setRejectReason}>
                      {FICHA_REJECTION_REASONS.map(reason => (
                        <div key={reason} className="flex items-center space-x-2">
                          <RadioGroupItem value={reason} id={`ficha-${reason}`} />
                          <Label htmlFor={`ficha-${reason}`}>{reason}</Label>
                        </div>
                      ))}
                    </RadioGroup>
                    <div className="space-y-2">
                      <Label>Detalhes (opcional)</Label>
                      <Textarea
                        placeholder="Informações adicionais..."
                        value={rejectDetails}
                        onChange={e => setRejectDetails(e.target.value)}
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setRejectDialogOpen(false)}>Cancelar</Button>
                    <Button variant="destructive" onClick={handleRejectFicha} disabled={!rejectReason || actionLoading}>
                      {actionLoading ? 'Processando...' : 'Confirmar Reprovação'}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Rejection notice */}
      {rental.is_rejected && (
        <Card className="border-destructive/30 bg-destructive/5">
          <CardContent className="py-4">
            <div className="flex items-center gap-2 text-destructive">
              <AlertTriangle className="h-4 w-4" />
              <p className="font-medium text-sm">Ficha reprovada</p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* ── STEP 5: Landlord Document Upload ── */}
      {isStep5 && (
        <Card className="border-primary/30 bg-primary/5">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Upload className="h-4 w-4" />
              Documentos do Imóvel — Etapa 5
            </CardTitle>
            <CardDescription>
              Envie os documentos necessários do imóvel para continuar o processo.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {LANDLORD_DOC_TYPES.map(docType => {
              const uploaded = landlordDocs.filter(d => d.document_type === docType.key);
              const hasFile = uploaded.length > 0;

              return (
                <div key={docType.key} className="flex items-center justify-between p-3 border rounded-lg bg-background">
                  <div className="flex items-center gap-3 min-w-0">
                    {hasFile ? (
                      <Check className="h-4 w-4 text-sla-ok shrink-0" />
                    ) : (
                      <Upload className="h-4 w-4 text-muted-foreground shrink-0" />
                    )}
                    <div className="min-w-0">
                      <p className="text-sm font-medium">{docType.label}</p>
                      {hasFile && (
                        <p className="text-xs text-muted-foreground truncate">{uploaded[0].file_name}</p>
                      )}
                      {docType.required && !hasFile && (
                        <p className="text-xs text-destructive">Obrigatório</p>
                      )}
                    </div>
                  </div>
                  <div>
                    {hasFile ? (
                      <Badge className="bg-sla-ok/20 text-sla-ok border-sla-ok/30 text-xs">Enviado</Badge>
                    ) : (
                      <label className="cursor-pointer">
                        <input
                          type="file"
                          className="hidden"
                          accept=".pdf,.jpg,.jpeg,.png,.webp"
                          onChange={e => {
                            const file = e.target.files?.[0];
                            if (file) handleLandlordDocUpload(docType.key, file);
                            e.target.value = '';
                          }}
                        />
                        <Button variant="outline" size="sm" asChild disabled={uploading === docType.key}>
                          <span>
                            {uploading === docType.key ? (
                              <Loader2 className="h-3 w-3 animate-spin" />
                            ) : (
                              'Enviar'
                            )}
                          </span>
                        </Button>
                      </label>
                    )}
                  </div>
                </div>
              );
            })}

            {/* Finalize button */}
            <div className="pt-2 border-t">
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button
                    className="w-full bg-sla-ok hover:bg-sla-ok/90 text-white gap-2"
                    disabled={!allRequiredLandlordDocsUploaded || actionLoading}
                  >
                    <FileCheck className="h-4 w-4" />
                    {actionLoading ? 'Processando...' : 'Finalizar Envio de Documentos'}
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Finalizar envio de documentos</AlertDialogTitle>
                    <AlertDialogDescription>
                      Ao confirmar, o processo avança para a Etapa 6 (Emissão do Contrato). Certifique-se de que todos os documentos estão corretos.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancelar</AlertDialogCancel>
                    <AlertDialogAction onClick={handleFinalizeLandlordDocs} className="bg-sla-ok hover:bg-sla-ok/90">
                      Confirmar Finalização
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
              {!allRequiredLandlordDocsUploaded && (
                <p className="text-xs text-muted-foreground mt-2 text-center">
                  Envie todos os documentos obrigatórios para habilitar a finalização.
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Landlord docs summary (when not in step 5) */}
      {!isStep5 && landlordDocs.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Building className="h-4 w-4" />
              Documentos do Locador ({landlordDocs.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {landlordDocs.map(doc => (
                <div key={doc.id} className="flex items-center justify-between p-2 bg-muted/50 rounded-lg">
                  <div className="flex items-center gap-2 min-w-0">
                    <FileCheck className="h-4 w-4 text-muted-foreground shrink-0" />
                    <div className="min-w-0">
                      <p className="text-sm font-medium truncate">{doc.file_name}</p>
                      <p className="text-xs text-muted-foreground">{DOCUMENT_TYPES[doc.document_type as LandlordDocumentType] || doc.document_type}</p>
                    </div>
                  </div>
                  <Badge variant="secondary" className="text-xs shrink-0">Enviado</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* ── STEP 6: Contract Emission ── */}
      {isStep6 && (
        <Card className="border-primary/30 bg-primary/5">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <FileCheck className="h-4 w-4" />
              Emissão do Contrato — Etapa 6
            </CardTitle>
            <CardDescription>
              {contract ? 'O contrato foi gerado. Revise e envie para assinatura.' : 'Gere o contrato de locação baseado na proposta aceita.'}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {contract ? (
              <>
                <div className="p-3 bg-background rounded-lg border space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Status:</span>
                    <Badge variant={contract.status === 'generated' ? 'secondary' : 'default'}>
                      {contract.status === 'generated' ? 'Gerado' : contract.status === 'pending_signature' ? 'Aguardando assinatura' : contract.status === 'signed' ? 'Assinado' : contract.status}
                    </Badge>
                  </div>
                  {contract.preview_url && (
                    <Button variant="outline" size="sm" className="w-full gap-2" onClick={() => window.open(contract.preview_url!, '_blank')}>
                      <Eye className="h-4 w-4" />
                      Visualizar Contrato
                    </Button>
                  )}
                </div>
                {contract.status === 'generated' && (
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button className="w-full bg-primary hover:bg-primary/90 gap-2" disabled={actionLoading}>
                        <Pen className="h-4 w-4" />
                        {actionLoading ? 'Processando...' : 'Enviar para Assinatura Digital'}
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Enviar para assinatura?</AlertDialogTitle>
                        <AlertDialogDescription>
                          O contrato será enviado para assinatura digital do locatário e do locador. Ambas as partes receberão um link.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancelar</AlertDialogCancel>
                        <AlertDialogAction onClick={handleSendForSignature}>
                          Confirmar Envio
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                )}
              </>
            ) : (
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button className="w-full bg-sla-ok hover:bg-sla-ok/90 text-white gap-2" disabled={actionLoading}>
                    <FileCheck className="h-4 w-4" />
                    {actionLoading ? 'Gerando contrato...' : 'Emitir Contrato'}
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Emitir contrato de locação?</AlertDialogTitle>
                    <AlertDialogDescription>
                      O contrato será gerado com base nos valores da proposta aceita e poderá ser revisado antes do envio para assinatura.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancelar</AlertDialogCancel>
                    <AlertDialogAction onClick={handleEmitContract} className="bg-sla-ok hover:bg-sla-ok/90">
                      Confirmar Emissão
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            )}
          </CardContent>
        </Card>
      )}

      {/* ── STEP 7: Contract Signature ── */}
      {isStep7 && (
        <Card className="border-primary/30 bg-primary/5">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Pen className="h-4 w-4" />
              Assinatura do Contrato — Etapa 7
            </CardTitle>
            <CardDescription>
              O contrato está aguardando assinatura digital de ambas as partes.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {contract && (
              <div className="p-3 bg-background rounded-lg border space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Locador:</span>
                  {contract.signed_by_landlord_at ? (
                    <Badge className="bg-sla-ok/20 text-sla-ok border-sla-ok/30">Assinado ✓</Badge>
                  ) : (
                    <Badge variant="secondary">Pendente</Badge>
                  )}
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Locatário:</span>
                  {contract.signed_by_tenant_at ? (
                    <Badge className="bg-sla-ok/20 text-sla-ok border-sla-ok/30">Assinado ✓</Badge>
                  ) : (
                    <Badge variant="secondary">Pendente</Badge>
                  )}
                </div>
              </div>
            )}
            {contract && !contract.signed_by_landlord_at && (
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button className="w-full bg-primary hover:bg-primary/90 gap-2" disabled={actionLoading}>
                    <Pen className="h-4 w-4" />
                    {actionLoading ? 'Processando...' : 'Assinar Contrato (Locador)'}
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Assinar contrato?</AlertDialogTitle>
                    <AlertDialogDescription>
                      Ao confirmar, sua assinatura digital será registrada no contrato.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancelar</AlertDialogCancel>
                    <AlertDialogAction onClick={handleLandlordSign}>
                      Confirmar Assinatura
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            )}
            {contract?.signed_by_landlord_at && !contract.signed_by_tenant_at && (
              <div className="p-3 bg-muted/50 rounded-lg text-center">
                <p className="text-sm text-muted-foreground">Aguardando assinatura do locatário...</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* ── STEP 8: Inspection Scheduling ── */}
      {isStep8 && (
        <Card className="border-primary/30 bg-primary/5">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Agendamento de Vistoria — Etapa 8
            </CardTitle>
            <CardDescription>
              Agende a vistoria de entrada do imóvel.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {inspection?.status === 'scheduled' ? (
              <div className="p-3 bg-background rounded-lg border space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Data:</span>
                  <span className="font-medium">{inspection.scheduled_date}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Horário:</span>
                  <span className="font-medium">{inspection.scheduled_time}</span>
                </div>
                <Badge className="bg-sla-ok/20 text-sla-ok border-sla-ok/30">Vistoria agendada</Badge>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label className="text-xs">Data</Label>
                    <input
                      type="date"
                      className="w-full h-9 rounded-md border border-input bg-background px-3 py-1 text-sm"
                      value={inspectionDate}
                      onChange={e => setInspectionDate(e.target.value)}
                      min={new Date().toISOString().split('T')[0]}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs">Horário</Label>
                    <input
                      type="time"
                      className="w-full h-9 rounded-md border border-input bg-background px-3 py-1 text-sm"
                      value={inspectionTime}
                      onChange={e => setInspectionTime(e.target.value)}
                    />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">Observações (opcional)</Label>
                  <Textarea
                    placeholder="Local de encontro, orientações..."
                    value={inspectionNotes}
                    onChange={e => setInspectionNotes(e.target.value)}
                    className="h-16"
                  />
                </div>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button
                      className="w-full bg-primary hover:bg-primary/90 gap-2"
                      disabled={!inspectionDate || !inspectionTime || actionLoading}
                    >
                      <Calendar className="h-4 w-4" />
                      {actionLoading ? 'Agendando...' : 'Agendar Vistoria'}
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Confirmar agendamento da vistoria?</AlertDialogTitle>
                      <AlertDialogDescription>
                        A vistoria será agendada para {inspectionDate} às {inspectionTime}. O locatário será notificado.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancelar</AlertDialogCancel>
                      <AlertDialogAction onClick={async () => {
                        if (!rental) return;
                        setActionLoading(true);
                        try {
                          const result = await scheduleInspection({
                            rentalId: rental.id,
                            date: inspectionDate,
                            time: inspectionTime,
                            locationNotes: inspectionNotes || undefined,
                          });
                          if (result) {
                            toast({ title: "Vistoria agendada!", description: `Data: ${inspectionDate} às ${inspectionTime}` });
                            await loadData();
                          } else {
                            toast({ title: "Erro", description: "Não foi possível agendar.", variant: "destructive" });
                          }
                        } finally {
                          setActionLoading(false);
                        }
                      }}>Confirmar</AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* ── STEP 9: Inspection Report Signature ── */}
      {isStep9 && (
        <Card className="border-primary/30 bg-primary/5">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <ClipboardCheck className="h-4 w-4" />
              Assinatura de Vistoria — Etapa 9
            </CardTitle>
            <CardDescription>
              Assine o laudo de vistoria do imóvel. Ambas as partes precisam assinar.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {inspection && (
              <div className="p-3 bg-background rounded-lg border space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Locador:</span>
                  {inspection.signed_by_landlord_at ? (
                    <Badge className="bg-sla-ok/20 text-sla-ok border-sla-ok/30">Assinado ✓</Badge>
                  ) : (
                    <Badge variant="secondary">Pendente</Badge>
                  )}
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Locatário:</span>
                  {inspection.signed_by_tenant_at ? (
                    <Badge className="bg-sla-ok/20 text-sla-ok border-sla-ok/30">Assinado ✓</Badge>
                  ) : (
                    <Badge variant="secondary">Pendente</Badge>
                  )}
                </div>
              </div>
            )}
            {inspection && !inspection.signed_by_landlord_at && (
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button className="w-full bg-primary hover:bg-primary/90 gap-2" disabled={actionLoading}>
                    <Pen className="h-4 w-4" />
                    {actionLoading ? 'Processando...' : 'Assinar Laudo (Locador)'}
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Assinar laudo de vistoria?</AlertDialogTitle>
                    <AlertDialogDescription>
                      Ao confirmar, sua assinatura será registrada no laudo de vistoria.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancelar</AlertDialogCancel>
                    <AlertDialogAction onClick={async () => {
                      if (!rental) return;
                      setActionLoading(true);
                      try {
                        const success = await signInspectionReport({ rentalId: rental.id, signerRole: 'landlord' });
                        if (success) {
                          toast({ title: "Laudo assinado!", description: "Sua assinatura foi registrada." });
                          await loadData();
                        } else {
                          toast({ title: "Erro", description: "Não foi possível assinar.", variant: "destructive" });
                        }
                      } finally {
                        setActionLoading(false);
                      }
                    }}>Confirmar Assinatura</AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            )}
            {inspection?.signed_by_landlord_at && !inspection.signed_by_tenant_at && (
              <div className="p-3 bg-muted/50 rounded-lg text-center">
                <p className="text-sm text-muted-foreground">Aguardando assinatura do locatário...</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* ── STEP 10: Key Delivery ── */}
      {isStep10 && (
        <Card className="border-primary/30 bg-primary/5">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Key className="h-4 w-4" />
              Entrega das Chaves — Etapa 10
            </CardTitle>
            <CardDescription>
              Confirme a entrega das chaves ao locatário para finalizar o processo.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {inspection?.keys_delivered_at ? (
              <div className="p-3 bg-sla-ok/10 rounded-lg border border-sla-ok/30 text-center space-y-1">
                <Check className="h-6 w-6 text-sla-ok mx-auto" />
                <p className="font-semibold text-sla-ok text-sm">Chaves entregues!</p>
                <p className="text-xs text-muted-foreground">Processo de locação concluído.</p>
              </div>
            ) : (
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button className="w-full bg-sla-ok hover:bg-sla-ok/90 text-white gap-2" disabled={actionLoading}>
                    <Key className="h-4 w-4" />
                    {actionLoading ? 'Processando...' : 'Confirmar Entrega das Chaves'}
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Confirmar entrega das chaves?</AlertDialogTitle>
                    <AlertDialogDescription>
                      Ao confirmar, o processo de locação será finalizado. Esta ação não pode ser desfeita.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancelar</AlertDialogCancel>
                    <AlertDialogAction onClick={async () => {
                      if (!rental) return;
                      setActionLoading(true);
                      try {
                        const success = await deliverKeys({ rentalId: rental.id, deliveredBy: user?.id });
                        if (success) {
                          toast({ title: "🎉 Chaves entregues!", description: "Processo de locação concluído com sucesso." });
                          await loadData();
                        } else {
                          toast({ title: "Erro", description: "Não foi possível registrar.", variant: "destructive" });
                        }
                      } finally {
                        setActionLoading(false);
                      }
                    }} className="bg-sla-ok hover:bg-sla-ok/90">Confirmar Entrega</AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            )}
          </CardContent>
        </Card>
      )}

      {/* Event History */}
      {events.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Histórico ({events.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {events.map(evt => (
                <div key={evt.id} className="flex items-start gap-2 p-2 bg-muted/30 rounded">
                  <Badge variant="outline" className="text-[10px] shrink-0 mt-0.5">
                    {EVENT_LABELS[evt.event_type] || evt.event_type}
                  </Badge>
                  <div className="min-w-0">
                    <p className="text-xs text-muted-foreground truncate">{evt.description}</p>
                    {evt.created_at && (
                      <p className="text-[10px] text-muted-foreground/70">
                        {format(new Date(evt.created_at), "dd/MM HH:mm", { locale: ptBR })}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
