import { useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { useLandlordDashboard } from "@/hooks/useLandlordDashboard";
import { useVistaSoftSync } from "@/hooks/useVistaSoftSync";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { FinancialKPICards } from "@/components/locador/dashboard/FinancialKPICards";
import { PropertyExpandableCard } from "@/components/locador/dashboard/PropertyExpandableCard";
import { ProposalCard } from "@/components/locador/dashboard/ProposalCard";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  FileText,
  Building,
  Plus,
  HelpCircle,
  ChevronDown,
  Search,
  Zap,
  Clock,
  RefreshCw,
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function LocadorHome() {
  const { profile } = useAuth();
  const {
    kpis,
    properties,
    proposals,
    urgentProposals,
    analysisProposals,
    isLoading,
  } = useLandlordDashboard();
  const { isSyncing } = useVistaSoftSync();
  const { toast } = useToast();

  const [proposalsOpen, setProposalsOpen] = useState(true);
  const [propertiesOpen, setPropertiesOpen] = useState(true);
  const [propertyFilter, setPropertyFilter] = useState("");
  const [proposalTab, setProposalTab] = useState<string>("urgent");

  const handleAcceptProposal = async (proposalId: string) => {
    try {
      // Try updating rental_applications first
      const { error: appError } = await supabase
        .from('rental_applications')
        .update({
          status: 'approved',
          current_step: '3',
        })
        .eq('id', proposalId);

      // Also update rentals table — use proposal_status for consistency
      const { error: rentalError } = await supabase
        .from('rentals')
        .update({
          landlord_action_required: false,
          landlord_accepted: true,
          landlord_accepted_at: new Date().toISOString(),
          proposal_status: 'proposal_accepted',
        } as any)
        .eq('id', proposalId);

      // Create event
      await supabase.from('application_events').insert({
        application_id: proposalId,
        event_type: 'locador_aprovou',
        from_step: '2',
        to_step: '3',
        note: 'Locador aprovou a proposta de locação',
      });

      // Also create rental event with standardized type
      await supabase.from('rental_events').insert({
        rental_id: proposalId,
        event_type: 'proposal_accepted',
        description: 'Locador aceitou a proposta de locação',
        idempotency_key: `accept_home_${proposalId}`,
      });

      // Audit log
      await supabase.rpc('log_audit', {
        p_action: 'LANDLORD_APPROVED',
        p_table_name: 'rental_applications',
        p_record_id: proposalId,
      });

      toast({
        title: "Proposta Aceita!",
        description: "O locatário será notificado automaticamente.",
      });
    } catch (error) {
      console.error('Error accepting proposal:', error);
      toast({
        title: "Erro ao aceitar proposta",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      });
    }
  };

  const handleRejectProposal = async (proposalId: string, reason: string, details?: string) => {
    try {
      // Update rental_applications
      await supabase
        .from('rental_applications')
        .update({
          status: 'rejected',
        })
        .eq('id', proposalId);

      // Create event
      await supabase.from('application_events').insert({
        application_id: proposalId,
        event_type: 'locador_recusou',
        note: `${reason}${details ? ` - ${details}` : ''}`,
      });

      // Audit log
      await supabase.rpc('log_audit', {
        p_action: 'LANDLORD_REJECTED',
        p_table_name: 'rental_applications',
        p_record_id: proposalId,
        p_new_data: { reason, details },
      });

      toast({
        title: "Proposta Recusada",
        description: "O locatário será notificado.",
      });
    } catch (error) {
      console.error('Error rejecting proposal:', error);
      toast({
        title: "Erro ao recusar proposta",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      });
    }
  };

  const handleCounterProposal = async (proposalId: string, newValue: number) => {
    try {
      // Create event for counter-proposal
      await supabase.from('application_events').insert({
        application_id: proposalId,
        event_type: 'locador_contraproposta',
        note: `Locador propôs R$ ${newValue.toLocaleString('pt-BR')}`,
      });

      toast({
        title: "Contra-proposta Enviada",
        description: "O locatário será notificado sobre a nova proposta.",
      });
    } catch (error) {
      console.error('Error sending counter-proposal:', error);
      toast({
        title: "Erro ao enviar contra-proposta",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      });
    }
  };

  // Filter proposals by property code
  const filterProposals = (proposalList: typeof proposals) => {
    if (!propertyFilter.trim()) return proposalList;
    const filter = propertyFilter.toLowerCase();
    return proposalList.filter(
      p =>
        p.propertyCode.toLowerCase().includes(filter) ||
        p.propertyAddress.toLowerCase().includes(filter)
    );
  };

  const filteredUrgent = filterProposals(urgentProposals);
  const filteredAnalysis = filterProposals(analysisProposals);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="space-y-2">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-4 w-64" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Skeleton className="h-40" />
          <Skeleton className="h-40" />
        </div>
        <Skeleton className="h-32" />
        <Skeleton className="h-32" />
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-5xl">
      {/* Sync Indicator */}
      {isSyncing && (
        <div className="flex items-center gap-2 text-sm text-muted-foreground animate-pulse">
          <RefreshCw className="h-4 w-4 animate-spin" />
          Sincronizando imóveis...
        </div>
      )}

      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">
          Olá, {profile?.full_name?.split(" ")[0] || "Proprietário"}!
        </h1>
        <p className="text-muted-foreground">
          Visão geral dos seus imóveis e propostas
        </p>
      </div>

      {/* Quick Actions Bar */}
      <div className="flex flex-wrap gap-2">
        <Button asChild>
          <Link to="/locador/anunciar">
            <Plus className="mr-2 h-4 w-4" />
            Anunciar imóvel
          </Link>
        </Button>
        <Button
          variant="outline"
          onClick={() => {
            setProposalsOpen(true);
            setProposalTab("urgent");
          }}
        >
          <FileText className="mr-2 h-4 w-4" />
          Ver propostas
          {urgentProposals.length > 0 && (
            <Badge variant="destructive" className="ml-2">
              {urgentProposals.length}
            </Badge>
          )}
        </Button>
        <Button variant="outline" asChild>
          <Link to="/locador/ajuda">
            <HelpCircle className="mr-2 h-4 w-4" />
            Ajuda
          </Link>
        </Button>
      </div>

      {/* Financial KPIs */}
      <FinancialKPICards kpis={kpis} />

      {/* Proposals Section - Collapsible */}
      <Collapsible open={proposalsOpen} onOpenChange={setProposalsOpen}>
        <Card>
          <CollapsibleTrigger asChild>
            <div className="flex items-center justify-between p-4 cursor-pointer hover:bg-muted/30 transition-colors">
              <div className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-muted-foreground" />
                <h2 className="text-lg font-semibold">Propostas Recebidas</h2>
                <Badge variant="secondary">{proposals.length}</Badge>
                {urgentProposals.length > 0 && (
                  <Badge variant="destructive" className="animate-pulse">
                    {urgentProposals.length} urgente
                    {urgentProposals.length > 1 ? "s" : ""}
                  </Badge>
                )}
              </div>
              <ChevronDown
                className={cn(
                  "h-5 w-5 text-muted-foreground transition-transform",
                  proposalsOpen && "rotate-180"
                )}
              />
            </div>
          </CollapsibleTrigger>

          <CollapsibleContent>
            <CardContent className="pt-0">
              {proposals.length === 0 ? (
                <div className="py-8 text-center">
                  <FileText className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
                  <p className="text-muted-foreground">
                    Aguardando novas propostas.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Search by property code */}
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Buscar por código do imóvel..."
                      value={propertyFilter}
                      onChange={(e) => setPropertyFilter(e.target.value)}
                      className="pl-10"
                    />
                  </div>

                  {/* Tabs: Urgentes / Em Análise */}
                  <Tabs value={proposalTab} onValueChange={setProposalTab}>
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="urgent" className="gap-2">
                        <Zap className="h-4 w-4" />
                        Urgentes ({filteredUrgent.length})
                      </TabsTrigger>
                      <TabsTrigger value="analysis" className="gap-2">
                        <Clock className="h-4 w-4" />
                        Em Análise ({filteredAnalysis.length})
                      </TabsTrigger>
                    </TabsList>

                    <TabsContent value="urgent" className="mt-4 space-y-3">
                      {filteredUrgent.length === 0 ? (
                        <p className="text-center text-muted-foreground py-4">
                          Nenhuma proposta urgente.
                        </p>
                      ) : (
                        filteredUrgent.map((proposal) => (
                          <ProposalCard
                            key={proposal.id}
                            proposal={proposal}
                            onAccept={handleAcceptProposal}
                            onReject={handleRejectProposal}
                            onCounterProposal={handleCounterProposal}
                          />
                        ))
                      )}
                    </TabsContent>

                    <TabsContent value="analysis" className="mt-4 space-y-3">
                      {filteredAnalysis.length === 0 ? (
                        <p className="text-center text-muted-foreground py-4">
                          Nenhuma proposta em análise.
                        </p>
                      ) : (
                        filteredAnalysis.map((proposal) => (
                          <ProposalCard
                            key={proposal.id}
                            proposal={proposal}
                            onAccept={handleAcceptProposal}
                            onReject={handleRejectProposal}
                            onCounterProposal={handleCounterProposal}
                          />
                        ))
                      )}
                    </TabsContent>
                  </Tabs>
                </div>
              )}
            </CardContent>
          </CollapsibleContent>
        </Card>
      </Collapsible>

      {/* Properties Section - Collapsible */}
      <Collapsible open={propertiesOpen} onOpenChange={setPropertiesOpen}>
        <Card>
          <CollapsibleTrigger asChild>
            <div className="flex items-center justify-between p-4 cursor-pointer hover:bg-muted/30 transition-colors">
              <div className="flex items-center gap-2">
                <Building className="h-5 w-5 text-muted-foreground" />
                <h2 className="text-lg font-semibold">Seus Imóveis</h2>
                <Badge variant="secondary">{properties.length}</Badge>
              </div>
              <ChevronDown
                className={cn(
                  "h-5 w-5 text-muted-foreground transition-transform",
                  propertiesOpen && "rotate-180"
                )}
              />
            </div>
          </CollapsibleTrigger>

          <CollapsibleContent>
            <CardContent className="pt-0">
              {properties.length === 0 ? (
                <div className="py-8 text-center">
                  <Building className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
                  <p className="text-muted-foreground">
                    Você ainda não tem imóveis cadastrados.
                  </p>
                  <Button className="mt-4" asChild>
                    <Link to="/locador/anunciar">
                      <Plus className="mr-2 h-4 w-4" />
                      Anunciar imóvel
                    </Link>
                  </Button>
                </div>
              ) : (
                <div>
                  {properties.map((property) => (
                    <PropertyExpandableCard
                      key={property.id}
                      property={property}
                    />
                  ))}
                </div>
              )}
            </CardContent>
          </CollapsibleContent>
        </Card>
      </Collapsible>
    </div>
  );
}
