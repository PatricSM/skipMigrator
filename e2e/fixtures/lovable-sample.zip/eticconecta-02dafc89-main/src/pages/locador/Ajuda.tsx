import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Mail, Phone, MessageCircle, Shield, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";

const faqs = [
  {
    question: "Como faço para cadastrar um novo imóvel?",
    answer: "Para cadastrar um novo imóvel, acesse a seção 'Imóveis' e clique no botão 'Novo Imóvel'. Preencha as informações solicitadas e envie os documentos necessários."
  },
  {
    question: "Como acompanho as propostas de locação?",
    answer: "Na seção 'Propostas' você pode ver todas as propostas recebidas para seus imóveis, o status de cada uma e as ações pendentes."
  },
  {
    question: "Quais documentos preciso enviar?",
    answer: "Os documentos necessários variam de acordo com o tipo de imóvel. Em geral, são solicitados: documento de identidade, comprovante de propriedade, IPTU e contas de consumo."
  },
  {
    question: "Como funciona o processo de locação?",
    answer: "Após receber uma proposta, você será notificado para enviar os documentos do imóvel. Depois da aprovação, o contrato é gerado e enviado para assinatura digital de todas as partes."
  },
  {
    question: "Como funciona o envio de proposta?",
    answer: "Após escolher o imóvel, o locatário preenche seus dados e envia documentos. A proposta é analisada em até 24h."
  },
  {
    question: "Meus documentos ficam seguros?",
    answer: "Sim! Utilizamos criptografia de ponta a ponta e seguimos a LGPD rigorosamente."
  },
];

export default function LocadorAjuda() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Central de Ajuda</h1>
        <p className="text-muted-foreground mt-1">
          Tire suas dúvidas e entre em contato conosco.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Mail className="h-5 w-5" />
              Email
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground text-sm mb-3">
              Envie suas dúvidas por email
            </p>
            <Button variant="outline" className="w-full" asChild>
              <a href="mailto:contato@eticconecta.com.br">Enviar email</a>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Phone className="h-5 w-5" />
              Telefone
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground text-sm mb-3">
              Ligue para nossa central
            </p>
            <Button variant="outline" className="w-full" asChild>
              <a href="tel:+5511999999999">Ligar agora</a>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <MessageCircle className="h-5 w-5" />
              WhatsApp
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground text-sm mb-3">
              Atendimento rápido via WhatsApp
            </p>
            <Button variant="outline" className="w-full" asChild>
              <a href="https://wa.me/5511999999999" target="_blank" rel="noopener noreferrer">
                Abrir WhatsApp
              </a>
            </Button>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Perguntas Frequentes</CardTitle>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`}>
                <AccordionTrigger>{faq.question}</AccordionTrigger>
                <AccordionContent>{faq.answer}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </CardContent>
      </Card>

      {/* Terms of Use Section */}
      <Card id="termos">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Termos de Uso
          </CardTitle>
        </CardHeader>
        <CardContent className="prose prose-sm max-w-none dark:prose-invert">
          <p className="text-muted-foreground">
            Ao utilizar a plataforma Etic Imóveis, você concorda com os seguintes termos:
          </p>
          <ul className="text-muted-foreground space-y-2 mt-4">
            <li>A plataforma destina-se à gestão de locações imobiliárias entre locadores e locatários.</li>
            <li>Os usuários são responsáveis pela veracidade das informações fornecidas.</li>
            <li>Os documentos enviados são armazenados de forma segura e utilizados exclusivamente para fins de análise de locação.</li>
            <li>A Etic Imóveis atua como facilitadora do processo, não sendo responsável por disputas entre as partes.</li>
            <li>O uso indevido da plataforma pode resultar em suspensão ou cancelamento da conta.</li>
            <li>Reservamo-nos o direito de modificar estes termos a qualquer momento, notificando os usuários por email.</li>
          </ul>
          <p className="text-muted-foreground mt-4">
            Para dúvidas sobre os termos, entre em contato pelo email: <a href="mailto:juridico@eticconecta.com.br" className="text-primary hover:underline">juridico@eticconecta.com.br</a>
          </p>
        </CardContent>
      </Card>

      {/* Privacy Policy Section */}
      <Card id="privacidade">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Política de Privacidade (LGPD)
          </CardTitle>
        </CardHeader>
        <CardContent className="prose prose-sm max-w-none dark:prose-invert">
          <p className="text-muted-foreground">
            Seus dados pessoais são tratados conforme a Lei Geral de Proteção de Dados (Lei nº 13.709/2018):
          </p>
          
          <h4 className="text-foreground font-semibold mt-4">Dados Coletados</h4>
          <ul className="text-muted-foreground space-y-1">
            <li>Nome completo, CPF, RG e data de nascimento</li>
            <li>Email, telefone e endereço</li>
            <li>Comprovantes de renda e documentos de identificação</li>
            <li>Dados de navegação e uso da plataforma</li>
          </ul>

          <h4 className="text-foreground font-semibold mt-4">Finalidade do Tratamento</h4>
          <ul className="text-muted-foreground space-y-1">
            <li>Análise de crédito e aprovação de locação</li>
            <li>Comunicação sobre o andamento do processo</li>
            <li>Geração de contratos e documentos</li>
            <li>Melhoria contínua dos serviços</li>
          </ul>

          <h4 className="text-foreground font-semibold mt-4">Seus Direitos</h4>
          <ul className="text-muted-foreground space-y-1">
            <li>Acesso aos seus dados pessoais</li>
            <li>Correção de dados incompletos ou desatualizados</li>
            <li>Anonimização, bloqueio ou eliminação de dados desnecessários</li>
            <li>Portabilidade dos dados</li>
            <li>Revogação do consentimento</li>
          </ul>

          <h4 className="text-foreground font-semibold mt-4">Contato do DPO</h4>
          <p className="text-muted-foreground">
            Para exercer seus direitos ou esclarecer dúvidas sobre o tratamento de dados, entre em contato com nosso Encarregado de Proteção de Dados:
          </p>
          <p className="text-muted-foreground">
            Email: <a href="mailto:dpo@eticconecta.com.br" className="text-primary hover:underline">dpo@eticconecta.com.br</a>
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
