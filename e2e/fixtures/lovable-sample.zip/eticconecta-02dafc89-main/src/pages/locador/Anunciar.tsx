import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, ExternalLink } from "lucide-react";
import { Link } from "react-router-dom";

export default function LocadorAnunciar() {
  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="text-2xl font-bold text-foreground">
          Anunciar Imóvel
        </h1>
        <p className="text-muted-foreground">
          Cadastre um novo imóvel para locação
        </p>
      </div>

      <Card>
        <CardContent className="py-12 text-center space-y-4">
          <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
            <Plus className="h-8 w-8 text-primary" />
          </div>
          
          <div className="space-y-2">
            <h2 className="text-lg font-semibold">
              Adicione seu imóvel
            </h2>
            <p className="text-muted-foreground max-w-md mx-auto">
              Para anunciar um novo imóvel, entre em contato com a Etic Imóveis.
              Nossa equipe irá ajudá-lo a cadastrar seu imóvel de forma rápida e segura.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 justify-center pt-4">
            <Button asChild>
              <a 
                href="https://wa.me/5511970932722?text=Olá!%20Gostaria%20de%20anunciar%20meu%20imóvel%20para%20locação." 
                target="_blank"
                rel="noopener noreferrer"
                className="gap-2"
              >
                Falar com a Etic
                <ExternalLink className="h-4 w-4" />
              </a>
            </Button>
            
            <Button variant="outline" asChild>
              <Link to="/locador/imoveis">
                Ver meus imóveis
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
