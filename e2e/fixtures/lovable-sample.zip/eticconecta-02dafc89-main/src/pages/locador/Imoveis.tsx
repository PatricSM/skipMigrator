import { Card, CardContent } from "@/components/ui/card";
import { Building } from "lucide-react";

export default function LocadorImoveis() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Meus Imóveis</h1>
        <p className="text-muted-foreground mt-1">
          Gerencie os imóveis cadastrados na plataforma.
        </p>
      </div>

      <Card>
        <CardContent className="py-12">
          <div className="text-center">
            <Building className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-muted-foreground">
              Nenhum imóvel cadastrado.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
