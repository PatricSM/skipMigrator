import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Download, FileText, ArrowLeft, FileBadge, FileDown, Loader2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { marked } from "marked";

import docContent from "../../docs/DOCUMENTACAO_COMPLETA.md?raw";
import prdContent from "../../docs/PRD_ETIC_CONECTA.md?raw";
import techContent from "../../docs/DOCUMENTO_TECNICO_COMPLETO.md?raw";
import historyContent from "../../docs/HISTORICO_CONVERSAS.md?raw";

type PdfKind = "doc" | "prd" | "tech" | "history";

export default function DownloadDocs() {
  const navigate = useNavigate();
  const [generatingPdf, setGeneratingPdf] = useState<null | PdfKind>(null);

  const triggerDownload = (content: string, filename: string) => {
    const blob = new Blob([content], { type: "text/markdown;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const downloadPdf = async (
    markdown: string,
    filename: string,
    title: string,
    kind: PdfKind,
  ) => {
    try {
      setGeneratingPdf(kind);
      const html2pdf = (await import("html2pdf.js")).default;
      const bodyHtml = await marked.parse(markdown);

      const container = document.createElement("div");
      container.style.cssText =
        "position:fixed;left:-10000px;top:0;width:794px;padding:48px;background:#fff;color:#111;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:1.55;";
      container.innerHTML = `
        <style>
          .pdf-doc h1{font-size:24px;margin:24px 0 12px;color:#111;border-bottom:2px solid #333;padding-bottom:6px;}
          .pdf-doc h2{font-size:18px;margin:20px 0 10px;color:#222;}
          .pdf-doc h3{font-size:15px;margin:16px 0 8px;color:#333;}
          .pdf-doc h4{font-size:13px;margin:12px 0 6px;color:#444;}
          .pdf-doc p{margin:0 0 8px;}
          .pdf-doc ul,.pdf-doc ol{margin:0 0 10px 20px;padding:0;}
          .pdf-doc li{margin-bottom:4px;}
          .pdf-doc code{background:#f3f4f6;padding:1px 4px;border-radius:3px;font-family:Consolas,Monaco,monospace;font-size:11px;}
          .pdf-doc pre{background:#f3f4f6;padding:10px;border-radius:4px;overflow:hidden;font-size:10.5px;white-space:pre-wrap;word-break:break-word;page-break-inside:avoid;}
          .pdf-doc pre code{background:transparent;padding:0;}
          .pdf-doc table{border-collapse:collapse;width:100%;margin:10px 0;font-size:11px;page-break-inside:avoid;}
          .pdf-doc th,.pdf-doc td{border:1px solid #ccc;padding:6px 8px;text-align:left;vertical-align:top;}
          .pdf-doc th{background:#f3f4f6;font-weight:600;}
          .pdf-doc blockquote{border-left:3px solid #888;padding-left:10px;color:#444;margin:8px 0;}
          .pdf-doc hr{border:none;border-top:1px solid #ddd;margin:16px 0;}
          .pdf-doc h1,.pdf-doc h2,.pdf-doc h3{page-break-after:avoid;}
        </style>
        <div class="pdf-doc">
          <h1 style="text-align:center;border:none;font-size:26px;margin-bottom:4px;">${title}</h1>
          <p style="text-align:center;color:#666;margin-bottom:24px;">Etic Conecta — Gerado em ${new Date().toLocaleDateString("pt-BR")}</p>
          ${bodyHtml}
        </div>
      `;
      document.body.appendChild(container);

      const opts = {
        margin: [10, 10, 12, 10],
        filename,
        image: { type: "jpeg", quality: 0.95 },
        html2canvas: { scale: 2, useCORS: true, letterRendering: true },
        jsPDF: { unit: "mm", format: "a4", orientation: "portrait" },
        pagebreak: { mode: ["css", "legacy", "avoid-all"] },
      };
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      await html2pdf().set(opts as any).from(container).save();

      document.body.removeChild(container);
    } catch (err) {
      console.error("Erro ao gerar PDF:", err);
      alert("Não foi possível gerar o PDF. Tente baixar a versão .md.");
    } finally {
      setGeneratingPdf(null);
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-card">
        <CardHeader className="text-center space-y-2">
          <div className="mx-auto w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center">
            <FileText className="w-8 h-8 text-primary" />
          </div>
          <CardTitle className="text-xl">Documentos do Projeto</CardTitle>
          <p className="text-sm text-muted-foreground">
            Baixe a documentação técnica e o PRD oficial do Etic Conecta em Markdown ou PDF.
          </p>
        </CardHeader>
        <CardContent className="space-y-5">
          <div className="space-y-2">
            <p className="text-sm font-semibold">Documentação Técnica</p>
            <Button
              size="lg"
              className="w-full h-12 text-sm font-semibold"
              onClick={() => triggerDownload(docContent, "DOCUMENTACAO_COMPLETA_ETIC_CONECTA.md")}
            >
              <Download className="mr-2 h-4 w-4" />
              Baixar (.md)
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="w-full h-12 text-sm font-semibold"
              disabled={generatingPdf !== null}
              onClick={() =>
                downloadPdf(
                  docContent,
                  "DOCUMENTACAO_COMPLETA_ETIC_CONECTA.pdf",
                  "Documentação Técnica Completa",
                  "doc",
                )
              }
            >
              {generatingPdf === "doc" ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <FileDown className="mr-2 h-4 w-4" />
              )}
              {generatingPdf === "doc" ? "Gerando PDF..." : "Baixar (.pdf)"}
            </Button>
            <p className="text-xs text-muted-foreground text-center">
              ~{Math.round(docContent.length / 1024)} KB • 32 seções
            </p>
          </div>

          <div className="space-y-2 pt-2 border-t">
            <p className="text-sm font-semibold">PRD Oficial</p>
            <Button
              size="lg"
              variant="secondary"
              className="w-full h-12 text-sm font-semibold"
              onClick={() => triggerDownload(prdContent, "PRD_ETIC_CONECTA.md")}
            >
              <FileBadge className="mr-2 h-4 w-4" />
              Baixar (.md)
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="w-full h-12 text-sm font-semibold"
              disabled={generatingPdf !== null}
              onClick={() =>
                downloadPdf(prdContent, "PRD_ETIC_CONECTA.pdf", "PRD — Etic Conecta", "prd")
              }
            >
              {generatingPdf === "prd" ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <FileDown className="mr-2 h-4 w-4" />
              )}
              {generatingPdf === "prd" ? "Gerando PDF..." : "Baixar (.pdf)"}
            </Button>
            <p className="text-xs text-muted-foreground text-center">
              ~{Math.round(prdContent.length / 1024)} KB • 14 seções
            </p>
          </div>

          <div className="space-y-2 pt-2 border-t">
            <p className="text-sm font-semibold">Documento Técnico Completo</p>
            <p className="text-xs text-muted-foreground">
              Visão consolidada para recriar o projeto do zero (estrutura, banco, design, integrações).
            </p>
            <Button
              size="lg"
              variant="secondary"
              className="w-full h-12 text-sm font-semibold"
              onClick={() => triggerDownload(techContent, "DOCUMENTO_TECNICO_COMPLETO_ETIC_CONECTA.md")}
            >
              <FileBadge className="mr-2 h-4 w-4" />
              Baixar (.md)
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="w-full h-12 text-sm font-semibold"
              disabled={generatingPdf !== null}
              onClick={() =>
                downloadPdf(
                  techContent,
                  "DOCUMENTO_TECNICO_COMPLETO_ETIC_CONECTA.pdf",
                  "Documento Técnico Completo",
                  "tech",
                )
              }
            >
              {generatingPdf === "tech" ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <FileDown className="mr-2 h-4 w-4" />
              )}
              {generatingPdf === "tech" ? "Gerando PDF..." : "Baixar (.pdf)"}
            </Button>
            <p className="text-xs text-muted-foreground text-center">
              ~{Math.round(techContent.length / 1024)} KB • 7 seções consolidadas
            </p>
          </div>

          <div className="space-y-2 pt-2 border-t">
            <p className="text-sm font-semibold">Histórico de Conversas</p>
            <p className="text-xs text-muted-foreground">
              Jornada completa do projeto (710 mensagens em 16 sprints).
            </p>
            <Button
              size="lg"
              variant="secondary"
              className="w-full h-12 text-sm font-semibold"
              onClick={() => triggerDownload(historyContent, "HISTORICO_CONVERSAS_ETIC_CONECTA.md")}
            >
              <FileBadge className="mr-2 h-4 w-4" />
              Baixar (.md)
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="w-full h-12 text-sm font-semibold"
              disabled={generatingPdf !== null}
              onClick={() =>
                downloadPdf(
                  historyContent,
                  "HISTORICO_CONVERSAS_ETIC_CONECTA.pdf",
                  "Histórico de Conversas — Etic Conecta",
                  "history",
                )
              }
            >
              {generatingPdf === "history" ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <FileDown className="mr-2 h-4 w-4" />
              )}
              {generatingPdf === "history" ? "Gerando PDF..." : "Baixar (.pdf)"}
            </Button>
            <p className="text-xs text-muted-foreground text-center">
              ~{Math.round(historyContent.length / 1024)} KB • 16 sprints
            </p>
          </div>

          <Button
            variant="ghost"
            className="w-full"
            onClick={() => navigate("/locatario")}
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Voltar ao início
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
