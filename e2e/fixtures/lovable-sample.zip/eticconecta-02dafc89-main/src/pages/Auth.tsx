import { useState, useEffect } from "react";
import { useNavigate, Link, useLocation, useSearchParams } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Eye, EyeOff, Mail, Lock, User, ArrowLeft, Loader2 } from "lucide-react";
import { z } from "zod";
import { ForgotPasswordDialog } from "@/components/auth/ForgotPasswordDialog";
import { ResetPasswordForm } from "@/components/auth/ResetPasswordForm";

const emailSchema = z.string().email("Email inválido");
const loginPasswordSchema = z.string().min(6, "Senha deve ter pelo menos 6 caracteres");

import { strongPasswordSchema } from '@/lib/passwordPolicy';
const signupPasswordSchema = strongPasswordSchema;
const nameSchema = z.string().min(2, "Nome deve ter pelo menos 2 caracteres");

const REDIRECT_KEY = "auth_redirect_to";

export default function Auth() {
  const navigate = useNavigate();
  const location = useLocation();
  const [searchParams] = useSearchParams();
  const { user, login, register, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  
  // Read the pathname from location.state.from (passed by ProtectedRoute)
  const stateLocation = (location.state as { from?: { pathname: string } })?.from;
  const stateFrom = stateLocation?.pathname;
  const storedFrom = sessionStorage.getItem(REDIRECT_KEY);
  const from = stateFrom || storedFrom || "/selecionar-imovel";
  
  // Check if user is in password recovery mode
  const [isRecoveryMode, setIsRecoveryMode] = useState(false);
  const [checkingRecovery, setCheckingRecovery] = useState(true);

  useEffect(() => {
    if (stateFrom && stateFrom !== "/") {
      sessionStorage.setItem(REDIRECT_KEY, stateFrom);
    }
  }, [stateFrom]);

  // Check for recovery session on mount with multiple detection methods
  useEffect(() => {
    let isMounted = true;

    const checkRecoverySession = async () => {
      // PRIORITY 1: If route is /reset-password, wait for Supabase to process token
      if (window.location.pathname === '/reset-password') {
        // Small delay to let Supabase process the hash before we check
        await new Promise(resolve => setTimeout(resolve, 300));
        
        const { data: { session } } = await supabase.auth.getSession();
        if (session && isMounted) {
          // Active session on /reset-password route = recovery mode
          setIsRecoveryMode(true);
          setCheckingRecovery(false);
          return;
        }
      }

      // PRIORITY 2: Check URL hash for recovery indicators (direct link with intact hash)
      const hashParams = new URLSearchParams(window.location.hash.substring(1));
      const type = hashParams.get('type');
      const accessToken = hashParams.get('access_token');
      
      if (type === 'recovery' && accessToken) {
        // Set the session from the recovery token
        const { error } = await supabase.auth.setSession({
          access_token: accessToken,
          refresh_token: hashParams.get('refresh_token') || '',
        });
        
        if (!error && isMounted) {
          setIsRecoveryMode(true);
          setCheckingRecovery(false);
          return;
        }
      }
      
      if (isMounted) {
        setCheckingRecovery(false);
      }
    };

    // PRIORITY 3: Listen for PASSWORD_RECOVERY event from Supabase
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (event === 'PASSWORD_RECOVERY' && isMounted) {
          // Recovery event fired by Supabase
          setIsRecoveryMode(true);
          setCheckingRecovery(false);
        }
      }
    );

    checkRecoverySession();

    return () => {
      isMounted = false;
      subscription.unsubscribe();
    };
  }, []);
  
  const isRedirectedFromProtectedRoute = from !== "/" && from.startsWith("/enviar-documentos");
  
  const defaultTab = searchParams.get("tab") === "signup" ? "signup" : "login";
  
  const [activeTab, setActiveTab] = useState<"login" | "signup">(defaultTab);
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  
  const [errors, setErrors] = useState<{
    email?: string;
    password?: string;
    fullName?: string;
    confirmPassword?: string;
  }>({});

  useEffect(() => {
    // CRITICAL: Wait for recovery check to complete before redirecting
    // Don't redirect if in recovery mode or still checking
    if (user && !authLoading && !isRecoveryMode && !checkingRecovery) {
      sessionStorage.removeItem(REDIRECT_KEY);
      navigate(from, { replace: true });
    }
  }, [user, authLoading, navigate, from, isRecoveryMode, checkingRecovery]);

  const handlePasswordResetSuccess = async () => {
    setIsRecoveryMode(false);
    
    // Check user type to redirect appropriately
    try {
      const { data: { user: currentUser } } = await supabase.auth.getUser();
      if (currentUser) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('role')
          .eq('id', currentUser.id)
          .single();
        
        if (profile?.role === 'locador') {
          navigate("/locador/home", { replace: true });
          return;
        }
      }
    } catch (err) {
      console.error('Error checking user role:', err);
    }
    
    navigate("/locatario", { replace: true });
  };

  const validateLogin = () => {
    const newErrors: typeof errors = {};
    
    try {
      emailSchema.parse(email);
    } catch (e) {
      if (e instanceof z.ZodError) {
        newErrors.email = e.errors[0].message;
      }
    }
    
    try {
      loginPasswordSchema.parse(password);
    } catch (e) {
      if (e instanceof z.ZodError) {
        newErrors.password = e.errors[0].message;
      }
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validateSignup = () => {
    const newErrors: typeof errors = {};
    
    try {
      nameSchema.parse(fullName);
    } catch (e) {
      if (e instanceof z.ZodError) {
        newErrors.fullName = e.errors[0].message;
      }
    }
    
    try {
      emailSchema.parse(email);
    } catch (e) {
      if (e instanceof z.ZodError) {
        newErrors.email = e.errors[0].message;
      }
    }
    
    try {
      signupPasswordSchema.parse(password);
    } catch (e) {
      if (e instanceof z.ZodError) {
        newErrors.password = e.errors[0].message;
      }
    }
    
    if (password !== confirmPassword) {
      newErrors.confirmPassword = "Senhas não coincidem";
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateLogin()) return;
    
    setLoading(true);
    const { error } = await login(email, password);
    setLoading(false);
    
    if (error) {
      // Anti-enumeration: generic message
      toast({
        title: "Credenciais inválidas",
        description: "Verifique seu e-mail e senha e tente novamente.",
        variant: "destructive",
      });
    } else {
      sessionStorage.removeItem(REDIRECT_KEY);
      toast({
        title: "Bem-vindo!",
        description: "Login realizado com sucesso",
      });
      navigate(from, { replace: true });
    }
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateSignup()) return;
    
    setLoading(true);
    const { error } = await register(email, password, fullName);
    setLoading(false);
    
    if (error) {
      let message = error.message || "Erro ao criar conta";
      if (error.message.includes("User already registered")) {
        message = "Este email já está cadastrado";
      } else if (
        error.message.toLowerCase().includes("weak_password") ||
        error.message.includes("Password is known to be weak")
      ) {
        message = "Senha muito fraca. Use uma senha mais forte (mín. 8 caracteres, com letras e números).";
      }
      
      toast({
        title: "Erro",
        description: message,
        variant: "destructive",
      });
    } else {
      sessionStorage.removeItem(REDIRECT_KEY);
      toast({
        title: "Conta criada!",
        description: "Você já pode acessar o sistema",
      });
      navigate(from, { replace: true });
    }
  };

  const clearForm = () => {
    setEmail("");
    setPassword("");
    setFullName("");
    setConfirmPassword("");
    setErrors({});
  };

  if (authLoading || checkingRecovery) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  // Show password reset form if in recovery mode
  if (isRecoveryMode) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-background to-muted/30">
        <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-50">
          <div className="container mx-auto px-4 py-4">
            <Link to="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
              <ArrowLeft className="h-4 w-4" />
              Voltar ao início
            </Link>
          </div>
        </header>

        <main className="container mx-auto px-4 py-12 flex items-center justify-center">
          <div className="w-full max-w-md">
            <div className="text-center mb-8">
              <Link to="/" className="inline-flex items-center gap-2">
                <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                  <span className="text-primary-foreground font-bold text-xl">E</span>
                </div>
                <span className="text-2xl font-bold">Etic Imóveis</span>
              </Link>
            </div>

            <ResetPasswordForm onSuccess={handlePasswordResetSuccess} />
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/30">
      {/* Header */}
      <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <Link to="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="h-4 w-4" />
            Voltar ao início
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12 flex items-center justify-center">
        <div className="w-full max-w-md">
          {/* Logo */}
          <div className="text-center mb-8">
            <Link to="/" className="inline-flex items-center gap-2">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-xl">E</span>
              </div>
              <span className="text-2xl font-bold">Etic Imóveis</span>
            </Link>
          </div>

          {/* Info message when redirected */}
          {isRedirectedFromProtectedRoute && (
            <div className="mb-6 p-4 bg-primary/5 border border-primary/20 rounded-lg">
              <p className="text-sm text-center text-foreground">
                Para iniciar a locação, faça login ou crie uma conta
              </p>
            </div>
          )}

          <Card className="border-0 shadow-xl">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">
                {activeTab === "login" ? "Entrar na conta" : "Criar conta"}
              </CardTitle>
              <CardDescription>
                {activeTab === "login" 
                  ? "Acesse sua conta para continuar" 
                  : "Preencha os dados para se cadastrar"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs value={activeTab} onValueChange={(v) => { setActiveTab(v as "login" | "signup"); clearForm(); }}>
                <TabsList className="grid w-full grid-cols-2 mb-6">
                  <TabsTrigger value="login">Entrar</TabsTrigger>
                  <TabsTrigger value="signup">Cadastrar</TabsTrigger>
                </TabsList>

                {/* Login Form */}
                <TabsContent value="login">
                  <form onSubmit={handleLogin} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="login-email">Email</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="login-email"
                          type="email"
                          placeholder="seu@email.com"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className={`pl-10 ${errors.email ? "border-destructive" : ""}`}
                        />
                      </div>
                      {errors.email && <p className="text-sm text-destructive">{errors.email}</p>}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="login-password">Senha</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="login-password"
                          type={showPassword ? "text" : "password"}
                          placeholder="••••••••"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          className={`pl-10 pr-10 ${errors.password ? "border-destructive" : ""}`}
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                        >
                          {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                      </div>
                      {errors.password && <p className="text-sm text-destructive">{errors.password}</p>}
                    </div>

                    <Button type="submit" className="w-full" size="lg" disabled={loading}>
                      {loading ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Entrando...
                        </>
                      ) : (
                        "Entrar"
                      )}
                    </Button>
                  </form>
                </TabsContent>

                {/* Signup Form */}
                <TabsContent value="signup">
                  <form onSubmit={handleSignup} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="signup-name">Nome completo</Label>
                      <div className="relative">
                        <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="signup-name"
                          type="text"
                          placeholder="Seu nome completo"
                          value={fullName}
                          onChange={(e) => setFullName(e.target.value)}
                          className={`pl-10 ${errors.fullName ? "border-destructive" : ""}`}
                        />
                      </div>
                      {errors.fullName && <p className="text-sm text-destructive">{errors.fullName}</p>}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="signup-email">Email</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="signup-email"
                          type="email"
                          placeholder="seu@email.com"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className={`pl-10 ${errors.email ? "border-destructive" : ""}`}
                        />
                      </div>
                      {errors.email && <p className="text-sm text-destructive">{errors.email}</p>}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="signup-password">Senha</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="signup-password"
                          type={showPassword ? "text" : "password"}
                          placeholder="••••••••"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          className={`pl-10 pr-10 ${errors.password ? "border-destructive" : ""}`}
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                        >
                          {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                      </div>
                      {errors.password && <p className="text-sm text-destructive">{errors.password}</p>}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="signup-confirm">Confirmar senha</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="signup-confirm"
                          type="password"
                          placeholder="••••••••"
                          value={confirmPassword}
                          onChange={(e) => setConfirmPassword(e.target.value)}
                          className={`pl-10 ${errors.confirmPassword ? "border-destructive" : ""}`}
                        />
                      </div>
                      {errors.confirmPassword && <p className="text-sm text-destructive">{errors.confirmPassword}</p>}
                    </div>

                    <Button type="submit" className="w-full" size="lg" disabled={loading}>
                      {loading ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Criando conta...
                        </>
                      ) : (
                        "Criar conta"
                      )}
                    </Button>
                  </form>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          {/* Forgot Password Link */}
          <div className="text-center mt-4">
            <ForgotPasswordDialog />
          </div>

          {/* Footer */}
          <p className="text-center text-sm text-muted-foreground mt-4">
            Ao continuar, você concorda com nossos{" "}
            <Link to="/termos" className="underline hover:text-foreground">Termos de Uso</Link>
            {" "}e{" "}
            <Link to="/privacidade" className="underline hover:text-foreground">Política de Privacidade</Link>
          </p>
        </div>
      </main>
    </div>
  );
}
