import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Shield, AlertTriangle, Lock, RefreshCw } from 'lucide-react';

type SecurityEvent = {
  id: string;
  event_type: string;
  identifier_hash: string | null;
  metadata: Record<string, unknown> | null;
  created_at: string;
};

const EVENT_TYPE_LABELS: Record<string, string> = {
  rate_limit_block: 'Rate Limit',
  signed_url_error: 'Signed URL Error',
  login_failure: 'Login Failure',
  admin_reauth: 'Admin Re-Auth',
};

export default function SecurityDashboard() {
  const [events, setEvents] = useState<SecurityEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    rateLimitBlocks24h: 0,
    signedUrlErrors24h: 0,
    loginFailures24h: 0,
  });

  const loadData = async () => {
    setLoading(true);
    try {
      const since24h = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();

      // Fetch recent events (last 50)
      const { data: evts } = await supabase
        .from('security_events')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(50);

      setEvents((evts ?? []) as SecurityEvent[]);

      // Compute 24h stats
      const recent = (evts ?? []).filter((e: any) => e.created_at >= since24h);
      setStats({
        rateLimitBlocks24h: recent.filter((e: any) => e.event_type === 'rate_limit_block').length,
        signedUrlErrors24h: recent.filter((e: any) => e.event_type === 'signed_url_error').length,
        loginFailures24h: recent.filter((e: any) => e.event_type === 'login_failure').length,
      });
    } catch (e) {
      console.error('Error loading security events:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadData(); }, []);

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 h-14 flex items-center gap-4">
          <Button variant="ghost" size="sm" asChild>
            <Link to="/admin"><ArrowLeft className="h-4 w-4 mr-1" />Admin</Link>
          </Button>
          <Shield className="h-5 w-5 text-primary" />
          <h1 className="font-semibold">Segurança</h1>
          <div className="ml-auto">
            <Button variant="outline" size="sm" onClick={loadData} disabled={loading}>
              <RefreshCw className={`h-4 w-4 mr-1 ${loading ? 'animate-spin' : ''}`} />
              Atualizar
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6 space-y-6">
        {/* KPI Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-destructive/10">
                  <Lock className="h-5 w-5 text-destructive" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stats.rateLimitBlocks24h}</p>
                  <p className="text-xs text-muted-foreground">Rate Limit Blocks (24h)</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-yellow-500/10">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stats.signedUrlErrors24h}</p>
                  <p className="text-xs text-muted-foreground">Signed URL Errors (24h)</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-primary/10">
                  <Shield className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stats.loginFailures24h}</p>
                  <p className="text-xs text-muted-foreground">Login Failures (24h)</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Events Log */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Eventos de Segurança (últimos 50)</CardTitle>
          </CardHeader>
          <CardContent>
            {events.length === 0 ? (
              <p className="text-muted-foreground text-sm">Nenhum evento registrado.</p>
            ) : (
              <div className="space-y-2">
                {events.map((evt) => (
                  <div key={evt.id} className="flex items-center gap-3 border rounded-lg p-3 text-sm">
                    <Badge variant={evt.event_type === 'rate_limit_block' ? 'destructive' : 'outline'}>
                      {EVENT_TYPE_LABELS[evt.event_type] ?? evt.event_type}
                    </Badge>
                    <span className="text-muted-foreground font-mono text-xs">
                      {evt.identifier_hash ? `...${evt.identifier_hash.substring(0, 8)}` : '—'}
                    </span>
                    {evt.metadata && (
                      <span className="text-xs text-muted-foreground">
                        {Object.entries(evt.metadata as Record<string, unknown>)
                          .filter(([k]) => !['identifier'].includes(k))
                          .map(([k, v]) => `${k}: ${v}`)
                          .join(' • ')}
                      </span>
                    )}
                    <span className="text-xs text-muted-foreground ml-auto whitespace-nowrap">
                      {new Date(evt.created_at).toLocaleString('pt-BR')}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
