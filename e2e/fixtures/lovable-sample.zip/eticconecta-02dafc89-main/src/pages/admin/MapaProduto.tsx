import { Link, useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertTriangle, CheckSquare, User, Building, Shield, Wrench, GitBranch, Play } from "lucide-react";

type RouteItem = {
  path: string;
  label: string;
  description: string;
  isPublic?: boolean;
  hasParam?: boolean;
  paramNote?: string;
};

type ParamRouteItem = {
  pattern: string;
  example: string;
  description: string;
  note: string;
};

const locatarioRoutes: RouteItem[] = [
  { path: "/locatario", label: "/locatario", description: "Landing page do locatário", isPublic: true },
  { path: "/locatario/login", label: "/locatario/login", description: "Login do locatário", isPublic: true },
  { path: "/locatario/register", label: "/locatario/register", description: "Cadastro do locatário", isPublic: true },
  { path: "/locatario/selecionar-imovel", label: "/locatario/selecionar-imovel", description: "Busca e seleção de imóveis", isPublic: true },
  { path: "/locatario/painel", label: "/locatario/painel", description: "Dashboard principal do locatário" },
  { path: "/locatario/meu-cadastro", label: "/locatario/meu-cadastro", description: "Dados cadastrais do locatário" },
  { path: "/locatario/acompanhamento", label: "/locatario/acompanhamento", description: "Acompanhamento de propostas" },
];

const locadorRoutes: RouteItem[] = [
  { path: "/locador/auth", label: "/locador/auth", description: "Login/cadastro do locador", isPublic: true },
  { path: "/locador/home", label: "/locador/home", description: "Dashboard do locador" },
  { path: "/locador/propostas", label: "/locador/propostas", description: "Lista de propostas recebidas" },
  { path: "/locador/imoveis", label: "/locador/imoveis", description: "Gestão de imóveis do locador" },
  { path: "/locador/anunciar", label: "/locador/anunciar", description: "Anunciar novo imóvel" },
  { path: "/locador/ajuda", label: "/locador/ajuda", description: "Central de ajuda do locador" },
];

const adminRoutes: RouteItem[] = [
  { path: "/admin", label: "/admin", description: "Kanban operacional + Analytics" },
  { path: "/admin/invites", label: "/admin/invites", description: "Gestão de convites de imóveis" },
  { path: "/mapa", label: "/mapa", description: "Esta página (Mapa do Produto)" },
];

const utilityRoutes: RouteItem[] = [
  { path: "/privacidade", label: "/privacidade", description: "Portal de privacidade (LGPD)", isPublic: true },
  { path: "/convite/SEU_TOKEN_AQUI", label: "/convite/:token", description: "Aceitar convite de imóvel", isPublic: true, hasParam: true, paramNote: "Substitua SEU_TOKEN_AQUI pelo token real recebido por e-mail." },
  { path: "/auth", label: "/auth", description: "Página legada de autenticação (redirect)", isPublic: true },
  { path: "/reset-password", label: "/reset-password", description: "Fluxo de redefinição de senha", isPublic: true },
];

const paramRoutes: ParamRouteItem[] = [
  { pattern: "/convite/:token", example: "/convite/EXEMPLO_TOKEN", description: "Aceitar convite de imóvel", note: "Precisa existir no banco" },
  { pattern: "/locatario/enviar-documentos/:id", example: "/locatario/enviar-documentos/EXEMPLO_ID", description: "Envio de documentos da proposta", note: "Precisa existir no banco" },
  { pattern: "/locatario/envio-sucesso/:id", example: "/locatario/envio-sucesso/EXEMPLO_ID", description: "Confirmação de envio", note: "Precisa existir no banco" },
  { pattern: "/locatario/acompanhamento/:id?", example: "/locatario/acompanhamento/EXEMPLO_ID", description: "Acompanhamento de proposta", note: "Parâmetro id é opcional — funciona com ou sem id" },
  { pattern: "/locador/proposta/:protocolo", example: "/locador/proposta/EXEMPLO_PROTOCOLO", description: "Detalhes da proposta do locador", note: "Precisa existir no banco" },
];

const testChecklist = [
  "Login locatário funciona e redireciona para /locatario/painel",
  "Login locador funciona e redireciona para /locador/home",
  "Sessão expirada redireciona para login correto por contexto (/locatario/login ou /locador/auth)",
  "Acesso negado (role errada) redireciona para dashboard do perfil correto",
  "/privacidade acessível sem login",
  "/convite/:token aceita convite e redireciona corretamente",
];

function RouteList({ routes }: { routes: RouteItem[] }) {
  return (
    <ul className="space-y-3">
      {routes.map((r) => (
        <li key={r.path} className="flex flex-col gap-1">
          <div className="flex items-center gap-2 flex-wrap">
            <Link
              to={r.hasParam ? "#" : r.path}
              className="font-mono text-sm text-primary hover:underline"
              onClick={r.hasParam ? (e) => e.preventDefault() : undefined}
            >
              {r.label}
            </Link>
            <Badge variant={r.isPublic ? "secondary" : "default"} className="text-xs">
              {r.isPublic ? "Pública" : "Protegida"}
            </Badge>
          </div>
          <p className="text-sm text-muted-foreground">{r.description}</p>
          {r.hasParam && r.paramNote && (
            <p className="text-xs text-muted-foreground italic">⚠️ {r.paramNote}</p>
          )}
        </li>
      ))}
    </ul>
  );
}

export default function MapaProduto() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-5xl space-y-6">
        {/* Warning */}
        <Card className="border-destructive/50 bg-destructive/5">
          <CardContent className="flex items-center gap-3 py-4">
            <AlertTriangle className="h-5 w-5 text-destructive shrink-0" />
            <p className="text-sm text-destructive">
              Página interna para revisão do fluxo. Não expor ao público.
            </p>
          </CardContent>
        </Card>

        <h1 className="text-3xl font-bold">Mapa do Produto (Revisão)</h1>
        <p className="text-muted-foreground">
          Visão geral de todas as rotas do sistema, organizadas por perfil de usuário.
        </p>

        {/* Route cards grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-lg">
                <User className="h-5 w-5" />
                Locatário
              </CardTitle>
            </CardHeader>
            <CardContent>
              <RouteList routes={locatarioRoutes} />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Building className="h-5 w-5" />
                Locador
              </CardTitle>
            </CardHeader>
            <CardContent>
              <RouteList routes={locadorRoutes} />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Shield className="h-5 w-5" />
                Admin
              </CardTitle>
            </CardHeader>
            <CardContent>
              <RouteList routes={adminRoutes} />
            </CardContent>
          </Card>
        </div>

        {/* Utility routes */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Wrench className="h-5 w-5" />
              Rotas Utilitárias
            </CardTitle>
          </CardHeader>
          <CardContent>
            <RouteList routes={utilityRoutes} />
          </CardContent>
        </Card>

        {/* Parameterized routes */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-lg">
              <GitBranch className="h-5 w-5" />
              Rotas com Parâmetros (exemplos)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-4">
              {paramRoutes.map((r) => (
                <li key={r.pattern} className="flex flex-col gap-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-mono text-sm text-muted-foreground">{r.pattern}</span>
                    <Badge variant="outline" className="text-xs">Exemplo</Badge>
                  </div>
                  <Link to={r.example} className="font-mono text-sm text-primary hover:underline">
                    {r.example}
                  </Link>
                  <p className="text-sm text-muted-foreground">{r.description}</p>
                  <p className="text-xs text-muted-foreground italic">⚠️ {r.note}</p>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        {/* Test checklist */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-lg">
              <CheckSquare className="h-5 w-5" />
              Testes Rápidos
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ol className="space-y-3 list-decimal list-inside">
              {testChecklist.map((item, i) => (
                <li key={i} className="text-sm text-muted-foreground">
                  {item}
                </li>
              ))}
            </ol>
          </CardContent>
        </Card>

        {/* Quick test buttons */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Play className="h-5 w-5" />
              Testar Fluxos
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-3">
              <Button variant="outline" size="sm" onClick={() => navigate("/locatario/painel")}>
                <User className="mr-2 h-4 w-4" />
                Testar como Locatário
              </Button>
              <Button variant="outline" size="sm" onClick={() => navigate("/locador/home")}>
                <Building className="mr-2 h-4 w-4" />
                Testar como Locador
              </Button>
              <Button variant="outline" size="sm" onClick={() => navigate("/admin")}>
                <Shield className="mr-2 h-4 w-4" />
                Testar Admin
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
