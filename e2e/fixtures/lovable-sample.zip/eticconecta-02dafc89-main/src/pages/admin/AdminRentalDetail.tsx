import { useEffect, useState, useMemo } from 'react';
import { useParams, Link } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { toast } from 'sonner';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { ArrowLeft, AlertTriangle, Check, ExternalLink, FileText, Download, Eye, Copy, ChevronDown, ChevronUp } from 'lucide-react';
import { setRentalStepAndLog, logRentalEvent, fetchProposals, fetchContract, fetchInspection, EVENT_LABELS, runConsistencyChecks, type ProposalRow, type ContractRow, type InspectionRow } from '@/lib/proposalEvents';
import { buildCrmReadyPayload } from '@/lib/buildCrmReadyPayload';
import { ReAuthDialog } from '@/components/auth/ReAuthDialog';

// ── Step Labels ──
const STEP_LABELS: Record<number, string> = {
  1: 'Proposta inicial',
  2: 'Negociação',
  3: 'Documentos locatário',
  4: 'Revisão / Triagem',
  5: 'Análise ficha + Docs locador',
  6: 'Emissão do contrato',
  7: 'Assinatura do contrato',
  8: 'Contrato assinado',
  9: 'Vistoria / Laudo',
  10: 'Chaves entregues',
};

function formatMoney(v: number | null | undefined) {
  if (v == null) return '—';
  return `R$ ${Number(v).toLocaleString('pt-BR')}`;
}

function formatDate(d: string | null | undefined) {
  if (!d) return '—';
  return new Date(d).toLocaleString('pt-BR');
}

type DocRow = {
  id: string;
  file_name: string;
  file_path: string;
  file_type: string;
  document_type: string;
  status: string;
  created_at: string;
  bucket: 'documents' | 'landlord-documents';
};

type EventRow = {
  id: string;
  event_type: string;
  description: string;
  created_at: string | null;
  created_by: string | null;
  idempotency_key: string | null;
  metadata: Record<string, unknown> | null;
  author_name?: string | null;
};

type LandlordDataRow = {
  full_name: string | null;
  email: string | null;
  phone: string | null;
  profession: string | null;
  marital_status: string | null;
  bank_name: string | null;
  bank_agency: string | null;
  bank_account: string | null;
  bank_account_type: string | null;
  pix_key: string | null;
  bills_responsible: string | null;
  has_second_landlord: boolean | null;
  second_landlord_name: string | null;
  second_landlord_email: string | null;
  second_landlord_phone: string | null;
};

export default function AdminRentalDetail() {
  const { rentalId } = useParams<{ rentalId: string }>();
  const { user } = useAuth();

  const [rental, setRental] = useState<any>(null);
  const [tenant, setTenant] = useState<any>(null);
  const [landlordData, setLandlordData] = useState<LandlordDataRow | null>(null);
  const [tenantDocs, setTenantDocs] = useState<DocRow[]>([]);
  const [landlordDocs, setLandlordDocs] = useState<DocRow[]>([]);
  const [events, setEvents] = useState<EventRow[]>([]);
  const [proposals, setProposals] = useState<ProposalRow[]>([]);
  const [contract, setContract] = useState<ContractRow | null>(null);
  const [inspection, setInspection] = useState<InspectionRow | null>(null);
  const [loading, setLoading] = useState(true);
  const [showAllEvents, setShowAllEvents] = useState(false);

  // Override state
  const [overrideStep, setOverrideStep] = useState('');
  const [overrideReason, setOverrideReason] = useState('');
  const [overrideLoading, setOverrideLoading] = useState(false);

  const loadAll = async () => {
    if (!rentalId) return;
    setLoading(true);
    try {
      // Rental
      const { data: r } = await supabase
        .from('rentals')
        .select('*')
        .eq('id', rentalId)
        .maybeSingle();
      if (!r) { toast.error('Rental não encontrado'); return; }
      setRental(r);

      // Tenant
      const { data: t } = await supabase
        .from('profiles')
        .select('id, full_name, email, phone, birth_date, nationality, nationality_country, marital_status, profession, monthly_income, is_politically_exposed')
        .eq('id', r.user_id)
        .maybeSingle();
      setTenant(t);

      // Landlord data
      const { data: ld } = await supabase
        .from('landlord_data')
        .select('full_name, email, phone, profession, marital_status, bank_name, bank_agency, bank_account, bank_account_type, pix_key, bills_responsible, has_second_landlord, second_landlord_name, second_landlord_email, second_landlord_phone')
        .eq('rental_id', rentalId)
        .maybeSingle();
      setLandlordData(ld as any);

      // Tenant docs
      const { data: td } = await supabase
        .from('documents')
        .select('id, file_name, file_path, file_type, document_type, status, created_at')
        .eq('rental_id', rentalId)
        .order('created_at', { ascending: false });
      setTenantDocs((td ?? []).map((d: any) => ({ ...d, bucket: 'documents' })));

      // Landlord docs
      const { data: ldd } = await supabase
        .from('landlord_documents')
        .select('id, file_name, file_path, file_type, document_type, status, created_at')
        .eq('rental_id', rentalId)
        .order('created_at', { ascending: false });
      setLandlordDocs((ldd ?? []).map((d: any) => ({ ...d, bucket: 'landlord-documents' })));

      // Events
      const { data: evts } = await supabase
        .from('rental_events')
        .select('id, event_type, description, created_at, created_by, idempotency_key, metadata')
        .eq('rental_id', rentalId)
        .order('created_at', { ascending: false });

      const baseEvents = (evts ?? []) as EventRow[];
      const authorIds = [...new Set(baseEvents.map(e => e.created_by).filter(Boolean) as string[])];
      if (authorIds.length) {
        const { data: authors } = await supabase.from('profiles').select('id, full_name').in('id', authorIds);
        const map = new Map((authors ?? []).map((a: any) => [a.id, a.full_name]));
        baseEvents.forEach(e => { if (e.created_by) e.author_name = map.get(e.created_by) ?? null; });
      }
      setEvents(baseEvents);

      // Proposals
      const p = await fetchProposals(rentalId);
      setProposals(p);

      // Contract
      const c = await fetchContract(rentalId);
      setContract(c);

      // Inspection
      const i = await fetchInspection(rentalId);
      setInspection(i);
    } catch (e: any) {
      toast.error(e?.message ?? 'Erro ao carregar dados');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadAll(); }, [rentalId]);

  // ── QA checks ──
  const qaChecks = useMemo(() => {
    if (!rental) return [];
    const missingTypes: string[] = [];
    if (rental.pending_documents) {
      try {
        const pd = typeof rental.pending_documents === 'string' ? JSON.parse(rental.pending_documents) : rental.pending_documents;
        if (Array.isArray(pd)) missingTypes.push(...pd);
      } catch {}
    }
    return runConsistencyChecks({
      currentStep: rental.current_step ?? 1,
      proposalStatus: rental.proposal_status ?? '',
      documentsFinalizedAt: rental.documents_finalized_at ? new Date(rental.documents_finalized_at) : undefined,
      documentsCycle: rental.documents_cycle ?? 1,
      missingTypes,
      events: events.map(e => ({ eventType: e.event_type })),
      proposals,
      isRejected: rental.is_rejected ?? false,
    });
  }, [rental, events, proposals]);

  const qaOk = qaChecks.every(c => c.ok);
  const qaFailing = qaChecks.filter(c => !c.ok);

  // Re-auth state
  const [showReAuth, setShowReAuth] = useState(false);
  const [pendingOverride, setPendingOverride] = useState(false);

  // ── Override handler with re-authentication ──
  const requestOverride = () => {
    if (!rental || !rentalId || !user) return;
    const targetStep = parseInt(overrideStep);
    if (isNaN(targetStep) || targetStep < 1 || targetStep > 10) {
      toast.error('Step inválido (1-10)');
      return;
    }
    if (!overrideReason.trim()) {
      toast.error('Motivo é obrigatório');
      return;
    }
    // Require re-authentication
    setPendingOverride(true);
    setShowReAuth(true);
  };

  const handleOverride = async () => {
    if (!rental || !rentalId || !user) return;
    const targetStep = parseInt(overrideStep);
    if (isNaN(targetStep) || targetStep < 1 || targetStep > 10) {
      toast.error('Step inválido (1-10)');
      return;
    }
    if (!overrideReason.trim()) {
      toast.error('Motivo é obrigatório');
      return;
    }

    setOverrideLoading(true);
    try {
      const fromStep = rental.current_step ?? 1;

      const success = await setRentalStepAndLog({
        rentalId,
        newStep: targetStep,
        reason: `Admin override: ${overrideReason.trim()}`,
        metadata: {
          source: 'admin_override',
          admin_user_id: user.id,
          from_step: fromStep,
          to_step: targetStep,
          reason: overrideReason.trim(),
        },
      });

      if (!success) {
        toast.error('Falha ao alterar etapa');
        return;
      }

      // Log explicit admin_step_override event
      await logRentalEvent({
        rentalId,
        eventType: 'admin_step_override',
        description: `Admin alterou etapa manualmente: ${fromStep} → ${targetStep}. Motivo: ${overrideReason.trim()}`,
        metadata: {
          from_step: fromStep,
          to_step: targetStep,
          reason: overrideReason.trim(),
          admin_user_id: user.id,
        },
      });

      toast.success(`Etapa alterada: ${fromStep} → ${targetStep}`);
      setOverrideStep('');
      setOverrideReason('');
      await loadAll();
    } catch (e: any) {
      toast.error(e?.message ?? 'Erro ao alterar etapa');
    } finally {
      setOverrideLoading(false);
    }
  };

  // ── Signed URL helper (60s TTL) ──
  const openSignedUrl = async (doc: DocRow) => {
    try {
      const { data, error } = await supabase.storage.from(doc.bucket).createSignedUrl(doc.file_path, 60);
      if (error) throw error;
      window.open(data.signedUrl, '_blank', 'noopener,noreferrer');
    } catch (e: any) {
      toast.error(e?.message ?? 'Erro ao abrir documento');
    }
  };

  const copySignedUrl = async (doc: DocRow) => {
    try {
      const { data, error } = await supabase.storage.from(doc.bucket).createSignedUrl(doc.file_path, 60);
      if (error) throw error;
      await navigator.clipboard.writeText(data.signedUrl);
      toast.success('URL copiada!');
    } catch (e: any) {
      toast.error(e?.message ?? 'Erro ao copiar URL');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">Carregando...</p>
      </div>
    );
  }

  if (!rental) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <p className="text-muted-foreground">Rental não encontrado</p>
          <Button asChild><Link to="/admin">Voltar</Link></Button>
        </div>
      </div>
    );
  }

  const currentStep = rental.current_step ?? 1;
  const visibleEvents = showAllEvents ? events : events.slice(0, 5);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 h-14 flex items-center gap-4">
          <Button variant="ghost" size="sm" asChild>
            <Link to="/admin"><ArrowLeft className="h-4 w-4 mr-1" />Admin</Link>
          </Button>
          <Separator orientation="vertical" className="h-6" />
          <div className="flex items-center gap-2 min-w-0">
            <Badge variant="outline">{rental.protocol}</Badge>
            <Badge variant="secondary">{rental.property_code}</Badge>
            <Badge className={rental.is_rejected ? 'bg-destructive' : currentStep >= 10 ? 'bg-step-complete' : 'bg-primary'}>
              Etapa {currentStep}
            </Badge>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6 space-y-6">
        {/* ── 5.1 Step Timeline ── */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Fluxo de Locação (Steps 1–10)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto pb-2">
              <div className="flex items-start gap-1 min-w-max">
                {Array.from({ length: 10 }, (_, i) => i + 1).map((step) => {
                  const isComplete = step < currentStep;
                  const isCurrent = step === currentStep;
                  return (
                    <div key={step} className="flex items-center">
                      <div className="flex flex-col items-center" style={{ width: 72 }}>
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                          isComplete ? 'bg-step-complete text-step-complete-foreground' :
                          isCurrent ? 'bg-primary text-primary-foreground ring-2 ring-primary/30' :
                          'bg-muted text-muted-foreground'
                        }`}>
                          {isComplete ? <Check className="h-4 w-4" /> : step}
                        </div>
                        <span className={`text-[10px] mt-1 text-center leading-tight ${
                          isComplete ? 'text-step-complete font-medium' :
                          isCurrent ? 'text-primary font-semibold' :
                          'text-muted-foreground'
                        }`}>
                          {STEP_LABELS[step]}
                        </span>
                      </div>
                      {step < 10 && (
                        <div className={`h-0.5 w-4 mt-[-16px] ${isComplete ? 'bg-step-complete' : 'bg-muted'}`} />
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
            <div className="mt-3 flex flex-wrap gap-3 text-xs">
              <span><strong>Status:</strong> {rental.step_status ?? '—'}</span>
              <span><strong>Proposta:</strong> {rental.proposal_status ?? '—'}</span>
              <span><strong>Tenant:</strong> {rental.tenant_status ?? '—'}</span>
              {rental.is_rejected && <Badge variant="destructive">Rejeitado</Badge>}
              <span><strong>Criado:</strong> {formatDate(rental.created_at)}</span>
              <span><strong>Atualizado:</strong> {formatDate(rental.updated_at)}</span>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* ── 5.2 Tenant Data ── */}
          <Card>
            <CardHeader className="pb-3"><CardTitle className="text-lg">Locatário</CardTitle></CardHeader>
            <CardContent className="space-y-1 text-sm">
              <Field label="Nome" value={tenant?.full_name} />
              <Field label="Email" value={tenant?.email} />
              <Field label="Telefone" value={tenant?.phone} />
              <Field label="Nascimento" value={tenant?.birth_date} />
              <Field label="Nacionalidade" value={tenant?.nationality} />
              <Field label="Estado Civil" value={tenant?.marital_status} />
              <Field label="Profissão" value={tenant?.profession} />
              <Field label="Renda" value={tenant?.monthly_income ? formatMoney(tenant.monthly_income) : undefined} />
              <Field label="PEP" value={tenant?.is_politically_exposed ? 'Sim' : 'Não'} />
              {rental.is_rejected && <Field label="Motivo rejeição" value={rental.rejection_reason} />}
              <p className="text-xs text-muted-foreground mt-2">CPF armazenado de forma criptografada (LGPD)</p>
            </CardContent>
          </Card>

          {/* ── 5.3 Landlord Data ── */}
          <Card>
            <CardHeader className="pb-3"><CardTitle className="text-lg">Locador</CardTitle></CardHeader>
            <CardContent className="space-y-1 text-sm">
              {landlordData ? (
                <>
                  <Field label="Nome" value={landlordData.full_name} />
                  <Field label="Email" value={landlordData.email} />
                  <Field label="Telefone" value={landlordData.phone} />
                  <Field label="Profissão" value={landlordData.profession} />
                  <Field label="Estado Civil" value={landlordData.marital_status} />
                  <Field label="Resp. Contas" value={landlordData.bills_responsible} />
                  <Separator className="my-2" />
                  <p className="font-medium text-xs">Dados bancários</p>
                  <Field label="Banco" value={landlordData.bank_name} />
                  <Field label="Agência" value={landlordData.bank_agency} />
                  <Field label="Conta" value={`${landlordData.bank_account ?? '—'} (${landlordData.bank_account_type ?? '—'})`} />
                  <Field label="PIX" value={landlordData.pix_key} />
                  {landlordData.has_second_landlord && (
                    <>
                      <Separator className="my-2" />
                      <p className="font-medium text-xs">2º Locador</p>
                      <Field label="Nome" value={landlordData.second_landlord_name} />
                      <Field label="Email" value={landlordData.second_landlord_email} />
                      <Field label="Telefone" value={landlordData.second_landlord_phone} />
                    </>
                  )}
                </>
              ) : (
                <p className="text-muted-foreground">Dados do locador ainda não preenchidos.</p>
              )}
            </CardContent>
          </Card>
        </div>

        {/* ── 5.4 Documents ── */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">
              Documentos
              <span className="ml-2 text-xs font-normal text-muted-foreground">
                Ciclo {rental.documents_cycle ?? 1}
                {rental.documents_finalized_at && ` • Finalizado em ${formatDate(rental.documents_finalized_at)}`}
              </span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <DocSection title="Locatário" docs={tenantDocs} onOpen={openSignedUrl} onCopy={copySignedUrl} />
              <DocSection title="Locador" docs={landlordDocs} onOpen={openSignedUrl} onCopy={copySignedUrl} />
              {rental.pending_documents && Array.isArray(rental.pending_documents) && rental.pending_documents.length > 0 && (
                <div className="p-3 rounded-lg bg-destructive/10 text-destructive text-sm">
                  <AlertTriangle className="h-4 w-4 inline mr-1" />
                  Documentos pendentes: {rental.pending_documents.join(', ')}
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* ── 5.5 Contract ── */}
          <Card>
            <CardHeader className="pb-3"><CardTitle className="text-lg">Contrato</CardTitle></CardHeader>
            <CardContent className="text-sm space-y-2">
              {contract ? (
                <>
                  <Field label="Status" value={contract.status} />
                  <Field label="Criado" value={formatDate(contract.created_at)} />
                  {contract.preview_url && (
                    <a href={contract.preview_url} target="_blank" rel="noopener noreferrer" className="text-primary text-xs flex items-center gap-1">
                      <Eye className="h-3 w-3" /> Preview
                    </a>
                  )}
                  {contract.signature_url && (
                    <a href={contract.signature_url} target="_blank" rel="noopener noreferrer" className="text-primary text-xs flex items-center gap-1">
                      <ExternalLink className="h-3 w-3" /> Assinatura
                    </a>
                  )}
                  <Field label="Locatário assinou" value={contract.signed_by_tenant_at ? formatDate(contract.signed_by_tenant_at) : 'Não'} />
                  <Field label="Locador assinou" value={contract.signed_by_landlord_at ? formatDate(contract.signed_by_landlord_at) : 'Não'} />
                </>
              ) : (
                <p className="text-muted-foreground">Contrato ainda não emitido.</p>
              )}
            </CardContent>
          </Card>

          {/* ── 5.6 Inspection ── */}
          <Card>
            <CardHeader className="pb-3"><CardTitle className="text-lg">Vistoria / Chaves</CardTitle></CardHeader>
            <CardContent className="text-sm space-y-2">
              {inspection ? (
                <>
                  <Field label="Status" value={inspection.status} />
                  <Field label="Data" value={inspection.scheduled_date ?? '—'} />
                  <Field label="Hora" value={inspection.scheduled_time ?? '—'} />
                  <Field label="Locatário assinou laudo" value={inspection.signed_by_tenant_at ? formatDate(inspection.signed_by_tenant_at) : 'Não'} />
                  <Field label="Locador assinou laudo" value={inspection.signed_by_landlord_at ? formatDate(inspection.signed_by_landlord_at) : 'Não'} />
                  <Field label="Chaves entregues" value={inspection.keys_delivered_at ? formatDate(inspection.keys_delivered_at) : 'Não'} />
                </>
              ) : (
                <p className="text-muted-foreground">Vistoria ainda não agendada.</p>
              )}
            </CardContent>
          </Card>
        </div>

        {/* ── Proposals ── */}
        {proposals.length > 0 && (
          <Card>
            <CardHeader className="pb-3"><CardTitle className="text-lg">Propostas / Negociação</CardTitle></CardHeader>
            <CardContent>
              <div className="space-y-2">
                {proposals.map(p => (
                  <div key={p.id} className="flex items-center gap-3 text-sm border rounded-lg p-3">
                    <Badge variant={p.author === 'tenant' ? 'default' : 'secondary'}>{p.author === 'tenant' ? 'Locatário' : 'Locador'}</Badge>
                    <span className="font-medium">{formatMoney(p.rent_value)}/mês</span>
                    {p.deposit_value && <span className="text-muted-foreground">Depósito: {formatMoney(p.deposit_value)}</span>}
                    <Badge variant="outline">{p.status}</Badge>
                    <span className="text-xs text-muted-foreground ml-auto">{formatDate(p.created_at)}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* ── 5.7 History + QA ── */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              Histórico
              <Badge variant="outline">{events.length} eventos</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {visibleEvents.map(e => (
                <div key={e.id} className="border rounded-lg p-3 text-sm">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge variant="outline" className="text-xs">{EVENT_LABELS[e.event_type] ?? e.event_type}</Badge>
                        {e.author_name && <span className="text-xs text-muted-foreground">por {e.author_name}</span>}
                      </div>
                      <p className="text-muted-foreground mt-1">{e.description}</p>
                      {e.idempotency_key && <p className="text-xs text-muted-foreground/60 mt-0.5 font-mono">{e.idempotency_key}</p>}
                    </div>
                    <span className="text-xs text-muted-foreground whitespace-nowrap">{formatDate(e.created_at)}</span>
                  </div>
                </div>
              ))}
              {events.length > 5 && (
                <Button variant="ghost" size="sm" className="w-full" onClick={() => setShowAllEvents(!showAllEvents)}>
                  {showAllEvents ? <><ChevronUp className="h-4 w-4 mr-1" />Mostrar menos</> : <><ChevronDown className="h-4 w-4 mr-1" />Ver todos ({events.length})</>}
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {/* ── QA Panel ── */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              QA / Consistência
              <Badge variant={qaOk ? 'default' : 'destructive'}>{qaOk ? 'OK' : `${qaFailing.length} falha(s)`}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-1">
              {qaChecks.map((c, i) => (
                <div key={i} className={`flex items-center gap-2 text-sm py-1 ${c.ok ? 'text-step-complete' : 'text-destructive'}`}>
                  {c.ok ? <Check className="h-3.5 w-3.5" /> : <AlertTriangle className="h-3.5 w-3.5" />}
                  <span>{c.label}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* ── 6. Admin Override ── */}
        <Card className="border-primary/30">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Alterar etapa manualmente (Admin Override)</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Etapa atual: {currentStep} — {STEP_LABELS[currentStep]}</Label>
                <Select value={overrideStep} onValueChange={setOverrideStep}>
                  <SelectTrigger><SelectValue placeholder="Selecionar step destino" /></SelectTrigger>
                  <SelectContent>
                    {Array.from({ length: 10 }, (_, i) => i + 1).filter(s => s !== currentStep).map(s => (
                      <SelectItem key={s} value={String(s)}>{s} — {STEP_LABELS[s]}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Motivo (obrigatório)</Label>
                <Textarea
                  value={overrideReason}
                  onChange={e => setOverrideReason(e.target.value)}
                  placeholder="Ex.: Cliente solicitou reprocessamento de documentos..."
                  className="min-h-20"
                />
              </div>
            </div>
            {overrideStep && parseInt(overrideStep) > currentStep + 1 && (
              <div className="p-3 rounded-lg bg-destructive/10 text-destructive text-sm flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 shrink-0" />
                Atenção: você está pulando etapas. Isto será registrado na auditoria.
              </div>
            )}
            <Button onClick={requestOverride} disabled={overrideLoading || !overrideStep || !overrideReason.trim()}>
              {overrideLoading ? 'Alterando...' : 'Confirmar alteração (requer senha)'}
            </Button>
          </CardContent>
        </Card>

        {/* ── CRM info (read-only) ── */}
        {(rental.crm_deal_id || rental.crm_provider) && (
          <Card>
            <CardHeader className="pb-3"><CardTitle className="text-lg">CRM</CardTitle></CardHeader>
            <CardContent className="text-sm space-y-1">
              <Field label="Provider" value={rental.crm_provider} />
              <Field label="Deal ID" value={rental.crm_deal_id} />
              <Field label="Último sync" value={rental.crm_last_sync_at ? formatDate(rental.crm_last_sync_at) : undefined} />
            </CardContent>
          </Card>
        )}

        {/* Re-Auth Dialog */}
        <ReAuthDialog
          open={showReAuth}
          onOpenChange={(open) => {
            setShowReAuth(open);
            if (!open) setPendingOverride(false);
          }}
          onSuccess={() => {
            setPendingOverride(false);
            handleOverride();
          }}
          title="Confirmar Admin Override"
          description="Esta ação altera a etapa do rental e será registrada na auditoria. Digite sua senha para confirmar."
        />
      </main>
    </div>
  );
}

function Field({ label, value }: { label: string; value?: React.ReactNode }) {
  return (
    <p><span className="text-muted-foreground">{label}:</span> {value ?? '—'}</p>
  );
}

function DocSection({ title, docs, onOpen, onCopy }: { title: string; docs: DocRow[]; onOpen: (d: DocRow) => void; onCopy: (d: DocRow) => void }) {
  if (!docs.length) {
    return (
      <div>
        <p className="font-medium text-sm mb-1">{title}</p>
        <p className="text-xs text-muted-foreground">Nenhum documento.</p>
      </div>
    );
  }
  return (
    <div>
      <p className="font-medium text-sm mb-2">{title} ({docs.length})</p>
      <div className="space-y-1.5">
        {docs.map(d => (
          <div key={d.id} className="flex items-center gap-2 border rounded p-2 text-sm">
            <FileText className="h-4 w-4 text-muted-foreground shrink-0" />
            <div className="min-w-0 flex-1">
              <p className="truncate font-medium">{d.file_name}</p>
              <p className="text-xs text-muted-foreground">{d.document_type} • {d.status} • {formatDate(d.created_at)}</p>
            </div>
            <div className="flex gap-1 shrink-0">
              <Button variant="ghost" size="sm" onClick={() => onOpen(d)} title="Abrir"><Eye className="h-3.5 w-3.5" /></Button>
              <Button variant="ghost" size="sm" onClick={() => onCopy(d)} title="Copiar URL"><Copy className="h-3.5 w-3.5" /></Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
