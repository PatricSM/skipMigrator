import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAdminRentals, type AdminRentalWithProfile } from '@/hooks/useAdminRentals';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowLeft, Search, ExternalLink } from 'lucide-react';

const STEP_LABELS: Record<number, string> = {
  1: 'Proposta', 2: 'Negociação', 3: 'Docs locatário', 4: 'Triagem',
  5: 'Análise + Docs locador', 6: 'Emissão contrato', 7: 'Assinatura',
  8: 'Contrato assinado', 9: 'Vistoria', 10: 'Chaves',
};

export default function AdminRentalsList() {
  const { rentals, loading } = useAdminRentals();
  const [search, setSearch] = useState('');
  const [stepFilter, setStepFilter] = useState('all');
  const [sortBy, setSortBy] = useState<'recent' | 'oldest'>('recent');

  const filtered = useMemo(() => {
    let list = [...rentals];

    // Search
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(r =>
        r.protocol.toLowerCase().includes(q) ||
        r.id.toLowerCase().includes(q) ||
        r.property_code.toLowerCase().includes(q) ||
        (r.tenant?.full_name ?? '').toLowerCase().includes(q) ||
        (r.tenant?.email ?? '').toLowerCase().includes(q)
      );
    }

    // Step filter
    if (stepFilter !== 'all') {
      const step = parseInt(stepFilter);
      list = list.filter(r => (r as any).current_step === step);
    }

    // Sort
    if (sortBy === 'recent') {
      list.sort((a, b) => (b.updated_at ?? '').localeCompare(a.updated_at ?? ''));
    } else {
      list.sort((a, b) => (a.updated_at ?? '').localeCompare(b.updated_at ?? ''));
    }

    return list;
  }, [rentals, search, stepFilter, sortBy]);

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 h-14 flex items-center gap-4">
          <Button variant="ghost" size="sm" asChild>
            <Link to="/admin"><ArrowLeft className="h-4 w-4 mr-1" />Admin</Link>
          </Button>
          <h1 className="font-bold text-lg">Rentals</h1>
          <Badge variant="outline">{filtered.length}</Badge>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6 space-y-4">
        {/* Filters */}
        <div className="flex flex-wrap gap-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar protocolo, ID, imóvel, nome..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={stepFilter} onValueChange={setStepFilter}>
            <SelectTrigger className="w-[160px]"><SelectValue placeholder="Etapa" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas etapas</SelectItem>
              {Array.from({ length: 10 }, (_, i) => i + 1).map(s => (
                <SelectItem key={s} value={String(s)}>{s} — {STEP_LABELS[s]}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={sortBy} onValueChange={v => setSortBy(v as any)}>
            <SelectTrigger className="w-[160px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="recent">Mais recentes</SelectItem>
              <SelectItem value="oldest">Mais antigos</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {loading ? (
          <p className="text-center text-muted-foreground py-12">Carregando...</p>
        ) : filtered.length === 0 ? (
          <p className="text-center text-muted-foreground py-12">Nenhum rental encontrado.</p>
        ) : (
          <div className="space-y-2">
            {filtered.map(r => {
              const step = (r as any).current_step ?? 1;
              return (
                <Link key={r.id} to={`/admin/rentals/${r.id}`} className="block">
                  <Card className="hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between gap-3 flex-wrap">
                        <div className="flex items-center gap-2 min-w-0">
                          <Badge variant="outline" className="shrink-0">{r.protocol}</Badge>
                          <span className="text-sm font-medium truncate">{r.tenant?.full_name ?? 'Locatário'}</span>
                        </div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <Badge variant="secondary" className="text-xs">{r.property_code}</Badge>
                          <Badge className="text-xs">{step} — {STEP_LABELS[step] ?? `Step ${step}`}</Badge>
                          {(r as any).proposal_status && (
                            <Badge variant="outline" className="text-xs">{(r as any).proposal_status}</Badge>
                          )}
                          {r.is_rejected && <Badge variant="destructive" className="text-xs">Rejeitado</Badge>}
                          <ExternalLink className="h-3.5 w-3.5 text-muted-foreground" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
}
