import { Link } from "react-router-dom";
import { ChevronLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function PropertyInvitesAdmin() {
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <span className="text-primary-foreground font-bold">E</span>
              </div>
              <span className="font-bold text-lg">Etic Admin</span>
            </Link>
            <Button variant="ghost" asChild>
              <Link to="/admin">
                <ChevronLeft className="mr-2 h-4 w-4" />
                Voltar
              </Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-2">Convites de Propriedades</h1>
        <p className="text-muted-foreground mb-8">
          Gerencie convites para proprietários de imóveis.
        </p>
        
        <div className="text-center py-12 text-muted-foreground">
          <p>Sistema de convites será implementado aqui.</p>
        </div>
      </main>
    </div>
  );
}
