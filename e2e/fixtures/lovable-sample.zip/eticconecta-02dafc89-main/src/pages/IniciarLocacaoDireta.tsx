import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

export default function IniciarLocacaoDireta() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="text-center max-w-md mx-auto px-4">
        <h1 className="text-3xl font-bold mb-4">Iniciar Locação</h1>
        <p className="text-muted-foreground mb-8">
          Selecione um imóvel para iniciar o processo de locação.
        </p>
        <Button asChild>
          <Link to="/selecionar-imovel">Ver imóveis disponíveis</Link>
        </Button>
      </div>
    </div>
  );
}
