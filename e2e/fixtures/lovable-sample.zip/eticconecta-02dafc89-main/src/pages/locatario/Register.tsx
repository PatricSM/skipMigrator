import { useState } from "react";
import { Link, useNavigate, useLocation, useSearchParams } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Loader2, ChevronLeft } from "lucide-react";
import { toast } from "sonner";
import { maskPhone } from "@/lib/masks";
import { supabase } from "@/integrations/supabase/client";
import { sanitizeRedirect } from "@/lib/validations";

export default function LocatarioRegister() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [searchParams] = useSearchParams();
  // Read redirect from querystring (priority) or location.state
  const qsRedirect = searchParams.get('redirect');
  const fromState = (location.state as { from?: { pathname: string; search?: string } })?.from;
  const redirectUrl = sanitizeRedirect(qsRedirect ?? (fromState ? fromState.pathname + (fromState.search || '') : null));
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validação de campos obrigatórios
    if (!fullName || !email || !phone || !password || !confirmPassword) {
      toast.error("Preencha todos os campos obrigatórios");
      return;
    }

    // Validação de telefone
    const cleanPhone = phone.replace(/\D/g, "");
    if (cleanPhone.length < 10) {
      toast.error("Telefone inválido", {
        description: "O telefone deve ter pelo menos 10 dígitos",
      });
      return;
    }

    if (password !== confirmPassword) {
      toast.error("As senhas não coincidem");
      return;
    }

    // Strong password validation
    try {
      const { strongPasswordSchema } = await import('@/lib/passwordPolicy');
      strongPasswordSchema.parse(password);
    } catch (err: any) {
      const message = err?.errors?.[0]?.message || 'Senha não atende aos requisitos de segurança';
      toast.error(message);
      return;
    }

    setIsLoading(true);

    const { error, user: newUser } = await register(email, password, fullName, {
      phone: phone.replace(/\D/g, ""),
      userType: "locatario",
    });

    if (error) {
      toast.error("Erro ao criar conta", {
        description: error.message,
      });
      setIsLoading(false);
      return;
    }

    // Atualizar profile com telefone
    if (newUser) {
      await supabase
        .from("profiles")
        .update({ phone })
        .eq("id", newUser.id);
    }

    // Save redirect URL to sessionStorage so VerifiqueEmail and Login can use it
    if (redirectUrl && redirectUrl !== '/locatario/painel') {
      sessionStorage.setItem('postSignupRedirect', redirectUrl);
    }

    navigate("/locatario/verifique-email", { replace: true });
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="border-b bg-background/80 backdrop-blur-sm">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <Link to="/locatario" className="flex items-center gap-2">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <span className="text-primary-foreground font-bold">E</span>
              </div>
              <span className="font-bold text-lg">Etic Imóveis</span>
            </Link>
            <Button
              variant="ghost"
              onClick={() => navigate(-1)}
            >
              <ChevronLeft className="mr-2 h-4 w-4" />
              Voltar
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">Criar conta</CardTitle>
            <CardDescription>
              Crie seu perfil para agilizar a análise
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="fullName">Nome completo *</Label>
                <Input
                  id="fullName"
                  type="text"
                  placeholder="Seu nome completo"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  required
                  disabled={isLoading}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="seu@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  disabled={isLoading}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Telefone *</Label>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="(11) 99999-9999"
                  value={phone}
                  onChange={(e) => setPhone(maskPhone(e.target.value))}
                  required
                  disabled={isLoading}
                />
                <p className="text-xs text-muted-foreground">
                  O telefone será usado para notificações e vinculação com o CRM
                </p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Senha *</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  disabled={isLoading}
                />
                <p className="text-xs text-muted-foreground">
                  Mín. 14 caracteres, com maiúsculas, minúsculas, números ou especiais
                </p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Confirmar senha *</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  placeholder="••••••••"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                  disabled={isLoading}
                />
              </div>

              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Criando conta...
                  </>
                ) : (
                  "Criar conta"
                )}
              </Button>
            </form>

            <div className="mt-6 text-center text-sm">
              <span className="text-muted-foreground">Já tem uma conta? </span>
              <Link
                to={qsRedirect ? `/locatario/login?redirect=${encodeURIComponent(qsRedirect)}` : "/locatario/login"}
                className="text-primary font-medium hover:underline"
              >
                Entrar
              </Link>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
