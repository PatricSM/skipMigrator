import { useState, useEffect } from "react";
import { Link, useNavigate, useLocation, useSearchParams } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { ForgotPasswordDialog } from "@/components/auth/ForgotPasswordDialog";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import { AppHeader } from "@/components/layout/AppHeader";
import { sanitizeRedirect } from "@/lib/validations";

export default function LocatarioLogin() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [searchParams] = useSearchParams();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  // Priority: 1) querystring redirect, 2) location.state, 3) sessionStorage, 4) /locatario/painel
  const qsRedirect = searchParams.get('redirect');
  const fromState = (location.state as { from?: { pathname: string; search?: string } })?.from;
  const storedRedirect = sessionStorage.getItem('postSignupRedirect');

  const returnTo = sanitizeRedirect(
    qsRedirect
      ?? (fromState ? fromState.pathname + (fromState.search || '') : null)
      ?? storedRedirect
  );

  // Detect recovery token and redirect to reset password page
  useEffect(() => {
    const hashParams = new URLSearchParams(window.location.hash.substring(1));
    const type = hashParams.get('type');
    const accessToken = hashParams.get('access_token');
    
    if (type === 'recovery' && accessToken) {
      navigate(`/reset-password${window.location.hash}`, { replace: true });
    }
  }, [navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Rate limit check (fail open)
    try {
      const { checkRateLimit, formatBlockTime } = await import('@/lib/rateLimiter');
      const rl = await checkRateLimit(email, 'login');
      if (rl.blocked) {
        toast.error("Muitas tentativas", {
          description: `Aguarde ${formatBlockTime(rl.remaining_seconds)} antes de tentar novamente.`,
        });
        setIsLoading(false);
        return;
      }
    } catch {}

    const { error } = await login(email, password);

    if (error) {
      // Anti-enumeration: generic message regardless of error type
      toast.error("Credenciais inválidas", {
        description: "Verifique seu e-mail e senha e tente novamente.",
      });
      setIsLoading(false);
      return;
    }

    if (storedRedirect) sessionStorage.removeItem('postSignupRedirect');
    toast.success("Bem-vindo de volta!");
    navigate(returnTo, { replace: true });
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <AppHeader />

      {/* Main Content */}
      <main className="flex-1 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">Entrar</CardTitle>
            <CardDescription>
              Acesse sua conta para continuar
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="seu@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  disabled={isLoading}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Senha</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  disabled={isLoading}
                />
              </div>

              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Entrando...
                  </>
                ) : (
                  "Entrar"
                )}
              </Button>
            </form>

            <div className="mt-4 text-center">
              <ForgotPasswordDialog />
            </div>

            <div className="mt-6 text-center text-sm">
              <span className="text-muted-foreground">Não tem uma conta? </span>
              <Link
                to={qsRedirect ? `/locatario/register?redirect=${encodeURIComponent(qsRedirect)}` : "/locatario/register"}
                state={{ from: fromState }}
                className="text-primary font-medium hover:underline"
              >
                Criar conta
              </Link>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
