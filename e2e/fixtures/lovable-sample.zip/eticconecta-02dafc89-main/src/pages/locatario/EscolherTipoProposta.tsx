import { useMemo, useEffect, useState } from "react";
import { useParams, Link, useNavigate, useLocation, useSearchParams } from "react-router-dom";
import { Lock, Banknote, Check, Star, AlertTriangle, MapPin, ExternalLink, Loader2, Clock, FileText, ArrowLeft, X } from "lucide-react";
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogFooter,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useProperties } from "@/hooks/useProperties";
import { maskCurrencyInput } from "@/lib/masks";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { AppHeader } from "@/components/layout/AppHeader";

interface PropertyData {
  id: string;
  code: string;
  neighborhood: string;
  streetName: string;
  shortAddress: string;
  price: number;
  condoFee: number;
  iptu: number;
  image: string;
}

type ProposalSubOption = "wait" | "sendDocs";

// Gamification feedback function with visual styling
function getDiscountFeedback(discount: number) {
  if (discount <= 0) return {
    status: "announced",
    title: "Valor anunciado",
    message: "Máxima prioridade na análise",
    color: "text-primary",
    bgColor: "bg-primary/10",
    borderColor: "border-primary/30",
    barColor: "bg-primary"
  };
  if (discount <= 3) return {
    status: "competitive",
    title: "Proposta competitiva",
    message: "Excelentes chances de aprovação",
    color: "text-emerald-600",
    bgColor: "bg-emerald-50",
    borderColor: "border-emerald-200",
    barColor: "bg-emerald-500"
  };
  if (discount <= 6) return {
    status: "negotiation",
    title: "Proposta de negociação",
    message: "Você tem chances, mas pode haver propostas melhores",
    color: "text-amber-600",
    bgColor: "bg-amber-50",
    borderColor: "border-amber-200",
    barColor: "bg-amber-500"
  };
  if (discount <= 9) return {
    status: "risk",
    title: "Este desconto pode reduzir suas chances",
    message: "Considere aproximar do valor anunciado",
    color: "text-orange-600",
    bgColor: "bg-orange-50",
    borderColor: "border-orange-200",
    barColor: "bg-orange-500"
  };
  if (discount <= 12) return {
    status: "aggressive",
    title: "Proposta agressiva",
    message: "Baixa chance de aprovação",
    color: "text-red-600",
    bgColor: "bg-red-50",
    borderColor: "border-red-200",
    barColor: "bg-red-500"
  };
  return {
    status: "blocked",
    title: "Valor abaixo do limite",
    message: "Desconto máximo permitido é 12%",
    color: "text-destructive",
    bgColor: "bg-destructive/10",
    borderColor: "border-destructive/30",
    barColor: "bg-destructive"
  };
}

export default function EscolherTipoProposta() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const [searchParams] = useSearchParams();
  const { user, profile } = useAuth();

  console.log('[ESCOLHER] component rendered, pathname:', location.pathname, 'search:', location.search);
  console.log('[ESCOLHER] user:', user?.id ?? null, 'profile:', profile?.full_name ?? null);
  const { toast } = useToast();
  const { data: properties, isLoading: loading } = useProperties();
  const [proposedValue, setProposedValue] = useState("");
  const [selectedType, setSelectedType] = useState<"direct" | "standard" | null>(null);
  const [proposalSubOption, setProposalSubOption] = useState<ProposalSubOption>("wait");
  const [proposalStep, setProposalStep] = useState<1 | 2>(1);
  const [isSubmittingWait, setIsSubmittingWait] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [_hasAutoAdvanced, setHasAutoAdvanced] = useState(false); // kept for future use

  // Restore selectedType from querystring on mount
  useEffect(() => {
    const modo = searchParams.get('modo');
    if (modo === 'prioridade') setSelectedType('direct');
    else if (modo === 'proposta') setSelectedType('standard');
  }, []);

  // Sync selectedType to querystring
  useEffect(() => {
    if (selectedType === 'direct') {
      navigate(`${location.pathname}?modo=prioridade`, { replace: true });
    } else if (selectedType === 'standard') {
      navigate(`${location.pathname}?modo=proposta`, { replace: true });
    }
  }, [selectedType]);

  // Close auth modal when user becomes truthy (e.g. after login/signup)
  useEffect(() => {
    if (user) {
      setShowAuthModal(false);
    }
  }, [user]);

  // Find property from cached data
  const property = useMemo(() => {
    if (!properties || !id) return null;
    return properties.find(p => p.code === id || p.id === id) as PropertyData | undefined ?? null;
  }, [properties, id]);

  // Post-login intent: auto-execute the action if user just returned from login
  useEffect(() => {
    if (!user || !id || !property) return;
    try {
      const raw = sessionStorage.getItem('postLoginIntent');
      if (!raw) return;
      const intent = JSON.parse(raw);
      // Check TTL (10 min)
      if (Date.now() - intent.timestamp > 10 * 60 * 1000) {
        sessionStorage.removeItem('postLoginIntent');
        return;
      }
      // Check property match
      if (intent.propertyCode !== id) return;

      sessionStorage.removeItem('postLoginIntent');

      if (intent.type === 'guarantee_property') {
        setTimeout(() => handleDirect(), 100);
      } else if (intent.type === 'send_proposal_wait') {
        // Restore proposal value and auto-submit wait flow
        if (intent.proposedValue) {
          setProposedValue(intent.proposedValue);
          setSelectedType('standard');
          setProposalSubOption('wait');
          setProposalStep(2);
          // Wait a tick for state to settle, then submit
          setTimeout(() => handleStandardWait(), 200);
        }
      } else if (intent.type === 'send_proposal_docs') {
        // Restore proposal value and navigate to docs
        if (intent.proposedValue) {
          setProposedValue(intent.proposedValue);
          setSelectedType('standard');
          setProposalSubOption('sendDocs');
          setProposalStep(2);
          setTimeout(() => {
            const returnTo = encodeURIComponent(location.pathname + location.search);
            const numericValue = parseFloat(intent.proposedValue.replace(/[R$\s.]/g, "").replace(",", ".")) || 0;
            navigate(`/locatario/enviar-documentos/${id}?returnTo=${returnTo}`, {
              state: {
                proposalType: "standard",
                proposedValue: numericValue,
                sendDocs: true,
              },
            });
          }, 100);
        }
      }
    } catch {
      sessionStorage.removeItem('postLoginIntent');
    }
  }, [user, id, property]); // eslint-disable-line react-hooks/exhaustive-deps

  // Pre-fill with announced value when selecting "standard" option
  useEffect(() => {
    if (selectedType === "standard" && property?.price && !proposedValue) {
      const formattedPrice = new Intl.NumberFormat("pt-BR", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      }).format(property.price);
      setProposedValue(formattedPrice);
    }
  }, [selectedType, property?.price, proposedValue]);

  const formatCurrency = (value: number | null) => {
    if (!value) return "-";
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value);
  };

  // Calculate 12% discount limit
  const minProposalValue = property?.price ? property.price * 0.88 : 0;
  const proposedNumeric = proposedValue 
    ? parseFloat(proposedValue.replace(/[R$\s.]/g, "").replace(",", ".")) 
    : 0;
  const isValidProposal = proposedNumeric >= minProposalValue;
  
  // Discount with 1 decimal place
  const discountPercentage = property?.price && proposedNumeric 
    ? Math.round((1 - proposedNumeric / property.price) * 1000) / 10
    : 0;

  // Check if high discount (>= 8.1%) to highlight recommended option
  const isHighDiscount = discountPercentage >= 8.1;

  // Handle manual input - allow clearing
  const handleValueChange = (value: string) => {
    // Allow empty value when user is clearing
    if (value === '' || value === 'R$' || value === 'R$ ' || value.trim() === '') {
      setProposedValue('');
      return;
    }
    
    // Only apply mask if there are digits
    const digits = value.replace(/\D/g, '');
    if (digits.length === 0) {
      setProposedValue('');
      return;
    }
    
    setProposedValue(maskCurrencyInput(value));
  };

  // Auth gate: check if user is logged in, if not show modal and save intent
  const requireAuth = (intentType?: string, extraData?: Record<string, any>): boolean => {
    if (!user) {
      console.log('[ESCOLHER] opening auth modal because no user');
      // Save intent so it auto-executes after login
      if (intentType && id) {
        const modo = searchParams.get('modo') || (selectedType === 'direct' ? 'prioridade' : 'proposta');
        sessionStorage.setItem('postLoginIntent', JSON.stringify({
          type: intentType,
          propertyCode: id,
          modo,
          timestamp: Date.now(),
          ...extraData,
        }));
      }
      setShowAuthModal(true);
      return false;
    }
    return true;
  };

  // Handle "Aguardar Retorno" - create rental directly and go to tracking
  const handleStandardWait = async () => {
    if (!requireAuth('send_proposal_wait', { proposedValue, proposalSubOption: 'wait' })) return;

    if (!proposedValue || proposedNumeric <= 0) {
      toast({
        title: "Valor inválido",
        description: "Informe o valor da proposta antes de enviar.",
        variant: "destructive",
      });
      return;
    }

    if (!isValidProposal) {
      toast({
        title: "Valor fora do limite",
        description: `O valor mínimo aceito é ${formatCurrency(minProposalValue)}.`,
        variant: "destructive",
      });
      return;
    }

    setIsSubmittingWait(true);

    try {
      // Generate unique protocol
      const now = new Date();
      const day = now.getDate().toString().padStart(2, '0');
      const month = (now.getMonth() + 1).toString().padStart(2, '0');
      const year = now.getFullYear().toString().slice(-2);
      const timestamp = Date.now().toString(36).toUpperCase();
      const randomSuffix = Math.random().toString(36).substring(2, 6).toUpperCase();
      const protocol = `${(id || 'PROP').toUpperCase()}-${day}${month}${year}-${timestamp}${randomSuffix}`;

      // Get property data
      const propertyCode = property?.code || id || '';
      const propertyAddress = property?.shortAddress || property?.neighborhood || `Imóvel ${propertyCode}`;
      const rentValue: number | null = property?.price || null;
      const condoFee: number | null = property?.condoFee || null;
      const iptu: number | null = property?.iptu || null;

      // Create minimal rental record - goes directly to step 2 (awaiting landlord)
      const { data: rental, error: rentalError } = await supabase
        .from('rentals')
        .insert({
          user_id: user.id,
          property_id: propertyCode,
          property_code: propertyCode,
          property_address: propertyAddress,
          protocol,
          current_step: 2,
          step_status: 'pending',
          tenant_status: 'awaiting_landlord',
          admin_stage: 1,
          has_pending: true,
          pending_documents: JSON.parse(JSON.stringify(['identity', 'income', 'residence'])),
          pending_reason: 'Aguardando envio de documentos',
          pending_description: 'Documentos a enviar: RG, Comprovante de Renda, Comprovante de Residência',
          rent_value: rentValue,
          condo_fee: condoFee,
          iptu: iptu,
          proposal_type: 'standard',
          proposed_value: proposedNumeric,
          landlord_accepted: false,
          landlord_action_required: true,
          docs_submitted_early: false,
        })
        .select()
        .single();

      if (rentalError) {
        console.error('Rental insert error:', rentalError);
        
        // Handle duplicate protocol
        if (rentalError.code === '23505') {
          toast({
            title: "Erro temporário",
            description: "Tente enviar novamente.",
            variant: "destructive",
          });
          return;
        }
        
        throw rentalError;
      }

      // Create rental event with standardized type
      await supabase.from('rental_events').insert({
        rental_id: rental.id,
        event_type: 'proposal_sent',
        description: `Proposta de R$ ${proposedNumeric.toLocaleString('pt-BR', { minimumFractionDigits: 2 })} enviada — aguardando retorno do locador`,
        idempotency_key: `proposal_sent_${rental.id}`,
      });

      toast({
        title: "Proposta enviada!",
        description: "Aguarde o retorno do locador. Você pode acompanhar no painel.",
      });

      navigate(`/acompanhamento/${rental.id}`);
    } catch (error: any) {
      console.error('Submit error:', error);
      toast({
        title: "Erro ao enviar",
        description: error?.message || "Ocorreu um erro ao enviar sua proposta. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsSubmittingWait(false);
    }
  };

  const handleDirect = () => {
    if (!requireAuth('guarantee_property')) return;
    const returnTo = encodeURIComponent(location.pathname + location.search);
    navigate(`/locatario/enviar-documentos/${id}?returnTo=${returnTo}`, {
      state: {
        proposalType: "direct",
        proposedValue: property?.price || null,
        sendDocs: true,
      },
    });
  };

  const handleStandard = () => {
    if (!proposedValue || !isValidProposal) return;
    const intentType = proposalSubOption === 'wait' ? 'send_proposal_wait' : 'send_proposal_docs';
    if (!requireAuth(intentType, { proposedValue, proposalSubOption })) return;
    
    // If user chose to wait, use the direct flow that creates rental immediately
    if (proposalSubOption === "wait") {
      handleStandardWait();
      return;
    }
    
    // Otherwise, go to document submission page
    const returnTo = encodeURIComponent(location.pathname + location.search);
    navigate(`/locatario/enviar-documentos/${id}?returnTo=${returnTo}`, {
      state: {
        proposalType: "standard",
        proposedValue: proposedNumeric,
        sendDocs: true,
      },
    });
  };

  const handleUseMinValue = () => {
    const formattedMin = new Intl.NumberFormat("pt-BR", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(minProposalValue);
    setProposedValue(formattedMin);
  };

  const propertyLink = property?.code 
    ? `https://www.eticimoveis.com.br/imovel/${property.code}` 
    : null;

  // Get feedback for current discount - always returns an object now
  const currentFeedback = getDiscountFeedback(discountPercentage);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!property) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
        <p className="text-muted-foreground mb-4">Imóvel não encontrado</p>
        <Button asChild>
          <Link to="/locatario/selecionar-imovel">Voltar para lista</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <AppHeader />

      <main className="container mx-auto px-4 py-6 max-w-2xl">
        {/* Property Card */}
        <Card className="overflow-hidden mb-6">
          <div className="flex flex-col sm:flex-row">
            {property.image && (
              <div className="sm:w-48 h-36 sm:h-auto bg-muted shrink-0">
                <img
                  src={property.image}
                  alt={property.code}
                  className="w-full h-full object-cover"
                />
              </div>
            )}
            <CardContent className="flex-1 p-4">
              <div className="flex items-start justify-between gap-2">
                <div>
                  {propertyLink ? (
                    <a
                      href={propertyLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1.5 text-primary hover:underline"
                    >
                      <Badge variant="outline" className="cursor-pointer">
                        {property.code}
                        <ExternalLink className="h-3 w-3 ml-1" />
                      </Badge>
                    </a>
                  ) : (
                    <Badge variant="outline">{property.code}</Badge>
                  )}
                  <p className="font-medium text-foreground flex items-center gap-1.5 mt-2 text-sm">
                    <MapPin className="h-4 w-4 text-muted-foreground shrink-0" />
                    {property.neighborhood}
                    {property.streetName && ` - ${property.streetName}`}
                  </p>
                </div>
              </div>
              
              <div className="grid grid-cols-3 gap-2 mt-4">
                <div className="p-2 bg-muted/50 rounded-lg text-center">
                  <p className="text-[10px] text-muted-foreground uppercase">Aluguel</p>
                  <p className="font-semibold text-sm text-primary">{formatCurrency(property.price)}</p>
                </div>
                <div className="p-2 bg-muted/50 rounded-lg text-center">
                  <p className="text-[10px] text-muted-foreground uppercase">Condomínio</p>
                  <p className="font-semibold text-xs">{formatCurrency(property.condoFee)}</p>
                </div>
                <div className="p-2 bg-muted/50 rounded-lg text-center">
                  <p className="text-[10px] text-muted-foreground uppercase">IPTU</p>
                  <p className="font-semibold text-xs">{formatCurrency(property.iptu)}</p>
                </div>
              </div>
            </CardContent>
          </div>
        </Card>

        {/* Title */}
        <div className="text-center mb-6">
          <h1 className="text-xl font-bold text-foreground">Como você deseja prosseguir?</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Escolha entre aceitar o valor anunciado ou fazer uma proposta
          </p>
        </div>

        {/* Option Cards */}
        <div className="space-y-4">
          {/* Direct Option - Accept asking price */}
          <Card 
            className={cn(
              "cursor-pointer transition-all border-2",
              selectedType === "direct" 
                ? "border-primary bg-primary/5" 
                : "border-transparent hover:border-muted-foreground/30"
            )}
            onClick={() => setSelectedType("direct")}
          >
            <CardHeader className="pb-2">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Lock className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <CardTitle className="text-base flex items-center gap-2">
                    Garantir este Imóvel
                    <Badge className="bg-primary/20 text-primary border-0 text-[10px]">
                      <Star className="h-3 w-3 mr-1" />
                      Prioridade
                    </Badge>
                  </CardTitle>
                  <CardDescription className="text-xs">
                    Aceito o valor e condições anunciados
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="space-y-2 text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-primary shrink-0" />
                  <span>Sua ficha terá prioridade sobre outras propostas</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-primary shrink-0" />
                  <span>Iremos direto para análise de ficha</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-primary shrink-0" />
                  <span>Ainda confirmaremos disponibilidade com locador</span>
                </div>
              </div>

              {selectedType === "direct" && (
                <div className="mt-4 p-3 bg-primary/10 rounded-lg border border-primary/20">
                  <div className="flex items-start gap-2 text-xs text-primary">
                    <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
                    <p>
                      Ao prosseguir, você concorda com o valor de{" "}
                      <strong>{formatCurrency(property.price)}/mês</strong>. 
                      Precisaremos aprovar sua ficha e obter o aceite do proprietário 
                      quanto à disponibilidade do imóvel.
                    </p>
                  </div>
                </div>
              )}

              {selectedType === "direct" && (
                <Button 
                  className="w-full mt-4" 
                  size="lg"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDirect();
                  }}
                >
                  <Lock className="h-4 w-4 mr-2" />
                  Garantir Imóvel
                </Button>
              )}
            </CardContent>
          </Card>

          {/* Standard Option - Counter-proposal */}
          <Card 
            className={cn(
              "cursor-pointer transition-all border-2",
              selectedType === "standard" 
                ? "border-amber-500 bg-amber-50/50" 
                : "border-transparent hover:border-muted-foreground/30"
            )}
            onClick={() => setSelectedType("standard")}
          >
            <CardHeader className="pb-2">
              <div className="flex items-center gap-3">
                <div className={cn(
                  "w-10 h-10 rounded-full flex items-center justify-center",
                  selectedType === "standard" 
                    ? "bg-amber-500/20" 
                    : "bg-amber-500/10"
                )}>
                  <Banknote className="h-5 w-5 text-amber-600" />
                </div>
                <div>
                  <CardTitle className="text-base flex items-center gap-2">
                    Fazer uma Proposta
                    <Badge className="bg-amber-100 text-amber-700 border-0 text-[10px]">
                      <Clock className="h-3 w-3 mr-1" />
                      Fila de propostas
                    </Badge>
                  </CardTitle>
                  <CardDescription className="text-xs">
                    Quero propor um valor diferente
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              {/* Checkpoints - sempre visíveis */}
              <div className="space-y-2 text-sm text-muted-foreground mb-4">
                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-amber-600 shrink-0" />
                  <span>Um especialista em negociação fará a tratativa da sua proposta</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-amber-600 shrink-0" />
                  <span>Enviaremos a aprovação do Locador</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-amber-600 shrink-0" />
                  <span>Sem prioridade, por ordem do envio da proposta</span>
                </div>
              </div>

              {selectedType === "standard" && (
                <div className="space-y-4">
                  {/* Step 1: Value Selection */}
                  {proposalStep === 1 && (
                    <>
                      {/* Proposal Value Input */}
                      <div className="space-y-3">
                        <Label htmlFor="proposedValue">Valor proposto (aluguel mensal)</Label>
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">
                            R$
                          </span>
                          <Input
                            id="proposedValue"
                            type="text"
                            placeholder="0,00"
                            value={proposedValue}
                            onChange={(e) => handleValueChange(e.target.value)}
                            className={cn(
                              "pl-10",
                              proposedValue && !isValidProposal && "border-destructive focus-visible:ring-destructive"
                            )}
                            onClick={(e) => e.stopPropagation()}
                          />
                        </div>
                        
                        {/* Gamification Feedback Card - sempre visível quando há valor */}
                        {proposedValue && proposedNumeric > 0 && (
                          <>
                            {/* Valor acima do anunciado - erro */}
                            {proposedNumeric > property.price ? (
                              <div className="p-4 rounded-xl border-2 border-destructive/30 bg-destructive/10">
                                <div className="text-center">
                                  <p className="text-destructive font-semibold">
                                    O valor não pode ser maior que o anunciado
                                  </p>
                                  <p className="text-sm text-muted-foreground">
                                    Valor máximo: {formatCurrency(property.price)}
                                  </p>
                                </div>
                              </div>
                            ) : isValidProposal ? (
                              <div className={cn(
                                "p-4 rounded-xl border-2 transition-all",
                                currentFeedback.bgColor,
                                currentFeedback.borderColor
                              )}>
                                {/* Percentual em destaque */}
                                <div className="flex items-center justify-between mb-3">
                                  <div>
                                    <p className="text-xs text-muted-foreground uppercase tracking-wide">
                                      Sua proposta
                                    </p>
                                    <p className={cn("text-2xl font-bold", currentFeedback.color)}>
                                      {discountPercentage === 0 
                                        ? "Valor anunciado" 
                                        : `-${discountPercentage}% de desconto`}
                                    </p>
                                  </div>
                                  <div className={cn(
                                    "w-12 h-12 rounded-full flex items-center justify-center",
                                    currentFeedback.bgColor
                                  )}>
                                    {discountPercentage <= 3 ? (
                                      <Check className={cn("h-6 w-6", currentFeedback.color)} />
                                    ) : (
                                      <AlertTriangle className={cn("h-6 w-6", currentFeedback.color)} />
                                    )}
                                  </div>
                                </div>

                                {/* Barra de progresso visual */}
                                <div className="h-2 bg-muted rounded-full overflow-hidden mb-3">
                                  <div 
                                    className={cn(
                                      "h-full transition-all duration-300",
                                      currentFeedback.barColor
                                    )}
                                    style={{ width: `${Math.min(discountPercentage / 12 * 100, 100)}%` }}
                                  />
                                </div>

                                {/* Status e mensagem */}
                                <div className="space-y-1">
                                  <p className={cn("font-semibold text-sm", currentFeedback.color)}>
                                    {currentFeedback.title}
                                  </p>
                                  <p className="text-xs text-muted-foreground">
                                    {currentFeedback.message}
                                  </p>
                                </div>

                                {/* Incentivo para valor mais próximo */}
                                {discountPercentage > 3 && (
                                  <div className="mt-3 pt-3 border-t border-current/10">
                                    <p className="text-xs text-muted-foreground flex items-center gap-1">
                                      <Star className="h-3 w-3 text-amber-500" />
                                      Dica: Quanto mais próximo do valor anunciado, maiores suas chances!
                                    </p>
                                  </div>
                                )}
                              </div>
                            ) : (
                              /* Desconto inválido (> 12%) */
                              <div className="p-4 rounded-xl border-2 border-destructive/30 bg-destructive/10">
                                <p className="text-sm text-destructive font-medium mb-2">
                                  O valor mínimo aceito é {formatCurrency(minProposalValue)} (desconto máximo de 12%).
                                </p>
                                <Button
                                  type="button"
                                  variant="outline"
                                  size="sm"
                                  className="text-xs h-8 border-primary text-primary hover:bg-primary/10"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleUseMinValue();
                                  }}
                                >
                                  Usar valor mínimo ({formatCurrency(minProposalValue)})
                                </Button>
                              </div>
                            )}
                          </>
                        )}
                      </div>

                      {/* Continue button */}
                      <Button 
                        className="w-full" 
                        size="lg"
                        disabled={
                          !proposedValue || 
                          proposedNumeric <= 0 ||
                          proposedNumeric > property.price ||
                          !isValidProposal
                        }
                        onClick={(e) => {
                          e.stopPropagation();
                          setProposalStep(2);
                        }}
                      >
                        Continuar
                      </Button>
                    </>
                  )}

                  {/* Step 2: How to proceed */}
                  {proposalStep === 2 && (
                    <>
                      {/* Back button */}
                      <button
                        type="button"
                        className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
                        onClick={(e) => {
                          e.stopPropagation();
                          setProposalStep(1);
                        }}
                      >
                        <ArrowLeft className="h-4 w-4" />
                        Alterar valor
                      </button>

                      {/* Proposal summary */}
                      <div className="p-3 bg-muted/50 rounded-lg">
                        <p className="text-sm">
                          <span className="text-muted-foreground">Valor da proposta:</span>{" "}
                          <span className={cn("font-semibold", currentFeedback.color)}>
                            {formatCurrency(proposedNumeric)} (-{discountPercentage}%)
                          </span>
                        </p>
                        <p className={cn("text-xs mt-1", currentFeedback.color)}>
                          {currentFeedback.title} - {currentFeedback.message}
                        </p>
                      </div>

                      {/* Sub-options: Wait or Send Docs */}
                      <div className="space-y-3">
                        <p className="text-sm font-medium text-foreground">Como deseja prosseguir?</p>
                        
                        <RadioGroup
                          value={proposalSubOption}
                          onValueChange={(val) => setProposalSubOption(val as ProposalSubOption)}
                          className="space-y-2"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <div 
                            className={cn(
                              "flex items-start gap-3 p-3 rounded-lg border transition-colors cursor-pointer",
                              proposalSubOption === "wait" 
                                ? "border-primary bg-muted/50" 
                                : "border-border hover:border-muted-foreground/50"
                            )}
                            onClick={(e) => {
                              e.stopPropagation();
                              setProposalSubOption("wait");
                            }}
                          >
                            <RadioGroupItem value="wait" id="wait" className="mt-1" />
                            <div className="flex-1">
                              <Label htmlFor="wait" className="cursor-pointer font-medium flex items-center gap-2">
                                <Clock className="h-4 w-4 text-muted-foreground" />
                                Aguardar retorno da proposta
                              </Label>
                              <p className="text-xs text-muted-foreground mt-1">
                                O locador irá analisar e dar retorno.
                              </p>
                            </div>
                          </div>
                          
                          <div 
                            className={cn(
                              "flex items-start gap-3 p-3 rounded-lg border-2 transition-colors cursor-pointer",
                              proposalSubOption === "sendDocs" 
                                ? "border-primary bg-primary/5" 
                                : isHighDiscount 
                                  ? "border-orange-500 bg-orange-50 hover:border-orange-600" 
                                  : "border-border hover:border-primary/30"
                            )}
                            onClick={(e) => {
                              e.stopPropagation();
                              setProposalSubOption("sendDocs");
                            }}
                          >
                            <RadioGroupItem value="sendDocs" id="sendDocs" className="mt-1" />
                            <div className="flex-1">
                              <Label htmlFor="sendDocs" className="cursor-pointer font-medium flex items-center gap-2">
                                <FileText className="h-4 w-4 text-primary" />
                                Aprovar minha ficha e acelerar o processo
                              </Label>
                              <p className="text-xs text-muted-foreground mt-1">
                                Envie sua documentação agora e ganhe prioridade!
                              </p>
                              {isHighDiscount && (
                                <p className="text-xs text-orange-600 font-medium mt-1">
                                  Aumente suas chances enviando a ficha agora.
                                </p>
                              )}
                              <Badge variant="outline" className="mt-2 text-[10px] border-primary/30 text-primary">
                                Recomendado
                              </Badge>
                            </div>
                          </div>
                        </RadioGroup>
                      </div>

                      <div className="space-y-2">
                        <Button 
                          className="w-full" 
                          size="lg"
                          disabled={isSubmittingWait}
                          onClick={(e) => {
                            e.stopPropagation();
                            handleStandard();
                          }}
                        >
                          {isSubmittingWait ? (
                            <>
                              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                              Enviando...
                            </>
                          ) : (
                            <>
                              <Banknote className="h-4 w-4 mr-2" />
                              Enviar Proposta
                            </>
                          )}
                        </Button>
                        <p className="text-xs text-center text-muted-foreground">
                          {proposalSubOption === "wait" 
                            ? "Você irá direto para a página de acompanhamento."
                            : "Você poderá acompanhar o status no painel."}
                        </p>
                      </div>
                    </>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Auth Modal */}
      <AlertDialog open={showAuthModal} onOpenChange={setShowAuthModal}>
        <AlertDialogContent className="z-[100] sm:max-w-[425px]">
          <button
            onClick={() => setShowAuthModal(false)}
            className="absolute right-4 top-4 rounded-sm opacity-70 hover:opacity-100 transition-opacity"
            aria-label="Fechar"
          >
            <X className="h-4 w-4" />
          </button>
          <AlertDialogHeader>
            <AlertDialogTitle>Acesse sua conta para prosseguir</AlertDialogTitle>
            <AlertDialogDescription>
              Para garantir a segurança e a agilidade da sua proposta, o acesso é necessário. Crie sua conta em menos de um minuto ou faça login para continuar.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex flex-col gap-3 sm:flex-col">
            <div className="flex flex-col sm:flex-row gap-2 w-full">
              <Button
                className="flex-1"
                onClick={() => {
                  console.log('[ESCOLHER] navigating to register with redirect:', location.pathname + location.search);
                  setShowAuthModal(false);
                  setTimeout(() => navigate(`/locatario/register?redirect=${encodeURIComponent(location.pathname + location.search)}`), 0);
                }}
              >
                Criar conta
              </Button>
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => {
                  console.log('[ESCOLHER] navigating to login with redirect:', location.pathname + location.search);
                  setShowAuthModal(false);
                  setTimeout(() => navigate(`/locatario/login?redirect=${encodeURIComponent(location.pathname + location.search)}`), 0);
                }}
              >
                Entrar
              </Button>
            </div>
            <Button
              variant="link"
              className="text-sm text-muted-foreground mx-auto"
              onClick={() => setShowAuthModal(false)}
            >
              Agora não
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
