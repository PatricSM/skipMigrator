import { useState, useEffect } from "react";
import logoEticBlue from "@/assets/logo-etic-blue.png";
import { Link } from "react-router-dom";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { SmartRedirect } from "@/components/auth/SmartRedirect";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import {
  Search,
  Key,
  Building,
  UserPlus,
  FileText,
  Check,
  Lock,
  Eye,
  ShieldCheck,
  MessageCircle,
  Menu,
  LogOut,
  LayoutDashboard,
  Plus,
} from "lucide-react";

const quickActions = [
  {
    title: "Buscar imóveis",
    description: "Encontre imóveis disponíveis e envie proposta.",
    href: "/locatario/selecionar-imovel",
    icon: Search,
  },
  {
    title: "Cadastrar locador",
    description: "Cadastre imóveis e gerencie propostas em um painel.",
    href: "/locador/auth",
    icon: Building,
  },
  {
    title: "Criar perfil de locatário",
    description: "Crie seu perfil e agilize a análise.",
    href: "/locatario/register",
    icon: UserPlus,
  },
  {
    title: "Acompanhar proposta",
    description: "Veja etapas, pendências e próximos passos.",
    href: "/locatario/acompanhamento",
    icon: FileText,
  },
];

const steps = [
  { title: "Busca do imóvel", description: "Encontre o imóvel ideal" },
  { title: "Envio da proposta", description: "Submeta seus dados" },
  { title: "Documentos e análise", description: "Aprovação em 24h" },
  { title: "Assinatura do contrato", description: "100% digital" },
  { title: "Entrega das chaves", description: "Início da locação" },
];

const landingFaqs = [
  {
    question: "Como funciona o envio de proposta?",
    answer:
      "Após escolher o imóvel, você preenche seus dados e envia documentos. A proposta é analisada em até 24h.",
  },
  {
    question: "Quais documentos vou precisar enviar?",
    answer:
      "RG ou CNH, comprovante de renda (holerites ou extratos) e comprovante de residência.",
  },
  {
    question: "Meus documentos ficam seguros?",
    answer:
      "Sim! Utilizamos criptografia de ponta a ponta e seguimos a LGPD rigorosamente.",
  },
  {
    question: "Como recebo notificações por WhatsApp?",
    answer:
      "Após cadastrar seu telefone, você recebe atualizações automáticas a cada mudança de etapa.",
  },
  {
    question: "Locador e locatário veem as mesmas informações?",
    answer:
      "Cada parte vê apenas as informações relevantes ao seu papel, com privacidade garantida.",
  },
  {
    question: "Posso acompanhar tudo pelo celular?",
    answer:
      "Sim! A plataforma é 100% responsiva e funciona perfeitamente em dispositivos móveis.",
  },
];

export default function LocatarioLanding() {
  const { user, logout, isLandlord } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const queryClient = useQueryClient();

  // Prefetch properties on mount - user will likely navigate to selection page
  useEffect(() => {
    queryClient.prefetchQuery({
      queryKey: ["properties"],
      queryFn: async () => {
        const { data, error } = await supabase.functions.invoke("fetch-properties");
        if (error) throw error;
        return data?.properties || [];
      },
      staleTime: 10 * 60 * 1000, // 10 minutes (matches edge function cache)
    });
  }, [queryClient]);

  const panelLink = isLandlord ? "/locador/home" : "/locatario/painel";

  return (
    <SmartRedirect>
      <div className="min-h-screen bg-background">
        {/* Header Sticky */}
        <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-50">
          <div className="container mx-auto px-4">
            <div className="flex items-center justify-between h-16">
              {/* Logo */}
              <Link to="/locatario" className="flex items-center gap-2">
                <img 
                  src={logoEticBlue} 
                  alt="Etic Imóveis" 
                  className="w-10 h-10 rounded-full object-cover"
                />
                <span className="font-bold text-lg">Etic Imóveis</span>
              </Link>

              {/* Desktop Nav */}
              <nav className="hidden md:flex items-center gap-6">
                <Link
                  to="/locatario/selecionar-imovel"
                  className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
                >
                  Buscar imóveis
                </Link>
                <a
                  href="#como-funciona"
                  className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
                >
                  Como funciona
                </a>
                <Link
                  to="/locador/ajuda"
                  className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
                >
                  Ajuda / FAQ
                </Link>
              </nav>

              {/* Desktop Actions */}
              <div className="hidden md:flex items-center gap-3">
                {user ? (
                  <>
                    <Button variant="ghost" asChild>
                      <Link to={panelLink}>
                        <LayoutDashboard className="mr-2 h-4 w-4" />
                        Meu painel
                      </Link>
                    </Button>
                    <Button variant="outline" onClick={logout}>
                      <LogOut className="mr-2 h-4 w-4" />
                      Sair
                    </Button>
                  </>
                ) : (
                  <>
                    <Button variant="outline" asChild>
                      <Link to="/locatario/login">Entrar</Link>
                    </Button>
                    <Button asChild>
                      <Link to="/locatario/register">Criar conta</Link>
                    </Button>
                    <Button variant="secondary" asChild>
                      <Link to="/locador/auth">
                        <Building className="mr-2 h-4 w-4" />
                        Sou Locador
                      </Link>
                    </Button>
                  </>
                )}
              </div>

              {/* Mobile Menu */}
              <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
                <SheetTrigger asChild className="md:hidden">
                  <Button variant="ghost" size="icon">
                    <Menu className="h-5 w-5" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="w-72">
                  <nav className="flex flex-col gap-4 mt-8">
                    {user ? (
                      <>
                        <Button asChild className="w-full">
                          <Link
                            to={panelLink}
                            onClick={() => setMobileMenuOpen(false)}
                          >
                            <LayoutDashboard className="mr-2 h-4 w-4" />
                            Meu painel
                          </Link>
                        </Button>
                        <Button
                          variant="outline"
                          className="w-full"
                          onClick={() => {
                            logout();
                            setMobileMenuOpen(false);
                          }}
                        >
                          <LogOut className="mr-2 h-4 w-4" />
                          Sair
                        </Button>
                      </>
                    ) : (
                      <>
                        <Link
                          to="/locatario/selecionar-imovel"
                          className="flex items-center gap-3 text-lg font-medium py-2"
                          onClick={() => setMobileMenuOpen(false)}
                        >
                          <Search className="h-5 w-5" />
                          Buscar Imóveis
                        </Link>
                        
                        <Link
                          to="/locatario/login"
                          className="flex items-center gap-3 text-lg font-medium py-2"
                          onClick={() => setMobileMenuOpen(false)}
                        >
                          <FileText className="h-5 w-5" />
                          Minhas Propostas
                        </Link>
                        
                        <Link
                          to="/locador/auth"
                          className="flex items-center gap-3 text-lg font-medium py-2"
                          onClick={() => setMobileMenuOpen(false)}
                        >
                          <Building className="h-5 w-5" />
                          Sou Locador
                        </Link>
                        
                        <Link
                          to="/anunciar-imovel"
                          className="flex items-center gap-3 text-lg font-medium py-2"
                          onClick={() => setMobileMenuOpen(false)}
                        >
                          <Plus className="h-5 w-5" />
                          Anunciar Imóvel
                        </Link>
                      </>
                    )}
                  </nav>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </header>

        <main>
          {/* Hero Section - Optimized for Mobile */}
          <section className="py-8 md:py-24 bg-gradient-to-br from-primary/5 via-background to-background">
            <div className="container mx-auto px-4">
              <div className="max-w-4xl mx-auto text-center">
                <img 
                  src={logoEticBlue} 
                  alt="Etic Imóveis" 
                  className="w-12 h-12 md:w-16 md:h-16 mx-auto mb-4 md:mb-6 rounded-full object-cover"
                />
                <h1 className="text-2xl sm:text-3xl md:text-5xl font-bold mb-3 md:mb-4">
                  Gestão de locação com acompanhamento em tempo real
                </h1>
                <p className="text-base md:text-lg text-muted-foreground mb-4 md:mb-8 max-w-2xl mx-auto">
                  Da proposta à entrega das chaves, com documentos centralizados
                  e notificações automáticas.
                </p>

                {/* Search Card */}
                <Card className="max-w-2xl mx-auto mb-4 md:mb-8">
                  <CardContent className="p-4 md:p-6">
                    <div className="flex flex-col md:flex-row gap-3 md:gap-4">
                      <Input
                        placeholder="Bairro e Código do imóvel"
                        className="flex-1"
                      />
                      <Select>
                        <SelectTrigger className="w-full md:w-48">
                          <SelectValue placeholder="Tipo de imóvel" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="apartamento">
                            Apartamento
                          </SelectItem>
                          <SelectItem value="casa">Casa</SelectItem>
                          <SelectItem value="comercial">Comercial</SelectItem>
                        </SelectContent>
                      </Select>
                      <Button size="lg" asChild>
                        <Link to="/locatario/selecionar-imovel">
                          <Search className="mr-2 h-4 w-4" />
                          Buscar imóveis
                        </Link>
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Profile Segmentation */}
                <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center mb-4 md:mb-6">
                  <Button size="lg" asChild className="text-base px-4 md:px-6">
                    <Link to="/locatario/selecionar-imovel">
                      <Key className="mr-2 h-5 w-5" />
                      Quero alugar um imóvel
                    </Link>
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    asChild
                    className="text-base px-4 md:px-6"
                  >
                    <Link to="/locador/auth">
                      <Building className="mr-2 h-5 w-5" />
                      Sou Locador (Painel Locador)
                    </Link>
                  </Button>
                </div>

                {/* Discrete link */}
                <Link
                  to="/locatario/acompanhamento"
                  className="text-sm text-muted-foreground hover:text-foreground transition-colors inline-flex items-center gap-1"
                >
                  Já iniciou uma proposta? Acompanhar minha proposta →
                </Link>
              </div>
            </div>
          </section>

          {/* Quick Actions */}
          <section className="py-12 bg-muted/30">
            <div className="container mx-auto px-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {quickActions.map((action) => (
                  <Link
                    key={action.href}
                    to={action.href}
                    className="group p-6 rounded-xl border bg-card hover:shadow-lg transition-all"
                  >
                    <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                      <action.icon className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="font-semibold mb-1">{action.title}</h3>
                    <p className="text-sm text-muted-foreground mb-3">
                      {action.description}
                    </p>
                    <span className="text-sm font-medium text-primary group-hover:underline">
                      Acessar →
                    </span>
                  </Link>
                ))}
              </div>
            </div>
          </section>

          {/* How It Works */}
          <section id="como-funciona" className="py-20">
            <div className="container mx-auto px-4">
              <h2 className="text-3xl font-bold text-center mb-4">
                Como funciona
              </h2>
              <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
                Tudo fica registrado no seu painel, com notificações automáticas
                por WhatsApp.
              </p>

              <div className="max-w-5xl mx-auto">
                <div className="flex flex-col md:flex-row md:items-start gap-6 md:gap-2">
                  {steps.map((step, index) => (
                    <div key={index} className="flex-1 relative">
                      <div className="flex flex-col items-center text-center">
                        <div className="w-14 h-14 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xl font-bold mb-3">
                          {index + 1}
                        </div>
                        <h3 className="font-semibold mb-1">{step.title}</h3>
                        <p className="text-sm text-muted-foreground">
                          {step.description}
                        </p>
                      </div>
                      {/* Connector line (desktop only) */}
                      {index < steps.length - 1 && (
                        <div className="hidden md:block absolute top-7 left-[55%] w-[90%] h-0.5 bg-border" />
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </section>

          {/* Benefits by Audience */}
          <section className="py-20 bg-muted/30">
            <div className="container mx-auto px-4">
              <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
                {/* For Landlords */}
                <Card className="p-8">
                  <div className="flex items-center gap-2 mb-4">
                    <Building className="h-6 w-6 text-primary" />
                    <h3 className="text-xl font-bold">Para Locadores</h3>
                  </div>
                  <h4 className="text-lg font-semibold mb-4">
                    Maximize seu patrimônio com eficiência
                  </h4>
                  <ul className="space-y-2 mb-6">
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                      <span>Aprove propostas em minutos, direto do celular</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                      <span>
                        Compare candidatos automaticamente e mantenha histórico
                      </span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                      <span>Documentos organizados em um só lugar</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                      <span>Histórico de manutenções e insights</span>
                    </li>
                  </ul>
                  <div className="bg-primary/10 p-4 rounded-lg mb-4">
                    <p className="text-sm font-medium">
                      Benefício real: reduza o tempo de vacância em até 40%
                    </p>
                  </div>
                  <Button className="w-full" asChild>
                    <Link to={user && isLandlord ? "/locador/home" : "/locador/auth"}>
                      Quero gerenciar meus imóveis
                    </Link>
                  </Button>
                </Card>

                {/* For Tenants */}
                <Card className="p-8">
                  <div className="flex items-center gap-2 mb-4">
                    <Key className="h-6 w-6 text-primary" />
                    <h3 className="text-xl font-bold">Para Locatários</h3>
                  </div>
                  <h4 className="text-lg font-semibold mb-4">
                    Tranquilidade e controle total
                  </h4>
                  <ul className="space-y-2 mb-6">
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                      <span>Transparência total: veja a etapa atual</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                      <span>Notificações automáticas: WhatsApp e e-mail</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                      <span>
                        Envio de documentos com segurança e checklist
                      </span>
                    </li>
                  </ul>
                  <div className="bg-primary/10 p-4 rounded-lg mb-4">
                    <p className="text-sm font-medium">
                      Benefício real: paz de espírito e segurança no seu lar
                    </p>
                  </div>
                  <Button className="w-full" asChild>
                    <Link to="/locatario/selecionar-imovel">
                      Quero alugar agora
                    </Link>
                  </Button>
                </Card>
              </div>
            </div>
          </section>

          {/* Security & LGPD */}
          <section className="py-16">
            <div className="container mx-auto px-4">
              <h2 className="text-2xl font-bold text-center mb-8">
                Segurança e privacidade
              </h2>
              <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
                <Card className="p-6 text-center">
                  <Lock className="h-10 w-10 text-primary mx-auto mb-3" />
                  <h3 className="font-semibold mb-2">
                    Seus documentos protegidos
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Acesso controlado com criptografia
                  </p>
                </Card>
                <Card className="p-6 text-center">
                  <Eye className="h-10 w-10 text-primary mx-auto mb-3" />
                  <h3 className="font-semibold mb-2">
                    Transparência no processo
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Histórico e status visíveis
                  </p>
                </Card>
                <Card className="p-6 text-center">
                  <ShieldCheck className="h-10 w-10 text-primary mx-auto mb-3" />
                  <h3 className="font-semibold mb-2">Conformidade com LGPD</h3>
                  <p className="text-sm text-muted-foreground">
                    Finalidade e consentimento claros
                  </p>
                </Card>
              </div>
            </div>
          </section>

          {/* FAQ */}
          <section className="py-16 bg-muted/30">
            <div className="container mx-auto px-4">
              <h2 className="text-2xl font-bold text-center mb-8">
                Perguntas frequentes
              </h2>
              <div className="max-w-3xl mx-auto">
                <Accordion type="single" collapsible className="w-full">
                  {landingFaqs.map((faq, index) => (
                    <AccordionItem key={index} value={`item-${index}`}>
                      <AccordionTrigger className="text-left">
                        {faq.question}
                      </AccordionTrigger>
                      <AccordionContent>{faq.answer}</AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </div>
            </div>
          </section>
        </main>

        {/* Footer */}
        <footer className="border-t bg-muted/30 py-12">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              {/* Logo + Description */}
              <div className="md:col-span-2">
                <Link to="/locatario" className="flex items-center gap-2 mb-4">
                  <img 
                    src={logoEticBlue} 
                    alt="Etic Imóveis" 
                    className="w-10 h-10 rounded-full object-cover"
                  />
                  <span className="font-bold text-lg">Etic Imóveis</span>
                </Link>
                <p className="text-muted-foreground text-sm max-w-sm">
                  Gestão de locação do início ao fim: proposta, documentos,
                  contrato e entrega das chaves.
                </p>
              </div>

              {/* Navigation Links */}
              <div>
                <h4 className="font-semibold mb-4">Navegação</h4>
                <nav className="flex flex-col gap-2 text-sm">
                  <Link
                    to="/locatario/selecionar-imovel"
                    className="text-muted-foreground hover:text-foreground transition-colors"
                  >
                    Buscar imóveis
                  </Link>
                  <a
                    href="#como-funciona"
                    className="text-muted-foreground hover:text-foreground transition-colors"
                  >
                    Como funciona
                  </a>
                  <Link
                    to="/locador/ajuda"
                    className="text-muted-foreground hover:text-foreground transition-colors"
                  >
                    Ajuda
                  </Link>
                  <Link
                    to="/locatario/login"
                    className="text-muted-foreground hover:text-foreground transition-colors"
                  >
                    Entrar
                  </Link>
                  <Link
                    to="/locatario/register"
                    className="text-muted-foreground hover:text-foreground transition-colors"
                  >
                    Criar conta
                  </Link>
                </nav>
              </div>

              {/* Support */}
              <div>
                <h4 className="font-semibold mb-4">Suporte</h4>
                <div className="space-y-3">
                  <Button variant="outline" size="sm" className="w-full" asChild>
                    <a
                      href="https://wa.me/5511970932722"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <MessageCircle className="mr-2 h-4 w-4" />
                      Falar com suporte
                    </a>
                  </Button>
                  <p className="text-sm text-muted-foreground">
                    contato@eticconecta.com.br
                  </p>
                </div>
              </div>
            </div>

            {/* Bottom bar */}
            <div className="border-t mt-8 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
              <p className="text-sm text-muted-foreground">
                © {new Date().getFullYear()} Etic Imóveis. Todos os direitos
                reservados.
              </p>
              <div className="flex gap-4 text-sm">
                <Link
                  to="/locador/ajuda#termos"
                  className="text-muted-foreground hover:text-foreground transition-colors"
                >
                  Termos de uso
                </Link>
                <Link
                  to="/locador/ajuda#privacidade"
                  className="text-muted-foreground hover:text-foreground transition-colors"
                >
                  Política de privacidade
                </Link>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </SmartRedirect>
  );
}
