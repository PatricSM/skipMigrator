import { Link } from "react-router-dom";
import { MailCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import logoEticBlue from "@/assets/logo-etic-blue.png";
import { sanitizeRedirect } from "@/lib/validations";

export default function VerifiqueEmail() {
  // Read saved redirect so the CTA takes the user back to their original destination
  const stored = sessionStorage.getItem('postSignupRedirect');
  const ctaTarget = sanitizeRedirect(stored);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="border-b bg-background/80 backdrop-blur-sm">
        <div className="container mx-auto px-4">
          <div className="flex items-center h-16">
            <Link to="/locatario" className="flex items-center gap-2">
              <img
                src={logoEticBlue}
                alt="Etic Imóveis"
                className="w-8 h-8 rounded-full object-cover"
              />
              <span className="font-bold text-lg">Etic Imóveis</span>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center p-4">
        <Card className="w-full max-w-md text-center">
          <CardContent className="pt-8 pb-8 space-y-6">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
              <MailCheck className="h-8 w-8 text-primary" />
            </div>

            <div className="space-y-2">
              <h1 className="text-2xl font-semibold tracking-tight">
                Confirme seu e-mail para continuar
              </h1>
              <p className="text-muted-foreground">
                Enviamos um link de confirmação para o seu endereço de e-mail.
                Por favor, verifique sua caixa de entrada e spam para ativar
                sua conta e prosseguir com a proposta.
              </p>
            </div>

            <Button asChild className="w-full">
              <Link to={ctaTarget}>Ir para o Painel</Link>
            </Button>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
