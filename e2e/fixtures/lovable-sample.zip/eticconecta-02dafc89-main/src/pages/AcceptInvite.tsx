import { useParams, Link } from "react-router-dom";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function AcceptInvite() {
  const { token } = useParams<{ token: string }>();

  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="text-center max-w-md mx-auto px-4">
        <h1 className="text-3xl font-bold mb-4">Aceitar Convite</h1>
        <p className="text-muted-foreground mb-8">
          Processando convite...
        </p>
        <p className="text-sm text-muted-foreground">
          Token: {token}
        </p>
        <Button asChild className="mt-6">
          <Link to="/">Voltar ao início</Link>
        </Button>
      </div>
    </div>
  );
}
