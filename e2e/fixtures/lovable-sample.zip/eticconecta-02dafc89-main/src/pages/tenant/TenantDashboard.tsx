import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Search, Sparkles, UserCog } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useTenantDashboard } from '@/hooks/useTenantDashboard';
import { UserPreferences, MatchedProperty } from '@/types/tenant-dashboard';
import { TenantHeader } from '@/components/tenant/dashboard/TenantHeader';
import { DashboardSkeleton } from '@/components/tenant/dashboard/DashboardSkeleton';
import { ProposalDashboardCard } from '@/components/tenant/dashboard/ProposalDashboardCard';
import { TenantKPIBar } from '@/components/tenant/dashboard/TenantKPIBar';
import { MatchmakerQuiz } from '@/components/tenant/dashboard/MatchmakerQuiz';
import { MatchmakerResults } from '@/components/tenant/dashboard/MatchmakerResults';
import { useAuth } from '@/hooks/useAuth';
import { toast } from 'sonner';

export default function TenantDashboard() {
  const { user } = useAuth();
  const {
    dashboardState,
    allProposals,
    activeProposals,
    approvedProposals,
    rejectedProposals,
    isLoading,
  } = useTenantDashboard();

  const [activeTab, setActiveTab] = useState('active');
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [userPreferences, setUserPreferences] = useState<UserPreferences | null>(null);
  const [matchedProperties, setMatchedProperties] = useState<MatchedProperty[]>([]);

  const handleQuizComplete = (preferences: UserPreferences) => {
    setUserPreferences(preferences);
    setQuizCompleted(true);
    setMatchedProperties([]);
    toast.success('Preferências salvas! Buscando imóveis...');
  };

  const handlePropertyInterest = (propertyId: string) => {
    toast.success('Interesse registrado! Nossa equipe entrará em contato.');
  };

  const pendingProposals = activeProposals.filter(p => p.hasPending);

  const firstName = user?.user_metadata?.full_name?.split(' ')[0] || 'Locatário';

  return (
    <div className="min-h-screen bg-secondary/30">
      <TenantHeader />

      <main className="container max-w-4xl mx-auto py-6 px-4 space-y-6">
        {isLoading ? (
          <DashboardSkeleton />
        ) : dashboardState === 'active_journey' && allProposals.length > 0 ? (
          <>
            {/* Greeting + actions */}
            <div className="flex items-center justify-between gap-3">
              <div>
                <h1 className="text-xl font-bold text-foreground">
                  Olá, {firstName}!
                </h1>
                <p className="text-sm text-muted-foreground">
                  Você tem {allProposals.length} proposta{allProposals.length !== 1 ? 's' : ''}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <Button asChild size="sm" variant="outline">
                  <Link to="/locatario/meu-cadastro">
                    <UserCog className="mr-1.5 h-4 w-4" />
                    <span className="hidden sm:inline">Meu Cadastro</span>
                  </Link>
                </Button>
                <Button asChild size="sm">
                  <Link to="/locatario/selecionar-imovel">
                    <Plus className="mr-1.5 h-4 w-4" />
                    <span className="hidden sm:inline">Buscar Imóveis</span>
                  </Link>
                </Button>
              </div>
            </div>

            {/* KPIs - clickable to filter */}
            <TenantKPIBar
              activeProposals={activeProposals}
              approvedProposals={approvedProposals}
              rejectedProposals={rejectedProposals}
              onFilterChange={setActiveTab}
              activeFilter={activeTab}
            />

            {/* Tabs controlled by KPI + tab clicks */}
            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
              <TabsList className="flex w-full overflow-x-auto no-scrollbar h-auto p-1">
                <TabsTrigger value="active" className="flex-1 flex-shrink-0 text-xs py-2 px-3">
                  Andamento ({activeProposals.length})
                </TabsTrigger>
                <TabsTrigger value="approved" className="flex-1 flex-shrink-0 text-xs py-2 px-3">
                  Aprovadas ({approvedProposals.length})
                </TabsTrigger>
                <TabsTrigger value="rejected" className="flex-1 flex-shrink-0 text-xs py-2 px-3">
                  Reprovadas ({rejectedProposals.length})
                </TabsTrigger>
              </TabsList>

              <TabsContent value="active" className="space-y-3">
                {activeProposals.length === 0 ? (
                  <EmptyTabMessage message="Nenhuma proposta em andamento." />
                ) : (
                  activeProposals.map(p => (
                    <ProposalDashboardCard key={p.id} proposal={p} />
                  ))
                )}
              </TabsContent>

              <TabsContent value="approved" className="space-y-3">
                {approvedProposals.length === 0 ? (
                  <EmptyTabMessage message="Nenhuma proposta aprovada ainda." />
                ) : (
                  approvedProposals.map(p => (
                    <ProposalDashboardCard key={p.id} proposal={p} />
                  ))
                )}
              </TabsContent>

              <TabsContent value="rejected" className="space-y-3">
                {rejectedProposals.length === 0 ? (
                  <EmptyTabMessage message="Nenhuma proposta reprovada." />
                ) : (
                  rejectedProposals.map(p => (
                    <ProposalDashboardCard key={p.id} proposal={p} />
                  ))
                )}
              </TabsContent>

              {/* Hidden tab for pending filter via KPI click */}
              <TabsContent value="pending" className="space-y-3">
                {pendingProposals.length === 0 ? (
                  <EmptyTabMessage message="Nenhuma pendência no momento. 🎉" />
                ) : (
                  pendingProposals.map(p => (
                    <ProposalDashboardCard key={p.id} proposal={p} />
                  ))
                )}
              </TabsContent>
            </Tabs>
          </>
        ) : (
          <>
            {/* Matchmaker state */}
            {!quizCompleted ? (
              <MatchmakerQuiz onComplete={handleQuizComplete} />
            ) : (
              <>
                {userPreferences && (
                  <MatchmakerResults
                    properties={matchedProperties}
                    preferences={userPreferences}
                    onInterest={handlePropertyInterest}
                  />
                )}
                <div className="text-center">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setQuizCompleted(false);
                      setUserPreferences(null);
                    }}
                  >
                    <Sparkles className="mr-2 h-4 w-4" />
                    Refazer Busca
                  </Button>
                </div>
              </>
            )}

            {/* CTA */}
            <Card className="rounded-2xl bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
              <CardContent className="p-6 text-center space-y-4">
                <div className="w-12 h-12 rounded-full bg-primary/10 mx-auto flex items-center justify-center">
                  <Search className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">Prefere buscar você mesmo?</h3>
                  <p className="text-sm text-muted-foreground mt-1">Veja todos os imóveis disponíveis</p>
                </div>
                <Button asChild className="w-full sm:w-auto">
                  <Link to="/locatario/selecionar-imovel">
                    <Plus className="mr-2 h-4 w-4" />
                    Ver Imóveis Disponíveis
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </>
        )}
      </main>
    </div>
  );
}

function EmptyTabMessage({ message }: { message: string }) {
  return (
    <div className="text-center py-8 text-sm text-muted-foreground">
      {message}
    </div>
  );
}
