import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Save, Upload, FileText, Check, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { TenantHeader } from '@/components/tenant/dashboard/TenantHeader';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useQuery } from '@tanstack/react-query';
import { maskPhone } from '@/lib/masks';

export default function MeuCadastro() {
  const { user, profile } = useAuth();
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    full_name: '',
    phone: '',
    birth_date: '',
    profession: '',
    marital_status: '',
    nationality: '',
    monthly_income: '',
  });

  useEffect(() => {
    if (profile) {
      setForm({
        full_name: profile.full_name || '',
        phone: profile.phone || '',
        birth_date: profile.birth_date || '',
        profession: profile.profession || '',
        marital_status: profile.marital_status || '',
        nationality: profile.nationality || '',
        monthly_income: profile.monthly_income?.toString() || '',
      });
    }
  }, [profile]);

  // Fetch user documents
  const { data: documents = [], refetch: refetchDocs } = useQuery({
    queryKey: ['user-documents', user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data, error } = await supabase
        .from('documents')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data || [];
    },
    enabled: !!user,
  });

  const handleSave = async () => {
    if (!user) return;
    setSaving(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          full_name: form.full_name,
          phone: form.phone,
          birth_date: form.birth_date || null,
          profession: form.profession || null,
          marital_status: form.marital_status || null,
          nationality: form.nationality || null,
          monthly_income: form.monthly_income ? Number(form.monthly_income) : null,
        })
        .eq('id', user.id);
      if (error) throw error;
      toast.success('Dados atualizados com sucesso!');
    } catch (err: any) {
      toast.error(err.message || 'Erro ao salvar dados');
    } finally {
      setSaving(false);
    }
  };

  const handleDocUpload = async (e: React.ChangeEvent<HTMLInputElement>, docType: string) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    const filePath = `${user.id}/${docType}/${Date.now()}_${file.name}`;
    const { error: uploadError } = await supabase.storage
      .from('documents')
      .upload(filePath, file);

    if (uploadError) {
      toast.error('Erro ao enviar arquivo');
      return;
    }

    const { error: dbError } = await supabase
      .from('documents')
      .insert({
        user_id: user.id,
        document_type: docType,
        file_name: file.name,
        file_path: filePath,
        file_type: file.type,
        status: 'pending',
      });

    if (dbError) {
      toast.error('Erro ao registrar documento');
      return;
    }

    toast.success('Documento enviado com sucesso!');
    refetchDocs();
    e.target.value = '';
  };

  const docTypes = [
    { key: 'rg_cnh', label: 'RG / CNH' },
    { key: 'comprovante_renda', label: 'Comprovante de Renda' },
    { key: 'comprovante_residencia', label: 'Comprovante de Residência' },
    { key: 'extrato_bancario', label: 'Extrato Bancário' },
    { key: 'outros', label: 'Outros Documentos' },
  ];

  return (
    <div className="min-h-screen bg-secondary/30">
      <TenantHeader />
      <main className="container max-w-2xl mx-auto py-6 px-4 space-y-6">
        {/* Back button */}
        <Button variant="ghost" size="sm" asChild>
          <Link to="/locatario/painel">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Voltar ao Painel
          </Link>
        </Button>

        <h1 className="text-xl font-bold text-foreground">Meu Cadastro</h1>

        {/* Personal Data */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Dados Pessoais</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label htmlFor="full_name">Nome Completo</Label>
                <Input id="full_name" value={form.full_name} onChange={e => setForm(f => ({ ...f, full_name: e.target.value }))} />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="phone">Telefone</Label>
                <Input id="phone" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: maskPhone(e.target.value) }))} />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="birth_date">Data de Nascimento</Label>
                <Input id="birth_date" type="date" value={form.birth_date} onChange={e => setForm(f => ({ ...f, birth_date: e.target.value }))} />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="profession">Profissão</Label>
                <Input id="profession" value={form.profession} onChange={e => setForm(f => ({ ...f, profession: e.target.value }))} />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="marital_status">Estado Civil</Label>
                <Select value={form.marital_status} onValueChange={v => setForm(f => ({ ...f, marital_status: v }))}>
                  <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="solteiro">Solteiro(a)</SelectItem>
                    <SelectItem value="casado">Casado(a)</SelectItem>
                    <SelectItem value="divorciado">Divorciado(a)</SelectItem>
                    <SelectItem value="viuvo">Viúvo(a)</SelectItem>
                    <SelectItem value="uniao_estavel">União Estável</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="nationality">Nacionalidade</Label>
                <Input id="nationality" value={form.nationality} onChange={e => setForm(f => ({ ...f, nationality: e.target.value }))} />
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <Label htmlFor="monthly_income">Renda Mensal (R$)</Label>
                <Input id="monthly_income" type="number" value={form.monthly_income} onChange={e => setForm(f => ({ ...f, monthly_income: e.target.value }))} />
              </div>
            </div>
            <Button onClick={handleSave} disabled={saving} className="w-full sm:w-auto">
              {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
              Salvar Alterações
            </Button>
          </CardContent>
        </Card>

        {/* Documents */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Documentos</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Existing documents */}
            {documents.length > 0 && (
              <div className="space-y-2 mb-4">
                <p className="text-sm font-medium text-muted-foreground">Documentos enviados</p>
                {documents.map(doc => (
                  <div key={doc.id} className="flex items-center gap-3 p-3 rounded-lg border border-border/60 bg-card">
                    <div className="w-8 h-8 rounded-full bg-[hsl(var(--step-complete))]/10 flex items-center justify-center flex-shrink-0">
                      {doc.status === 'pending' ? (
                        <FileText className="h-4 w-4 text-muted-foreground" />
                      ) : (
                        <Check className="h-4 w-4 text-[hsl(var(--step-complete))]" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">{doc.file_name}</p>
                      <p className="text-[10px] text-muted-foreground">{doc.document_type} • {doc.status === 'pending' ? 'Em análise' : 'Aprovado'}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Upload new documents */}
            <p className="text-sm font-medium text-muted-foreground">Enviar novo documento</p>
            <div className="grid grid-cols-1 gap-3">
              {docTypes.map(dt => (
                <label
                  key={dt.key}
                  className="flex items-center gap-3 p-3 rounded-xl border-2 border-dashed border-border hover:border-primary/50 cursor-pointer transition-colors"
                >
                  <div className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center flex-shrink-0">
                    <Upload className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground">{dt.label}</p>
                    <p className="text-xs text-primary">Selecionar arquivo</p>
                  </div>
                  <input type="file" accept="image/*,.pdf" className="hidden" onChange={e => handleDocUpload(e, dt.key)} />
                </label>
              ))}
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
