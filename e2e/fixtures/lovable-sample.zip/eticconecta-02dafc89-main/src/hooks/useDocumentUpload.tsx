import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { DocumentUploadState } from '@/types/rental';
import { logger } from '@/lib/logger';
import { validateFileUpload } from '@/lib/fileValidation';
import { DOCUMENT_LIMITS } from '@/types/documentLimits';

export function useDocumentUpload() {
  const { user } = useAuth();
  const [uploading, setUploading] = useState(false);

  const uploadDocument = async (
    docId: string,
    file: File,
    documentType: string,
    setDocs: React.Dispatch<React.SetStateAction<DocumentUploadState[]>>,
    rentalId?: string,
    documentLabel?: string
  ): Promise<string | null> => {
    if (!user) {
      setDocs(prev =>
        prev.map(d =>
          d.id === docId
            ? { ...d, status: 'error' as const, errorMessage: 'Usuário não autenticado' }
            : d
        )
      );
      return null;
    }

    // Start uploading
    setDocs(prev =>
      prev.map(d =>
        d.id === docId
          ? { ...d, status: 'uploading' as const, progress: 5, fileName: file.name }
          : d
      )
    );
    setUploading(true);

    try {
      // Enforce document limit before upload
      if (rentalId) {
        const { count, error: countError } = await supabase
          .from('documents')
          .select('id', { count: 'exact', head: true })
          .eq('rental_id', rentalId)
          .eq('document_type', documentType)
          .eq('user_id', user.id);

        if (countError) {
          logger.error('Error checking document count:', countError);
        }

        const limit = DOCUMENT_LIMITS[documentType] ?? 1;
        if ((count ?? 0) >= limit) {
          throw new Error(`Limite de ${limit} arquivo(s) para "${documentType}" atingido.`);
        }
      }

      // Server-side file validation with magic byte checking
      const validation = await validateFileUpload(file);
      if (!validation.valid) {
        throw new Error(validation.error || 'Arquivo inválido');
      }

      // Update progress after validation
      setDocs(prev =>
        prev.map(d => (d.id === docId ? { ...d, progress: 15 } : d))
      );

      // Sanitize file name: remove special chars, spaces, parentheses
      const sanitizedName = file.name
        .normalize('NFD').replace(/[\u0300-\u036f]/g, '') // remove accents
        .replace(/[^a-zA-Z0-9._-]/g, '_') // replace special chars with underscore
        .replace(/_+/g, '_') // collapse multiple underscores
        .toLowerCase();

      // Create unique file path using UUID
      const uuid = crypto.randomUUID();
      const basePath = rentalId
        ? `rentals/${rentalId}/${documentType}`
        : `${user.id}/${documentType}`;
      const fileName = `${basePath}/${uuid}-${sanitizedName}`;

      // Simulate progress for better UX
      let progress = 0;
      const progressInterval = setInterval(() => {
        progress += 8;
        if (progress <= 90) {
          setDocs(prev =>
            prev.map(d => (d.id === docId ? { ...d, progress: 15 + progress } : d))
          );
        }
      }, 100);

      // Upload to Supabase Storage
      const { error: uploadError, data } = await supabase.storage
        .from('documents')
        .upload(fileName, file, {
          cacheControl: '3600',
          upsert: false,
        });

      clearInterval(progressInterval);

      if (uploadError) {
        console.error('[STORAGE ERROR]', { message: uploadError.message, name: uploadError.name, fileName, bucket: 'documents' });
        throw uploadError;
      }

      // Save document reference in database
      const insertPayload = {
        user_id: user.id,
        rental_id: rentalId ?? null,
        document_type: documentType,
        file_name: file.name,
        file_path: data.path,
        file_type: file.type,
        status: 'pending',
        document_label: documentLabel ?? null,
      };
      logger.info('[DOCS] inserting document row', insertPayload);
      const { error: dbError } = await supabase
        .from('documents')
        .insert(insertPayload);

      if (dbError) {
        console.error('[DOCS] insert failed', { code: dbError.code, message: dbError.message, details: dbError.details, hint: dbError.hint, payload: insertPayload });
        // If database insert fails, remove uploaded file
        await supabase.storage.from('documents').remove([fileName]);
        throw dbError;
      }

      // Success
      setDocs(prev =>
        prev.map(d =>
          d.id === docId
            ? { ...d, status: 'uploaded' as const, progress: 100, fileUrl: data.path }
            : d
        )
      );

      return data.path;
    } catch (error) {
      logger.error('Upload error:', error);
      setDocs(prev =>
        prev.map(d =>
          d.id === docId
            ? {
                ...d,
                status: 'error' as const,
                errorMessage: error instanceof Error ? error.message : 'Erro ao enviar arquivo',
              }
            : d
        )
      );
      return null;
    } finally {
      setUploading(false);
    }
  };

  const removeDocument = async (
    docId: string,
    fileUrl: string | undefined,
    setDocs: React.Dispatch<React.SetStateAction<DocumentUploadState[]>>
  ) => {
    if (fileUrl && user) {
      try {
        // Remove from storage
        await supabase.storage.from('documents').remove([fileUrl]);

        // Remove from database (filter by user_id for RLS safety)
        await supabase
          .from('documents')
          .delete()
          .eq('file_path', fileUrl)
          .eq('user_id', user.id);
      } catch (error) {
        logger.error('Error removing document:', error);
      }
    }

    setDocs(prev =>
      prev.map(d =>
        d.id === docId
          ? { ...d, status: 'empty' as const, fileName: undefined, progress: undefined, fileUrl: undefined }
          : d
      )
    );
  };

  const retryDocument = (
    docId: string,
    setDocs: React.Dispatch<React.SetStateAction<DocumentUploadState[]>>
  ) => {
    setDocs(prev =>
      prev.map(d => (d.id === docId ? { ...d, status: 'empty' as const } : d))
    );
  };

  return {
    uploading,
    uploadDocument,
    removeDocument,
    retryDocument,
  };
}
