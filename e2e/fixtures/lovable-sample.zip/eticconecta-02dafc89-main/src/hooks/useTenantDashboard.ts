import { useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { RentalTracking, RentalEvent } from '@/types/tracking';
import { DashboardState } from '@/types/tenant-dashboard';

interface PropertyFromAPI {
  id: string;
  code: string;
  image: string;
  images: string[];
  price?: number;
  condoFee?: number;
  iptu?: number;
}

interface UseTenantDashboardResult {
  dashboardState: DashboardState;
  activeProposal: RentalTracking | null;
  allProposals: RentalTracking[];
  activeProposals: RentalTracking[];
  approvedProposals: RentalTracking[];
  rejectedProposals: RentalTracking[];
  proposalHistory: RentalTracking[];
  events: RentalEvent[];
  isLoading: boolean;
  error: Error | null;
  refetch: () => void;
}

async function fetchTenantProposals(userId: string): Promise<RentalTracking[]> {
  const { data: rentalsData, error: rentalsError } = await supabase
    .from('rentals')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (rentalsError) throw rentalsError;
  if (!rentalsData || rentalsData.length === 0) return [];

  let propertyImages: Record<string, string> = {};
  try {
    const { data: propData } = await supabase.functions.invoke<{ success: boolean; properties: PropertyFromAPI[] }>(
      'fetch-properties'
    );
    if (propData?.success && propData.properties) {
      propData.properties.forEach(p => {
        propertyImages[p.id] = p.image || p.images?.[0];
        propertyImages[p.code] = p.image || p.images?.[0];
      });
    }
  } catch (e) {
    console.warn('Could not fetch property images:', e);
  }

  return rentalsData.map(rental => {
    const pendingDocs = rental.pending_documents as string[] | null;
    
    return {
      id: rental.id,
      protocol: rental.protocol,
      propertyId: rental.property_id,
      propertyAddress: rental.property_address,
      propertyCode: rental.property_code,
      propertyImage: propertyImages[rental.property_id] || propertyImages[rental.property_code],
      rentValue: rental.rent_value ? Number(rental.rent_value) : null,
      condoFee: rental.condo_fee ? Number(rental.condo_fee) : null,
      iptu: rental.iptu ? Number(rental.iptu) : null,
      currentStep: rental.current_step || 1,
      stepStatus: rental.step_status as RentalTracking['stepStatus'],
      tenantStatus: rental.tenant_status || 'in_analysis',
      hasPending: rental.has_pending || false,
      pending: rental.has_pending
        ? {
            description: rental.pending_description || '',
            reason: rental.pending_reason || '',
          }
        : undefined,
      pendingDescription: rental.pending_description || undefined,
      isRejected: rental.is_rejected || false,
      rejectionReason: rental.rejection_reason || undefined,
      contractPreviewUrl: rental.contract_preview_url || undefined,
      contractSignUrl: rental.contract_sign_url || undefined,
      pendingDocuments: pendingDocs && pendingDocs.length > 0 ? pendingDocs : undefined,
      proposalType: (rental.proposal_type as 'standard' | 'direct') || 'standard',
      proposedValue: rental.proposed_value || null,
      landlordAccepted: rental.landlord_accepted || false,
      landlordAcceptedAt: rental.landlord_accepted_at ? new Date(rental.landlord_accepted_at) : undefined,
      docsSubmittedEarly: rental.docs_submitted_early || false,
      createdAt: new Date(rental.created_at!),
      updatedAt: new Date(rental.updated_at!),
    };
  });
}

async function fetchRentalEvents(rentalId: string): Promise<RentalEvent[]> {
  const { data, error } = await supabase
    .from('rental_events')
    .select('*')
    .eq('rental_id', rentalId)
    .order('created_at', { ascending: false });

  if (error) throw error;

  return (data || []).map(event => ({
    id: event.id,
    eventType: event.event_type,
    description: event.description,
    createdAt: new Date(event.created_at!),
  }));
}

export function useTenantDashboard(): UseTenantDashboardResult {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const {
    data: proposals = [],
    isLoading: proposalsLoading,
    error: proposalsError,
    refetch: refetchProposals,
  } = useQuery({
    queryKey: ['tenant-proposals', user?.id],
    queryFn: () => fetchTenantProposals(user!.id),
    enabled: !!user,
    staleTime: 30000,
  });

  // Realtime subscription
  useEffect(() => {
    if (!user) return;
    const channel = supabase
      .channel('tenant-rentals-realtime')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'rentals',
        filter: `user_id=eq.${user.id}`,
      }, () => {
        queryClient.invalidateQueries({ queryKey: ['tenant-proposals', user.id] });
      })
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'rental_events',
      }, () => {
        queryClient.invalidateQueries({ queryKey: ['tenant-events'] });
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [user?.id, queryClient]);

  // Categorize proposals
  const activeProposals = proposals.filter(p => !p.isRejected && p.currentStep < 8);
  const approvedProposals = proposals.filter(p => !p.isRejected && p.currentStep >= 8);
  const rejectedProposals = proposals.filter(p => p.isRejected);
  
  const activeProposal = activeProposals[0] || null;
  const proposalHistory = proposals.filter(p => p.isRejected || p.currentStep >= 8);

  const {
    data: events = [],
    isLoading: eventsLoading,
  } = useQuery({
    queryKey: ['tenant-events', activeProposal?.id],
    queryFn: () => fetchRentalEvents(activeProposal!.id),
    enabled: !!activeProposal,
    staleTime: 30000,
  });

  let dashboardState: DashboardState = 'loading';
  if (!proposalsLoading) {
    dashboardState = proposals.length > 0 ? 'active_journey' : 'matchmaker';
  }

  return {
    dashboardState,
    activeProposal,
    allProposals: proposals,
    activeProposals,
    approvedProposals,
    rejectedProposals,
    proposalHistory,
    events,
    isLoading: proposalsLoading || (!!activeProposal && eventsLoading),
    error: proposalsError as Error | null,
    refetch: refetchProposals,
  };
}
