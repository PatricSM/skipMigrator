import { useState, useEffect, useCallback, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { RentalTracking, RentalEvent } from "@/types/tracking";
import { useAuth } from "@/hooks/useAuth";
import { DOC_TYPE_LABELS } from "@/types/documentLimits";
import { setRentalStepAndLog, logRentalEvent } from "@/lib/proposalEvents";
import { logger } from "@/lib/logger";
import { notifyStepChange, notifyEvent } from "@/lib/notifications";

interface PropertyFromAPI {
  id: string;
  code: string;
  image: string;
  images: string[];
  price?: number;
  condoFee?: number;
  iptu?: number;
}

interface UseRentalTrackingResult {
  rental: RentalTracking | null;
  events: RentalEvent[];
  loading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
}

// Helper to validate UUID format
function isValidUUID(id: string): boolean {
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  return uuidRegex.test(id);
}

export function useRentalTracking(rentalId?: string): UseRentalTrackingResult {
  const { user } = useAuth();
  const [rental, setRental] = useState<RentalTracking | null>(null);
  const [events, setEvents] = useState<RentalEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchRental = useCallback(async () => {
    if (!user) {
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError(null);

      let query = supabase.from("rentals").select("*");

      if (rentalId && isValidUUID(rentalId)) {
        query = query.eq("id", rentalId);
      } else {
        query = query.eq("user_id", user.id).order("created_at", { ascending: false }).limit(1);
      }

      const { data: rentalData, error: rentalError } = await query.maybeSingle();

      if (rentalError) throw rentalError;

      if (!rentalData) {
        setRental(null);
        setEvents([]);
        setLoading(false);
        return;
      }

      const pendingDocs = rentalData.pending_documents as string[] | null;

      // Fetch property data from API
      let propertyImage: string | undefined = undefined;
      let rentValue = rentalData.rent_value ? Number(rentalData.rent_value) : null;
      let condoFee = rentalData.condo_fee ? Number(rentalData.condo_fee) : null;
      let iptu = rentalData.iptu ? Number(rentalData.iptu) : null;

      try {
        const { data: propData } = await supabase.functions.invoke<{ success: boolean; properties: PropertyFromAPI[] }>(
          "fetch-properties",
        );
        if (propData?.success && propData.properties) {
          const prop = propData.properties.find(
            (p) => p.id === rentalData.property_id || p.code === rentalData.property_code,
          );
          if (prop) {
            propertyImage = prop.image || prop.images?.[0];
            if (rentValue === null && prop.price) rentValue = prop.price;
            if (condoFee === null && prop.condoFee) condoFee = prop.condoFee;
            if (iptu === null && prop.iptu) iptu = prop.iptu;
          }
        }
      } catch {
        // Property data fetch is non-critical
      }

      // Fetch proposal count for the same property
      let proposalCount = 1;
      try {
        const { count } = await supabase
          .from('rentals')
          .select('*', { count: 'exact', head: true })
          .eq('property_code', rentalData.property_code)
          .eq('is_rejected', false);
        proposalCount = count || 1;
      } catch {
        // Non-critical
      }

      const mappedRental: RentalTracking = {
        id: rentalData.id,
        protocol: rentalData.protocol,
        propertyId: rentalData.property_id,
        propertyAddress: rentalData.property_address,
        propertyCode: rentalData.property_code,
        propertyImage,
        rentValue,
        condoFee,
        iptu,
        currentStep: rentalData.current_step || 1,
        stepStatus: rentalData.step_status as RentalTracking["stepStatus"],
        tenantStatus: rentalData.tenant_status || "in_analysis",
        hasPending: rentalData.has_pending || false,
        pending: rentalData.has_pending
          ? {
              description: rentalData.pending_description || "",
              reason: rentalData.pending_reason || "",
            }
          : undefined,
        pendingDescription: rentalData.pending_description || undefined,
        isRejected: rentalData.is_rejected || false,
        rejectionReason: rentalData.rejection_reason || undefined,
        contractPreviewUrl: rentalData.contract_preview_url || undefined,
        contractSignUrl: rentalData.contract_sign_url || undefined,
        pendingDocuments: pendingDocs && pendingDocs.length > 0 ? pendingDocs : undefined,
        proposalType: ((rentalData as any).proposal_type as 'standard' | 'direct') || 'standard',
        proposedValue: (rentalData as any).proposed_value || null,
        landlordAccepted: (rentalData as any).landlord_accepted || false,
        landlordAcceptedAt: (rentalData as any).landlord_accepted_at 
          ? new Date((rentalData as any).landlord_accepted_at) 
          : undefined,
        docsSubmittedEarly: (rentalData as any).docs_submitted_early || false,
        documentsFinalizedAt: (rentalData as any).documents_finalized_at
          ? new Date((rentalData as any).documents_finalized_at)
          : undefined,
        proposalCount,
        proposalStatus: (rentalData as any).proposal_status || 'waiting_landlord_acceptance',
        documentsCycle: (rentalData as any).documents_cycle || 1,
        createdAt: new Date(rentalData.created_at),
        updatedAt: new Date(rentalData.updated_at),
      };

      setRental(mappedRental);

      // Fetch events
      const { data: eventsData, error: eventsError } = await supabase
        .from("rental_events")
        .select("*")
        .eq("rental_id", rentalData.id)
        .order("created_at", { ascending: true });

      if (eventsError) {
        console.error("Error fetching events:", eventsError);
      }

      const mappedEvents: RentalEvent[] = (eventsData || []).map((event) => ({
        id: event.id,
        eventType: event.event_type,
        description: event.description,
        createdAt: new Date(event.created_at),
      }));

      setEvents(mappedEvents);
    } catch (err) {
      console.error("Error fetching rental:", err);
      setError("Erro ao carregar dados da locação");
    } finally {
      setLoading(false);
    }
  }, [user, rentalId]);

  // Initial fetch
  useEffect(() => {
    fetchRental();
  }, [fetchRental]);

  // Real-time subscriptions
  useEffect(() => {
    if (!rental?.id) return;

    const rentalIdValue = rental.id;

    const eventsChannel = supabase
      .channel(`rental-events-${rentalIdValue}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'rental_events',
        filter: `rental_id=eq.${rentalIdValue}`,
      }, (payload) => {
        const newEvent = payload.new as any;
        setEvents(prev => {
          if (prev.some(e => e.id === newEvent.id)) return prev;
          // Trigger browser notification for the new event
          notifyEvent(newEvent.event_type);
          return [...prev, {
            id: newEvent.id,
            eventType: newEvent.event_type,
            description: newEvent.description,
            createdAt: new Date(newEvent.created_at),
          }];
        });
      })
      .subscribe();

    const rentalChannel = supabase
      .channel(`rental-${rentalIdValue}`)
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'rentals',
        filter: `id=eq.${rentalIdValue}`,
      }, (payload) => {
        const updated = payload.new as any;
        if (updated.current_step && updated.current_step !== rental?.currentStep) {
          notifyStepChange(updated.current_step);
        }
        fetchRental();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(eventsChannel);
      supabase.removeChannel(rentalChannel);
    };
  }, [rental?.id, fetchRental]);

  return {
    rental,
    events,
    loading,
    error,
    refetch: fetchRental,
  };
}

// Helper function to generate protocol using property code + date (DD-MM-YY)
export function generateProtocol(propertyCode: string): string {
  const now = new Date();
  const day = now.getDate().toString().padStart(2, "0");
  const month = (now.getMonth() + 1).toString().padStart(2, "0");
  const year = now.getFullYear().toString().slice(-2);
  return `${propertyCode.toUpperCase()}-${day}-${month}-${year}`;
}

// Helper function to create a new rental
export async function createRental(
  userId: string,
  propertyId: string,
  propertyAddress: string,
  propertyCode: string,
  rentValue?: number,
  condoFee?: number,
  iptu?: number,
  pendingDocuments?: string[],
): Promise<{ id: string; protocol: string } | null> {
  const protocol = generateProtocol(propertyCode);
  const hasPendingDocs = pendingDocuments && pendingDocuments.length > 0;

  const { data, error } = await supabase
    .from("rentals")
    .insert({
      user_id: userId,
      property_id: propertyId,
      property_address: propertyAddress,
      property_code: propertyCode,
      rent_value: rentValue,
      condo_fee: condoFee,
      iptu: iptu,
      protocol: protocol,
      current_step: 1,
      step_status: "pending",
      tenant_status: "proposal_created",
      pending_documents: pendingDocuments || [],
      has_pending: hasPendingDocs || false,
      pending_description: hasPendingDocs ? "Documentos pendentes de envio" : null,
    })
    .select("id, protocol")
    .single();

  if (error) {
    console.error("Error creating rental:", error);
    return null;
  }

  await logRentalEvent({
    rentalId: data.id,
    eventType: "proposal_created",
    description: "Proposta criada pelo locatário",
    idempotencyKey: `proposal_created_${data.id}`,
  });

  return data;
}

// Helper function to update pending documents after upload
export async function removePendingDocument(rentalId: string, documentType: string): Promise<boolean> {
  const { data: rental, error: fetchError } = await supabase
    .from("rentals")
    .select("pending_documents")
    .eq("id", rentalId)
    .single();

  if (fetchError || !rental) {
    console.error("Error fetching rental:", fetchError);
    return false;
  }

  const currentPending = (rental.pending_documents as string[]) || [];
  const updatedPending = currentPending.filter((doc) => doc !== documentType);

  const { error: updateError } = await supabase
    .from("rentals")
    .update({
      pending_documents: updatedPending,
    })
    .eq("id", rentalId);

  if (updateError) {
    console.error("Error updating rental:", updateError);
    return false;
  }

  return true;
}

// Helper function to finalize document submission (explicit user action).
// Uses setRentalStepAndLog for centralized step transitions.
export async function finalizeDocumentSubmission(
  rentalId: string,
  missingTypes?: string[]
): Promise<boolean> {
  const hasPending = missingTypes && missingTypes.length > 0;

  if (hasPending) {
    // Save pending state without advancing step
    const { error: updateError } = await supabase
      .from("rentals")
      .update({
        has_pending: true,
        pending_documents: missingTypes,
        pending_reason: 'Documentos faltando',
        pending_description: `Faltam: ${missingTypes.map(t => DOC_TYPE_LABELS[t]?.label || t).join(', ')}`,
      })
      .eq("id", rentalId);

    if (updateError) {
      console.error("Error saving pending:", updateError);
      return false;
    }

    await logRentalEvent({
      rentalId,
      eventType: 'documents_uploaded',
      description: `Documentação salva com pendências: ${missingTypes.map(t => DOC_TYPE_LABELS[t]?.label || t).join(', ')}`,
    });
    return true;
  }

  // Full finalization — advance to step 4 via centralized function
  const stepSuccess = await setRentalStepAndLog({
    rentalId,
    newStep: 4,
    reason: 'Documentação finalizada — análise de ficha iniciada.',
    extraUpdate: {
      pending_documents: [] as string[],
      step_status: "in_progress",
      has_pending: false,
      pending_description: null as string | null,
      pending_reason: null as string | null,
      documents_finalized_at: new Date().toISOString(),
    },
  });

  if (!stepSuccess) {
    console.error("Error finalizing submission via setRentalStepAndLog");
    return false;
  }

  await logRentalEvent({
    rentalId,
    eventType: 'documents_finalized',
    description: 'Documentação finalizada pelo locatário — Análise de ficha iniciada',
    idempotencyKey: `docs_finalized_${rentalId}_cycle_${Date.now()}`,
  });

  logger.info('[DOCS_EVENT_FINALIZED]', { rentalId });
  return true;
}

// Reopen finalized documents — resets documents_finalized_at and logs event
export async function reopenDocumentSubmission(rentalId: string): Promise<boolean> {
  logger.info('[EDIT_MODE] User reopened documents for rentalId:', rentalId);

  // Fetch current cycle to increment
  const { data: rental } = await supabase
    .from('rentals')
    .select('documents_cycle')
    .eq('id', rentalId)
    .maybeSingle();

  const currentCycle = (rental as any)?.documents_cycle || 1;

  // Use setRentalStepAndLog for step transition back to 3
  const stepSuccess = await setRentalStepAndLog({
    rentalId,
    newStep: 3,
    reason: 'Documentação reaberta para edição.',
    extraUpdate: {
      documents_finalized_at: null,
      has_pending: true,
      step_status: 'in_progress',
      documents_cycle: currentCycle + 1,
    },
  });

  if (!stepSuccess) {
    console.error("[EDIT_MODE] Error reopening documents:", rentalId);
    return false;
  }

  await logRentalEvent({
    rentalId,
    eventType: 'documents_reopened',
    description: `O usuário reabriu a documentação (ciclo ${currentCycle + 1}).`,
    idempotencyKey: `docs_reopened_${rentalId}_cycle_${currentCycle + 1}`,
  });

  return true;
}

// Helper to create a documents_uploaded event (no finalization)
export async function createDocumentUploadEvent(
  rentalId: string,
  uploadedTypes: string[],
  missingTypesAfter: string[]
): Promise<void> {
  // Deduplication: check if same event exists in last 60s
  const { data: recent } = await supabase
    .from("rental_events")
    .select("id, created_at")
    .eq("rental_id", rentalId)
    .eq("event_type", "documents_uploaded")
    .order("created_at", { ascending: false })
    .limit(1);

  if (recent && recent.length > 0) {
    const lastEvent = new Date(recent[0].created_at);
    if (Date.now() - lastEvent.getTime() < 60_000) {
      logger.info('[DOCS_EVENT_UPLOADED] skipped (dedup)', { uploadedTypes });
      return;
    }
  }

  const uploadedLabels = uploadedTypes.map(t => DOC_TYPE_LABELS[t]?.label || t).join(', ');
  const desc = missingTypesAfter.length > 0
    ? `Documentos enviados: ${uploadedLabels}. Ainda faltam: ${missingTypesAfter.map(t => DOC_TYPE_LABELS[t]?.label || t).join(', ')}`
    : `Documentos enviados: ${uploadedLabels}. Todos os documentos obrigatórios foram enviados.`;

  await supabase.from("rental_events").insert({
    rental_id: rentalId,
    event_type: "documents_uploaded",
    description: desc,
  });

  logger.info('[DOCS_EVENT_UPLOADED]', { uploadedTypes, missingTypesAfter });
}
