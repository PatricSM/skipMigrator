import { useCallback, useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export type AdminStage = 1 | 2 | 3 | 4 | 5 | 6 | 7;

export type AdminRental = {
  id: string;
  protocol: string;
  user_id: string;
  property_id: string;
  property_code: string;
  property_address: string;
  rent_value: number | null;
  condo_fee: number | null;
  iptu: number | null;
  landlord_property_id: string | null;
  tenant_status: string | null;
  is_rejected: boolean | null;
  rejection_reason: string | null;
  admin_stage: number;
  admin_stage_id?: string | null;
  admin_stage_entered_at?: string | null;
  created_at: string | null;
  updated_at: string | null;
  // Step-based fields (source of truth)
  current_step: number | null;
  proposal_status: string | null;
  step_status: string | null;
  has_pending: boolean | null;
  documents_finalized_at: string | null;
  documents_cycle: number | null;
  crm_deal_id: string | null;
};

export type AdminProperty = {
  id: string;
  short_address: string;
  images: string[] | null;
  rent_value: number | null;
  condo_fee: number | null;
  iptu: number | null;
};

export type AdminProfile = {
  id: string;
  full_name: string | null;
  email: string | null;
  phone: string | null;
  cpf_encrypted?: string | null;
  birth_date?: string | null;
  nationality?: string | null;
  nationality_country?: string | null;
  marital_status?: string | null;
  profession?: string | null;
  is_politically_exposed?: boolean | null;
  monthly_income?: number | null;
};

export type AdminRentalWithProfile = AdminRental & {
  tenant?: AdminProfile;
  property?: AdminProperty;
};

export function useAdminRentals() {
  const [rentals, setRentals] = useState<AdminRentalWithProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchRentals = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const { data: rentalsData, error: rentalsError } = await supabase
        .from("rentals")
        .select(
          "id, protocol, user_id, property_id, property_code, property_address, rent_value, condo_fee, iptu, landlord_property_id, tenant_status, is_rejected, rejection_reason, admin_stage, admin_stage_id, admin_stage_entered_at, created_at, updated_at, current_step, proposal_status, step_status, has_pending, documents_finalized_at, documents_cycle, crm_deal_id"
        )
        .order("created_at", { ascending: false })
        .limit(500);

      if (rentalsError) throw rentalsError;

      const base = (rentalsData ?? []) as AdminRental[];
      const userIds = Array.from(new Set(base.map((r) => r.user_id).filter(Boolean)));

      const landlordPropertyIds = Array.from(
        new Set(base.map((r) => r.landlord_property_id).filter(Boolean) as string[])
      );

      let profileMap = new Map<string, AdminProfile>();
      if (userIds.length) {
        const { data: profilesData, error: profilesError } = await supabase
          .from("profiles")
          .select(
            "id, full_name, email, phone, cpf_encrypted, birth_date, nationality, nationality_country, marital_status, profession, is_politically_exposed, monthly_income"
          )
          .in("id", userIds);
        if (profilesError) throw profilesError;
        (profilesData ?? []).forEach((p) => profileMap.set(p.id, p as AdminProfile));
      }

      let propertyMap = new Map<string, AdminProperty>();
      if (landlordPropertyIds.length) {
        const { data: propertiesData, error: propertiesError } = await supabase
          .from("properties")
          .select("id, short_address, images, rent_value, condo_fee, iptu")
          .in("id", landlordPropertyIds);
        if (propertiesError) throw propertiesError;
        (propertiesData ?? []).forEach((p) => propertyMap.set(p.id, p as AdminProperty));
      }

      setRentals(
        base.map((r) => ({
          ...r,
          tenant: profileMap.get(r.user_id),
          property: r.landlord_property_id ? propertyMap.get(r.landlord_property_id) : undefined,
        }))
      );
    } catch (e: any) {
      setError(e?.message ?? "Erro ao carregar propostas");
      setRentals([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchRentals();
  }, [fetchRentals]);

  // Realtime subscription para atualizações automáticas
  useEffect(() => {
    const channel = supabase
      .channel('admin-rentals-live')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'rentals' },
        () => fetchRentals()
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'documents' },
        () => fetchRentals()
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'profiles' },
        () => fetchRentals()
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'landlord_data' },
        () => fetchRentals()
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'landlord_documents' },
        () => fetchRentals()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchRentals]);

  const byStage = useMemo(() => {
    const map = new Map<AdminStage, AdminRentalWithProfile[]>();
    ([1, 2, 3, 4, 5, 6, 7] as AdminStage[]).forEach((s) => map.set(s, []));
    rentals.forEach((r) => {
      const stage = (Math.min(7, Math.max(1, Number(r.admin_stage ?? 1))) as AdminStage);
      map.get(stage)?.push(r);
    });
    return map;
  }, [rentals]);

  return { rentals, byStage, loading, error, refetch: fetchRentals };
}
