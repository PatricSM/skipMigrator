import { useState, useEffect, useCallback } from 'react';
import {
  isNotificationSupported,
  isNotificationEnabled,
  requestNotificationPermission,
  disableNotifications,
  getNotificationPermission,
} from '@/lib/notifications';

export function useNotificationPermission() {
  const [supported, setSupported] = useState(false);
  const [enabled, setEnabled] = useState(false);
  const [permission, setPermission] = useState<NotificationPermission | 'unsupported'>('unsupported');

  useEffect(() => {
    const sup = isNotificationSupported();
    setSupported(sup);
    setEnabled(isNotificationEnabled());
    setPermission(getNotificationPermission());
  }, []);

  const requestPermission = useCallback(async () => {
    const granted = await requestNotificationPermission();
    setEnabled(granted);
    setPermission(getNotificationPermission());
    return granted;
  }, []);

  const disable = useCallback(() => {
    disableNotifications();
    setEnabled(false);
  }, []);

  return { supported, enabled, permission, requestPermission, disable };
}
