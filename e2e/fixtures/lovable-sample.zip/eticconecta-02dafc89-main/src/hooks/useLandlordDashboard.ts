import { useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import {
  LandlordKPI,
  PropertyPerformance,
  TenantProposal,
  VACANT_STATUSES,
  RENTED_STATUSES,
  calculateTenantScore,
} from '@/types/locador-dashboard';

export function useLandlordDashboard() {
  const { user, profile } = useAuth();

  // Query for landlord profile to get property_codes
  const { data: landlordProfile } = useQuery({
    queryKey: ['landlord-profile', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('profiles')
        .select('property_codes, codigo_locador, total_imoveis')
        .eq('id', user?.id)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  // Extract property codes from profile (JSONB array)
  const propertyCodes = useMemo(() => {
    const codes = landlordProfile?.property_codes;
    if (Array.isArray(codes)) return codes as string[];
    if (typeof codes === 'string') {
      try {
        const parsed = JSON.parse(codes);
        return Array.isArray(parsed) ? parsed : [];
      } catch {
        return [];
      }
    }
    return [];
  }, [landlordProfile]);

  // SECURE: Query rentals ONLY by property_codes - no unsafe fallback
  const { data: dbRentals, isLoading: rentalsLoading } = useQuery({
    queryKey: ['landlord-rentals-by-code', propertyCodes, user?.id],
    queryFn: async () => {
      // SECURITY: Without property_codes, return empty array
      // DO NOT use fallback that exposes other users' data
      if (propertyCodes.length === 0) {
        console.info('Landlord has no property_codes configured - returning empty');
        return [];
      }
      
      const { data, error } = await supabase
        .from('rental_full_view')
        .select('*')
        .in('property_code', propertyCodes);
      
      if (error) throw error;
      return data || [];
    },
    enabled: !!user,
  });

  // Stable rental IDs for query key
  const rentalIds = useMemo(() => 
    (dbRentals || []).map(r => r.id).filter(Boolean) as string[],
    [dbRentals]
  );

  // Query for real documents count (batch query to avoid N+1)
  const { data: docsData } = useQuery({
    queryKey: ['landlord-docs-count', rentalIds],
    queryFn: async () => {
      if (rentalIds.length === 0) return {};
      
      const { data } = await supabase
        .from('documents')
        .select('rental_id, status')
        .in('rental_id', rentalIds);
      
      // Group by rental_id
      const grouped: Record<string, { total: number; approved: number }> = {};
      (data || []).forEach(d => {
        if (!d.rental_id) return;
        if (!grouped[d.rental_id]) {
          grouped[d.rental_id] = { total: 0, approved: 0 };
        }
        grouped[d.rental_id].total++;
        if (d.status === 'approved') {
          grouped[d.rental_id].approved++;
        }
      });
      return grouped;
    },
    enabled: rentalIds.length > 0,
  });

  // Also query local properties for backward compatibility
  const { data: dbProperties, isLoading: propertiesLoading } = useQuery({
    queryKey: ['landlord-properties', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('properties')
        .select('*')
        .eq('owner_id', user?.id);
      if (error) throw error;
      return data || [];
    },
    enabled: !!user,
  });

  // Create "virtual properties" from rentals grouped by property_code
  const virtualProperties: PropertyPerformance[] = useMemo(() => {
    const grouped: Record<string, {
      code: string;
      address: string;
      rentValue: number;
      condoFee: number;
      iptu: number;
      proposals: number;
      hasActionRequired: boolean;
      rentals: typeof dbRentals;
    }> = {};

    (dbRentals || []).forEach(r => {
      const code = r.property_code || 'UNKNOWN';
      if (code === ':id') return; // Skip invalid entries
      
      if (!grouped[code]) {
        grouped[code] = {
          code,
          address: r.property_address || '',
          rentValue: Number(r.rent_value) || 0,
          condoFee: Number(r.condo_fee) || 0,
          iptu: Number(r.iptu) || 0,
          proposals: 0,
          hasActionRequired: false,
          rentals: [],
        };
      }
      grouped[code].proposals++;
      if (r.landlord_action_required) {
        grouped[code].hasActionRequired = true;
      }
      (grouped[code].rentals as any[]).push(r);
    });

    return Object.values(grouped).map(g => ({
      id: g.code,
      code: g.code,
      address: g.address,
      neighborhood: g.address.split(',')[1]?.trim() || g.address.split(',')[0] || '',
      status: g.hasActionRequired ? 'vacant' as const : 'rented' as const,
      rentValue: g.rentValue,
      condoFee: g.condoFee,
      iptu: g.iptu,
      image: 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=400&h=300&fit=crop',
      views: 0,
      visits: 0,
      proposals: g.proposals,
      visitFeedbacks: [],
      averageRegionPrice: g.rentValue * 0.9,
      suggestedPrice: g.rentValue * 0.95,
      revenueHistory: g.hasActionRequired ? [] : Array(6).fill(g.rentValue),
      description: undefined,
    }));
  }, [dbRentals]);

  // Merge local properties with virtual properties
  const properties: PropertyPerformance[] = useMemo(() => {
    const localProperties: PropertyPerformance[] = (dbProperties || []).map(p => {
      const isVacant = VACANT_STATUSES.includes(p.status?.toLowerCase() || '');
      const isRented = RENTED_STATUSES.includes(p.status?.toLowerCase() || '');

      // Count proposals for this property from rentals
      const proposalCount = (dbRentals || []).filter(
        r => r.property_code === p.code || r.landlord_property_id === p.id
      ).length;

      return {
        id: p.id,
        code: p.code,
        address: p.address || p.short_address,
        neighborhood: p.short_address?.split(' - ')[0] || '',
        status: isRented ? 'rented' : isVacant ? 'vacant' : (p.status as PropertyPerformance['status']) || 'vacant',
        rentValue: p.rent_value || 0,
        condoFee: p.condo_fee || 0,
        iptu: p.iptu || 0,
        image: p.images?.[0] || 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=400&h=300&fit=crop',
        views: 0,
        visits: 0,
        proposals: proposalCount,
        visitFeedbacks: [],
        averageRegionPrice: (p.rent_value || 3000) * 0.9,
        suggestedPrice: (p.rent_value || 3000) * 0.95,
        revenueHistory: isRented ? Array(6).fill(p.rent_value || 0) : [],
        description: p.description || undefined,
      };
    });

    // Merge: local properties + virtual properties (avoid duplicates by code)
    const localCodes = new Set(localProperties.map(p => p.code));
    const uniqueVirtual = virtualProperties.filter(vp => !localCodes.has(vp.code));
    const allProperties = [...localProperties, ...uniqueVirtual];

    // Return empty array if no properties (no mock data fallback)
    if (allProperties.length === 0) {
      return [];
    }

    // Sort: vacant with proposals first, then vacant, then rented
    return allProperties.sort((a, b) => {
      if (a.status === 'vacant' && b.status !== 'vacant') return -1;
      if (a.status !== 'vacant' && b.status === 'vacant') return 1;
      if (a.status === 'vacant' && b.status === 'vacant') {
        return b.proposals - a.proposals;
      }
      return 0;
    });
  }, [dbProperties, virtualProperties, dbRentals]);

  // Map rentals to TenantProposal format with REAL document data
  const proposals: TenantProposal[] = useMemo(() => {
    const realProposals: TenantProposal[] = (dbRentals || [])
      .filter(r => r.property_code !== ':id')
      .map(r => {
        const monthlyIncome = Number(r.tenant_monthly_income) || 0;
        const rentValue = Number(r.rent_value) || 0;
        
        // Get real document counts for this rental
        const rentalDocs = docsData?.[r.id || ''] || { total: 0, approved: 0 };

        // Calculate tenant score with REAL data
        const scoreResult = calculateTenantScore(
          monthlyIncome,
          rentValue,
          rentalDocs.approved,
          rentalDocs.total || 3, // Fallback to 3 expected if no docs yet
          (r.current_step || 1) >= 4
        );

        // Determine document status based on real data
        const docsStatus: 'pending' | 'partial' | 'complete' = 
          rentalDocs.total === 0 
            ? 'pending'
            : rentalDocs.approved === rentalDocs.total 
              ? 'complete'
              : 'partial';

        // Determine if direct rental (urgent) - step 2 with action required
        const isDirectRental = r.landlord_action_required === true && r.current_step === 2;

        return {
          id: r.id || '',
          applicationId: r.id || '',
          rentalId: r.id || '',
          protocol: r.protocol || '',
          propertyId: r.landlord_property_id || r.property_code || '',
          propertyCode: r.property_code || '',
          propertyAddress: r.property_address || '',
          propertyRentValue: rentValue,
          tenantId: '',
          tenantName: r.tenant_name || 'Locatário',
          familyMembers: 2, // TODO: Add to rental_full_view when available
          familyIncome: monthlyIncome,
          tenantScore: scoreResult.score,
          tenantScoreStatus: scoreResult.status,
          tenantScoreReasons: scoreResult.reasons,
          badges: {
            incomeVerified: monthlyIncome > 0,
            guaranteeApproved: (r.current_step || 1) >= 4,
            goodHistory: true,
          },
          imobiliariaApproved: (r.current_step || 1) >= 2,
          currentStep: r.current_step || 1,
          status: r.step_status || 'pending',
          createdAt: new Date(r.created_at || Date.now()),
          respondedAt: !r.landlord_action_required && r.updated_at
            ? new Date(r.updated_at)
            : undefined,
          isUrgent: r.landlord_action_required === true,
          isDirectRental,
          proposalType: isDirectRental ? 'direct' : 'standard',
          proposedValue: null,
          landlordAccepted: r.landlord_action_required === false,
          landlordAcceptedAt: r.landlord_action_required === false && r.updated_at
            ? new Date(r.updated_at)
            : undefined,
          docsStatus,
          docsCount: rentalDocs.total,
          fichaStatus: r.step_status === 'approved' ? 'aprovada' : null,
        };
      });

    // Return empty array if no proposals (no mock data fallback)
    if (realProposals.length === 0) {
      return [];
    }

    // Sort: direct/urgent first, then by date descending
    return realProposals.sort((a, b) => {
      if (a.isDirectRental && !b.isDirectRental) return -1;
      if (!a.isDirectRental && b.isDirectRental) return 1;
      if (a.isUrgent && !b.isUrgent) return -1;
      if (!a.isUrgent && b.isUrgent) return 1;
      return b.createdAt.getTime() - a.createdAt.getTime();
    });
  }, [dbRentals, docsData]);

  // Separate proposals into urgent and analysis queues
  const urgentProposals = useMemo(() =>
    proposals.filter(p => p.isDirectRental && !p.landlordAccepted),
    [proposals]
  );

  const analysisProposals = useMemo(() =>
    proposals.filter(p => !p.isDirectRental && !p.landlordAccepted),
    [proposals]
  );

  // Calculate KPIs
  const kpis: LandlordKPI = useMemo(() => {
    const rentedProperties = properties.filter(p => p.status === 'rented');
    const vacantProperties = properties.filter(p =>
      p.status === 'vacant' || p.status === 'em_negociacao'
    );

    const monthlyRevenue = rentedProperties.reduce((acc, p) => acc + p.rentValue, 0);

    // Vacancy cost: rent + condo + iptu for vacant properties
    const vacancyCost = vacantProperties.reduce((acc, p) => acc + p.rentValue, 0);
    const vacancyCostWithExpenses = vacantProperties.reduce(
      (acc, p) => acc + p.rentValue + p.condoFee + p.iptu,
      0
    );

    return {
      totalRevenue: monthlyRevenue * 6,
      monthlyRevenue,
      revenueTrend: [
        { month: 'Ago', value: monthlyRevenue * 0.95 },
        { month: 'Set', value: monthlyRevenue * 0.98 },
        { month: 'Out', value: monthlyRevenue },
        { month: 'Nov', value: monthlyRevenue },
        { month: 'Dez', value: monthlyRevenue },
        { month: 'Jan', value: monthlyRevenue },
      ],
      vacancyCost,
      vacancyCostWithExpenses,
      dailyVacancyLoss: Math.round(vacancyCostWithExpenses / 30),
      activeProperties: rentedProperties.length,
      vacantProperties: vacantProperties.length,
      pendingProposals: proposals.length,
      urgentProposals: urgentProposals.length,
    };
  }, [properties, proposals, urgentProposals]);

  // Group proposals by property
  const proposalsByProperty = useMemo(() => {
    const grouped: Record<string, TenantProposal[]> = {};
    proposals.forEach(p => {
      const key = p.propertyCode || p.propertyId;
      if (!grouped[key]) {
        grouped[key] = [];
      }
      grouped[key].push(p);
    });
    return grouped;
  }, [proposals]);

  const isLoading = propertiesLoading || rentalsLoading;
  const hasNoPropertyCodes = propertyCodes.length === 0 && !rentalsLoading;

  return {
    properties,
    proposals,
    urgentProposals,
    analysisProposals,
    proposalsByProperty,
    kpis,
    isLoading,
    profile,
    propertyCodes,
    hasNoPropertyCodes, // UI can show "No properties linked" message
  };
}
