import { supabase } from '@/integrations/supabase/client';
import { logger } from '@/lib/logger';

export function useAuditLog() {
  const logAction = async (
    action: string,
    tableName: string,
    recordId?: string,
    data?: Record<string, unknown>
  ) => {
    try {
      await supabase.rpc('log_audit', {
        p_action: action,
        p_table_name: tableName,
        p_record_id: recordId || null,
        p_new_data: data ? JSON.stringify(data) : null,
      });
    } catch (error) {
      logger.error('Audit log error:', error);
    }
  };

  return { logAction };
}
