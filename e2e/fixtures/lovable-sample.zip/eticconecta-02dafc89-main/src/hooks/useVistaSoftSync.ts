import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

const SYNC_INTERVAL_HOURS = 12;
const WEBHOOK_URL = 'https://powerfulmarlin-n8n.cloudfy.live/webhook/validar-locador';

interface SyncState {
  isSyncing: boolean;
  lastSyncAt: Date | null;
  error: string | null;
}

export function useVistaSoftSync() {
  const { user, isLandlord } = useAuth();
  const [syncState, setSyncState] = useState<SyncState>({
    isSyncing: false,
    lastSyncAt: null,
    error: null,
  });
  
  // Prevent multiple sync attempts
  const syncAttemptedRef = useRef(false);

  const shouldSync = useCallback((lastSyncAt: string | null): boolean => {
    // Sincronizar se nunca sincronizou
    if (!lastSyncAt) return true;
    
    // Verificar se passaram mais de 12 horas
    const lastSync = new Date(lastSyncAt);
    const hoursSinceSync = (Date.now() - lastSync.getTime()) / (1000 * 60 * 60);
    return hoursSinceSync >= SYNC_INTERVAL_HOURS;
  }, []);

  const performSync = useCallback(async (userId: string, phoneE164: string) => {
    setSyncState(prev => ({ ...prev, isSyncing: true, error: null }));
    
    try {
      const response = await fetch(WEBHOOK_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: userId,
          telefone: phoneE164,
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      // Atualizar timestamp de sincronizacao no profile
      const now = new Date().toISOString();
      await supabase
        .from('profiles')
        .update({
          last_vista_sync_at: now,
          last_vista_sync_status: 'success',
          last_vista_sync_error: null,
        })
        .eq('id', userId);

      setSyncState({
        isSyncing: false,
        lastSyncAt: new Date(now),
        error: null,
      });

      console.info('[VistaSoft Sync] Sincronizacao concluida com sucesso');
    } catch (error) {
      // Tratar erro silenciosamente - nao interromper UX
      const errorMessage = error instanceof Error ? error.message : 'Erro desconhecido';
      console.warn('[VistaSoft Sync] Erro na sincronizacao:', errorMessage);
      
      // Registrar erro no profile (para debug futuro)
      await supabase
        .from('profiles')
        .update({
          last_vista_sync_status: 'error',
          last_vista_sync_error: errorMessage,
        })
        .eq('id', userId);

      setSyncState(prev => ({
        ...prev,
        isSyncing: false,
        error: errorMessage,
      }));
    }
  }, []);

  // Efeito principal: verificar e executar sync quando usuario logar
  useEffect(() => {
    // Apenas para locadores autenticados
    if (!user || !isLandlord) return;
    
    // Prevent duplicate sync attempts in StrictMode
    if (syncAttemptedRef.current) return;
    syncAttemptedRef.current = true;

    const checkAndSync = async () => {
      try {
        // Buscar dados do profile
        const { data: profile, error } = await supabase
          .from('profiles')
          .select('phone_e164, last_vista_sync_at')
          .eq('id', user.id)
          .single();

        if (error || !profile) {
          console.warn('[VistaSoft Sync] Profile nao encontrado');
          return;
        }

        // Atualizar estado com ultima sincronizacao
        if (profile.last_vista_sync_at) {
          setSyncState(prev => ({
            ...prev,
            lastSyncAt: new Date(profile.last_vista_sync_at),
          }));
        }

        // Verificar se precisa sincronizar
        if (!shouldSync(profile.last_vista_sync_at)) {
          console.info('[VistaSoft Sync] Sincronizacao nao necessaria (< 12h)');
          return;
        }

        // Verificar se tem telefone
        if (!profile.phone_e164) {
          console.warn('[VistaSoft Sync] Usuario sem telefone cadastrado');
          return;
        }

        // Executar sincronizacao
        await performSync(user.id, profile.phone_e164);
      } catch (error) {
        console.warn('[VistaSoft Sync] Erro ao verificar sincronizacao:', error);
      }
    };

    checkAndSync();
  }, [user, isLandlord, shouldSync, performSync]);

  return {
    isSyncing: syncState.isSyncing,
    lastSyncAt: syncState.lastSyncAt,
    syncError: syncState.error,
  };
}
