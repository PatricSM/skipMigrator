import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

// Light property for listings (optimized payload from edge function)
export interface Property {
  id: string;
  code: string;
  title: string;
  streetName: string;
  neighborhood: string;
  shortAddress: string;
  price: number;
  bedrooms: number;
  bathrooms: number;
  suites: number;
  parkingSpaces: number;
  area: number;
  image: string;
  images3: string[];
  condoFee: number;
  iptu: number;
}

interface FetchPropertiesResponse {
  success: boolean;
  count: number;
  properties: Property[];
  fetchedAt: string;
  error?: string;
}

async function fetchProperties(): Promise<Property[]> {
  const { data, error } = await supabase.functions.invoke<FetchPropertiesResponse>(
    "fetch-properties"
  );

  if (error) {
    console.error("Error fetching properties:", error);
    throw new Error("Falha ao carregar imóveis");
  }

  if (!data?.success) {
    console.error("API error:", data?.error);
    throw new Error(data?.error || "Falha ao carregar imóveis");
  }

  return data.properties;
}

export function useProperties() {
  return useQuery({
    queryKey: ["properties"],
    queryFn: fetchProperties,
    staleTime: 10 * 60 * 1000, // 10 minutes (matches server cache)
    gcTime: 30 * 60 * 1000, // 30 minutes
    retry: 2,
    refetchOnWindowFocus: false,
  });
}

// Hook for fetching a single property by code
export function useProperty(code: string | undefined) {
  const { data: properties, isLoading, error } = useProperties();
  
  const property = properties?.find(p => p.code === code || p.id === code);
  
  return {
    data: property,
    isLoading,
    error,
    isNotFound: !isLoading && !property && !!code,
  };
}
