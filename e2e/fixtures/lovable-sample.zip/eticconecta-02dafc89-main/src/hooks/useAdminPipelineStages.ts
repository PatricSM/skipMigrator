import { useCallback, useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export type AdminPipelineStage = {
  id: string;
  name: string;
  order_index: number;
  color_key: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
};

export function useAdminPipelineStages(options?: { includeInactive?: boolean }) {
  const [stages, setStages] = useState<AdminPipelineStage[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchStages = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      let q = supabase
        .from("admin_pipeline_stages")
        .select("id, name, order_index, color_key, is_active, created_at, updated_at")
        .order("order_index", { ascending: true })
        .limit(50);

      if (!options?.includeInactive) q = q.eq("is_active", true);

      const { data, error } = await q;

      if (error) throw error;
      setStages((data ?? []) as AdminPipelineStage[]);
    } catch (e: any) {
      setError(e?.message ?? "Erro ao carregar etapas");
      setStages([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchStages();
  }, [fetchStages]);

  const stageById = useMemo(() => {
    const m = new Map<string, AdminPipelineStage>();
    stages.forEach((s) => m.set(s.id, s));
    return m;
  }, [stages]);

  return { stages, stageById, loading, error, refetch: fetchStages };
}

export function stageBadgeClass(colorKey?: string) {
  switch ((colorKey ?? "").toLowerCase()) {
    case "teal":
      return "bg-primary/10 text-primary border-primary/20";
    case "cyan":
      return "bg-chart-c2/10 text-chart-c2 border-chart-c2/20";
    case "blue":
      return "bg-chart-c4/10 text-chart-c4 border-chart-c4/20";
    case "indigo":
      return "bg-chart-c3/10 text-chart-c3 border-chart-c3/20";
    case "amber":
      return "bg-sla-warning/10 text-sla-warning border-sla-warning/20";
    case "orange":
      return "bg-destructive/10 text-destructive border-destructive/20";
    case "emerald":
      return "bg-sla-ok/10 text-sla-ok border-sla-ok/20";
    default:
      return "bg-muted/40 text-foreground border-border";
  }
}
