import { supabase } from '@/integrations/supabase/client';
import { logger } from '@/lib/logger';

export function useCpfEncryption() {
  const encryptCpf = async (cpf: string): Promise<string | null> => {
    try {
      // Validate CPF format before sending to edge function
      const cleanCpf = cpf?.replace(/\D/g, '') || '';
      if (cleanCpf.length !== 11) {
        logger.error('Invalid CPF format - must have 11 digits:', cleanCpf.length);
        return null;
      }

      const { data, error } = await supabase.functions.invoke('encrypt-cpf', {
        body: { action: 'encrypt', cpf: cleanCpf }
      });

      if (error) {
        logger.error('Error encrypting CPF:', error);
        return null;
      }

      return data?.encrypted || null;
    } catch (error) {
      logger.error('Error calling encrypt-cpf function:', error);
      return null;
    }
  };

  const decryptCpf = async (encryptedCpf: string): Promise<string | null> => {
    try {
      const { data, error } = await supabase.functions.invoke('encrypt-cpf', {
        body: { action: 'decrypt', cpf: encryptedCpf }
      });

      if (error) {
        logger.error('Error decrypting CPF:', error);
        return null;
      }

      return data?.cpf || null;
    } catch (error) {
      logger.error('Error calling decrypt-cpf function:', error);
      return null;
    }
  };

  const formatCpf = (cpf: string): string => {
    const clean = cpf.replace(/\D/g, '');
    if (clean.length !== 11) return cpf;
    return `${clean.slice(0, 3)}.${clean.slice(3, 6)}.${clean.slice(6, 9)}-${clean.slice(9)}`;
  };

  const maskCpf = (cpf: string): string => {
    const clean = cpf.replace(/\D/g, '');
    if (clean.length !== 11) return '***.***.***-**';
    return `***.***. ${clean.slice(6, 9)}-${clean.slice(9)}`;
  };

  return { encryptCpf, decryptCpf, formatCpf, maskCpf };
}
