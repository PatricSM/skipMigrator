// User & Authentication Types
export type AppRole = 'admin' | 'locatario' | 'locador';

export interface Profile {
  id: string;
  full_name: string | null;
  email: string | null;
  phone: string | null;
  cpf_encrypted: string | null;
  birth_date: string | null;
  nationality: string | null;
  nationality_country: string | null;
  marital_status: string | null;
  profession: string | null;
  monthly_income: number | null;
  is_politically_exposed: boolean | null;
  created_at: string;
  updated_at: string;
}

export interface UserRole {
  id: string;
  user_id: string;
  role: AppRole;
  created_at: string;
}

// Property Types
export interface Property {
  id: string;
  owner_id: string;
  code: string;
  address: string;
  short_address: string;
  description: string | null;
  rent_value: number | null;
  condo_fee: number | null;
  iptu: number | null;
  has_condo: boolean | null;
  images: string[] | null;
  status: string;
  created_at: string;
  updated_at: string;
}

export interface PropertyInvite {
  id: string;
  property_id: string;
  token_hash: string;
  created_by: string;
  expires_at: string;
  used_at: string | null;
  used_by: string | null;
  revoked_at: string | null;
  created_at: string;
}

// Rental Types
export interface Rental {
  id: string;
  user_id: string;
  protocol: string;
  property_id: string;
  property_code: string;
  property_address: string;
  rent_value: number | null;
  condo_fee: number | null;
  iptu: number | null;
  current_step: number | null;
  step_status: string | null;
  tenant_status: string | null;
  is_rejected: boolean | null;
  rejection_reason: string | null;
  has_pending: boolean | null;
  pending_reason: string | null;
  pending_description: string | null;
  pending_documents: Record<string, unknown>[] | null;
  admin_stage: number;
  admin_stage_id: string | null;
  admin_stage_entered_at: string;
  landlord_property_id: string | null;
  landlord_action_required: boolean | null;
  landlord_progress: number | null;
  contract_preview_url: string | null;
  contract_sign_url: string | null;
  created_at: string | null;
  updated_at: string | null;
}

export interface RentalEvent {
  id: string;
  rental_id: string;
  event_type: string;
  description: string;
  created_by: string | null;
  created_at: string | null;
}

// Document Types
export interface Document {
  id: string;
  user_id: string;
  rental_id: string | null;
  document_type: string;
  file_name: string;
  file_path: string;
  file_type: string;
  status: string;
  reviewed_by: string | null;
  reviewed_at: string | null;
  created_at: string;
}

export interface LandlordDocument {
  id: string;
  landlord_id: string;
  rental_id: string;
  document_type: string;
  file_name: string;
  file_path: string;
  file_type: string;
  status: string;
  reviewed_by: string | null;
  reviewed_at: string | null;
  created_at: string;
}

// Landlord Data
export interface LandlordData {
  id: string;
  rental_id: string;
  landlord_id: string;
  full_name: string | null;
  email: string | null;
  phone: string | null;
  marital_status: string | null;
  profession: string | null;
  has_second_landlord: boolean | null;
  second_landlord_name: string | null;
  second_landlord_email: string | null;
  second_landlord_phone: string | null;
  second_landlord_marital_status: string | null;
  second_landlord_profession: string | null;
  bank_name: string | null;
  bank_agency: string | null;
  bank_account: string | null;
  bank_account_type: string | null;
  pix_key: string | null;
  bills_responsible: string | null;
  created_at: string;
  updated_at: string;
}

// Pipeline Types
export interface PipelineStage {
  id: string;
  name: string;
  order_index: number;
  color_key: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

// Rental Full View (aggregated data)
export interface RentalFullView extends Rental {
  tenant_name: string | null;
  tenant_email: string | null;
  tenant_phone: string | null;
  tenant_cpf_encrypted: string | null;
  tenant_birth_date: string | null;
  tenant_nationality: string | null;
  tenant_marital_status: string | null;
  tenant_profession: string | null;
  tenant_monthly_income: number | null;
  tenant_is_pep: boolean | null;
  tenant_doc_count: number | null;
  landlord_name: string | null;
  landlord_email: string | null;
  landlord_phone: string | null;
  landlord_doc_count: number | null;
  has_second_landlord: boolean | null;
  second_landlord_name: string | null;
  second_landlord_email: string | null;
  second_landlord_phone: string | null;
  bank_name: string | null;
  bank_agency: string | null;
  bank_account: string | null;
  pix_key: string | null;
  bills_responsible: string | null;
  stage_name: string | null;
  stage_color: string | null;
  stage_order: number | null;
  event_count: number | null;
}

// Form Types
export interface RentalFormData {
  // Step 1: Property
  propertyCode: string;
  propertyAddress: string;
  rentValue: number;
  condoFee?: number;
  iptu?: number;
  
  // Step 2: Personal Data
  fullName: string;
  email: string;
  phone: string;
  cpf: string;
  birthDate: string;
  nationality: string;
  maritalStatus: string;
  profession: string;
  monthlyIncome: number;
  isPoliticallyExposed: boolean;
}

// API Response Types
export interface AuthResponse {
  user: {
    id: string;
    email: string;
  } | null;
  error: Error | null;
}
