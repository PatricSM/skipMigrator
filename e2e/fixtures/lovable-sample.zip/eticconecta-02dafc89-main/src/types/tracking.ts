export type RentalStepStatus = 'completed' | 'current' | 'future' | 'rejected';

export interface TrackingStep {
  step: number;
  title: string;
  description: string;
  responsible: 'locatario' | 'admin' | 'locador' | 'todos';
  whatCanDelay: string;
  whatUserNeedsToDo: string;
  status: RentalStepStatus;
}

export interface Pending {
  description: string;
  reason: string;
}

export interface RentalTracking {
  id: string;
  protocol: string;
  propertyId: string;
  propertyAddress: string;
  propertyCode: string;
  propertyImage?: string;
  rentValue: number | null;
  condoFee: number | null;
  iptu: number | null;
  currentStep: number;
  stepStatus: 'in_progress' | 'completed' | 'pending' | 'rejected';
  tenantStatus: string;
  hasPending: boolean;
  pending?: Pending;
  pendingDescription?: string;
  isRejected: boolean;
  rejectionReason?: string;
  contractPreviewUrl?: string;
  contractSignUrl?: string;
  pendingDocuments?: string[];
  // New fields for proposal type
  proposalType?: 'standard' | 'direct';
  proposedValue?: number | null;
  // Landlord acceptance tracking
  landlordAccepted?: boolean;
  landlordAcceptedAt?: Date;
  docsSubmittedEarly?: boolean;
  // Explicit finalization timestamp
  documentsFinalizedAt?: Date;
  // Documents cycle for reopen tracking
  documentsCycle?: number;
  // Proposal count for urgency indicator
  proposalCount?: number;
  // Proposal negotiation status
  proposalStatus?: 'waiting_landlord_acceptance' | 'counter_proposal_pending' | 'proposal_accepted' | 'proposal_rejected';
  createdAt: Date;
  updatedAt: Date;
}

export interface RentalEvent {
  id: string;
  eventType: string;
  description: string;
  createdAt: Date;
}

export const TRACKING_STEPS: Omit<TrackingStep, 'status'>[] = [
  {
    step: 1,
    title: 'Proposta',
    description: 'Envio da proposta de locação.',
    responsible: 'locatario',
    whatCanDelay: 'Dados incompletos ou valor abaixo do mínimo.',
    whatUserNeedsToDo: 'Nenhuma ação necessária. Sua proposta já foi enviada.',
  },
  {
    step: 2,
    title: 'Aceite da Proposta',
    description: 'O locador/admin analisa e aceita sua proposta.',
    responsible: 'locador',
    whatCanDelay: 'Tempo de resposta do locador.',
    whatUserNeedsToDo: 'Aguarde o aceite do locador.',
  },
  {
    step: 3,
    title: 'Documentação',
    description: 'Você enviou seus dados e documentos para análise.',
    responsible: 'locatario',
    whatCanDelay: 'Documentos incompletos ou ilegíveis.',
    whatUserNeedsToDo: 'Envie todos os documentos obrigatórios.',
  },
  {
    step: 4,
    title: 'Análise da Ficha',
    description: 'Nossa equipe está analisando sua documentação.',
    responsible: 'admin',
    whatCanDelay: 'Volume alto de análises ou documentos pendentes.',
    whatUserNeedsToDo: 'Aguarde a conclusão da análise. Entraremos em contato se precisarmos de algo.',
  },
  {
    step: 5,
    title: 'Documentos do Locador',
    description: 'Locador envia os documentos do imóvel.',
    responsible: 'locador',
    whatCanDelay: 'Locador ainda não enviou os documentos do imóvel.',
    whatUserNeedsToDo: 'Nenhuma ação necessária por enquanto.',
  },
  {
    step: 6,
    title: 'Emissão do Contrato',
    description: 'Estamos preparando o contrato de locação.',
    responsible: 'admin',
    whatCanDelay: 'Ajustes no contrato ou informações pendentes.',
    whatUserNeedsToDo: 'Você poderá revisar a prévia do contrato em breve.',
  },
  {
    step: 7,
    title: 'Assinatura do Contrato',
    description: 'O contrato está pronto para assinatura digital.',
    responsible: 'todos',
    whatCanDelay: 'Aguardando assinatura de todas as partes.',
    whatUserNeedsToDo: 'Assine o contrato digitalmente quando disponível.',
  },
  {
    step: 8,
    title: 'Agendamento de Vistoria',
    description: 'Aguardando data de agendamento da Vistoria de Entrada do Imóvel.',
    responsible: 'locatario',
    whatCanDelay: 'Disponibilidade de horários.',
    whatUserNeedsToDo: 'Confirmar se irá participar e agendar uma data.',
  },
  {
    step: 9,
    title: 'Assinatura de Vistoria',
    description: 'Você está na etapa de assinatura do laudo de vistoria.',
    responsible: 'todos',
    whatCanDelay: 'Aguardando assinatura do laudo por todas as partes.',
    whatUserNeedsToDo: 'Revise e assine o laudo de vistoria.',
  },
  {
    step: 10,
    title: 'Entrega das Chaves',
    description: 'Parabéns! Suas chaves estão prontas para retirada.',
    responsible: 'todos',
    whatCanDelay: 'Nenhum atraso esperado nesta etapa.',
    whatUserNeedsToDo: 'Compareça ao local combinado para retirar as chaves.',
  },
];

export const STATUS_LABELS: Record<RentalTracking['stepStatus'], string> = {
  in_progress: 'Em andamento',
  completed: 'Concluído',
  pending: 'Ação necessária',
  rejected: 'Reprovado',
};

export const STATUS_MICROCOPY: Record<number, string> = {
  1: 'Sua proposta foi enviada com sucesso.',
  2: 'Aguardando aceite do locador.',
  3: 'Envie seus documentos para análise.',
  4: 'Estamos analisando seus documentos e informações.',
  5: 'Agora dependemos do envio de documentos pelo locador.',
  6: 'Estamos preparando o contrato com base nos dados aprovados.',
  7: 'O contrato está pronto para assinatura digital.',
  8: 'Agende a vistoria de entrada para seguir com a entrega.',
  9: 'Você está na etapa de assinatura do laudo de vistoria.',
  10: 'Parabéns! Suas chaves estão prontas para retirada.',
};

export const STEP_ESTIMATES: Record<number, string> = {
  1: 'Concluído',
  2: 'até 24h',
  3: 'depende de você',
  4: 'até 24h úteis',
  5: 'depende do locador',
  6: 'até 48h úteis',
  7: 'depende das assinaturas',
  8: 'você agenda',
  9: 'depende das assinaturas',
  10: 'Concluído',
};
