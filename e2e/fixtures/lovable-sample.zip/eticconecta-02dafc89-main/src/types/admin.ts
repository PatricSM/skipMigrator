// Status do Kanban
export type KanbanStatus = 'received' | 'analysis' | 'approved' | 'rejected';

// Motivos de reprovação
export type RejectionReason = 
  | 'renda_insuficiente'
  | 'documentos_invalidos'
  | 'serasa_negativo'
  | 'desistencia_cliente'
  | 'imovel_indisponivel'
  | 'outros';

export const rejectionReasonLabels: Record<RejectionReason, string> = {
  renda_insuficiente: 'Renda Insuficiente',
  documentos_invalidos: 'Documentos Inválidos',
  serasa_negativo: 'Serasa Negativo',
  desistencia_cliente: 'Desistência do Cliente',
  imovel_indisponivel: 'Imóvel Indisponível',
  outros: 'Outros',
};

// Status das tarefas
export type TaskStatus = 'pending' | 'done' | 'scheduled';

// Tarefa
export interface Task {
  id: string;
  title: string;
  status: TaskStatus;
  dueDate?: Date;
}

// Documentos do locatário
export interface DocumentInfo {
  url: string;
  validated: boolean;
  fileName?: string;
}

// Checklist de validação
export interface ValidationChecklist {
  documentLegible: boolean;
  incomeVerified: boolean;
  incomeCompatible: boolean;
  serasaClean: boolean;
  residenceValid: boolean;
}

// Ficha de locação para o Kanban
export interface RentalApplication {
  id: string;
  propertyId: string;
  propertyCode: string;
  propertyAddress: string;
  propertyPrice: number;
  
  // Dados do locatário
  tenantName: string;
  tenantCpf: string;
  tenantCpfEncrypted?: string;
  tenantPhone: string;
  tenantEmail: string;
  tenantPhoto?: string;
  
  // Status e tracking
  status: KanbanStatus;
  rejectionReason?: RejectionReason;
  
  // Timestamps para SLA
  createdAt: Date;
  enteredCurrentStatusAt: Date;
  
  // Documentos
  documents: {
    identity: DocumentInfo;
    income: DocumentInfo;
    residence: DocumentInfo;
  };
  
  // Checklist de validação
  checklist: ValidationChecklist;
  
  // Tarefas
  tasks: Task[];
}

// Colunas do Kanban
export interface KanbanColumnData {
  id: KanbanStatus;
  title: string;
  color: string;
  bgColor: string;
  borderColor: string;
}

// Dados do funil de vendas
export interface FunnelStage {
  stage: string;
  count: number;
  percentage: number;
  color: string;
}

// Dados de métricas por período
export interface MonthlyMetric {
  month: string;
  received: number;
  approved: number;
  rejected: number;
}

// Tempo médio por etapa
export interface StageTime {
  stage: string;
  hours: number;
}
