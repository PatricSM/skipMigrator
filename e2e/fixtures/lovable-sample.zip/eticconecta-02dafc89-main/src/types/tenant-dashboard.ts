 import { LucideIcon } from 'lucide-react';
 import { 
   FileText, 
   Upload, 
   ClipboardCheck, 
   Building, 
   FileCheck, 
   Pen, 
   Key,
   ThumbsUp,
   Check,
   Clock,
   Calendar,
   AlertCircle,
   X
 } from 'lucide-react';
 
 export interface TenantJourneyStep {
   step: number;
   title: string;
   shortTitle: string;
   icon: LucideIcon;
   description: string;
   motivationalMessage: string;
 }
 
export const TENANT_JOURNEY_STEPS: TenantJourneyStep[] = [
  { 
    step: 1, 
    title: "Proposta", 
    shortTitle: "Proposta", 
    icon: FileText,
    description: "Sua proposta foi enviada para análise",
    motivationalMessage: "Proposta enviada! Aguarde o aceite do locador."
  },
  { 
    step: 2, 
    title: "Aceite da Proposta", 
    shortTitle: "Aceite", 
    icon: ThumbsUp,
    description: "O locador analisa e aceita sua proposta",
    motivationalMessage: "Aguardando aceite. Enquanto isso, envie seus documentos."
  },
  { 
    step: 3, 
    title: "Documentação", 
    shortTitle: "Docs", 
    icon: Upload,
    description: "Documentação enviada para análise",
    motivationalMessage: "Complete o envio dos documentos para agilizar a análise."
  },
  { 
    step: 4, 
    title: "Análise da Ficha", 
    shortTitle: "Análise", 
    icon: ClipboardCheck,
    description: "Ficha em análise pela equipe",
    motivationalMessage: "Nossa equipe está analisando. Prazo: até 24h úteis."
  },
  { 
    step: 5, 
    title: "Documentos do Locador", 
    shortTitle: "Locador", 
    icon: Building,
    description: "Aguardando documentos do locador",
    motivationalMessage: "Os documentos do imóvel estão sendo preparados."
  },
  { 
    step: 6, 
    title: "Emissão do Contrato", 
    shortTitle: "Contrato", 
    icon: FileCheck,
    description: "Contrato pronto para revisão",
    motivationalMessage: "Revise os termos antes de assinar digitalmente."
  },
  { 
    step: 7, 
    title: "Assinatura do Contrato", 
    shortTitle: "Assinar", 
    icon: Pen,
    description: "Assine o contrato digitalmente",
    motivationalMessage: "Assine o contrato e fique mais perto do seu novo lar."
  },
  { 
    step: 8, 
    title: "Agendamento de Vistoria", 
    shortTitle: "Vistoria", 
    icon: Calendar,
    description: "Agende a vistoria do imóvel",
    motivationalMessage: "Agende a vistoria de entrada do imóvel."
  },
  { 
    step: 9, 
    title: "Assinatura de Vistoria", 
    shortTitle: "Laudo", 
    icon: ClipboardCheck,
    description: "Assine o laudo de vistoria",
    motivationalMessage: "Revise e assine o laudo de vistoria."
  },
  { 
    step: 10, 
    title: "Entrega das Chaves", 
    shortTitle: "Chaves", 
    icon: Key,
    description: "Receba as chaves do seu novo lar!",
    motivationalMessage: "Parabéns! Suas chaves estão prontas para retirada."
  },
];
 
 export interface UserPreferences {
   motivation: 'trabalho' | 'familia' | 'espaco' | 'outro' | null;
   budget: { min: number; max: number };
   features: string[];
   neighborhoods: string[];
 }
 
 export const DEFAULT_USER_PREFERENCES: UserPreferences = {
   motivation: null,
   budget: { min: 1500, max: 5000 },
   features: [],
   neighborhoods: [],
 };
 
 export interface MatchedProperty {
   id: string;
   code: string;
   address: string;
   shortAddress: string;
   images: string[];
   price: number;
   condoFee?: number;
   matchScore: number;
   matchedFeatures: string[];
 }
 
 export type DashboardState = 'active_journey' | 'matchmaker' | 'loading';
 
 export interface FeedEventConfig {
   icon: LucideIcon;
   colorClass: string;
   bgClass: string;
 }
 
 export const EVENT_TYPE_CONFIG: Record<string, FeedEventConfig> = {
   proposal_created: { icon: FileText, colorClass: 'text-primary', bgClass: 'bg-primary/10' },
   documents_uploaded: { icon: Upload, colorClass: 'text-primary', bgClass: 'bg-primary/10' },
   documents_completed: { icon: Check, colorClass: 'text-step-complete', bgClass: 'bg-step-complete/10' },
   ficha_approved: { icon: ThumbsUp, colorClass: 'text-step-complete', bgClass: 'bg-step-complete/10' },
   landlord_docs_received: { icon: Building, colorClass: 'text-primary', bgClass: 'bg-primary/10' },
   contract_generated: { icon: FileCheck, colorClass: 'text-primary', bgClass: 'bg-primary/10' },
   contract_signed: { icon: Pen, colorClass: 'text-step-complete', bgClass: 'bg-step-complete/10' },
   inspection_scheduled: { icon: Calendar, colorClass: 'text-primary', bgClass: 'bg-primary/10' },
   keys_delivered: { icon: Key, colorClass: 'text-step-complete', bgClass: 'bg-step-complete/10' },
   landlord_accepted: { icon: ThumbsUp, colorClass: 'text-step-complete', bgClass: 'bg-step-complete/10' },
   pending: { icon: Clock, colorClass: 'text-amber-500', bgClass: 'bg-amber-500/10' },
   rejection: { icon: X, colorClass: 'text-destructive', bgClass: 'bg-destructive/10' },
   step_change: { icon: Check, colorClass: 'text-primary', bgClass: 'bg-primary/10' },
   default: { icon: AlertCircle, colorClass: 'text-muted-foreground', bgClass: 'bg-muted' },
 };
 
 export const MOTIVATION_OPTIONS = [
   { id: 'trabalho', label: 'Trabalho', description: 'Mudança profissional' },
   { id: 'familia', label: 'Família', description: 'Mais espaço para a família' },
   { id: 'espaco', label: 'Mais Espaço', description: 'Preciso de mais ambiente' },
   { id: 'outro', label: 'Outro', description: 'Outros motivos' },
 ] as const;
 
 export const FEATURE_OPTIONS = [
   { id: 'varanda', label: 'Varanda' },
   { id: 'pet_friendly', label: 'Aceita Pet' },
   { id: 'garagem', label: 'Garagem' },
   { id: 'portaria', label: 'Portaria 24h' },
   { id: 'academia', label: 'Academia' },
   { id: 'piscina', label: 'Piscina' },
   { id: 'churrasqueira', label: 'Churrasqueira' },
   { id: 'mobiliado', label: 'Mobiliado' },
 ] as const;
 
 export const NEIGHBORHOOD_OPTIONS = [
   'Centro', 'Jardins', 'Pinheiros', 'Vila Madalena', 'Moema',
   'Itaim Bibi', 'Perdizes', 'Higienópolis', 'Santana', 'Tatuapé',
 ];
 
 export const TENANT_RESOURCES = [
   {
     id: 'manual',
     title: 'Manual do Locatário',
     description: 'Tudo sobre seus direitos e deveres',
     href: '#',
   },
   {
     id: 'checklist',
     title: 'Checklist de Mudança',
     description: 'Não esqueça de nada importante',
     href: '#',
   },
   {
     id: 'guia',
     title: 'Guia de Entrada',
     description: 'Primeiros passos no seu novo lar',
     href: '#',
   },
 ];