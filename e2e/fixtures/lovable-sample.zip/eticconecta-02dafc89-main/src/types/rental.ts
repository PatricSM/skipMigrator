export interface TenantData {
  fullName: string;
  email: string;
  phone: string;
  birthDate: string;
  cpf: string;
  nationality: string;
  nationalityCountry: string;
  maritalStatus: string;
  profession: string;
  isPoliticallyExposed: boolean;
  monthlyIncome: string;
}

export type DocumentStatus = 'empty' | 'uploading' | 'uploaded' | 'error';

export interface DocumentUploadState {
  id: string;
  type: 'identity' | 'income' | 'residence' | 'other';
  label: string;
  description: string;
  status: DocumentStatus;
  progress?: number;
  fileName?: string;
  fileUrl?: string;
  errorMessage?: string;
  documentLabel?: string;
}

export type RentalStep = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8;

export interface RentalStepInfo {
  step: RentalStep;
  title: string;
  description: string;
  duration?: string;
}

export const RENTAL_STEPS: RentalStepInfo[] = [
  { step: 1, title: 'Envio de Documentos', description: 'Você envia seus dados e documentos' },
  { step: 2, title: 'Análise de Ficha', description: 'Nossa equipe analisa sua documentação', duration: 'até 24h úteis' },
  { step: 3, title: 'Documentação do Locador', description: 'Locador envia os documentos do imóvel' },
  { step: 4, title: 'Emissão de Contratos', description: 'Geramos o contrato de locação' },
  { step: 5, title: 'Assinatura Digital', description: 'Assinatura eletrônica do contrato' },
  { step: 6, title: 'Agendamento de Vistoria', description: 'Marcamos a vistoria do imóvel' },
  { step: 7, title: 'Assinatura da Vistoria', description: 'Você assina o laudo de vistoria' },
  { step: 8, title: 'Entrega das Chaves', description: 'Você recebe as chaves do imóvel' },
];

export interface Rental {
  id: string;
  propertyId: string;
  userId: string;
  status: 'draft' | 'documents_pending' | 'analysis' | 'approved' | 'contract' | 'signed' | 'complete';
  currentStep: RentalStep;
  mainTenant: TenantData;
  secondTenant?: TenantData;
  documents: DocumentUploadState[];
  createdAt: Date;
  updatedAt: Date;
}

export const initialTenantData: TenantData = {
  fullName: '',
  email: '',
  phone: '',
  birthDate: '',
  cpf: '',
  nationality: 'Brasileira',
  nationalityCountry: '',
  maritalStatus: '',
  profession: '',
  isPoliticallyExposed: false,
  monthlyIncome: '',
};

export const initialDocuments: DocumentUploadState[] = [
  {
    id: 'identity',
    type: 'identity',
    label: 'RG ou CNH',
    description: 'Foto ou scan legível, frente e verso',
    status: 'empty',
  },
  {
    id: 'income',
    type: 'income',
    label: 'Comprovante de Renda',
    description: 'Últimos 3 meses: extratos bancários, IR ou holerites',
    status: 'empty',
  },
  {
    id: 'residence',
    type: 'residence',
    label: 'Comprovante de Residência',
    description: 'Conta de luz, água ou gás (últimos 90 dias)',
    status: 'empty',
  },
  {
    id: 'other',
    type: 'other',
    label: 'Outros (opcional)',
    description: 'Documentos complementares',
    status: 'empty',
  },
];
