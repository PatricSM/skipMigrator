export interface Property {
  id: number | string;
  title: string;
  type: string;
  address: string;
  neighborhood: string;
  city: string;
  state: string;
  
  // Values
  rentPrice: number;
  condoFee: number;
  iptu: number;
  fireInsurance: number;
  serviceFee: number;
  totalPrice: number;
  
  // Characteristics
  area: number;
  bedrooms: number;
  bathrooms: number;
  parkingSpaces: number;
  
  // Media
  images: string[];
  videoUrl?: string;
  
  // Status
  availableFrom?: string;
  isEndingContract?: boolean;
  
  // Requirements
  minimumIncome: number;
  maxOccupants: number;
}

// Simple property for listings
export interface PropertySummary {
  id: number | string;
  title: string;
  address: string;
  price: number;
  bedrooms: number;
  bathrooms: number;
  area: number;
  image: string;
}
