export const DOCUMENT_LIMITS: Record<string, number> = {
  identity: 2,
  income: 6,
  residence: 2,
  other: 6,
};

export const REQUIRED_DOC_TYPES = ['identity', 'income', 'residence'];

export const DOC_TYPE_LABELS: Record<string, { label: string; description: string }> = {
  identity: { label: 'RG ou CNH', description: 'Foto ou scan legível, frente e verso' },
  income: { label: 'Comprovante de Renda', description: 'Últimos 3 meses: extratos bancários, IR ou holerites' },
  residence: { label: 'Comprovante de Residência', description: 'Conta de luz, água ou gás (últimos 90 dias)' },
  other: { label: 'Outros (opcional)', description: 'Documentos complementares' },
};

export const DOC_MICROCOPY: Record<string, string> = {
  identity: '(Documento oficial dentro da validade)',
  income: '(90 dias de extratos bancários em PDF com número da conta e dados, últimos 3 holerites ou Imposto de Renda completo)',
  residence: '(Enviar com no máximo 90 dias de vencimento)',
  other: '',
};
