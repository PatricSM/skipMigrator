// Types for Landlord Dashboard - Painel do Locador

export interface LandlordKPI {
  totalRevenue: number;
  monthlyRevenue: number;
  revenueTrend: { month: string; value: number }[];
  vacancyCost: number;
  vacancyCostWithExpenses: number; // rent + condo + iptu
  dailyVacancyLoss: number;
  activeProperties: number;
  vacantProperties: number;
  pendingProposals: number;
  urgentProposals: number;
}

export interface PropertyPerformance {
  id: string;
  code: string;
  address: string;
  neighborhood: string;
  status: 'rented' | 'vacant' | 'em_negociacao' | 'suspenso';
  rentValue: number;
  condoFee: number;
  iptu: number;
  image?: string;
  tenant?: string;
  // Funnel data
  views: number;
  visits: number;
  proposals: number;
  // Visits feedback
  visitFeedbacks: VisitFeedback[];
  // Market comparison
  averageRegionPrice: number;
  suggestedPrice: number;
  // Revenue history for sparkline
  revenueHistory: number[];
  // Additional fields
  description?: string;
}

export interface VisitFeedback {
  id: string;
  date: string;
  sentiment: 'happy' | 'neutral' | 'sad';
  comment: string;
}

export interface TenantProposal {
  id: string;
  applicationId: string; // rental_applications.id
  rentalId: string;
  protocol: string;
  propertyId: string;
  propertyCode: string;
  propertyAddress: string;
  propertyRentValue: number;
  tenantId: string;
  tenantName: string;
  tenantPhoto?: string;
  familyMembers: number;
  familyIncome: number;
  tenantScore: number; // 0-100
  tenantScoreStatus: 'Em análise' | 'Aprovado' | 'Reprovado' | 'Atenção';
  tenantScoreReasons: string[];
  badges: {
    incomeVerified: boolean;
    guaranteeApproved: boolean;
    goodHistory: boolean;
  };
  imobiliariaApproved: boolean;
  currentStep: number;
  status: string;
  createdAt: Date;
  respondedAt?: Date;
  isUrgent: boolean; // > 2h sem resposta
  // Proposal type
  isDirectRental: boolean; // true = aceitou valor anúncio = URGENTE
  proposalType: 'standard' | 'direct';
  proposedValue: number | null;
  // Landlord acceptance
  landlordAccepted: boolean;
  landlordAcceptedAt?: Date;
  // Document status
  docsStatus: 'pending' | 'partial' | 'complete';
  docsCount: number;
  // Ficha status
  fichaStatus: 'em_analise' | 'aprovada' | 'reprovada' | null;
}

export interface JourneyStep {
  step: number;
  title: string;
  icon: string;
}

// 10 etapas do processo de locação
export const JOURNEY_STEPS: JourneyStep[] = [
  { step: 1, title: "Proposta Iniciada", icon: "FileText" },
  { step: 2, title: "Aprovação do Locador", icon: "ThumbsUp" },
  { step: 3, title: "Documentação Locatário", icon: "Files" },
  { step: 4, title: "Aprovação da Ficha", icon: "ClipboardCheck" },
  { step: 5, title: "Docs Locador", icon: "FileUser" },
  { step: 6, title: "Emissão Contrato", icon: "FileCheck" },
  { step: 7, title: "Assinatura Digital", icon: "Pen" },
  { step: 8, title: "Agendamento Vistoria", icon: "Calendar" },
  { step: 9, title: "Assinatura Vistoria", icon: "ClipboardCheck" },
  { step: 10, title: "Entrega das Chaves", icon: "Key" },
];

// Motivos de recusa pelo locador
export const REJECTION_REASONS = [
  'Imóvel Locado',
  'Suspenso',
  'Retirado de Locação',
  'Imóvel Vendido',
  'Desistência do Locador',
] as const;

export type RejectionReason = typeof REJECTION_REASONS[number];

// Status de imóveis considerados vagos
export const VACANT_STATUSES = ['disponivel', 'active', 'em_negociacao', 'disponível'];

// Status de imóveis alugados
export const RENTED_STATUSES = ['rented', 'alugado'];

// Tenant Score calculation helper
export function calculateTenantScore(
  monthlyIncome: number,
  rentValue: number,
  docsApproved: number,
  docsTotal: number,
  hasGuarantee: boolean
): { score: number; status: TenantProposal['tenantScoreStatus']; reasons: string[] } {
  let score = 50; // Base
  const reasons: string[] = [];

  // Renda: +30 se renda >= 3x aluguel
  if (monthlyIncome >= rentValue * 3) {
    score += 30;
    reasons.push('Renda compatível');
  } else if (monthlyIncome >= rentValue * 2) {
    score += 15;
    reasons.push('Renda parcialmente compatível');
  } else {
    reasons.push('Renda em análise');
  }

  // Docs: +20 se todos aprovados
  const docsRatio = docsTotal > 0 ? docsApproved / docsTotal : 0;
  if (docsRatio === 1 && docsTotal > 0) {
    score += 20;
    reasons.push('Docs completos');
  } else if (docsRatio >= 0.5) {
    score += 10;
    reasons.push('Docs parcialmente enviados');
  } else {
    reasons.push('Docs pendentes');
  }

  // Garantia: +20 se aprovada
  if (hasGuarantee) {
    score += 20;
    reasons.push('Garantia validada');
  }

  // Determinar status
  let status: TenantProposal['tenantScoreStatus'] = 'Em análise';
  if (score >= 80) status = 'Aprovado';
  else if (score >= 70) status = 'Em análise';
  else if (score < 50) status = 'Atenção';

  return {
    score: Math.min(100, score),
    status,
    reasons: reasons.slice(0, 3),
  };
}

// Mock data for demonstration
export const MOCK_RENTED_PROPERTY: PropertyPerformance = {
  id: 'prop-1',
  code: 'CPY001',
  address: 'Rua das Flores, 123 - Vila Mariana',
  neighborhood: 'Vila Mariana',
  status: 'rented',
  rentValue: 3500,
  condoFee: 500,
  iptu: 150,
  image: 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=400&h=300&fit=crop',
  tenant: 'João Silva',
  views: 0,
  visits: 0,
  proposals: 0,
  visitFeedbacks: [],
  averageRegionPrice: 3200,
  suggestedPrice: 3500,
  revenueHistory: [3500, 3500, 3500, 3500, 3500, 3500],
};

export const MOCK_VACANT_PROPERTY: PropertyPerformance = {
  id: 'prop-2',
  code: 'CPY002',
  address: 'Av. Paulista, 1000 - Bela Vista',
  neighborhood: 'Bela Vista',
  status: 'vacant',
  rentValue: 4200,
  condoFee: 800,
  iptu: 200,
  image: 'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=400&h=300&fit=crop',
  views: 342,
  visits: 15,
  proposals: 2,
  visitFeedbacks: [
    { id: '1', date: '2026-01-25', sentiment: 'happy', comment: 'Imóvel muito bem conservado! Gostei da iluminação natural.' },
    { id: '2', date: '2026-01-22', sentiment: 'neutral', comment: 'Gostei, mas achei pequeno para nossa família.' },
    { id: '3', date: '2026-01-20', sentiment: 'happy', comment: 'Localização excelente, perto do metrô.' },
    { id: '4', date: '2026-01-18', sentiment: 'sad', comment: 'Achei o valor um pouco acima do mercado.' },
    { id: '5', date: '2026-01-15', sentiment: 'happy', comment: 'Apartamento lindo, vou fazer proposta!' },
  ],
  averageRegionPrice: 3800,
  suggestedPrice: 3900,
  revenueHistory: [],
};

export const MOCK_PROPOSALS: TenantProposal[] = [
  {
    id: 'proposal-1',
    applicationId: 'app-1',
    rentalId: 'rental-1',
    protocol: 'LOC-2026-001',
    propertyId: 'prop-2',
    propertyCode: 'CPY002',
    propertyAddress: 'Av. Paulista, 1000 - Bela Vista',
    propertyRentValue: 4200,
    tenantId: 'tenant-1',
    tenantName: 'Maria Santos',
    familyMembers: 3,
    familyIncome: 15000,
    tenantScore: 85,
    tenantScoreStatus: 'Aprovado',
    tenantScoreReasons: ['Renda compatível', 'Docs completos', 'Garantia validada'],
    badges: { incomeVerified: true, guaranteeApproved: true, goodHistory: true },
    imobiliariaApproved: true,
    currentStep: 2,
    status: 'pending',
    createdAt: new Date(Date.now() - 3 * 60 * 60 * 1000), // 3h ago = urgent
    isUrgent: true,
    isDirectRental: true,
    proposalType: 'direct',
    proposedValue: null,
    landlordAccepted: false,
    docsStatus: 'complete',
    docsCount: 5,
    fichaStatus: 'em_analise',
  },
  {
    id: 'proposal-2',
    applicationId: 'app-2',
    rentalId: 'rental-2',
    protocol: 'LOC-2026-002',
    propertyId: 'prop-2',
    propertyCode: 'CPY002',
    propertyAddress: 'Av. Paulista, 1000 - Bela Vista',
    propertyRentValue: 4200,
    tenantId: 'tenant-2',
    tenantName: 'Carlos Oliveira',
    familyMembers: 2,
    familyIncome: 12000,
    tenantScore: 72,
    tenantScoreStatus: 'Em análise',
    tenantScoreReasons: ['Renda compatível', 'Docs parcialmente enviados'],
    badges: { incomeVerified: true, guaranteeApproved: false, goodHistory: true },
    imobiliariaApproved: true,
    currentStep: 2,
    status: 'pending',
    createdAt: new Date(Date.now() - 30 * 60 * 1000), // 30min ago = not urgent
    isUrgent: false,
    isDirectRental: false,
    proposalType: 'standard',
    proposedValue: 3800,
    landlordAccepted: false,
    docsStatus: 'partial',
    docsCount: 3,
    fichaStatus: null,
  },
];
