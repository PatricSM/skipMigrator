export interface Property {
  id: string;
  owner_id: string;
  address: string;
  short_address: string;
  code: string;
  rent_value: number | null;
  condo_fee: number | null;
  iptu: number | null;
  has_condo: boolean;
  status: 'active' | 'draft' | 'paused';
  description: string | null;
  images: string[];
  created_at: string;
  updated_at: string;
}

export interface LandlordData {
  id: string;
  rental_id: string;
  landlord_id: string;
  full_name: string | null;
  email: string | null;
  phone: string | null;
  cpf: string | null;
  rg: string | null;
  profession: string | null;
  marital_status: string | null;
  bills_responsible: 'locador' | 'locatario' | null;
  bank_name: string | null;
  bank_agency: string | null;
  bank_account: string | null;
  bank_account_type: 'corrente' | 'poupanca' | null;
  pix_key: string | null;
  has_second_landlord: boolean;
  second_landlord_name: string | null;
  second_landlord_email: string | null;
  second_landlord_phone: string | null;
  second_landlord_profession: string | null;
  second_landlord_marital_status: string | null;
  created_at: string;
  updated_at: string;
}

export interface LandlordDocument {
  id: string;
  landlord_id: string;
  rental_id: string;
  document_type: string;
  file_path: string;
  file_name: string;
  file_type: string;
  status: 'pending' | 'approved' | 'rejected';
  created_at: string;
  reviewed_at: string | null;
  reviewed_by: string | null;
}

export interface LandlordProposal {
  id: string;
  protocol: string;
  property_address: string;
  property_code: string;
  tenant_status: 'approved' | 'in_analysis' | 'rejected';
  landlord_action_required: boolean;
  landlord_progress: number;
  current_step: number;
  step_status: string;
  created_at: string;
  updated_at: string;
  has_pending: boolean;
  pending_reason: string | null;
  landlord_property_id: string | null;
}

export interface LandlordProposalEvent {
  id: string;
  rental_id: string;
  event_type: string;
  description: string;
  created_at: string;
}

export const DOCUMENT_TYPES = {
  documento_pessoal: 'Documento pessoal (CNH ou RG e CPF)',
  comprovante_residencia: 'Comprovante de residência atualizado',
  comprovante_titularidade: 'Comprovante de titularidade do imóvel',
  boleto_iptu: 'Boleto do IPTU (anual)',
  boleto_condominio: 'Boleto do condomínio (mensal)',
  contas_consumo: 'Contas de consumo (água, luz, gás)',
  segundo_locador_documento: 'Documento do segundo locador',
  segundo_locador_residencia: 'Comprovante de residência do segundo locador',
} as const;

export type LandlordDocumentType = keyof typeof DOCUMENT_TYPES;

export const MARITAL_STATUS_OPTIONS = [
  { value: 'solteiro', label: 'Solteiro(a)' },
  { value: 'casado', label: 'Casado(a)' },
  { value: 'divorciado', label: 'Divorciado(a)' },
  { value: 'viuvo', label: 'Viúvo(a)' },
  { value: 'uniao_estavel', label: 'União Estável' },
];

export const BANK_ACCOUNT_TYPES = [
  { value: 'corrente', label: 'Conta Corrente' },
  { value: 'poupanca', label: 'Conta Poupança' },
];
