import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { Loader2 } from 'lucide-react';

interface LocadorRouteProps {
  children: React.ReactNode;
}

export function LocadorRoute({ children }: LocadorRouteProps) {
  const { user, isLoading, isLandlord } = useAuth();
  const location = useLocation();

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Verificando permissões...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/locador/auth" state={{ from: location }} replace />;
  }

  if (!isLandlord) {
    // If user exists but isn't a locador, redirect to locador auth
    // so they can potentially get the role assigned
    return <Navigate to="/locador/auth" state={{ from: location }} replace />;
  }

  return <>{children}</>;
}
