import { ReactNode, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { Loader2 } from 'lucide-react';

interface SmartRedirectProps {
  children: ReactNode;
}

export function SmartRedirect({ children }: SmartRedirectProps) {
  const { user, isLoading, roles } = useAuth();
  const navigate = useNavigate();
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    if (isLoading) return;

    if (user) {
      // Redirect based on role
      if (roles.includes('locador')) {
        navigate('/locador/home', { replace: true });
        return;
      }
      if (roles.includes('locatario')) {
        navigate('/locatario/painel', { replace: true });
        return;
      }
      // User is logged in but has no specific role - show landing page
      setChecked(true);
    } else {
      // No user - show landing page
      setChecked(true);
    }
  }, [user, isLoading, roles, navigate]);

  if (isLoading || !checked) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Carregando...</p>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}
