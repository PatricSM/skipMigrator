import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Lock, Eye, EyeOff, Loader2, CheckCircle, AlertCircle } from "lucide-react";
import { z } from "zod";

import { strongPasswordSchema } from '@/lib/passwordPolicy';
import { PasswordStrengthIndicator } from '@/components/auth/PasswordStrengthIndicator';

const passwordSchema = strongPasswordSchema;

interface ResetPasswordFormProps {
  onSuccess: () => void;
}

export function ResetPasswordForm({ onSuccess }: ResetPasswordFormProps) {
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [sessionExpired, setSessionExpired] = useState(false);
  const [errors, setErrors] = useState<{ password?: string; confirmPassword?: string }>({});
  const { updatePassword } = useAuth();
  const { toast } = useToast();

  const validate = () => {
    const newErrors: typeof errors = {};

    try {
      passwordSchema.parse(password);
    } catch (err) {
      if (err instanceof z.ZodError) {
        newErrors.password = err.errors[0].message;
      }
    }

    if (password !== confirmPassword) {
      newErrors.confirmPassword = "Senhas não coincidem";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setLoading(true);
    
    // Verify session is still valid before attempting password update
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      setLoading(false);
      setSessionExpired(true);
      toast({
        title: "Link Expirado",
        description: "O link de recuperação expirou. Solicite um novo link.",
        variant: "destructive",
      });
      return;
    }

    const { error } = await updatePassword(password);
    setLoading(false);

    if (error) {
      // Handle specific error types
      let title = "Erro";
      let message = "Não foi possível atualizar a senha. Tente novamente.";
      
      const errorMsg = error.message.toLowerCase();
      
      if (errorMsg.includes("same_password") || errorMsg.includes("different") || errorMsg.includes("should be different")) {
        message = "A nova senha deve ser diferente da senha atual.";
      } else if (errorMsg.includes("weak") || errorMsg.includes("password should")) {
        message = "Senha muito fraca. Use letras, números e caracteres especiais.";
      } else if (errorMsg.includes("session") || errorMsg.includes("expired") || errorMsg.includes("invalid") || errorMsg.includes("not found")) {
        title = "Sessão Expirada";
        message = "O link de recuperação expirou. Solicite um novo link.";
        setSessionExpired(true);
      }
      
      toast({
        title,
        description: message,
        variant: "destructive",
      });
      return;
    }

    setSuccess(true);
    toast({
      title: "Senha atualizada!",
      description: "Sua nova senha foi definida com sucesso.",
    });

    // Redirect after success
    setTimeout(() => {
      onSuccess();
    }, 2000);
  };

  // Session expired UI
  if (sessionExpired) {
    return (
      <Card className="border-0 shadow-xl">
        <CardContent className="pt-8 pb-8">
          <div className="flex flex-col items-center space-y-4">
            <div className="w-16 h-16 bg-amber-100 dark:bg-amber-900/30 rounded-full flex items-center justify-center">
              <AlertCircle className="h-8 w-8 text-amber-600 dark:text-amber-400" />
            </div>
            <div className="text-center space-y-2">
              <h3 className="text-lg font-semibold">Link Expirado</h3>
              <p className="text-sm text-muted-foreground">
                O link de recuperação expirou ou já foi utilizado.
              </p>
            </div>
            <Button 
              onClick={() => window.location.href = '/locatario/login'} 
              className="w-full"
            >
              Solicitar novo link
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Success UI
  if (success) {
    return (
      <Card className="border-0 shadow-xl">
        <CardContent className="pt-8 pb-8">
          <div className="flex flex-col items-center space-y-4">
            <div className="w-16 h-16 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center">
              <CheckCircle className="h-8 w-8 text-green-600 dark:text-green-400" />
            </div>
            <div className="text-center space-y-2">
              <h3 className="text-lg font-semibold">Senha atualizada!</h3>
              <p className="text-sm text-muted-foreground">
                Você será redirecionado em instantes...
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-0 shadow-xl">
      <CardHeader className="text-center">
        <CardTitle className="text-2xl">Nova senha</CardTitle>
        <CardDescription>
          Digite sua nova senha abaixo
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="new-password">Nova senha</Label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="new-password"
                type={showPassword ? "text" : "password"}
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className={`pl-10 pr-10 ${errors.password ? "border-destructive" : ""}`}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
            {errors.password && <p className="text-sm text-destructive">{errors.password}</p>}
            <PasswordStrengthIndicator password={password} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="confirm-new-password">Confirmar nova senha</Label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="confirm-new-password"
                type="password"
                placeholder="••••••••"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className={`pl-10 ${errors.confirmPassword ? "border-destructive" : ""}`}
              />
            </div>
            {errors.confirmPassword && <p className="text-sm text-destructive">{errors.confirmPassword}</p>}
          </div>

          <Button type="submit" className="w-full" size="lg" disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Salvando...
              </>
            ) : (
              "Salvar nova senha"
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
