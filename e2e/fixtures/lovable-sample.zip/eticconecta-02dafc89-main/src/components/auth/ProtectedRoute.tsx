import { ReactNode, useEffect, useState } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { Loader2 } from 'lucide-react';
import type { Database } from '@/integrations/supabase/types';

type AppRole = Database['public']['Enums']['app_role'];

interface ProtectedRouteProps {
  children: ReactNode;
  allowedRoles?: AppRole[];
  redirectTo?: string;
}

export function ProtectedRoute({ 
  children, 
  allowedRoles,
  redirectTo = '/auth' 
}: ProtectedRouteProps) {
  const { user, isLoading, roles, hasRole } = useAuth();
  const location = useLocation();

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Carregando...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    // Se redirectTo foi passado explicitamente, respeitar o override
    if (redirectTo !== '/auth') {
      return <Navigate to={redirectTo} state={{ from: location }} replace />;
    }
    // Redirect contextual baseado na rota atual, com querystring para sobreviver a refresh
    const currentUrl = encodeURIComponent(location.pathname + location.search);
    const path = location.pathname;
    let target = `/locatario/login?redirect=${currentUrl}`;
    if (path.startsWith('/locador')) {
      target = `/locador/auth?redirect=${currentUrl}`;
    }
    return <Navigate to={target} state={{ from: location }} replace />;
  }

  // If roles are specified, check if user has at least one of them
  if (allowedRoles && allowedRoles.length > 0) {
    const hasAllowedRole = allowedRoles.some(role => hasRole(role));
    
    if (!hasAllowedRole) {
      // Redirect based on user's actual role
      if (roles.includes('admin')) {
        return <Navigate to="/admin" replace />;
      }
      if (roles.includes('locador')) {
        return <Navigate to="/locador/home" replace />;
      }
      if (roles.includes('locatario')) {
        return <Navigate to="/locatario/painel" replace />;
      }
      // Default fallback
      return <Navigate to="/" replace />;
    }
  }

  return <>{children}</>;
}
