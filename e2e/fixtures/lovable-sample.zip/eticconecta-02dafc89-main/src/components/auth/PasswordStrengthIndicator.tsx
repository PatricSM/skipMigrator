import { getPasswordStrength, PASSWORD_HINT } from '@/lib/passwordPolicy';

interface Props {
  password: string;
}

export function PasswordStrengthIndicator({ password }: Props) {
  const { score, label, color } = getPasswordStrength(password);

  if (!password) {
    return <p className="text-xs text-muted-foreground">{PASSWORD_HINT}</p>;
  }

  return (
    <div className="space-y-1">
      <div className="flex gap-1">
        {[1, 2, 3, 4].map((i) => (
          <div
            key={i}
            className={`h-1 flex-1 rounded-full transition-colors ${
              i <= score
                ? score <= 1
                  ? 'bg-destructive'
                  : score === 2
                  ? 'bg-yellow-500'
                  : 'bg-green-500'
                : 'bg-muted'
            }`}
          />
        ))}
      </div>
      <p className={`text-xs ${color}`}>{label}</p>
      {score < 3 && <p className="text-xs text-muted-foreground">{PASSWORD_HINT}</p>}
    </div>
  );
}
