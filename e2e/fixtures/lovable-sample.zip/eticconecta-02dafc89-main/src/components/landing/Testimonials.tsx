import { Star } from "lucide-react";

const testimonials = [
  {
    name: "Marina Silva",
    role: "Inquilina desde 2024",
    content: "Processo incrivelmente rápido! Em menos de 48h eu já tinha as chaves do meu apartamento. Recomendo muito!",
    rating: 5,
  },
  {
    name: "Carlos Eduardo",
    role: "Inquilino desde 2023",
    content: "Adorei não precisar de fiador. O seguro fiança foi aprovado rapidinho e o suporte me ajudou em tudo.",
    rating: 5,
  },
  {
    name: "Juliana Costa",
    role: "Inquilina desde 2024",
    content: "A plataforma é muito fácil de usar. Enviei meus documentos pelo celular e acompanhei tudo em tempo real.",
    rating: 5,
  },
];

export function Testimonials() {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">O que nossos clientes dizem</h2>
          <p className="text-lg text-muted-foreground">
            Histórias reais de quem já alugou com a Etic.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="p-6 rounded-xl border bg-card">
              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 fill-primary text-primary" />
                ))}
              </div>
              <p className="text-muted-foreground mb-4">"{testimonial.content}"</p>
              <div>
                <p className="font-semibold">{testimonial.name}</p>
                <p className="text-sm text-muted-foreground">{testimonial.role}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
