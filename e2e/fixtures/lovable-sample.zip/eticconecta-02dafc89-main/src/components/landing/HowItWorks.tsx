import { FileText, Search, CheckCircle, Key } from "lucide-react";

const steps = [
  {
    icon: Search,
    title: "Escolha o imóvel",
    description: "Navegue pelos imóveis disponíveis e selecione o que mais combina com você.",
  },
  {
    icon: FileText,
    title: "Envie seus documentos",
    description: "Faça o upload dos documentos necessários de forma rápida e segura.",
  },
  {
    icon: CheckCircle,
    title: "Aguarde a análise",
    description: "Nossa equipe analisa sua documentação em até 24 horas úteis.",
  },
  {
    icon: Key,
    title: "Receba as chaves",
    description: "Após aprovação e assinatura do contrato, suas chaves estarão prontas.",
  },
];

export function HowItWorks() {
  return (
    <section id="como-funciona" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Como funciona</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Um processo simples e transparente para você alugar seu imóvel sem complicações.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <div key={index} className="relative">
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <step.icon className="h-8 w-8 text-primary" />
                </div>
                <span className="absolute -top-2 -left-2 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold">
                  {index + 1}
                </span>
                <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
                <p className="text-muted-foreground">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
