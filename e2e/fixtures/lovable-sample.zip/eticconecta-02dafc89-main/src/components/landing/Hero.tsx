import { useState, useMemo } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ArrowRight, CheckCircle, Search, MapPin, Building2 } from "lucide-react";
import logoEticBlue from "@/assets/logo-etic-blue.png";
import { useProperties } from "@/hooks/useProperties";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

export function Hero() {
  const navigate = useNavigate();
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchValue, setSearchValue] = useState("");
  const { data: properties = [] } = useProperties();

  // Extract unique neighborhoods from properties
  const neighborhoods = useMemo(() => {
    const uniqueNeighborhoods = [...new Set(properties.map(p => p.neighborhood).filter(Boolean))];
    return uniqueNeighborhoods.sort();
  }, [properties]);

  // Filter suggestions based on search input
  const filteredSuggestions = useMemo(() => {
    if (!searchValue.trim()) {
      return {
        neighborhoods: neighborhoods.slice(0, 5),
        properties: properties.slice(0, 3),
      };
    }
    
    const searchLower = searchValue.toLowerCase();
    return {
      neighborhoods: neighborhoods.filter(n => 
        n.toLowerCase().includes(searchLower)
      ).slice(0, 5),
      properties: properties.filter(p => 
        p.code.toLowerCase().includes(searchLower) ||
        p.title.toLowerCase().includes(searchLower) ||
        p.neighborhood.toLowerCase().includes(searchLower) ||
        p.streetName.toLowerCase().includes(searchLower)
      ).slice(0, 5),
    };
  }, [searchValue, neighborhoods, properties]);

  const handleSelectNeighborhood = (neighborhood: string) => {
    setSearchOpen(false);
    navigate(`/selecionar-imovel?bairro=${encodeURIComponent(neighborhood)}`);
  };

  const handleSelectProperty = (code: string) => {
    setSearchOpen(false);
    navigate(`/selecionar-imovel?codigo=${encodeURIComponent(code)}`);
  };

  const handleSearch = () => {
    if (searchValue.trim()) {
      navigate(`/selecionar-imovel?busca=${encodeURIComponent(searchValue)}`);
    } else {
      navigate("/selecionar-imovel");
    }
  };

  return (
    <section className="relative py-20 md:py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-background" />
      
      <div className="container mx-auto px-4 relative">
        <div className="max-w-3xl mx-auto text-center">
          <img 
            src={logoEticBlue} 
            alt="Etic Imóveis" 
            className="w-16 h-16 mx-auto mb-6 rounded-full object-cover"
          />
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight mb-6">
            Gestão de locação com{" "}
            <span className="text-primary">acompanhamento em tempo real</span>
          </h1>
          
          <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Processo simplificado, sem burocracia. Envie seus documentos online e acompanhe 
            cada etapa da sua locação em tempo real.
          </p>

          {/* Search Bar */}
          <div className="max-w-xl mx-auto mb-8">
            <Popover open={searchOpen} onOpenChange={setSearchOpen}>
              <PopoverTrigger asChild>
                <div className="relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                  <Input
                    type="text"
                    placeholder="Bairro e Código do imóvel"
                    value={searchValue}
                    onChange={(e) => {
                      setSearchValue(e.target.value);
                      setSearchOpen(true);
                    }}
                    onFocus={() => setSearchOpen(true)}
                    className="h-14 pl-12 pr-28 text-base rounded-full border-2 border-muted focus:border-primary"
                  />
                  <Button 
                    onClick={handleSearch}
                    className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full px-6"
                  >
                    Buscar
                  </Button>
                </div>
              </PopoverTrigger>
              <PopoverContent className="w-[calc(100vw-2rem)] max-w-xl p-0" align="start">
                <Command>
                  <CommandList>
                    <CommandEmpty>Nenhum resultado encontrado.</CommandEmpty>
                    
                    {filteredSuggestions.neighborhoods.length > 0 && (
                      <CommandGroup heading="Bairros">
                        {filteredSuggestions.neighborhoods.map((neighborhood) => (
                          <CommandItem
                            key={neighborhood}
                            value={neighborhood}
                            onSelect={() => handleSelectNeighborhood(neighborhood)}
                            className="cursor-pointer"
                          >
                            <MapPin className="mr-2 h-4 w-4 text-muted-foreground" />
                            <span>{neighborhood}</span>
                          </CommandItem>
                        ))}
                      </CommandGroup>
                    )}
                    
                    {filteredSuggestions.properties.length > 0 && (
                      <CommandGroup heading="Imóveis">
                        {filteredSuggestions.properties.map((property) => (
                          <CommandItem
                            key={property.id}
                            value={`${property.code} ${property.title}`}
                            onSelect={() => handleSelectProperty(property.code)}
                            className="cursor-pointer"
                          >
                            <Building2 className="mr-2 h-4 w-4 text-muted-foreground" />
                            <div className="flex flex-col">
                              <span className="font-medium">{property.code}</span>
                              <span className="text-xs text-muted-foreground">{property.neighborhood}</span>
                            </div>
                          </CommandItem>
                        ))}
                      </CommandGroup>
                    )}
                  </CommandList>
                </Command>
              </PopoverContent>
            </Popover>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button size="lg" asChild className="text-lg px-8">
              <Link to="/selecionar-imovel">
                Ver todos os imóveis
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild className="text-lg px-8">
              <a href="#como-funciona">Como funciona</a>
            </Button>
          </div>

          <div className="flex flex-wrap justify-center gap-6 text-sm text-muted-foreground">
            <span className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-primary" />
              Sem fiador
            </span>
            <span className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-primary" />
              100% online
            </span>
            <span className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-primary" />
              Aprovação em 24h
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
