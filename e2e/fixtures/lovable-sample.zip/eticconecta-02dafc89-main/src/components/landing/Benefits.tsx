import { Clock, Shield, Smartphone, HeadphonesIcon, Zap, PiggyBank } from "lucide-react";

const benefits = [
  {
    icon: Clock,
    title: "Processo rápido",
    description: "Aprovação em até 24 horas úteis. Sem esperar semanas por uma resposta.",
  },
  {
    icon: Shield,
    title: "Segurança total",
    description: "Seus dados são protegidos com criptografia de ponta a ponta.",
  },
  {
    icon: Smartphone,
    title: "100% digital",
    description: "Todo o processo pelo celular ou computador, sem precisar ir a cartórios.",
  },
  {
    icon: HeadphonesIcon,
    title: "Suporte dedicado",
    description: "Equipe pronta para ajudar em cada etapa do processo.",
  },
  {
    icon: Zap,
    title: "Sem burocracia",
    description: "Documentação simplificada e assinatura digital de contratos.",
  },
  {
    icon: PiggyBank,
    title: "Sem fiador",
    description: "Alternativas modernas de garantia locatícia disponíveis.",
  },
];

export function Benefits() {
  return (
    <section id="beneficios" className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Por que escolher a Etic?</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Facilitamos sua vida com tecnologia e atendimento humanizado.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {benefits.map((benefit, index) => (
            <div 
              key={index} 
              className="p-6 rounded-xl border bg-card hover:shadow-lg transition-shadow"
            >
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                <benefit.icon className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">{benefit.title}</h3>
              <p className="text-muted-foreground">{benefit.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
