import { Link } from "react-router-dom";
import logoEticBlue from "@/assets/logo-etic-blue.png";

export function Footer() {
  return (
    <footer className="border-t bg-muted/30">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <Link to="/" className="flex items-center gap-2 mb-4">
              <img 
                src={logoEticBlue} 
                alt="Etic Imóveis" 
                className="w-10 h-10 rounded-full object-cover"
              />
              <span className="font-bold text-lg">Etic Imóveis</span>
            </Link>
            <p className="text-muted-foreground max-w-sm">
              Simplificando a locação de imóveis com tecnologia e atendimento humanizado.
            </p>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Links úteis</h3>
            <nav className="flex flex-col gap-2">
              <a href="#como-funciona" className="text-muted-foreground hover:text-foreground transition-colors">
                Como funciona
              </a>
              <a href="#beneficios" className="text-muted-foreground hover:text-foreground transition-colors">
                Benefícios
              </a>
              <a href="#faq" className="text-muted-foreground hover:text-foreground transition-colors">
                FAQ
              </a>
            </nav>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Contato</h3>
            <nav className="flex flex-col gap-2 text-muted-foreground">
              <a href="mailto:contato@eticconecta.com.br" className="hover:text-foreground transition-colors">
                contato@eticconecta.com.br
              </a>
              <a href="tel:+5511970932722" className="hover:text-foreground transition-colors">
                (11) 97093-2722
              </a>
            </nav>
          </div>
        </div>

        <div className="border-t mt-12 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} Etic Imóveis. Todos os direitos reservados.
          </p>
          <div className="flex gap-6 text-sm">
            <Link to="/termos" className="text-muted-foreground hover:text-foreground transition-colors">
              Termos de Uso
            </Link>
            <Link to="/privacidade" className="text-muted-foreground hover:text-foreground transition-colors">
              Política de Privacidade
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
