import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    question: "Quais documentos preciso enviar?",
    answer: "Você precisará enviar: RG ou CNH, comprovante de renda dos últimos 3 meses (extratos bancários, holerites ou declaração de IR) e comprovante de residência atualizado.",
  },
  {
    question: "Quanto tempo leva para ter uma resposta?",
    answer: "A análise da documentação é feita em até 24 horas úteis. Após a aprovação, o contrato é gerado e enviado para assinatura digital.",
  },
  {
    question: "Preciso de fiador?",
    answer: "Não! Oferecemos alternativas como seguro fiança e título de capitalização para facilitar seu processo de locação.",
  },
  {
    question: "O processo é 100% online?",
    answer: "Sim! Todo o processo, desde o envio de documentos até a assinatura do contrato, é feito de forma digital. Você só precisa ir pessoalmente para a vistoria e entrega das chaves.",
  },
  {
    question: "Posso acompanhar o status da minha solicitação?",
    answer: "Sim! Após enviar seus documentos, você terá acesso a uma área de acompanhamento onde poderá ver em tempo real em qual etapa está sua locação.",
  },
  {
    question: "É seguro enviar meus documentos pela plataforma?",
    answer: "Totalmente! Utilizamos criptografia de ponta a ponta e seguimos todas as diretrizes da LGPD para proteger seus dados pessoais.",
  },
];

export function FAQ() {
  return (
    <section id="faq" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Perguntas frequentes</h2>
          <p className="text-lg text-muted-foreground">
            Tire suas dúvidas sobre o processo de locação.
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`}>
                <AccordionTrigger className="text-left">{faq.question}</AccordionTrigger>
                <AccordionContent>{faq.answer}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
}
