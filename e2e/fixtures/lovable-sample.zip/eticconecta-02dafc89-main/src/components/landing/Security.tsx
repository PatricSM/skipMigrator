import { Lock, ShieldCheck, Eye } from "lucide-react";

export function Security() {
  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Seus dados estão seguros</h2>
            <p className="text-lg text-muted-foreground">
              Utilizamos as melhores práticas de segurança para proteger suas informações.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <Lock className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-semibold mb-2">Criptografia</h3>
              <p className="text-sm text-muted-foreground">
                Dados sensíveis criptografados com AES-256
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 mx-auto rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <ShieldCheck className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-semibold mb-2">LGPD Compliant</h3>
              <p className="text-sm text-muted-foreground">
                Em conformidade com a Lei Geral de Proteção de Dados
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 mx-auto rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <Eye className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-semibold mb-2">Transparência</h3>
              <p className="text-sm text-muted-foreground">
                Você sabe exatamente como seus dados são usados
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
