import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Menu, X, Building } from "lucide-react";
import { useState } from "react";
import logoEticBlue from "@/assets/logo-etic-blue.png";

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center gap-2">
            <img 
              src={logoEticBlue} 
              alt="Etic Imóveis" 
              className="w-10 h-10 rounded-full object-cover"
            />
            <span className="font-bold text-lg">Etic Imóveis</span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-6">
            <Link to="/locatario" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Propostas
            </Link>
            <a href="#como-funciona" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Como Funciona
            </a>
            <a href="#beneficios" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Benefícios
            </a>
            <a href="#faq" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              FAQ
            </a>
          </nav>

          <div className="hidden md:flex items-center gap-3">
            <Button variant="outline" asChild>
              <Link to="/locatario/login">Entrar</Link>
            </Button>
            <Button asChild>
              <Link to="/locatario/register">Criar conta</Link>
            </Button>
            <Button variant="secondary" asChild>
              <Link to="/locador/auth">
                <Building className="mr-2 h-4 w-4" />
                Sou Locador
              </Link>
            </Button>
          </div>

          {/* Mobile menu button */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>

        {/* Mobile Nav */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t py-4 space-y-4">
            <nav className="flex flex-col gap-2">
              <Link 
                to="/locatario" 
                className="px-4 py-2 text-muted-foreground hover:text-foreground"
                onClick={() => setMobileMenuOpen(false)}
              >
                Propostas
              </Link>
              <a 
                href="#como-funciona" 
                className="px-4 py-2 text-muted-foreground hover:text-foreground"
                onClick={() => setMobileMenuOpen(false)}
              >
                Como Funciona
              </a>
              <a 
                href="#beneficios" 
                className="px-4 py-2 text-muted-foreground hover:text-foreground"
                onClick={() => setMobileMenuOpen(false)}
              >
                Benefícios
              </a>
              <a 
                href="#faq" 
                className="px-4 py-2 text-muted-foreground hover:text-foreground"
                onClick={() => setMobileMenuOpen(false)}
              >
                FAQ
              </a>
            </nav>
            <div className="flex flex-col gap-2 px-4">
              <Button variant="outline" asChild>
                <Link to="/auth">Entrar</Link>
              </Button>
              <Button asChild>
                <Link to="/selecionar-imovel">Alugar um imóvel</Link>
              </Button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
