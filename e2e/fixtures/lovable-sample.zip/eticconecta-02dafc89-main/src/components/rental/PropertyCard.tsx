import { useNavigate } from "react-router-dom";
import { MapPin, Check, ChevronRight } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface PropertyCardProps {
  image: string;
  address: string;
  price: number;
  condoFee?: number;
  iptu?: number;
  title?: string;
  propertyId?: string;
  onClick?: () => void;
}

export function PropertyCard({ 
  image, 
  address, 
  price, 
  condoFee,
  iptu,
  title, 
  propertyId,
  onClick 
}: PropertyCardProps) {
  const navigate = useNavigate();

  const handleClick = () => {
    if (onClick) {
      onClick();
    } else if (propertyId) {
      navigate(`/imovel/${propertyId}`);
    }
  };

  const isClickable = onClick || propertyId;

  return (
    <div
      role={isClickable ? "button" : undefined}
      tabIndex={isClickable ? 0 : undefined}
      onClick={isClickable ? handleClick : undefined}
      onKeyDown={isClickable ? (e) => e.key === 'Enter' && handleClick() : undefined}
      className={`
        rounded-2xl border border-border bg-card overflow-hidden
        ${isClickable ? 'cursor-pointer hover:border-primary/50 hover:shadow-card transition-all' : ''}
      `}
    >
      <div className="flex gap-4 p-4">
        {/* Thumbnail */}
        <div className="w-24 h-24 rounded-xl overflow-hidden bg-muted shrink-0">
          <img
            src={image}
            alt={title || address}
            className="w-full h-full object-cover"
          />
        </div>

        {/* Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <Badge variant="secondary" className="bg-step-complete/10 text-step-complete border-0 text-xs">
              <Check className="h-3 w-3 mr-1" />
              Imóvel selecionado
            </Badge>
          </div>

          <p className="text-sm text-muted-foreground flex items-center gap-1 mb-1 truncate">
            <MapPin className="h-3.5 w-3.5 shrink-0" />
            {address}
          </p>

          <p className="text-lg font-bold text-foreground">
            R$ {price.toLocaleString("pt-BR")}/mês
          </p>
          
          {/* Condo Fee and IPTU - only show if values exist */}
          {(condoFee || iptu) && (
            <p className="text-xs text-muted-foreground mt-1">
              {condoFee && condoFee > 0 && (
                <span>Cond: R$ {condoFee.toLocaleString("pt-BR")}</span>
              )}
              {condoFee && condoFee > 0 && iptu && iptu > 0 && (
                <span className="mx-1">|</span>
              )}
              {iptu && iptu > 0 && (
                <span>IPTU: R$ {iptu.toLocaleString("pt-BR")}</span>
              )}
            </p>
          )}
        </div>

        {/* Chevron indicator for clickable state */}
        {isClickable && (
          <div className="flex items-center">
            <ChevronRight className="h-5 w-5 text-muted-foreground" />
          </div>
        )}
      </div>
    </div>
  );
}
