import { cn } from "@/lib/utils";
import { Check, User, DollarSign, FileText, Users } from "lucide-react";
import { TenantData, DocumentUploadState } from "@/types/rental";

interface ProgressStep {
  id: string;
  label: string;
  icon: typeof User;
  completed: boolean;
  current: boolean;
}

interface ProgressBarProps {
  steps: ProgressStep[];
  className?: string;
  onStepClick?: (stepId: string) => void;
}

export function ProgressBar({ steps, className, onStepClick }: ProgressBarProps) {
  const completedCount = steps.filter((s) => s.completed).length;
  const totalSteps = steps.length;
  const progress = (completedCount / totalSteps) * 100;

  return (
    <div className={cn("space-y-4", className)}>
      {/* Progress Bar */}
      <div className="space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Progresso do cadastro</span>
          <span className="font-medium text-foreground">
            {completedCount}/{totalSteps} etapas
          </span>
        </div>

        {/* Bar Background */}
        <div className="h-2 bg-muted rounded-full overflow-hidden">
          <div
            className="h-full bg-primary transition-all duration-500 ease-out rounded-full"
            style={{ width: `${progress}%` }}
          />
        </div>

        {/* Encouragement Message */}
        {progress < 100 && (
          <p className="text-xs text-muted-foreground">
            {progress === 0 && "Comece preenchendo seus dados pessoais"}
            {progress > 0 && progress < 50 && "Ótimo começo! Continue preenchendo"}
            {progress >= 50 && progress < 75 && "Mais da metade concluída!"}
            {progress >= 75 && progress < 100 && "Falta pouco para finalizar"}
          </p>
        )}
        {progress === 100 && (
          <p className="text-xs text-step-complete font-medium">
            Tudo pronto! Clique em enviar para finalizar
          </p>
        )}
      </div>

      {/* Step Indicators (clicáveis) */}
      <div className="flex justify-between">
        {steps.map((step) => {
          const StepIcon = step.icon;
          const isCompleted = step.completed;
          const isCurrent = step.current;
          const clickable = !!onStepClick;

          const Wrapper: any = clickable ? "button" : "div";
          const wrapperProps = clickable
            ? {
                type: "button" as const,
                onClick: () => onStepClick?.(step.id),
                "aria-label": `Ir para ${step.label}`,
              }
            : {};

          return (
            <Wrapper
              key={step.id}
              {...wrapperProps}
              className={cn(
                "flex flex-col items-center gap-1.5",
                clickable && "cursor-pointer hover:opacity-80 transition-opacity"
              )}
            >
              <div
                className={cn(
                  "w-10 h-10 rounded-full flex items-center justify-center transition-colors",
                  isCompleted && "bg-step-complete text-white",
                  isCurrent && !isCompleted && "bg-primary text-primary-foreground",
                  !isCompleted && !isCurrent && "bg-muted text-muted-foreground"
                )}
              >
                {isCompleted ? <Check className="h-5 w-5" /> : <StepIcon className="h-5 w-5" />}
              </div>
              <span
                className={cn(
                  "text-xs font-medium",
                  isCompleted && "text-step-complete",
                  isCurrent && !isCompleted && "text-primary",
                  !isCompleted && !isCurrent && "text-muted-foreground"
                )}
              >
                {step.label}
              </span>
            </Wrapper>
          );
        })}
      </div>
    </div>
  );
}

export function useProgressSteps({
  personalComplete,
  incomeComplete,
  documentsComplete,
  secondTenantComplete,
  hasSecondTenant,
}: {
  personalComplete: boolean;
  incomeComplete: boolean;
  documentsComplete: boolean;
  secondTenantComplete: boolean;
  hasSecondTenant: boolean;
}) {
  const steps: ProgressStep[] = [
    {
      id: "personal",
      label: "Pessoais",
      icon: User,
      completed: personalComplete,
      current: !personalComplete,
    },
    {
      id: "income",
      label: "Renda",
      icon: DollarSign,
      completed: incomeComplete,
      current: personalComplete && !incomeComplete,
    },
    {
      id: "documents",
      label: "Docs",
      icon: FileText,
      completed: documentsComplete,
      current: personalComplete && incomeComplete && !documentsComplete,
    },
  ];

  if (hasSecondTenant) {
    steps.push({
      id: "secondTenant",
      label: "2º Loc.",
      icon: Users,
      completed: secondTenantComplete,
      current: personalComplete && incomeComplete && documentsComplete && !secondTenantComplete,
    });
  }

  return steps;
}
