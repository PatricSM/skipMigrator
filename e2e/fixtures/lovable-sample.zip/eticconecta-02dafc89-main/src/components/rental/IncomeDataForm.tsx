import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { TenantData } from "@/types/rental";
import { ValidationErrors } from "@/utils/formValidation";
import { cn } from "@/lib/utils";

interface IncomeDataFormProps {
  data: TenantData;
  onChange: (data: TenantData) => void;
  prefix?: string;
  errors?: ValidationErrors;
}

export function IncomeDataForm({ data, onChange, prefix = "", errors = {} }: IncomeDataFormProps) {
  const handleChange = (field: keyof TenantData, value: string | boolean) => {
    onChange({ ...data, [field]: value });
  };

  const formatCurrency = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (!numbers) return '';
    const amount = parseInt(numbers, 10) / 100;
    return amount.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor={`${prefix}profession`}>
          Profissão *
        </Label>
        <Input
          id={`${prefix}profession`}
          placeholder="Ex: Engenheiro, Advogado, etc."
          value={data.profession}
          onChange={(e) => handleChange("profession", e.target.value)}
          maxLength={100}
          className={cn(errors.profession && "border-destructive focus-visible:ring-destructive")}
        />
        {errors.profession && (
          <p className="text-sm text-destructive">{errors.profession}</p>
        )}
      </div>

      <div className="space-y-3">
        <Label>Você é pessoa politicamente exposta? *</Label>
        <p className="text-xs text-muted-foreground">
          Pessoa que exerce ou exerceu cargo público relevante nos últimos 5 anos
        </p>
        <RadioGroup
          value={data.isPoliticallyExposed ? "yes" : "no"}
          onValueChange={(value) => handleChange("isPoliticallyExposed", value === "yes")}
          className="flex gap-4"
        >
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="no" id={`${prefix}pep-no`} />
            <Label htmlFor={`${prefix}pep-no`} className="cursor-pointer font-normal">
              Não
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="yes" id={`${prefix}pep-yes`} />
            <Label htmlFor={`${prefix}pep-yes`} className="cursor-pointer font-normal">
              Sim
            </Label>
          </div>
        </RadioGroup>
      </div>

      <div className="space-y-2">
        <Label htmlFor={`${prefix}monthlyIncome`}>
          Renda mensal bruta *
        </Label>
        <div className="relative">
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
            R$
          </span>
          <Input
            id={`${prefix}monthlyIncome`}
            inputMode="numeric"
            placeholder="0,00"
            value={data.monthlyIncome}
            onChange={(e) => handleChange("monthlyIncome", formatCurrency(e.target.value))}
            enterKeyHint="done"
            className={cn("pl-10", errors.monthlyIncome && "border-destructive focus-visible:ring-destructive")}
          />
        </div>
        {errors.monthlyIncome && (
          <p className="text-sm text-destructive">{errors.monthlyIncome}</p>
        )}
        <p className="text-xs text-muted-foreground">
          Informe sua renda bruta mensal (antes dos descontos)
        </p>
      </div>

      {/* Spacer for "peeking content" on mobile */}
      <div className="min-h-[2rem]" />
    </div>
  );
}
