import { cn } from "@/lib/utils";
import { Check, Trophy, Zap, ArrowRight, User, DollarSign, FileText, Users } from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface GamificationProgressProps {
  personalComplete: boolean;
  incomeComplete: boolean;
  documentsComplete: boolean;
  secondTenantComplete: boolean;
  hasSecondTenant: boolean;
  currentStep?: string;
  onStepClick?: (stepId: string) => void;
  className?: string;
}

interface StepInfo {
  id: string;
  label: string;
  icon: typeof User;
  complete: boolean;
  message: string;
}

export function GamificationProgress({
  personalComplete,
  incomeComplete,
  documentsComplete,
  secondTenantComplete,
  hasSecondTenant,
  currentStep,
  onStepClick,
  className,
}: GamificationProgressProps) {
  const steps: StepInfo[] = [
    {
      id: "personal",
      label: "Pessoais",
      icon: User,
      complete: personalComplete,
      message: "Identidade verificada",
    },
    {
      id: "income",
      label: "Renda",
      icon: DollarSign,
      complete: incomeComplete,
      message: "Análise financeira",
    },
    {
      id: "documents",
      label: "Docs",
      icon: FileText,
      complete: documentsComplete,
      message: "Documentação completa",
    },
  ];

  if (hasSecondTenant) {
    steps.push({
      id: "secondTenant",
      label: "2º Loc",
      icon: Users,
      complete: secondTenantComplete,
      message: "Dados do parceiro",
    });
  }

  const completedCount = steps.filter((s) => s.complete).length;
  const totalSteps = steps.length;
  const progress = (completedCount / totalSteps) * 100;
  const allComplete = completedCount === totalSteps;

  // Encouragement messages based on progress
  const getEncouragementMessage = () => {
    if (progress === 0) return "Comece sua jornada para o novo lar!";
    if (progress <= 25) return "Ótimo começo! Continue assim.";
    if (progress <= 50) return "Você está no caminho certo!";
    if (progress <= 75) return "Falta pouco para finalizar!";
    if (progress < 100) return "Quase lá! Uma última etapa.";
    return "Parabéns! Tudo pronto para enviar!";
  };

  const handleStepClick = (stepId: string) => {
    if (onStepClick) {
      onStepClick(stepId);
    }
  };

  return (
    <div className={cn("space-y-4", className)}>
      {/* Main Progress Card */}
      <div className="rounded-xl border border-border bg-card p-4 space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div
              className={cn(
                "w-10 h-10 rounded-full flex items-center justify-center transition-all",
                allComplete
                  ? "bg-step-complete text-step-complete-foreground"
                  : "bg-primary/10 text-primary"
              )}
            >
              {allComplete ? (
                <Trophy className="h-5 w-5" />
              ) : (
                <Zap className="h-5 w-5" />
              )}
            </div>
            <div>
              <h3 className="font-semibold text-foreground text-sm">
                Progresso da Ficha
              </h3>
              <p className="text-xs text-muted-foreground">
                {getEncouragementMessage()}
              </p>
            </div>
          </div>
          <div
            className={cn(
              "px-3 py-1.5 rounded-full text-xs font-bold",
              allComplete
                ? "bg-step-complete/10 text-step-complete"
                : "bg-primary/10 text-primary"
            )}
          >
            {completedCount}/{totalSteps}
          </div>
        </div>

        {/* Progress Bar */}
        <div className="space-y-2">
          <Progress value={progress} className="h-2" />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>Início</span>
            <span className="font-medium text-foreground">
              {Math.round(progress)}% completo
            </span>
            <span>Envio</span>
          </div>
        </div>

        {/* Clickable Step Indicators */}
        <div className="flex justify-between gap-1">
          {steps.map((step) => {
            const StepIcon = step.icon;
            const isComplete = step.complete;
            const isCurrent = currentStep === step.id;

            return (
              <button
                key={step.id}
                type="button"
                onClick={() => handleStepClick(step.id)}
                className={cn(
                  "flex flex-col items-center gap-1.5 flex-1 cursor-pointer transition-all",
                  onStepClick && "hover:opacity-80"
                )}
              >
                <div
                  className={cn(
                    "w-10 h-10 rounded-full flex items-center justify-center transition-all border-2",
                    isComplete
                      ? "bg-step-complete border-step-complete text-step-complete-foreground"
                      : isCurrent
                      ? "bg-primary border-primary text-primary-foreground"
                      : "bg-muted border-muted-foreground/20 text-muted-foreground"
                  )}
                >
                  {isComplete ? (
                    <Check className="h-5 w-5" />
                  ) : (
                    <StepIcon className="h-5 w-5" />
                  )}
                </div>
                <span
                  className={cn(
                    "text-xs font-medium text-center leading-tight",
                    isComplete
                      ? "text-step-complete"
                      : isCurrent
                      ? "text-primary"
                      : "text-muted-foreground"
                  )}
                >
                  {step.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Completion Celebration */}
      {allComplete && (
        <div className="rounded-xl border-2 border-step-complete/50 bg-step-complete/5 p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-step-complete/20 flex items-center justify-center">
              <Trophy className="h-5 w-5 text-step-complete" />
            </div>
            <div className="flex-1">
              <p className="font-semibold text-step-complete text-sm">
                🎉 Ficha Completa!
              </p>
              <p className="text-xs text-muted-foreground">
                Todos os dados foram preenchidos. Clique em enviar!
              </p>
            </div>
            <ArrowRight className="h-5 w-5 text-step-complete animate-pulse" />
          </div>
        </div>
      )}

      {/* Next Action Hint */}
      {!allComplete && (
        <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-primary/5 border border-primary/20">
          <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center">
            <ArrowRight className="h-3 w-3 text-primary" />
          </div>
          <p className="text-xs text-muted-foreground">
            <span className="font-medium text-foreground">Próximo:</span>{" "}
            {steps.find((s) => !s.complete)?.message || "Revisar dados"}
          </p>
        </div>
      )}
    </div>
  );
}
