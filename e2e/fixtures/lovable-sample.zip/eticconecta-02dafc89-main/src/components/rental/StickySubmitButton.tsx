import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";

interface StickySubmitButtonProps {
  label: string;
  sublabel?: string;
  disabled?: boolean;
  isLoading?: boolean;
  onClick: () => void;
}

export function StickySubmitButton({
  label,
  sublabel,
  disabled = false,
  isLoading = false,
  onClick,
}: StickySubmitButtonProps) {
  return (
    <div 
      className="fixed bottom-0 left-0 right-0 p-4 bg-background/95 backdrop-blur-sm border-t border-border z-50"
      style={{ paddingBottom: 'max(1rem, env(safe-area-inset-bottom))' }}
    >
      <div className="container max-w-lg mx-auto">
        <Button
          size="lg"
          className="w-full h-14 text-base font-semibold"
          disabled={disabled || isLoading}
          onClick={onClick}
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-5 w-5 animate-spin" />
              Enviando...
            </>
          ) : (
            label
          )}
        </Button>
        {sublabel && (
          <p className="text-xs text-muted-foreground text-center mt-2">
            {sublabel}
          </p>
        )}
      </div>
    </div>
  );
}
