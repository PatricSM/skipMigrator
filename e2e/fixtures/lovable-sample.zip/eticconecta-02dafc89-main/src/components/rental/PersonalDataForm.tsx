import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { DateInput } from "@/components/ui/date-input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { TenantData } from "@/types/rental";
import { ValidationErrors, validateAge } from "@/utils/formValidation";
import { cn } from "@/lib/utils";
import { isValidCPF } from "@/lib/masks";
import { AlertCircle, CheckCircle2 } from "lucide-react";

export type PersonalSection = 'all' | 'identity' | 'civil';

interface PersonalDataFormProps {
  data: TenantData;
  onChange: (data: TenantData) => void;
  prefix?: string;
  errors?: ValidationErrors;
  /** Which fields to show: 'identity' = name/email/phone, 'civil' = birth/cpf/nationality/marital, 'all' = everything */
  section?: PersonalSection;
}

export function PersonalDataForm({ data, onChange, prefix = "", errors = {}, section = 'all' }: PersonalDataFormProps) {
  const handleChange = (field: keyof TenantData, value: string | boolean) => {
    onChange({ ...data, [field]: value });
  };

  const formatCPF = (value: string) => {
    const numbers = value.replace(/\D/g, '').slice(0, 11);
    return numbers
      .replace(/(\d{3})(\d)/, '$1.$2')
      .replace(/(\d{3})(\d)/, '$1.$2')
      .replace(/(\d{3})(\d{1,2})$/, '$1-$2');
  };

  const formatPhone = (value: string) => {
    const numbers = value.replace(/\D/g, '').slice(0, 11);
    if (numbers.length <= 10) {
      return numbers
        .replace(/(\d{2})(\d)/, '($1) $2')
        .replace(/(\d{4})(\d)/, '$1-$2');
    }
    return numbers
      .replace(/(\d{2})(\d)/, '($1) $2')
      .replace(/(\d{5})(\d)/, '$1-$2');
  };

  // CPF validation state
  const cleanCpf = data.cpf?.replace(/\D/g, '') || '';
  const cpfComplete = cleanCpf.length === 11;
  const cpfValid = cpfComplete && isValidCPF(data.cpf);

  const showIdentity = section === 'all' || section === 'identity';
  const showCivil = section === 'all' || section === 'civil';

  return (
    <div className="space-y-6">
      <div className="space-y-4">
        {showIdentity && (
          <>
            <div className="space-y-2">
              <Label htmlFor={`${prefix}fullName`}>
                Nome completo *
              </Label>
              <Input
                id={`${prefix}fullName`}
                placeholder="Digite seu nome completo"
                value={data.fullName}
                onChange={(e) => handleChange('fullName', e.target.value)}
                maxLength={100}
                autoComplete="name"
                enterKeyHint="next"
                className={cn(errors.fullName && "border-destructive focus-visible:ring-destructive")}
              />
              {errors.fullName && (
                <p className="text-sm text-destructive">{errors.fullName}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor={`${prefix}email`}>
                E-mail *
              </Label>
              <Input
                id={`${prefix}email`}
                type="email"
                inputMode="email"
                placeholder="seu@email.com"
                value={data.email}
                onChange={(e) => handleChange('email', e.target.value)}
                maxLength={255}
                autoComplete="email"
                enterKeyHint="next"
                className={cn(errors.email && "border-destructive focus-visible:ring-destructive")}
              />
              {errors.email && (
                <p className="text-sm text-destructive">{errors.email}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor={`${prefix}phone`}>
                Telefone *
              </Label>
              <Input
                id={`${prefix}phone`}
                type="tel"
                inputMode="tel"
                placeholder="(11) 99999-9999"
                value={data.phone}
                onChange={(e) => handleChange('phone', formatPhone(e.target.value))}
                autoComplete="tel"
                enterKeyHint="next"
                className={cn(errors.phone && "border-destructive focus-visible:ring-destructive")}
              />
              {errors.phone && (
                <p className="text-sm text-destructive">{errors.phone}</p>
              )}
            </div>
          </>
        )}

        {showCivil && (
          <>
            <div className="space-y-2">
              <Label htmlFor={`${prefix}birthDate`}>
                Data de nascimento *
              </Label>
              <div className="relative">
                <DateInput
                  id={`${prefix}birthDate`}
                  value={data.birthDate}
                  onChange={(value) => handleChange('birthDate', value)}
                  className={cn(
                    "pr-10",
                    errors.birthDate && "border-destructive focus-visible:ring-destructive",
                    data.birthDate && validateAge(data.birthDate).valid && "border-step-complete focus-visible:ring-step-complete"
                  )}
                />
                {data.birthDate && (
                  <div className="absolute right-3 top-1/2 -translate-y-1/2">
                    {validateAge(data.birthDate).valid ? (
                      <CheckCircle2 className="h-4 w-4 text-step-complete" />
                    ) : (
                      <AlertCircle className="h-4 w-4 text-destructive" />
                    )}
                  </div>
                )}
              </div>
              {errors.birthDate && (
                <p className="text-sm text-destructive">{errors.birthDate}</p>
              )}
              {data.birthDate && !validateAge(data.birthDate).valid && !errors.birthDate && (
                <p className="text-sm text-destructive">{validateAge(data.birthDate).error}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor={`${prefix}cpf`}>
                CPF *
              </Label>
              <div className="relative">
                <Input
                  id={`${prefix}cpf`}
                  inputMode="numeric"
                  placeholder="000.000.000-00"
                  value={data.cpf}
                  onChange={(e) => handleChange('cpf', formatCPF(e.target.value))}
                  enterKeyHint="next"
                  className={cn(
                    "pr-10",
                    errors.cpf && "border-destructive focus-visible:ring-destructive",
                    cpfComplete && cpfValid && "border-step-complete focus-visible:ring-step-complete"
                  )}
                />
                {cpfComplete && (
                  <div className="absolute right-3 top-1/2 -translate-y-1/2">
                    {cpfValid ? (
                      <CheckCircle2 className="h-4 w-4 text-step-complete" />
                    ) : (
                      <AlertCircle className="h-4 w-4 text-destructive" />
                    )}
                  </div>
                )}
              </div>
              {errors.cpf && (
                <p className="text-sm text-destructive">{errors.cpf}</p>
              )}
              {cpfComplete && !cpfValid && !errors.cpf && (
                <p className="text-sm text-destructive">CPF inválido - verifique os dígitos</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor={`${prefix}nationality`}>
                Nacionalidade *
              </Label>
              <Select
                value={data.nationality}
                onValueChange={(value) => {
                  onChange({
                    ...data,
                    nationality: value,
                    nationalityCountry: value === "Brasileira" ? "" : data.nationalityCountry,
                  });
                }}
              >
                <SelectTrigger id={`${prefix}nationality`}>
                  <SelectValue placeholder="Selecione" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Brasileira">Brasileira</SelectItem>
                  <SelectItem value="Estrangeira">Estrangeira</SelectItem>
                </SelectContent>
              </Select>
              {errors.nationality && (
                <p className="text-sm text-destructive">{errors.nationality}</p>
              )}
            </div>

            {data.nationality === "Estrangeira" && (
              <div className="space-y-2">
                <Label htmlFor={`${prefix}nationalityCountry`}>
                  País de origem *
                </Label>
                <Input
                  id={`${prefix}nationalityCountry`}
                  placeholder="Digite o país"
                  value={data.nationalityCountry}
                  onChange={(e) => handleChange("nationalityCountry", e.target.value)}
                  maxLength={100}
                  className={cn(errors.nationalityCountry && "border-destructive focus-visible:ring-destructive")}
                />
                {errors.nationalityCountry && (
                  <p className="text-sm text-destructive">{errors.nationalityCountry}</p>
                )}
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor={`${prefix}maritalStatus`}>
                Estado civil *
              </Label>
              <Select value={data.maritalStatus} onValueChange={(value) => handleChange("maritalStatus", value)}>
                <SelectTrigger id={`${prefix}maritalStatus`}>
                  <SelectValue placeholder="Selecione" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Solteiro(a)">Solteiro(a)</SelectItem>
                  <SelectItem value="Casado(a)">Casado(a)</SelectItem>
                  <SelectItem value="Divorciado(a)">Divorciado(a)</SelectItem>
                  <SelectItem value="Viúvo(a)">Viúvo(a)</SelectItem>
                  <SelectItem value="União Estável">União Estável</SelectItem>
                </SelectContent>
              </Select>
              {errors.maritalStatus && (
                <p className="text-sm text-destructive">{errors.maritalStatus}</p>
              )}
            </div>
          </>
        )}
      </div>

      {/* Spacer for "peeking content" on mobile */}
      <div className="min-h-[2rem]" />
    </div>
  );
}