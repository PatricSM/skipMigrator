import { Users, User, DollarSign, FileText, Check } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { TenantData, DocumentUploadState } from "@/types/rental";
import { cn } from "@/lib/utils";

type SecondTenantSectionId = "personal" | "income" | "documents";

interface SecondTenantCardProps {
  hasSecondTenant: "no" | "yes";
  onHasSecondTenantChange: (value: "no" | "yes") => void;
  tenantData: TenantData;
  documents: DocumentUploadState[];
  isSaved: boolean;
  onOpenSecondTenantPage: (section?: SecondTenantSectionId) => void;
}

function getPersonalProgress(tenantData: TenantData) {
  const fields = [
    !!tenantData.fullName,
    !!tenantData.email,
    !!tenantData.phone,
    !!tenantData.birthDate,
    !!tenantData.cpf,
    !!tenantData.maritalStatus,
    !!tenantData.nationality,
    tenantData.nationality === "Estrangeira" ? !!tenantData.nationalityCountry : true,
  ];
  const total = fields.length;
  const filled = fields.filter(Boolean).length;
  return { filled, total, complete: filled === total };
}

function getIncomeProgress(tenantData: TenantData) {
  const complete = tenantData.profession.trim().length > 0 && tenantData.monthlyIncome.length > 0;
  return { filled: complete ? 2 : 0, total: 2, complete };
}

function getDocsProgress(documents: DocumentUploadState[]) {
  const uploaded = documents.filter((d) => d.status === "uploaded").length;
  const total = documents.length;
  return { uploaded, total, complete: uploaded === total };
}

export function SecondTenantCard({
  hasSecondTenant,
  onHasSecondTenantChange,
  tenantData,
  documents,
  isSaved,
  onOpenSecondTenantPage,
}: SecondTenantCardProps) {
  const personal = getPersonalProgress(tenantData);
  const income = getIncomeProgress(tenantData);
  const docs = getDocsProgress(documents);

  const completedSections = [personal.complete, income.complete, docs.complete].filter(Boolean).length;
  const progress = (completedSections / 3) * 100;

  const sections: {
    id: SecondTenantSectionId;
    label: string;
    icon: typeof User;
    complete: boolean;
    meta: string;
  }[] = [
    {
      id: "personal",
      label: "Dados Pessoais",
      icon: User,
      complete: personal.complete,
      meta: personal.complete ? "OK" : `${personal.filled}/${personal.total} campos`,
    },
    {
      id: "income",
      label: "Renda",
      icon: DollarSign,
      complete: income.complete,
      meta: income.complete ? "OK" : "Pendente",
    },
    {
      id: "documents",
      label: "Documentos",
      icon: FileText,
      complete: docs.complete,
      meta: `${docs.uploaded}/${docs.total} enviados`,
    },
  ];

  return (
    <div className="rounded-2xl border border-border bg-card p-6 space-y-6">
      <div className="flex items-start gap-4">
        <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <div className="relative">
            <Users className="h-6 w-6 text-primary" />
          </div>
        </div>
        <div>
          <h3 className="font-semibold text-foreground">Haverá 2º locatário?</h3>
          <p className="text-sm text-muted-foreground">Se sim, preencha os dados e envie os documentos dele.</p>
        </div>
      </div>

      <div className="space-y-3">
        <RadioGroup value={hasSecondTenant} onValueChange={(value) => onHasSecondTenantChange(value as "no" | "yes")} className="space-y-3">
          <div className="flex items-center space-x-3 p-3 rounded-lg border border-border hover:border-primary/30 transition-colors">
            <RadioGroupItem value="no" id="second-no" />
            <Label htmlFor="second-no" className="cursor-pointer font-normal flex-1">
              Não, apenas eu
            </Label>
          </div>

          <div className="flex items-center space-x-3 p-3 rounded-lg border border-border hover:border-primary/30 transition-colors">
            <RadioGroupItem value="yes" id="second-yes" />
            <Label htmlFor="second-yes" className="cursor-pointer font-normal flex-1">
              Sim, haverá outro locatário
            </Label>
          </div>
        </RadioGroup>
      </div>

      {hasSecondTenant === "yes" && (
        <div className="space-y-4 pt-2">
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Missões do 2º locatário</span>
              <Badge variant="secondary">{completedSections}/3</Badge>
            </div>
            <Progress value={progress} className="h-2" />
            <p className="text-xs text-muted-foreground">
              {progress === 0 && "Comece pela primeira missão para desbloquear o envio."}
              {progress > 0 && progress < 100 && "Ótimo! Complete as missões para liberar o botão de salvar."}
              {progress === 100 && "Tudo certo. Você pode salvar e voltar."}
            </p>
          </div>

          <div className="grid gap-3">
            {sections.map((s) => {
              const Icon = s.icon;
              return (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => onOpenSecondTenantPage(s.id)}
                  className={cn(
                    "rounded-lg border p-3 text-left transition-all",
                    "hover:border-primary/50 hover:bg-muted/30",
                    s.complete ? "border-step-complete/50 bg-step-complete/5" : "border-border"
                  )}
                  aria-label={`Abrir ${s.label} do segundo locatário`}
                >
                  <div className="flex items-center gap-3">
                    <div className={cn("w-8 h-8 rounded-full flex items-center justify-center", s.complete ? "bg-step-complete/20 text-step-complete" : "bg-muted text-muted-foreground")}>
                      {s.complete ? <Check className="h-4 w-4" /> : <Icon className="h-4 w-4" />}
                    </div>
                    <span className="text-xs font-bold text-primary">+1</span>
                  </div>
                  <p className="font-medium text-foreground mt-2">{s.label}</p>
                  <p className="text-xs text-muted-foreground">{s.meta}</p>
                </button>
              );
            })}
          </div>

          <Button variant="default" onClick={() => onOpenSecondTenantPage()} className="w-full">
            {isSaved ? "Revisar dados do 2º locatário" : "Preencher dados do 2º locatário"}
          </Button>
        </div>
      )}
    </div>
  );
}
