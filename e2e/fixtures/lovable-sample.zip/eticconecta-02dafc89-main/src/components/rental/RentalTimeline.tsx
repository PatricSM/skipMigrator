import { Check, Clock } from "lucide-react";
import { cn } from "@/lib/utils";
import { RENTAL_STEPS, RentalStep } from "@/types/rental";

interface RentalTimelineProps {
  currentStep: RentalStep;
  compact?: boolean;
}

export function RentalTimeline({ currentStep, compact = false }: RentalTimelineProps) {
  if (compact) {
    return (
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-foreground">
            Etapa {currentStep} de 8
          </span>
          <span className="text-sm text-muted-foreground">
            {RENTAL_STEPS[currentStep - 1].title}
          </span>
        </div>

        <div className="flex gap-1">
          {RENTAL_STEPS.map((step) => (
            <div
              key={step.step}
              className={cn(
                "h-1.5 flex-1 rounded-full transition-colors",
                step.step < currentStep && "bg-step-complete",
                step.step === currentStep && "bg-primary",
                step.step > currentStep && "bg-step-pending"
              )}
            />
          ))}
        </div>

        {currentStep < 8 && (
          <p className="text-xs text-muted-foreground flex items-center gap-1">
            <Clock className="h-3 w-3" />
            Próxima: {RENTAL_STEPS[currentStep].title}
            {RENTAL_STEPS[currentStep].duration && ` (${RENTAL_STEPS[currentStep].duration})`}
          </p>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h3 className="font-semibold text-foreground">Progresso da locação</h3>

      <div className="space-y-0">
        {RENTAL_STEPS.map((step, index) => {
          const isComplete = step.step < currentStep;
          const isCurrent = step.step === currentStep;
          const isPending = step.step > currentStep;

          return (
            <div key={step.step} className="flex gap-4">
              {/* Step indicator */}
              <div className="flex flex-col items-center">
                <div
                  className={cn(
                    "w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-colors",
                    isComplete && "bg-step-complete text-step-complete-foreground",
                    isCurrent && "bg-primary text-primary-foreground",
                    isPending && "bg-step-pending text-step-pending-foreground"
                  )}
                >
                  {isComplete ? <Check className="h-4 w-4" /> : step.step}
                </div>
                {index < RENTAL_STEPS.length - 1 && (
                  <div
                    className={cn(
                      "w-0.5 h-12 transition-colors",
                      isComplete ? "bg-step-complete" : "bg-step-pending"
                    )}
                  />
                )}
              </div>

              {/* Step content */}
              <div className="pb-8">
                <p
                  className={cn(
                    "font-medium",
                    isComplete && "text-step-complete",
                    isCurrent && "text-foreground",
                    isPending && "text-muted-foreground"
                  )}
                >
                  {step.title}
                </p>
                <p
                  className={cn(
                    "text-sm",
                    isCurrent ? "text-muted-foreground" : "text-muted-foreground/70"
                  )}
                >
                  {step.description}
                </p>
                {isCurrent && step.duration && (
                  <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                    <Clock className="h-3 w-3" />
                    {step.duration}
                  </p>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
