import { useRef, useState } from "react";
import { Upload, Check, AlertCircle, X, FileText, Loader2, Plus } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { DocumentStatus } from "@/types/rental";

export interface DocFileEntry {
  id: string;
  type: string;
  status: DocumentStatus;
  fileName?: string;
  fileUrl?: string;
  documentLabel?: string;
  progress?: number;
  errorMessage?: string;
}

interface DocumentUploadProps {
  docType: string;
  label: string;
  description: string;
  microcopy?: string;
  files: DocFileEntry[];
  maxFiles: number;
  onUpload: (files: File[], documentLabel?: string) => void;
  onRemove: (fileId: string) => void;
  onRetry: (fileId: string) => void;
  hasError?: boolean;
  compact?: boolean;
  showLabelInput?: boolean;
}

export function DocumentUpload({
  docType,
  label,
  description,
  microcopy,
  files,
  maxFiles,
  onUpload,
  onRemove,
  onRetry,
  hasError = false,
  compact = false,
  showLabelInput = false,
}: DocumentUploadProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [otherLabel, setOtherLabel] = useState("");

  const uploadedOrUploading = files.filter(
    (f) => f.status === "uploaded" || f.status === "uploading"
  ).length;
  const canAddMore = uploadedOrUploading < maxFiles;
  const labelValid = !showLabelInput || otherLabel.trim().length >= 3;

  const handleClick = () => {
    if (!labelValid) return;
    inputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files;
    if (selected && selected.length > 0) {
      onUpload(Array.from(selected), showLabelInput ? otherLabel.trim() : undefined);
      if (showLabelInput) setOtherLabel("");
    }
    if (inputRef.current) inputRef.current.value = "";
  };

  const showValidationError = hasError && files.filter((f) => f.status === "uploaded").length === 0;

  return (
    <div
      className={cn(
        "rounded-xl border bg-card transition-colors",
        compact ? "p-3" : "p-4",
        showValidationError && "border-destructive"
      )}
    >
      <input
        ref={inputRef}
        type="file"
        accept="image/*,.pdf"
        multiple
        onChange={handleFileChange}
        className="hidden"
      />

      {/* Header */}
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <p className={cn("font-medium text-foreground", compact && "text-sm")}>
              {label}
            </p>
            <Badge variant="secondary" className="text-xs shrink-0">
              {files.filter((f) => f.status === "uploaded").length}/{maxFiles}
            </Badge>
          </div>
          <p className={cn("text-muted-foreground mt-0.5", compact ? "text-xs" : "text-sm")}>
            {description}
          </p>
          {microcopy && (
            <p className="text-xs text-muted-foreground/80 mt-1 leading-relaxed italic">
              {microcopy}
            </p>
          )}
        </div>
      </div>

      {showValidationError && (
        <p className="text-xs text-destructive mt-1.5">
          Este documento é obrigatório
        </p>
      )}

      {/* File List */}
      {files.length > 0 && (
        <div className="mt-3 space-y-2">
          {files.map((file) => (
            <div key={file.id}>
              {file.status === "uploaded" && (
                <div className="flex items-center gap-2 rounded-lg bg-muted/50 px-3 py-2">
                  <Check className="h-4 w-4 text-step-complete shrink-0" />
                  <div className="flex-1 min-w-0">
                    {file.documentLabel && (
                      <p className="text-xs font-medium text-foreground truncate">
                        {file.documentLabel}
                      </p>
                    )}
                    <p className="text-xs text-muted-foreground truncate flex items-center gap-1">
                      <FileText className="h-3 w-3 shrink-0" />
                      {file.fileName}
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="shrink-0 text-muted-foreground hover:text-destructive h-7 w-7"
                    onClick={() => onRemove(file.id)}
                    type="button"
                  >
                    <X className="h-3.5 w-3.5" />
                  </Button>
                </div>
              )}

              {file.status === "uploading" && (
                <div className="rounded-lg bg-muted/50 px-3 py-2 space-y-1.5">
                  <div className="flex items-center gap-2">
                    <Loader2 className="h-4 w-4 text-primary animate-spin shrink-0" />
                    <p className="text-xs text-foreground truncate flex-1">
                      {file.fileName}
                    </p>
                  </div>
                  <Progress value={file.progress || 0} className="h-1" />
                </div>
              )}

              {file.status === "error" && (
                <div className="flex items-center gap-2 rounded-lg bg-destructive/5 px-3 py-2">
                  <AlertCircle className="h-4 w-4 text-destructive shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-foreground truncate">{file.fileName || label}</p>
                    <p className="text-xs text-destructive">
                      {file.errorMessage || "Erro ao enviar"}
                    </p>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onRetry(file.id)}
                    type="button"
                    className="text-xs h-7 px-2"
                  >
                    Tentar
                  </Button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Label input for "other" type */}
      {showLabelInput && canAddMore && (
        <div className="mt-3">
          <Input
            placeholder="Ex.: Extrato bancário, declaração do contador, contrato de trabalho…"
            value={otherLabel}
            onChange={(e) => setOtherLabel(e.target.value)}
            className="text-sm h-9"
          />
          {otherLabel.length > 0 && otherLabel.trim().length < 3 && (
            <p className="text-xs text-destructive mt-1">Mínimo de 3 caracteres</p>
          )}
        </div>
      )}

      {/* Add file button */}
      {canAddMore && (
        <button
          type="button"
          onClick={handleClick}
          disabled={!labelValid}
          className={cn(
            "mt-3 w-full flex items-center justify-center gap-2 rounded-lg border-2 border-dashed border-border py-2.5 text-sm font-medium text-primary transition-colors hover:border-primary/50 hover:bg-primary/5",
            !labelValid && "opacity-50 cursor-not-allowed"
          )}
        >
          {files.length === 0 ? (
            <>
              <Upload className="h-4 w-4" />
              Selecionar arquivo
            </>
          ) : (
            <>
              <Plus className="h-4 w-4" />
              Adicionar arquivo
            </>
          )}
        </button>
      )}
    </div>
  );
}
