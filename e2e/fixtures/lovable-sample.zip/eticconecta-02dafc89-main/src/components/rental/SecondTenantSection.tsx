import { useState, useRef, useEffect } from "react";
import { Users, Check, ChevronDown, User, DollarSign, FileText, Edit2, ArrowDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { PersonalDataForm } from "./PersonalDataForm";
import { IncomeDataForm } from "./IncomeDataForm";
import { DocumentUpload } from "./DocumentUpload";
import { TenantData, DocumentUploadState } from "@/types/rental";
import { cn } from "@/lib/utils";

type FormSection = 'personal' | 'income' | 'documents';

interface SecondTenantSectionProps {
  hasSecondTenant: "no" | "yes";
  onHasSecondTenantChange: (value: "no" | "yes") => void;
  tenantData: TenantData;
  onTenantDataChange: (data: TenantData) => void;
  documents: DocumentUploadState[];
  onDocumentUpload: (docId: string, files: File[]) => void;
  onDocumentRetry: (docId: string) => void;
  onDocumentRemove: (docId: string) => void;
  isSaved: boolean;
  onSave: () => void;
}

export function SecondTenantSection({
  hasSecondTenant,
  onHasSecondTenantChange,
  tenantData,
  onTenantDataChange,
  documents,
  onDocumentUpload,
  onDocumentRetry,
  onDocumentRemove,
  isSaved,
  onSave,
}: SecondTenantSectionProps) {
  const [sheetOpen, setSheetOpen] = useState(false);
  const [activeSection, setActiveSection] = useState<FormSection>('personal');
  const [showScrollIndicator, setShowScrollIndicator] = useState(true);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // Check if content needs scrolling
  useEffect(() => {
    const container = scrollContainerRef.current;
    if (!container) return;

    const checkScroll = () => {
      const { scrollTop, scrollHeight, clientHeight } = container;
      const isAtBottom = scrollTop + clientHeight >= scrollHeight - 20;
      setShowScrollIndicator(!isAtBottom && scrollHeight > clientHeight);
    };

    checkScroll();
    container.addEventListener('scroll', checkScroll);
    return () => container.removeEventListener('scroll', checkScroll);
  }, [activeSection, sheetOpen]);

  // Calculate field-level completion for personal section
  const getPersonalFieldsProgress = () => {
    const fields = [
      { filled: !!tenantData.fullName, label: 'Nome' },
      { filled: !!tenantData.email, label: 'Email' },
      { filled: !!tenantData.phone, label: 'Telefone' },
      { filled: !!tenantData.birthDate, label: 'Nascimento' },
      { filled: !!tenantData.cpf, label: 'CPF' },
      { filled: !!tenantData.maritalStatus, label: 'Estado Civil' },
      { filled: !!tenantData.nationality, label: 'Nacionalidade' },
    ];
    
    if (tenantData.nationality === "Estrangeira") {
      fields.push({ filled: !!tenantData.nationalityCountry, label: 'País' });
    }
    
    return {
      filled: fields.filter(f => f.filled).length,
      total: fields.length,
      nextEmpty: fields.find(f => !f.filled)?.label
    };
  };

  const getIncomeFieldsProgress = () => {
    const fields = [
      { filled: !!tenantData.profession.trim(), label: 'Profissão' },
      { filled: !!tenantData.monthlyIncome, label: 'Renda' },
    ];
    return {
      filled: fields.filter(f => f.filled).length,
      total: fields.length,
      nextEmpty: fields.find(f => !f.filled)?.label
    };
  };

  // Calculate completion
  const isPersonalComplete = () => {
    const progress = getPersonalFieldsProgress();
    return progress.filled === progress.total;
  };

  const isIncomeComplete = () => {
    return tenantData.monthlyIncome.length > 0 && 
           tenantData.profession.trim().length > 0;
  };

  const getDocumentsProgress = () => {
    const uploaded = documents.filter(d => d.status === 'uploaded').length;
    return { uploaded, total: documents.length };
  };

  const areDocumentsComplete = () => {
    return documents.every(d => d.status === 'uploaded');
  };

  const personalComplete = isPersonalComplete();
  const incomeComplete = isIncomeComplete();
  const docsProgress = getDocumentsProgress();
  const documentsComplete = areDocumentsComplete();
  
  const totalSections = 3;
  const completedSections = [personalComplete, incomeComplete, documentsComplete].filter(Boolean).length;
  const overallProgress = (completedSections / totalSections) * 100;

  // Get current section progress
  const getCurrentSectionProgress = () => {
    switch (activeSection) {
      case 'personal':
        return getPersonalFieldsProgress();
      case 'income':
        return getIncomeFieldsProgress();
      case 'documents':
        return { filled: docsProgress.uploaded, total: docsProgress.total, nextEmpty: 'documento' };
    }
  };

  const goToNextSection = () => {
    const currentIndex = ['personal', 'income', 'documents'].indexOf(activeSection);
    const nextSection = ['personal', 'income', 'documents'][currentIndex + 1] as FormSection;
    if (nextSection) {
      setActiveSection(nextSection);
      scrollContainerRef.current?.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleSave = () => {
    onSave();
    setSheetOpen(false);
  };

  const sections: { id: FormSection; label: string; icon: typeof User; complete: boolean; subtitle: string }[] = [
    { 
      id: 'personal', 
      label: 'Dados Pessoais', 
      icon: User, 
      complete: personalComplete,
      subtitle: personalComplete ? tenantData.fullName || 'Completo' : 'Preencher dados'
    },
    { 
      id: 'income', 
      label: 'Renda', 
      icon: DollarSign, 
      complete: incomeComplete,
      subtitle: incomeComplete ? tenantData.profession || 'Completo' : 'Informar renda'
    },
    { 
      id: 'documents', 
      label: 'Documentos', 
      icon: FileText, 
      complete: documentsComplete,
      subtitle: `${docsProgress.uploaded}/${docsProgress.total} enviados`
    },
  ];

  return (
    <div className="rounded-2xl border border-border bg-card p-6 space-y-6">
      {/* Header */}
      <div className="flex items-start gap-4">
        <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <div className="relative">
            <Users className="h-6 w-6 text-primary" />
          </div>
        </div>
        <div>
          <h3 className="font-semibold text-foreground">Haverá mais de um locatário?</h3>
          <p className="text-sm text-muted-foreground">
            Adicione os dados de quem vai morar com você
          </p>
        </div>
      </div>

      {/* Radio Options */}
      <div className="space-y-3">
        <RadioGroup
          value={hasSecondTenant}
          onValueChange={(value) => {
            onHasSecondTenantChange(value as "no" | "yes");
          }}
          className="space-y-3"
        >
          <div className="flex items-center space-x-3 p-3 rounded-lg border border-border hover:border-primary/30 transition-colors">
            <RadioGroupItem value="no" id="second-tenant-no" />
            <Label htmlFor="second-tenant-no" className="cursor-pointer font-normal flex-1">
              Não, apenas eu
            </Label>
          </div>
          <div className="flex items-center space-x-3 p-3 rounded-lg border border-border hover:border-primary/30 transition-colors">
            <RadioGroupItem value="yes" id="second-tenant-yes" />
            <Label htmlFor="second-tenant-yes" className="cursor-pointer font-normal flex-1">
              Sim, haverá outro locatário
            </Label>
          </div>
        </RadioGroup>
      </div>

      {/* Second Tenant Content */}
      {hasSecondTenant === "yes" && (
        <div className="space-y-4 pt-2">
          {isSaved ? (
            // Saved State - Compact Summary
            <div className="rounded-lg border border-step-complete/30 bg-step-complete/5 p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-step-complete/20 flex items-center justify-center">
                    <Check className="h-5 w-5 text-step-complete" />
                  </div>
                  <div>
                    <p className="font-medium text-foreground">
                      {tenantData.fullName || "2º Locatário"}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Dados completos • {docsProgress.uploaded} docs enviados
                    </p>
                  </div>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setSheetOpen(true)}
                  className="gap-2"
                >
                  <Edit2 className="h-4 w-4" />
                  Editar
                </Button>
              </div>
            </div>
          ) : (
            // Edit State - Progress Cards
            <div className="space-y-4">
              {/* Overall Progress */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Progresso do 2º locatário</span>
                  <Badge variant="secondary">
                    {completedSections}/{totalSections}
                  </Badge>
                </div>
                <Progress value={overallProgress} className="h-2" />
              </div>

              {/* Section Cards */}
              <div className="grid gap-3">
                {sections.map((section) => {
                  const SectionIcon = section.icon;
                  return (
                    <button
                      key={section.id}
                      type="button"
                      onClick={() => {
                        setActiveSection(section.id);
                        setSheetOpen(true);
                      }}
                      className={cn(
                        "w-full flex items-center gap-3 p-3 rounded-lg border transition-all",
                        "hover:border-primary/50 hover:bg-muted/30",
                        section.complete ? "border-step-complete/50 bg-step-complete/5" : "border-border"
                      )}
                    >
                      <div className={cn(
                        "w-10 h-10 rounded-full flex items-center justify-center",
                        section.complete ? "bg-step-complete/20 text-step-complete" : "bg-muted text-muted-foreground"
                      )}>
                        {section.complete ? <Check className="h-5 w-5" /> : <SectionIcon className="h-5 w-5" />}
                      </div>
                      <div className="flex-1 text-left">
                        <p className="font-medium text-foreground">{section.label}</p>
                        <p className="text-sm text-muted-foreground">{section.subtitle}</p>
                      </div>
                      <ChevronDown className="h-5 w-5 text-muted-foreground -rotate-90" />
                    </button>
                  );
                })}
              </div>

              {/* Save Button */}
              {completedSections === totalSections && (
                <Button onClick={handleSave} className="w-full gap-2">
                  <Check className="h-4 w-4" />
                  Salvar dados do 2º locatário
                </Button>
              )}
            </div>
          )}
        </div>
      )}

      {/* Sheet for Editing */}
      <Sheet open={sheetOpen} onOpenChange={setSheetOpen}>
        <SheetContent side="bottom" className="h-[90vh] flex flex-col p-0">
          <SheetHeader className="px-6 pt-6 pb-4 border-b shrink-0">
            <div className="flex items-center justify-between">
              <div>
                <SheetTitle>Dados do 2º Locatário</SheetTitle>
                <SheetDescription>
                  Preencha as informações abaixo
                </SheetDescription>
              </div>
              <Badge variant="secondary">
                {completedSections}/{totalSections} completo
              </Badge>
            </div>

            {/* Section Tabs with Progress */}
            <div className="flex gap-2 mt-4 overflow-x-auto pb-2">
              {sections.map((section) => {
                const SectionIcon = section.icon;
                const isActive = activeSection === section.id;
                return (
                  <button
                    key={section.id}
                    type="button"
                    onClick={() => {
                      setActiveSection(section.id);
                      scrollContainerRef.current?.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className={cn(
                      "flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all shrink-0",
                      isActive 
                        ? "bg-primary text-primary-foreground" 
                        : section.complete 
                          ? "bg-step-complete/10 text-step-complete"
                          : "bg-muted text-muted-foreground"
                    )}
                  >
                    {section.complete && !isActive ? (
                      <Check className="h-4 w-4" />
                    ) : (
                      <SectionIcon className="h-4 w-4" />
                    )}
                    {section.label}
                  </button>
                );
              })}
            </div>
          </SheetHeader>

          {/* Form Content with Scroll */}
          <div className="flex-1 overflow-hidden relative">
            <div
              ref={scrollContainerRef}
              className="h-full overflow-y-auto px-6 py-6"
            >
              {activeSection === 'personal' && (
                <PersonalDataForm data={tenantData} onChange={onTenantDataChange} prefix="second-" />
              )}

              {activeSection === 'income' && (
                <IncomeDataForm data={tenantData} onChange={onTenantDataChange} prefix="second-" />
              )}

              {activeSection === 'documents' && (
                <div className="space-y-4">
                  {documents.map((doc) => {
                    const info = { label: doc.label, description: doc.description };
                    return (
                      <DocumentUpload
                        key={doc.id}
                        docType={doc.type}
                        label={info.label}
                        description={info.description}
                        files={[{
                          id: doc.id,
                          type: doc.type,
                          status: doc.status,
                          fileName: doc.fileName,
                          fileUrl: doc.fileUrl,
                          documentLabel: doc.documentLabel,
                          progress: doc.progress,
                          errorMessage: doc.errorMessage,
                        }]}
                        maxFiles={1}
                        onUpload={(files) => onDocumentUpload(doc.id, files)}
                        onRemove={() => onDocumentRemove(doc.id)}
                        onRetry={() => onDocumentRetry(doc.id)}
                      />
                    );
                  })}
                </div>
              )}
            </div>

            {/* Scroll Indicator */}
            {showScrollIndicator && (
              <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-background to-transparent pointer-events-none flex items-end justify-center pb-2">
                <div className="animate-bounce">
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                    <ArrowDown className="h-4 w-4 text-primary" />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Fixed Footer with Section Progress */}
          <div className="border-t bg-background p-4 shrink-0">
            {(() => {
              const progress = getCurrentSectionProgress();
              const currentSectionComplete = progress.filled === progress.total;
              const isLastSection = activeSection === 'documents';
              const allComplete = completedSections === totalSections;
              
              return (
                <div className="space-y-3">
                  {/* Progress Info */}
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">
                      {sections.find(s => s.id === activeSection)?.label}
                    </span>
                    <span className="font-medium">
                      {progress.filled}/{progress.total} {currentSectionComplete ? '✓' : ''}
                    </span>
                  </div>
                  
                  {/* Progress Bar */}
                  <Progress value={(progress.filled / progress.total) * 100} className="h-1.5" />
                  
                  {/* Action Buttons */}
                  {allComplete ? (
                    <Button onClick={handleSave} className="w-full gap-2">
                      <Check className="h-4 w-4" />
                      Salvar 2º Locatário
                    </Button>
                  ) : currentSectionComplete && !isLastSection ? (
                    <Button onClick={goToNextSection} className="w-full">
                      Próxima seção →
                    </Button>
                  ) : (
                    <p className="text-sm text-muted-foreground text-center">
                      {progress.nextEmpty 
                        ? `Preencha: ${progress.nextEmpty}` 
                        : 'Continue preenchendo os campos acima ↑'}
                    </p>
                  )}
                </div>
              );
            })()}
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}
