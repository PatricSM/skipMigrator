import { useState, useEffect, useRef, useCallback } from "react";
import { Loader2, AlertTriangle, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { DocumentUpload, DocFileEntry } from "@/components/rental/DocumentUpload";
import { DOCUMENT_LIMITS, DOC_TYPE_LABELS, DOC_MICROCOPY, REQUIRED_DOC_TYPES } from "@/types/documentLimits";
import { Button } from "@/components/ui/button";
import { logger } from "@/lib/logger";
import { validateFileUpload } from "@/lib/fileValidation";

export interface TenantDocumentsUploaderProps {
  identifier: string;
  identifierType: 'property_code' | 'rental_id';
  onDocFilesChange?: (files: DocFileEntry[]) => void;
  onRentalResolved?: (rentalId: string | null, isResolving: boolean) => void;
  initialDocFiles?: DocFileEntry[];
  autoCreateDraft?: boolean;
  draftMeta?: {
    propertyAddress?: string;
    proposalType?: string;
    proposedValue?: number | null;
  };
  errors?: Record<string, string>;
  compact?: boolean;
}

const DOC_TYPES = ['identity', 'income', 'residence', 'other'] as const;
const INIT_TIMEOUT_MS = 10000;
const UPLOAD_TIMEOUT_MS = 25000;

export function TenantDocumentsUploader({
  identifier,
  identifierType,
  onDocFilesChange,
  onRentalResolved,
  initialDocFiles,
  autoCreateDraft = false,
  draftMeta,
  errors,
  compact = true,
}: TenantDocumentsUploaderProps) {
  const { user } = useAuth();
  const { toast } = useToast();

  const [docFiles, setDocFiles] = useState<DocFileEntry[]>(initialDocFiles || []);
  const [isResolvingRental, setIsResolvingRental] = useState(true);
  const [initError, setInitError] = useState<string | null>(null);
  const [isBatchUploading, setIsBatchUploading] = useState(false);
  const [batchProgress, setBatchProgress] = useState<{ done: number; total: number; failed: number } | null>(null);
  const rentalIdRef = useRef<string | null>(null);
  const [rentalId, setRentalId] = useState<string | null>(null);
  const draftCreatedRef = useRef(false);
  const initStartedRef = useRef(false);
  const isBatchUploadingRef = useRef(false);
  const batchLockRef = useRef(false);

  // Track previous missing state for transition detection
  const prevMissingRef = useRef<boolean | null>(null);

  // Notify parent of docFiles changes
  useEffect(() => {
    onDocFilesChange?.(docFiles);
  }, [docFiles, onDocFilesChange]);

  // Notify parent of rental resolution
  useEffect(() => {
    onRentalResolved?.(rentalId, isResolvingRental);
  }, [rentalId, isResolvingRental, onRentalResolved]);

  // Debounced sync of pending state to DB — prevents rapid updates causing flicker
  const syncTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (!rentalId || isResolvingRental) return;
    if (isBatchUploadingRef.current) return;

    const uploadedCount = docFiles.filter(f => f.status === 'uploaded').length;
    if (uploadedCount === 0 && prevMissingRef.current === null) return;

    // Debounce: wait 500ms after last docFiles change before syncing
    if (syncTimeoutRef.current) clearTimeout(syncTimeoutRef.current);
    syncTimeoutRef.current = setTimeout(() => {
      const missingTypes = REQUIRED_DOC_TYPES.filter(
        type => !docFiles.some(f => f.type === type && f.status === 'uploaded')
      );
      const hasMissing = missingTypes.length > 0;

      const wasHavingMissing = prevMissingRef.current;
      prevMissingRef.current = hasMissing;

      const updateData = hasMissing
        ? {
            has_pending: true,
            pending_documents: missingTypes,
            pending_reason: 'Documentos faltando',
            pending_description: `Faltam: ${missingTypes.map(t => DOC_TYPE_LABELS[t]?.label || t).join(', ')}`,
          }
        : {
            has_pending: false,
            pending_documents: [] as string[],
            pending_reason: null as string | null,
            pending_description: null as string | null,
          };

      supabase
        .from('rentals')
        .update(updateData)
        .eq('id', rentalId)
        .then(({ error }) => {
          if (error) console.warn('[DOCS_SYNC] failed to update pending state:', error);
        });

      if (wasHavingMissing === true && !hasMissing) {
        console.log('[DOCS_SYNC] documents_completed transition detected');
        supabase.from('rental_events').insert({
          rental_id: rentalId,
          event_type: 'documents_completed',
          description: 'Documentos obrigatórios enviados (RG/CPF, Renda e Residência).',
        }).then(({ error }) => {
          if (error) console.warn('[DOCS_SYNC] failed to insert documents_completed event:', error);
        });
      }
    }, 500);

    return () => {
      if (syncTimeoutRef.current) clearTimeout(syncTimeoutRef.current);
    };
  }, [docFiles, rentalId, isResolvingRental]);

  // Sync initial doc files from parent
  useEffect(() => {
    if (initialDocFiles && initialDocFiles.length > 0) {
      setDocFiles(initialDocFiles);
    }
  }, [initialDocFiles]);

  // Fetch documents from DB (called once after batch or on init)
  const fetchDocuments = useCallback(async (reason: string) => {
    const rid = rentalIdRef.current;
    if (!rid || !user) return;
    console.log('[DOCS] fetchDocuments called', { reason, rentalId: rid });
    try {
      const { data: existingDocs } = await supabase
        .from('documents')
        .select('id, document_type, file_name, file_path, document_label')
        .eq('rental_id', rid)
        .eq('user_id', user.id);

      if (existingDocs) {
        console.log('[DOCS] documents fetched', { rentalId: rid, count: existingDocs.length });
        const entries: DocFileEntry[] = existingDocs.map(d => ({
          id: d.id,
          type: d.document_type,
          status: 'uploaded' as const,
          fileName: d.file_name,
          fileUrl: d.file_path,
          documentLabel: d.document_label || undefined,
        }));
        setDocFiles(entries);
      } else {
        console.log('[DOCS] documents fetched', { rentalId: rid, count: 0 });
      }
    } catch (e) {
      console.error('[DOCS] fetchDocuments error:', e);
    }
  }, [user]);

  // Resolve rentalId with timeout safety
  useEffect(() => {
    if (initStartedRef.current) return;
    initStartedRef.current = true;

    let timeoutId: ReturnType<typeof setTimeout> | null = null;
    let cancelled = false;

    const resolve = async () => {
      console.log('[DOCS_INIT] start', { identifier, identifierType });

      if (!identifier || !user) {
        console.log('[DOCS_INIT] end — no identifier or user');
        setIsResolvingRental(false);
        return;
      }

      setIsResolvingRental(true);
      setInitError(null);

      timeoutId = setTimeout(() => {
        if (!cancelled) {
          console.warn('[DOCS_INIT] timeout after', INIT_TIMEOUT_MS, 'ms');
          setIsResolvingRental(false);
          setInitError('timeout');
        }
      }, INIT_TIMEOUT_MS);

      try {
        let rental: { id: string } | null = null;

        if (identifierType === 'rental_id') {
          const { data } = await supabase
            .from('rentals')
            .select('id')
            .eq('id', identifier)
            .eq('user_id', user.id)
            .maybeSingle();
          rental = data;
        } else {
          const { data: byCode } = await supabase
            .from('rentals')
            .select('id')
            .eq('property_code', identifier)
            .eq('user_id', user.id)
            .order('created_at', { ascending: false })
            .limit(1)
            .maybeSingle();

          if (byCode) {
            rental = byCode;
          } else {
            const { data: byProtocol } = await supabase
              .from('rentals')
              .select('id')
              .like('protocol', `${identifier}%`)
              .eq('user_id', user.id)
              .order('created_at', { ascending: false })
              .limit(1)
              .maybeSingle();
            rental = byProtocol;
          }
        }

        if (cancelled) return;

        if (rental) {
          console.log('[DOCS] resolved rentalId', { rentalId: rental.id, propertyCode: identifier, identifierType });
          rentalIdRef.current = rental.id;
          setRentalId(rental.id);
          await fetchDocuments('init');
        } else {
          console.log('[DOCS] resolved rentalId', { rentalId: null, propertyCode: identifier, identifierType, note: 'no existing rental' });
        }
      } catch (e) {
        console.error('[DOCS_INIT] error:', e);
        if (!cancelled) {
          setInitError(e instanceof Error ? e.message : 'Erro ao carregar proposta');
        }
      } finally {
        if (!cancelled) {
          if (timeoutId) clearTimeout(timeoutId);
          setIsResolvingRental(false);
          console.log('[DOCS_INIT] end, rentalId:', rentalIdRef.current);
        }
      }
    };

    resolve();

    return () => {
      cancelled = true;
      if (timeoutId) clearTimeout(timeoutId);
    };
  }, [identifier, identifierType, user, fetchDocuments]);

  // Ensure rental exists (create draft if needed)
  const ensureRentalId = useCallback(async (): Promise<string | null> => {
    if (rentalIdRef.current) return rentalIdRef.current;
    if (!autoCreateDraft || !user?.id || !identifier) return null;
    if (draftCreatedRef.current) return null;

    draftCreatedRef.current = true;
    console.log('[DOCS] ensureRentalId: checking DB before creating draft', { identifier, identifierType });

    try {
      // ALWAYS re-check DB to prevent duplicate drafts
      let existingRental: { id: string } | null = null;

      if (identifierType === 'rental_id') {
        const { data } = await supabase
          .from('rentals')
          .select('id')
          .eq('id', identifier)
          .eq('user_id', user.id)
          .maybeSingle();
        existingRental = data;
      } else {
        // Search by property_code first
        const { data: byCode } = await supabase
          .from('rentals')
          .select('id')
          .eq('property_code', identifier)
          .eq('user_id', user.id)
          .order('created_at', { ascending: false })
          .limit(1)
          .maybeSingle();

        if (byCode) {
          existingRental = byCode;
        } else {
          // Fallback: search by protocol prefix
          const { data: byProtocol } = await supabase
            .from('rentals')
            .select('id')
            .like('protocol', `${identifier}%`)
            .eq('user_id', user.id)
            .order('created_at', { ascending: false })
            .limit(1)
            .maybeSingle();
          existingRental = byProtocol;
        }
      }

      if (existingRental) {
        console.log('[DOCS] draft reused', { action: 'reused', rentalId: existingRental.id });
        rentalIdRef.current = existingRental.id;
        setRentalId(existingRental.id);
        await fetchDocuments('draft_reused');
        return existingRental.id;
      }

      // No existing rental found — create draft
      console.log('[DOCS] draft creating new', { action: 'created', identifier });

      const now = new Date();
      const day = now.getDate().toString().padStart(2, '0');
      const month = (now.getMonth() + 1).toString().padStart(2, '0');
      const year = now.getFullYear().toString().slice(-2);
      const timestamp = Date.now().toString(36).toUpperCase();
      const protocol = `${identifier.toUpperCase()}-${day}${month}${year}-${timestamp}`;

      const { data: created, error } = await supabase
        .from('rentals')
        .insert({
          user_id: user.id,
          property_id: identifier,
          property_code: identifier,
          property_address: draftMeta?.propertyAddress || identifier,
          protocol,
          current_step: 1,
          step_status: 'in_progress',
          tenant_status: 'draft',
          admin_stage: 1,
          has_pending: false,
          pending_documents: [],
          proposal_type: draftMeta?.proposalType || 'standard',
          proposed_value: draftMeta?.proposedValue ?? null,
        })
        .select('id')
        .maybeSingle();

      if (error || !created) {
        console.error('[DOCS] draft status: error', error);
        toast({
          title: "Aviso",
          description: "Não foi possível criar a proposta automaticamente. Tente novamente.",
          variant: "destructive",
        });
        draftCreatedRef.current = false;
        return null;
      }

      console.log('[DOCS] draft reused', { action: 'created', rentalId: created.id });
      rentalIdRef.current = created.id;
      setRentalId(created.id);
      return created.id;
    } catch (e) {
      console.error('[DOCS] draft status: exception', e);
      draftCreatedRef.current = false;
      return null;
    }
  }, [user, identifier, identifierType, autoCreateDraft, draftMeta, toast, fetchDocuments]);

  // ========== Single file upload (with timeout) ==========
  const uploadSingleFile = async (
    file: File,
    docType: string,
    currentRentalId: string,
    tempId: string,
    documentLabel?: string
  ): Promise<{ ok: boolean; path?: string; dbId?: string }> => {
    const uploadPromise = async () => {
      // Validate
      const validation = await validateFileUpload(file);
      if (!validation.valid) throw new Error(validation.error || 'Arquivo inválido');

      // Sanitize file name
      const sanitizedName = file.name
        .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-zA-Z0-9._-]/g, '_')
        .replace(/_+/g, '_')
        .toLowerCase();

      const uuid = crypto.randomUUID();
      const basePath = `rentals/${currentRentalId}/${docType}`;
      const fileName = `${basePath}/${uuid}-${sanitizedName}`;

      // Upload to storage
      const { error: uploadError, data } = await supabase.storage
        .from('documents')
        .upload(fileName, file, { cacheControl: '3600', upsert: false });

      if (uploadError) throw uploadError;

      // Insert DB row
      console.log('[RLS_CHECK] Attempting document insert for rentalId:', currentRentalId, 'userId:', user!.id);
      const insertPayload = {
        user_id: user!.id,
        rental_id: currentRentalId,
        document_type: docType,
        file_name: file.name,
        file_path: data.path,
        file_type: file.type,
        status: 'pending',
        document_label: documentLabel ?? null,
      };

      const { error: dbError, data: dbRow } = await supabase
        .from('documents')
        .insert(insertPayload)
        .select('id')
        .maybeSingle();

      if (dbError) {
        await supabase.storage.from('documents').remove([fileName]);
        throw dbError;
      }

      return { ok: true, path: data.path, dbId: dbRow?.id };
    };

    // Race with timeout
    const timeoutPromise = new Promise<never>((_, reject) =>
      setTimeout(() => reject(new Error('Upload expirou (timeout)')), UPLOAD_TIMEOUT_MS)
    );

    return Promise.race([uploadPromise(), timeoutPromise]);
  };

  // ========== Batch Upload Controller ==========
  const handleDocUpload = async (docType: string, files: File[], documentLabel?: string) => {
    // Anti-reentry lock
    if (batchLockRef.current) {
      console.log('[BATCH] prevented reentry');
      return;
    }

    if (!user?.id) {
      toast({ title: "Sessão expirada", description: "Faça login novamente.", variant: "destructive" });
      return;
    }

    if (isResolvingRental) {
      toast({ title: "Aguarde", description: "Carregando sua proposta…" });
      return;
    }

    // Ensure rental exists (once, before batch)
    const currentRentalId = rentalIdRef.current || await ensureRentalId();
    if (!currentRentalId) {
      toast({
        title: "Erro ao preparar proposta",
        description: "Não foi possível identificar sua proposta. Recarregue a página.",
        variant: "destructive",
      });
      return;
    }

    // Check limits
    const currentCount = docFiles.filter(
      f => f.type === docType && (f.status === 'uploaded' || f.status === 'uploading')
    ).length;
    const limit = DOCUMENT_LIMITS[docType] ?? 1;
    const remaining = limit - currentCount;

    if (remaining <= 0) {
      toast({
        title: "Limite atingido",
        description: `Você atingiu o limite de ${limit} arquivo(s) para este documento.`,
        variant: "destructive",
      });
      return;
    }

    const filesToUpload = files.slice(0, remaining);
    if (filesToUpload.length < files.length) {
      toast({
        title: "Limite parcial",
        description: `Selecionou ${files.length}, mas o limite é ${limit}. Enviando ${filesToUpload.length}.`,
      });
    }

    // Create temp entries optimistically
    const tempEntries: { tempId: string; file: File }[] = filesToUpload.map(file => ({
      tempId: crypto.randomUUID(),
      file,
    }));

    setDocFiles(prev => [
      ...prev,
      ...tempEntries.map(({ tempId, file }) => ({
        id: tempId,
        type: docType,
        status: 'uploading' as const,
        fileName: file.name,
        documentLabel,
        progress: 0,
      })),
    ]);

    // Acquire lock and start batch
    batchLockRef.current = true;
    console.log('[BATCH] start', { count: filesToUpload.length, documentType: docType });
    setIsBatchUploading(true);
    isBatchUploadingRef.current = true;
    setBatchProgress({ done: 0, total: filesToUpload.length, failed: 0 });

    try {
      // Process all files in parallel — no counters inside callbacks
      const results = await Promise.allSettled(
        tempEntries.map(async ({ tempId, file }) => {
          const result = await uploadSingleFile(file, docType, currentRentalId, tempId, documentLabel);
          // Update entry to uploaded (only final state, no intermediate progress)
          setDocFiles(prev => prev.map(f =>
            f.id === tempId
              ? { ...f, id: result.dbId || tempId, status: 'uploaded' as const, progress: 100, fileUrl: result.path }
              : f
          ));
          return { tempId, file, result };
        })
      );

      // Count results safely AFTER allSettled
      let okCount = 0;
      let failCount = 0;
      results.forEach((r, idx) => {
        if (r.status === 'fulfilled') {
          okCount++;
        } else {
          failCount++;
          const { tempId } = tempEntries[idx];
          setDocFiles(prev => prev.map(f =>
            f.id === tempId
              ? { ...f, status: 'error' as const, errorMessage: r.reason instanceof Error ? r.reason.message : 'Erro ao enviar' }
              : f
          ));
        }
      });

      console.log('[BATCH] results', { okCount, failCount });
      setBatchProgress({ done: okCount + failCount, total: filesToUpload.length, failed: failCount });

      if (failCount > 0) {
        toast({
          title: "Upload parcial",
          description: `${okCount} enviado(s), ${failCount} com falha.`,
          variant: "destructive",
        });
      }
    } finally {
      console.log('[BATCH] end');

      // Single refetch at end of batch
      await fetchDocuments('batch_end');

      isBatchUploadingRef.current = false;
      setIsBatchUploading(false);
      setBatchProgress(null);
      batchLockRef.current = false;
    }
  };

  // Remove handler
  const handleDocRemove = async (fileId: string) => {
    const file = docFiles.find(f => f.id === fileId);
    if (!file || !user) return;

    if (file.fileUrl) {
      try {
        await supabase.storage.from('documents').remove([file.fileUrl]);
        await supabase.from('documents').delete().eq('file_path', file.fileUrl).eq('user_id', user.id);
      } catch (error) {
        logger.error('Error removing document:', error);
      }
    }

    setDocFiles(prev => prev.filter(f => f.id !== fileId));
  };

  // Retry handler
  const handleDocRetry = (fileId: string) => {
    setDocFiles(prev => prev.filter(f => f.id !== fileId));
  };

  const handleReload = () => {
    window.location.reload();
  };

  // Render
  return (
    <div className="space-y-4">
      {/* Batch progress indicator */}
      {isBatchUploading && batchProgress && (
        <div className="flex items-center gap-2 rounded-lg bg-primary/10 px-3 py-2 text-sm text-primary">
          <Loader2 className="h-4 w-4 animate-spin shrink-0" />
          <span>
            Enviando arquivos: {batchProgress.done}/{batchProgress.total}
            {batchProgress.failed > 0 && ` (${batchProgress.failed} com falha)`}
          </span>
        </div>
      )}

      {/* Loading state */}
      {isResolvingRental && (
        <div className="flex flex-col items-center gap-3 py-8">
          <Loader2 className="h-6 w-6 animate-spin text-primary" />
          <p className="text-sm text-muted-foreground">Carregando sua proposta…</p>
        </div>
      )}

      {/* Error state with reload button */}
      {!isResolvingRental && initError && (
        <div className="flex flex-col items-center gap-3 py-8 text-center">
          <AlertTriangle className="h-6 w-6 text-destructive" />
          <p className="text-sm text-destructive font-medium">
            {initError === 'timeout'
              ? 'Não foi possível carregar. A conexão demorou muito.'
              : 'Erro ao carregar sua proposta.'}
          </p>
          <Button variant="outline" size="sm" onClick={handleReload} className="gap-2">
            <RefreshCw className="h-4 w-4" />
            Recarregar
          </Button>
        </div>
      )}

      {/* No rental found */}
      {!isResolvingRental && !initError && !rentalId && !autoCreateDraft && (
        <div className="flex flex-col items-center gap-3 py-8 text-center">
          <AlertTriangle className="h-4 w-4 text-destructive" />
          <p className="text-sm text-destructive">Proposta não identificada.</p>
          <Button variant="outline" size="sm" onClick={handleReload} className="gap-2">
            <RefreshCw className="h-4 w-4" />
            Recarregar
          </Button>
        </div>
      )}

      {/* Document upload fields */}
      {!isResolvingRental && !initError && (rentalId || autoCreateDraft) && (
        <>
          {DOC_TYPES.map((docType) => {
            const info = DOC_TYPE_LABELS[docType];
            return (
              <DocumentUpload
                key={docType}
                docType={docType}
                label={info.label}
                description={info.description}
                microcopy={DOC_MICROCOPY[docType] || undefined}
                files={docFiles.filter(f => f.type === docType)}
                maxFiles={DOCUMENT_LIMITS[docType]}
                onUpload={(files, label) => handleDocUpload(docType, files, label)}
                onRemove={(fileId) => handleDocRemove(fileId)}
                onRetry={(fileId) => handleDocRetry(fileId)}
                hasError={!!errors?.[docType]}
                showLabelInput={docType === 'other'}
                compact={compact}
              />
            );
          })}
        </>
      )}
    </div>
  );
}

/** Helper: check if all required doc types have at least one uploaded file */
export function areRequiredDocsComplete(docFiles: DocFileEntry[]): boolean {
  return REQUIRED_DOC_TYPES.every(type =>
    docFiles.some(f => f.type === type && f.status === 'uploaded')
  );
}
