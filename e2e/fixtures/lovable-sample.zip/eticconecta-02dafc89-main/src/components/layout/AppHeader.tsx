import { Link, useNavigate, useLocation } from "react-router-dom";
import { Menu, ChevronLeft, Search, FileText, Building, Plus, LogOut, LogIn, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useState } from "react";
import logoEticBlue from "@/assets/logo-etic-blue.png";
import { useAuth } from "@/hooks/useAuth";

interface AppHeaderProps {
  showBack?: boolean;
  backLabel?: string;
  onBack?: () => void;
}

export function AppHeader({ showBack = true, backLabel = "Voltar", onBack }: AppHeaderProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, profile, logout, isAdmin } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);

  const handleBack = () => {
    if (onBack) {
      onBack();
    } else {
      navigate(-1);
    }
  };

  const menuItems = [
    { href: "/locatario/selecionar-imovel", label: "Buscar Imóveis", icon: Search },
    { href: "/locatario/painel", label: "Minhas Propostas", icon: FileText },
    { href: "/locador/auth", label: "Sou Locador", icon: Building },
    { href: "/anunciar-imovel", label: "Anunciar Imóvel", icon: Plus },
  ];

  return (
    <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-14">
          {/* Logo */}
          <Link to="/locatario" className="flex items-center gap-2">
            <img 
              src={logoEticBlue} 
              alt="Etic Imóveis" 
              className="w-8 h-8 rounded-full object-cover"
            />
            <span className="font-bold text-lg hidden sm:inline">Etic Imóveis</span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-4">
            <Link to="/locatario/selecionar-imovel" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Buscar
            </Link>
            <Link to="/locatario/painel" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Propostas
            </Link>
            <Link to="/locador/auth" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Sou Locador
            </Link>
            {isAdmin && (
              <Link to="/admin" className="text-sm text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1">
                <Shield className="h-3.5 w-3.5" />
                Admin
              </Link>
            )}
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-2">
            {/* Auth indicator - desktop */}
            <div className="hidden md:flex items-center gap-2">
              {user ? (
                <>
                  <span className="text-sm text-muted-foreground">
                    Olá, {profile?.full_name?.split(' ')[0] || user.email}
                  </span>
                  <Button variant="ghost" size="sm" onClick={() => logout()}>
                    <LogOut className="mr-1 h-4 w-4" />
                    Sair
                  </Button>
                </>
              ) : (
                <Button variant="outline" size="sm" asChild>
                  <Link to={`/locatario/login?redirect=${encodeURIComponent(location.pathname + location.search)}`}>
                    <LogIn className="mr-1 h-4 w-4" />
                    Entrar
                  </Link>
                </Button>
              )}
            </div>

            {/* Mobile Menu */}
            <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-64">
                <div className="flex items-center gap-2 mb-6">
                  <img 
                    src={logoEticBlue} 
                    alt="Etic Imóveis" 
                    className="w-8 h-8 rounded-full object-cover"
                  />
                  <span className="font-bold text-lg">Etic Imóveis</span>
                </div>

                {/* Auth block - mobile */}
                <div className="mb-4 px-3 py-2 border-b">
                  {user ? (
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium truncate">
                        Olá, {profile?.full_name?.split(' ')[0] || user.email}
                      </span>
                      <Button variant="ghost" size="sm" onClick={() => { setMenuOpen(false); logout(); }}>
                        <LogOut className="h-4 w-4" />
                      </Button>
                    </div>
                  ) : (
                    <Link
                      to={`/locatario/login?redirect=${encodeURIComponent(location.pathname + location.search)}`}
                      className="flex items-center gap-2 text-sm font-medium text-primary"
                      onClick={() => setMenuOpen(false)}
                    >
                      <LogIn className="h-4 w-4" />
                      Entrar na conta
                    </Link>
                  )}
                </div>

                <nav className="flex flex-col gap-2">
                  {menuItems.map((item) => (
                    <Link
                      key={item.href}
                      to={item.href}
                      className="flex items-center gap-3 px-3 py-2 text-foreground hover:bg-muted rounded-lg transition-colors"
                      onClick={() => setMenuOpen(false)}
                    >
                      <item.icon className="h-5 w-5" />
                      {item.label}
                    </Link>
                  ))}
                  {isAdmin && (
                    <Link
                      to="/admin"
                      className="flex items-center gap-3 px-3 py-2 text-foreground hover:bg-muted rounded-lg transition-colors"
                      onClick={() => setMenuOpen(false)}
                    >
                      <Shield className="h-5 w-5" />
                      Painel Admin
                    </Link>
                  )}
                </nav>
              </SheetContent>
            </Sheet>

            {/* Back Button */}
            {showBack && (
              <Button variant="ghost" size="sm" onClick={handleBack}>
                <ChevronLeft className="mr-1 h-4 w-4" />
                <span className="hidden sm:inline">{backLabel}</span>
              </Button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
