import * as React from "react";
import * as SliderPrimitive from "@radix-ui/react-slider";
import { cn } from "@/lib/utils";
import { Input } from "@/components/ui/input";

interface RangeSliderProps {
  min: number;
  max: number;
  step?: number;
  value: [number, number];
  onValueChange: (value: [number, number]) => void;
  formatValue?: (value: number) => string;
  formatLabel?: (value: number, isMax?: boolean) => string;
  parseValue?: (value: string) => number;
  label?: string;
  className?: string;
}

export function RangeSlider({
  min,
  max,
  step = 100,
  value,
  onValueChange,
  formatValue = (v) => `R$ ${v.toLocaleString("pt-BR")}`,
  formatLabel,
  parseValue = (v) => {
    const num = parseInt(v.replace(/\D/g, ""), 10);
    return isNaN(num) ? 0 : num;
  },
  label,
  className,
}: RangeSliderProps) {
  const [localMin, setLocalMin] = React.useState(formatValue(value[0]));
  const [localMax, setLocalMax] = React.useState(formatValue(value[1]));
  const [minFocused, setMinFocused] = React.useState(false);
  const [maxFocused, setMaxFocused] = React.useState(false);

  // Sync local state only when NOT focused (prevents overwriting during typing)
  React.useEffect(() => {
    if (!minFocused) {
      setLocalMin(formatValue(value[0]));
    }
  }, [value[0], formatValue, minFocused]);

  React.useEffect(() => {
    if (!maxFocused) {
      setLocalMax(formatValue(value[1]));
    }
  }, [value[1], formatValue, maxFocused]);

  const handleMinInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setLocalMin(e.target.value);
  };

  const handleMaxInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setLocalMax(e.target.value);
  };

  const handleMinBlur = () => {
    const parsed = parseValue(localMin);
    const newMin = Math.max(min, Math.min(parsed, value[1]));
    onValueChange([newMin, value[1]]);
    setLocalMin(formatValue(newMin));
  };

  const handleMaxBlur = () => {
    const parsed = parseValue(localMax);
    const newMax = Math.min(max, Math.max(parsed, value[0]));
    onValueChange([value[0], newMax]);
    setLocalMax(formatValue(newMax));
  };

  const handleKeyDown = (e: React.KeyboardEvent, type: "min" | "max") => {
    if (e.key === "Enter") {
      if (type === "min") handleMinBlur();
      else handleMaxBlur();
    }
  };

  // Use formatLabel for slider labels, fallback to formatValue
  const getLabelText = (val: number, isMax?: boolean) => {
    if (formatLabel) return formatLabel(val, isMax);
    return formatValue(val);
  };

  return (
    <div className={cn("space-y-3", className)}>
      {label && (
        <label className="text-sm font-medium text-foreground">{label}</label>
      )}
      
      {/* Input fields */}
      <div className="flex items-center gap-2">
        <Input
          type="text"
          value={localMin}
          onChange={handleMinInputChange}
          onFocus={() => setMinFocused(true)}
          onBlur={() => {
            setMinFocused(false);
            handleMinBlur();
          }}
          onKeyDown={(e) => handleKeyDown(e, "min")}
          className="h-9 text-sm"
          aria-label="Valor mínimo"
        />
        <span className="text-muted-foreground text-sm">até</span>
        <Input
          type="text"
          value={localMax}
          onChange={handleMaxInputChange}
          onFocus={() => setMaxFocused(true)}
          onBlur={() => {
            setMaxFocused(false);
            handleMaxBlur();
          }}
          onKeyDown={(e) => handleKeyDown(e, "max")}
          className="h-9 text-sm"
          aria-label="Valor máximo"
        />
      </div>

      {/* Slider */}
      <SliderPrimitive.Root
        className="relative flex w-full touch-none select-none items-center"
        min={min}
        max={max}
        step={step}
        value={value}
        onValueChange={(newValue) => onValueChange(newValue as [number, number])}
      >
        <SliderPrimitive.Track className="relative h-2 w-full grow overflow-hidden rounded-full bg-secondary">
          <SliderPrimitive.Range className="absolute h-full bg-primary" />
        </SliderPrimitive.Track>
        <SliderPrimitive.Thumb className="block h-5 w-5 rounded-full border-2 border-primary bg-background ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 cursor-grab active:cursor-grabbing" />
        <SliderPrimitive.Thumb className="block h-5 w-5 rounded-full border-2 border-primary bg-background ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 cursor-grab active:cursor-grabbing" />
      </SliderPrimitive.Root>

      {/* Min/Max labels */}
      <div className="flex justify-between text-xs text-muted-foreground">
        <span>{getLabelText(min)}</span>
        <span>{getLabelText(max, true)}</span>
      </div>
    </div>
  );
}
