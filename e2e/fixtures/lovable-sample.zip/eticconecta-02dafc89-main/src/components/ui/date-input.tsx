import * as React from "react";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

interface DateInputProps extends Omit<React.ComponentProps<"input">, "onChange" | "value"> {
  value?: string;
  onChange?: (value: string) => void;
}

function maskDate(value: string): string {
  const digits = value.replace(/\D/g, '').slice(0, 8);
  
  if (digits.length <= 2) return digits;
  if (digits.length <= 4) return `${digits.slice(0, 2)}/${digits.slice(2)}`;
  return `${digits.slice(0, 2)}/${digits.slice(2, 4)}/${digits.slice(4)}`;
}

function parseToISO(value: string): string {
  const digits = value.replace(/\D/g, '');
  if (digits.length !== 8) return '';
  
  const day = digits.slice(0, 2);
  const month = digits.slice(2, 4);
  const year = digits.slice(4, 8);
  
  // Validate date
  const dayNum = parseInt(day, 10);
  const monthNum = parseInt(month, 10);
  const yearNum = parseInt(year, 10);
  
  if (monthNum < 1 || monthNum > 12) return '';
  if (dayNum < 1 || dayNum > 31) return '';
  if (yearNum < 1900 || yearNum > 2100) return '';
  
  // Create date and check if it's valid
  const date = new Date(yearNum, monthNum - 1, dayNum);
  if (date.getDate() !== dayNum || date.getMonth() !== monthNum - 1) return '';
  
  return `${year}-${month}-${day}`;
}

function formatFromISO(isoDate: string): string {
  if (!isoDate) return '';
  
  const parts = isoDate.split('-');
  if (parts.length !== 3) return '';
  
  const [year, month, day] = parts;
  return `${day}/${month}/${year}`;
}

const DateInput = React.forwardRef<HTMLInputElement, DateInputProps>(
  ({ className, value, onChange, placeholder = "DD/MM/AAAA", ...props }, ref) => {
    const [displayValue, setDisplayValue] = React.useState(() => formatFromISO(value || ''));

    React.useEffect(() => {
      setDisplayValue(formatFromISO(value || ''));
    }, [value]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const masked = maskDate(e.target.value);
      setDisplayValue(masked);
      
      // If complete date, convert to ISO
      if (masked.length === 10) {
        const isoDate = parseToISO(masked);
        if (isoDate && onChange) {
          onChange(isoDate);
        }
      } else if (onChange && !masked) {
        onChange('');
      }
    };

    const handleBlur = (e: React.FocusEvent<HTMLInputElement>) => {
      // On blur, validate the date
      if (displayValue && displayValue.length === 10) {
        const isoDate = parseToISO(displayValue);
        if (!isoDate) {
          // Invalid date, clear or show error
          setDisplayValue('');
          if (onChange) onChange('');
        }
      }
      props.onBlur?.(e);
    };

    return (
      <Input
        ref={ref}
        type="text"
        inputMode="numeric"
        placeholder={placeholder}
        value={displayValue}
        onChange={handleChange}
        onBlur={handleBlur}
        maxLength={10}
        className={cn(className)}
        {...props}
      />
    );
  }
);

DateInput.displayName = "DateInput";

export { DateInput };
