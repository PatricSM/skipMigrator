import { useState, useCallback, memo } from 'react';
import { cn } from '@/lib/utils';

interface OptimizedImageProps {
  src: string;
  alt: string;
  width?: number;
  height?: number;
  className?: string;
  priority?: boolean;
  fallbackSrc?: string;
  aspectRatio?: '16/9' | '4/3' | '1/1' | '3/2' | 'auto';
  objectFit?: 'cover' | 'contain' | 'fill' | 'none';
  placeholderColor?: string;
}

/**
 * Optimized image component for LCP < 2.5s and CLS < 0.1
 * Features:
 * - Explicit dimensions to prevent layout shift
 * - Native lazy loading
 * - Placeholder during load
 * - Error fallback
 * - Priority loading for hero images
 */
export const OptimizedImage = memo(function OptimizedImage({
  src,
  alt,
  width,
  height,
  className,
  priority = false,
  fallbackSrc = 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=400&h=300&fit=crop',
  aspectRatio = 'auto',
  objectFit = 'cover',
  placeholderColor = 'hsl(var(--muted))',
}: OptimizedImageProps) {
  const [isLoaded, setIsLoaded] = useState(false);
  const [hasError, setHasError] = useState(false);

  const handleLoad = useCallback(() => {
    setIsLoaded(true);
  }, []);

  const handleError = useCallback(() => {
    setHasError(true);
  }, []);

  const imageSrc = hasError ? fallbackSrc : src;

  const aspectRatioClass = {
    '16/9': 'aspect-video',
    '4/3': 'aspect-[4/3]',
    '1/1': 'aspect-square',
    '3/2': 'aspect-[3/2]',
    'auto': '',
  }[aspectRatio];

  const objectFitClass = {
    'cover': 'object-cover',
    'contain': 'object-contain',
    'fill': 'object-fill',
    'none': 'object-none',
  }[objectFit];

  return (
    <div
      className={cn('relative overflow-hidden', aspectRatioClass, className)}
      style={{
        backgroundColor: !isLoaded ? placeholderColor : undefined,
        width: width ? `${width}px` : undefined,
        height: height ? `${height}px` : undefined,
      }}
    >
      <img
        src={imageSrc}
        alt={alt}
        width={width}
        height={height}
        loading={priority ? 'eager' : 'lazy'}
        decoding={priority ? 'sync' : 'async'}
        fetchPriority={priority ? 'high' : 'auto'}
        onLoad={handleLoad}
        onError={handleError}
        className={cn(
          'w-full h-full transition-opacity duration-300',
          objectFitClass,
          isLoaded ? 'opacity-100' : 'opacity-0'
        )}
      />
      {!isLoaded && !hasError && (
        <div
          className="absolute inset-0 animate-pulse"
          style={{ backgroundColor: placeholderColor }}
          aria-hidden="true"
        />
      )}
    </div>
  );
});
