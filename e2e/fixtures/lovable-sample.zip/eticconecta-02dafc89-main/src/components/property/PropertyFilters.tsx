import { Bed, Car, SlidersHorizontal, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { RangeSlider } from "@/components/ui/range-slider";
import { cn } from "@/lib/utils";
import { useIsMobile } from "@/hooks/use-mobile";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { useState } from "react";
import { Badge } from "@/components/ui/badge";

interface PropertyFiltersProps {
  bedrooms: number | null;
  onBedroomsChange: (value: number | null) => void;
  parkingSpaces: number | null;
  onParkingSpacesChange: (value: number | null) => void;
  priceRange: [number, number];
  onPriceRangeChange: (value: [number, number]) => void;
  minPropertyPrice: number;
  maxPropertyPrice: number;
  onClearFilters: () => void;
}

const bedroomOptions = [
  { value: null, label: "Todos" },
  { value: 1, label: "1+" },
  { value: 2, label: "2+" },
  { value: 3, label: "3+" },
  { value: 4, label: "4+" },
];

const parkingOptions = [
  { value: null, label: "Todas" },
  { value: 1, label: "1+" },
  { value: 2, label: "2+" },
  { value: 3, label: "3+" },
];

function FilterButton({
  selected,
  onClick,
  children,
}: {
  selected: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "px-3 py-1.5 text-sm rounded-md border transition-colors",
        selected
          ? "bg-primary text-primary-foreground border-primary"
          : "bg-background border-input hover:bg-accent hover:text-accent-foreground"
      )}
    >
      {children}
    </button>
  );
}

function FiltersContent({
  bedrooms,
  onBedroomsChange,
  parkingSpaces,
  onParkingSpacesChange,
  priceRange,
  onPriceRangeChange,
  minPropertyPrice,
  maxPropertyPrice,
  onClearFilters,
  isMobile,
}: PropertyFiltersProps & { isMobile?: boolean }) {
  const hasFilters =
    bedrooms !== null ||
    parkingSpaces !== null ||
    priceRange[0] > minPropertyPrice ||
    priceRange[1] < maxPropertyPrice;

  const formatPriceLabel = (value: number, isMax?: boolean) => {
    if (isMax && value >= maxPropertyPrice) {
      return `R$ ${value.toLocaleString("pt-BR")}+`;
    }
    return `R$ ${value.toLocaleString("pt-BR")}`;
  };

  return (
    <div className={cn("space-y-6", isMobile && "py-4")}>
      {/* Bedrooms */}
      <div className="space-y-2">
        <div className="flex items-center gap-2 text-sm font-medium">
          <Bed className="h-4 w-4" />
          Dormitórios
        </div>
        <div className="flex flex-wrap gap-2">
          {bedroomOptions.map((opt) => (
            <FilterButton
              key={opt.label}
              selected={bedrooms === opt.value}
              onClick={() => onBedroomsChange(opt.value)}
            >
              {opt.label}
            </FilterButton>
          ))}
        </div>
      </div>

      {/* Parking */}
      <div className="space-y-2">
        <div className="flex items-center gap-2 text-sm font-medium">
          <Car className="h-4 w-4" />
          Vagas
        </div>
        <div className="flex flex-wrap gap-2">
          {parkingOptions.map((opt) => (
            <FilterButton
              key={opt.label}
              selected={parkingSpaces === opt.value}
              onClick={() => onParkingSpacesChange(opt.value)}
            >
              {opt.label}
            </FilterButton>
          ))}
        </div>
      </div>

      {/* Price Range */}
      <div className="space-y-2">
        <RangeSlider
          label="Valor do Aluguel"
          min={minPropertyPrice}
          max={maxPropertyPrice}
          step={100}
          value={priceRange}
          onValueChange={onPriceRangeChange}
          formatLabel={formatPriceLabel}
        />
      </div>

      {/* Clear button */}
      {hasFilters && (
        <Button variant="outline" size="sm" onClick={onClearFilters} className="w-full">
          <X className="h-4 w-4 mr-2" />
          Limpar filtros avançados
        </Button>
      )}
    </div>
  );
}

export function PropertyFilters(props: PropertyFiltersProps) {
  const isMobile = useIsMobile();
  const [isOpen, setIsOpen] = useState(false);
  const [isExpanded, setIsExpanded] = useState(true);

  const {
    bedrooms,
    parkingSpaces,
    priceRange,
    minPropertyPrice,
    maxPropertyPrice,
  } = props;

  const activeFilterCount = [
    bedrooms !== null,
    parkingSpaces !== null,
    priceRange[0] > minPropertyPrice || priceRange[1] < maxPropertyPrice,
  ].filter(Boolean).length;

  const formatPriceLabel = (value: number, isMax?: boolean) => {
    if (isMax && value >= maxPropertyPrice) {
      return `R$ ${value.toLocaleString("pt-BR")}+`;
    }
    return `R$ ${value.toLocaleString("pt-BR")}`;
  };

  // Mobile: Sheet
  if (isMobile) {
    return (
      <div className="mb-4">
        <Sheet open={isOpen} onOpenChange={setIsOpen}>
          <SheetTrigger asChild>
            <Button variant="outline" className="w-full">
              <SlidersHorizontal className="h-4 w-4 mr-2" />
              Filtros avançados
              {activeFilterCount > 0 && (
                <Badge variant="secondary" className="ml-2">
                  {activeFilterCount}
                </Badge>
              )}
            </Button>
          </SheetTrigger>
          <SheetContent side="bottom" className="h-[80vh]">
            <SheetHeader>
              <SheetTitle>Filtros avançados</SheetTitle>
            </SheetHeader>
            <FiltersContent {...props} isMobile />
          </SheetContent>
        </Sheet>
      </div>
    );
  }

  // Desktop: Collapsible
  return (
    <Collapsible open={isExpanded} onOpenChange={setIsExpanded} className="mb-6">
      <div className="flex items-center justify-between">
        <CollapsibleTrigger asChild>
          <Button variant="ghost" size="sm" className="gap-2">
            <SlidersHorizontal className="h-4 w-4" />
            Filtros avançados
            {activeFilterCount > 0 && (
              <Badge variant="secondary">{activeFilterCount}</Badge>
            )}
          </Button>
        </CollapsibleTrigger>
        {activeFilterCount > 0 && (
          <Button variant="ghost" size="sm" onClick={props.onClearFilters}>
            Limpar
          </Button>
        )}
      </div>
      <CollapsibleContent className="pt-4">
        <div className="rounded-lg border bg-card p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Bedrooms */}
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm font-medium">
                <Bed className="h-4 w-4" />
                Dormitórios
              </div>
              <div className="flex flex-wrap gap-2">
                {bedroomOptions.map((opt) => (
                  <FilterButton
                    key={opt.label}
                    selected={bedrooms === opt.value}
                    onClick={() => props.onBedroomsChange(opt.value)}
                  >
                    {opt.label}
                  </FilterButton>
                ))}
              </div>
            </div>

            {/* Parking */}
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm font-medium">
                <Car className="h-4 w-4" />
                Vagas
              </div>
              <div className="flex flex-wrap gap-2">
                {parkingOptions.map((opt) => (
                  <FilterButton
                    key={opt.label}
                    selected={parkingSpaces === opt.value}
                    onClick={() => props.onParkingSpacesChange(opt.value)}
                  >
                    {opt.label}
                  </FilterButton>
                ))}
              </div>
            </div>

            {/* Price Range */}
            <div>
              <RangeSlider
                label="Valor do Aluguel"
                min={minPropertyPrice}
                max={maxPropertyPrice}
                step={100}
                value={priceRange}
                onValueChange={props.onPriceRangeChange}
                formatLabel={formatPriceLabel}
              />
            </div>
          </div>
        </div>
      </CollapsibleContent>
    </Collapsible>
  );
}
