import { useState, memo, useCallback } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

interface PropertyImageCarouselProps {
  images: string[];
  alt: string;
  code?: string;
  price?: string;
}

const FALLBACK_IMAGE = "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=400&h=300&fit=crop";
const MIN_SWIPE_DISTANCE = 50;

function PropertyImageCarouselComponent({ 
  images, 
  alt,
  code,
  price
}: PropertyImageCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [imageStates, setImageStates] = useState<Map<number, 'loading' | 'loaded' | 'error'>>(
    () => new Map([[0, 'loading']])
  );
  
  // Touch/Swipe state
  const [touchStart, setTouchStart] = useState<number | null>(null);
  const [touchEnd, setTouchEnd] = useState<number | null>(null);

  const validImages = images.filter(Boolean);
  
  // Use fallback if no valid images
  if (validImages.length === 0) {
    validImages.push(FALLBACK_IMAGE);
  }

  const handleImageLoad = useCallback((index: number) => {
    setImageStates(prev => new Map(prev).set(index, 'loaded'));
  }, []);

  const handleImageError = useCallback((index: number) => {
    setImageStates(prev => new Map(prev).set(index, 'error'));
  }, []);

  const navigateToIndex = useCallback((index: number) => {
    setCurrentIndex(index);
    setImageStates(prev => {
      if (!prev.has(index)) {
        return new Map(prev).set(index, 'loading');
      }
      return prev;
    });
  }, []);

  const goNext = useCallback((e?: React.MouseEvent) => {
    e?.stopPropagation();
    const nextIndex = (currentIndex + 1) % validImages.length;
    navigateToIndex(nextIndex);
  }, [currentIndex, validImages.length, navigateToIndex]);

  const goPrev = useCallback((e?: React.MouseEvent) => {
    e?.stopPropagation();
    const prevIndex = (currentIndex - 1 + validImages.length) % validImages.length;
    navigateToIndex(prevIndex);
  }, [currentIndex, validImages.length, navigateToIndex]);

  const goToIndex = useCallback((e: React.MouseEvent, index: number) => {
    e.stopPropagation();
    navigateToIndex(index);
  }, [navigateToIndex]);

  // Touch handlers for swipe
  const onTouchStart = useCallback((e: React.TouchEvent) => {
    setTouchEnd(null);
    setTouchStart(e.targetTouches[0].clientX);
  }, []);

  const onTouchMove = useCallback((e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  }, []);

  const onTouchEnd = useCallback(() => {
    if (!touchStart || !touchEnd) return;
    
    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > MIN_SWIPE_DISTANCE;
    const isRightSwipe = distance < -MIN_SWIPE_DISTANCE;
    
    if (isLeftSwipe && validImages.length > 1) {
      goNext();
    }
    if (isRightSwipe && validImages.length > 1) {
      goPrev();
    }
    
    // Reset touch state
    setTouchStart(null);
    setTouchEnd(null);
  }, [touchStart, touchEnd, validImages.length, goNext, goPrev]);

  return (
    <div 
      className="relative w-full h-full group touch-pan-y"
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
    >
      {/* Images Stack */}
      {validImages.map((src, idx) => {
        const state = imageStates.get(idx);
        const isVisible = idx === currentIndex;
        const shouldLoad = idx === 0 || idx === currentIndex || imageStates.has(idx);

        return (
          <div
            key={idx}
            className={cn(
              "absolute inset-0 transition-opacity duration-300",
              isVisible ? "opacity-100 z-10" : "opacity-0 z-0"
            )}
          >
            {shouldLoad && (
              <img
                src={state === 'error' ? FALLBACK_IMAGE : src}
                alt={`${alt} - foto ${idx + 1}`}
                width={400}
                height={300}
                loading={idx === 0 ? "eager" : "lazy"}
                decoding="async"
                onLoad={() => handleImageLoad(idx)}
                onError={() => handleImageError(idx)}
                className={cn(
                  "w-full h-full object-cover transition-opacity duration-200 group-hover:scale-105",
                  state === 'loaded' ? "opacity-100" : "opacity-0"
                )}
              />
            )}
            {state !== 'loaded' && (
              <div className="absolute inset-0 bg-muted animate-pulse" />
            )}
          </div>
        );
      })}

      {/* Navigation Arrows - ALWAYS visible on mobile, hover on desktop */}
      {validImages.length > 1 && (
        <>
          <button
            type="button"
            onClick={goPrev}
            className="absolute left-2 top-1/2 -translate-y-1/2 z-20
                       opacity-70 md:opacity-0 md:group-hover:opacity-100 
                       bg-black/50 hover:bg-black/70 active:bg-black/80 text-white 
                       rounded-full p-1.5 transition-all duration-200
                       focus:opacity-100 focus:outline-none focus:ring-2 focus:ring-white"
            aria-label="Foto anterior"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={goNext}
            className="absolute right-2 top-1/2 -translate-y-1/2 z-20
                       opacity-70 md:opacity-0 md:group-hover:opacity-100 
                       bg-black/50 hover:bg-black/70 active:bg-black/80 text-white 
                       rounded-full p-1.5 transition-all duration-200
                       focus:opacity-100 focus:outline-none focus:ring-2 focus:ring-white"
            aria-label="Próxima foto"
          >
            <ChevronRight className="h-4 w-4" />
          </button>
        </>
      )}

      {/* Dots Indicator - only show if multiple images */}
      {validImages.length > 1 && (
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-20 flex gap-1.5">
          {validImages.map((_, idx) => (
            <button
              key={idx}
              type="button"
              onClick={(e) => goToIndex(e, idx)}
              className={cn(
                "w-2 h-2 rounded-full transition-all duration-200",
                idx === currentIndex
                  ? "bg-white scale-110 shadow-sm"
                  : "bg-white/50 hover:bg-white/75"
              )}
              aria-label={`Ver foto ${idx + 1}`}
            />
          ))}
        </div>
      )}

      {/* Code Badge - top left */}
      {code && (
        <div className="absolute top-3 left-3 z-20 bg-background/90 backdrop-blur-sm px-2 py-1 rounded-md text-xs font-medium">
          {code}
        </div>
      )}

      {/* Price Badge - bottom right */}
      {price && (
        <div className="absolute bottom-3 right-3 z-20 bg-primary text-primary-foreground px-3 py-1 rounded-md text-sm font-bold">
          {price}
        </div>
      )}
    </div>
  );
}

export const PropertyImageCarousel = memo(PropertyImageCarouselComponent);