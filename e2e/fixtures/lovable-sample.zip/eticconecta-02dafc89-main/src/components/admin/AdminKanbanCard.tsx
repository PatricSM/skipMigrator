import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { AdminRentalWithProfile } from "@/hooks/useAdminRentals";
import { formatSlaFromDays, getStageSlaLevel } from "./adminSla";

export function AdminKanbanCard({
  rental,
  onClick,
  onOpenProperty,
}: {
  rental: AdminRentalWithProfile;
  onClick: () => void;
  onOpenProperty: () => void;
}) {
  const tenantName = rental.tenant?.full_name ?? "Locatário";
  const email = rental.tenant?.email ?? "";
  const phone = rental.tenant?.phone ?? "";
  const propertyLabel = rental.property?.short_address ?? rental.property_address;

  const { level, days } = getStageSlaLevel(rental.admin_stage_entered_at);
  const slaLabel = formatSlaFromDays(days);

  const slaClass =
    level === "ok"
      ? "bg-sla-ok/10 text-sla-ok border-sla-ok/20"
      : level === "warning"
        ? "bg-sla-warning/10 text-sla-warning border-sla-warning/20"
        : "bg-sla-breach/10 text-sla-breach border-sla-breach/20";

  return (
    <div onClick={onClick} className="cursor-pointer">
      <Card className="hover:shadow-md transition-shadow border-l-4 border-l-primary/50">
        <CardContent className="p-4 space-y-3">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0 flex-1">
              <p className="font-medium truncate">{tenantName}</p>
              <p className="text-xs text-muted-foreground truncate">{email}</p>
              <p className="text-xs text-muted-foreground truncate">{phone}</p>
            </div>
            <Badge variant="outline" className={slaClass}>
              {slaLabel}
            </Badge>
          </div>

          <div className="space-y-1">
            <button
              type="button"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                onOpenProperty();
              }}
              className="font-medium underline underline-offset-4 text-foreground/90 hover:text-foreground text-left text-sm"
              title="Abrir detalhes do imóvel"
            >
              {propertyLabel}
            </button>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <Badge variant="secondary" className="text-xs">
              {rental.protocol}
            </Badge>
            <span className="text-xs text-muted-foreground">{rental.property_code}</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
