import { Droppable, Draggable } from "@hello-pangea/dnd";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import type { AdminRentalWithProfile } from "@/hooks/useAdminRentals";
import { stageBadgeClass } from "@/hooks/useAdminPipelineStages";
import { AdminKanbanCard } from "./AdminKanbanCard";

export function AdminKanbanColumn({
  stageId,
  stageName,
  stageOrder,
  stageColorKey,
  rentals,
  onCardClick,
  onOpenProperty,
}: {
  stageId: string;
  stageName: string;
  stageOrder: number;
  stageColorKey?: string;
  rentals: AdminRentalWithProfile[];
  onCardClick: (r: AdminRentalWithProfile) => void;
  onOpenProperty: (r: AdminRentalWithProfile) => void;
}) {
  const stagePill = stageBadgeClass(stageColorKey);

  return (
    <div className="flex-shrink-0 w-[320px] bg-muted/30 rounded-lg overflow-hidden flex flex-col max-h-[calc(100vh-220px)]">
      <div className="p-4 border-b bg-background/50">
        <div className="flex items-center justify-between gap-2">
          <div className="min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <Badge variant="outline" className={stagePill}>
                Etapa {stageOrder}
              </Badge>
              <h3 className="font-semibold truncate">{stageName}</h3>
            </div>
            <p className="text-xs text-muted-foreground">Arraste e solte para atualizar</p>
          </div>
          <Badge variant="secondary" className="shrink-0">
            {rentals.length}
          </Badge>
        </div>
      </div>

      <Droppable droppableId={stageId}>
        {(provided, snapshot) => (
          <div
            ref={provided.innerRef}
            {...provided.droppableProps}
            className={`flex-1 min-h-0 transition-colors ${
              snapshot.isDraggingOver ? "bg-primary/5" : ""
            }`}
          >
            <ScrollArea className="h-full">
              <div className="p-3 space-y-3">
                {rentals.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground text-sm">
                    Etapa vazia
                  </div>
                ) : (
                  rentals.map((r, index) => (
                    <Draggable key={r.id} draggableId={r.id} index={index}>
                      {(dragProvided) => (
                        <div
                          ref={dragProvided.innerRef}
                          {...dragProvided.draggableProps}
                          {...dragProvided.dragHandleProps}
                        >
                          <AdminKanbanCard
                            rental={r}
                            onClick={() => onCardClick(r)}
                            onOpenProperty={() => onOpenProperty(r)}
                          />
                        </div>
                      )}
                    </Draggable>
                  ))
                )}
                {provided.placeholder}
              </div>
            </ScrollArea>
          </div>
        )}
      </Droppable>
    </div>
  );
}
