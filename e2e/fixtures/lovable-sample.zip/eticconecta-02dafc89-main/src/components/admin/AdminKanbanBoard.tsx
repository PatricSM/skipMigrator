import { useCallback, useEffect, useMemo, useState } from "react";
import { DragDropContext, type DropResult } from "@hello-pangea/dnd";
import type { AdminRentalWithProfile } from "@/hooks/useAdminRentals";
import type { AdminPipelineStage } from "@/hooks/useAdminPipelineStages";
import { AdminKanbanColumn } from "./AdminKanbanColumn";
import { toast } from "sonner";

type StageMap = Map<string, AdminRentalWithProfile[]>;

function buildMap(rentals: AdminRentalWithProfile[], stages: AdminPipelineStage[]): StageMap {
  const map = new Map<string, AdminRentalWithProfile[]>();
  stages.forEach((s) => map.set(s.id, []));

  for (const r of rentals) {
    const stageId = r.admin_stage_id ?? null;
    if (stageId && map.has(stageId)) {
      map.get(stageId)!.push(r);
      continue;
    }

    // Fallback: map by legacy admin_stage order_index
    const legacyOrder = Math.min(999, Math.max(1, Number(r.admin_stage ?? 1)));
    const fallbackStage = stages.find((s) => s.order_index === legacyOrder) ?? stages[0];
    if (fallbackStage) map.get(fallbackStage.id)!.push({ ...r, admin_stage_id: fallbackStage.id });
  }

  // keep order stable (latest first)
  for (const key of map.keys()) {
    map.get(key)!.sort((a, b) => (b.created_at ?? "").localeCompare(a.created_at ?? ""));
  }
  return map;
}

export function AdminKanbanBoard({
  rentals,
  stages,
  stageFilterId,
  onCardClick,
  onOpenProperty,
  onMoveStage,
}: {
  rentals: AdminRentalWithProfile[];
  stages: AdminPipelineStage[];
  stageFilterId?: string | null;
  onCardClick: (r: AdminRentalWithProfile) => void;
  onOpenProperty: (r: AdminRentalWithProfile) => void;
  onMoveStage: (rentalId: string, fromStageId: string, toStageId: string) => Promise<void>;
}) {
  const initial = useMemo(() => buildMap(rentals, stages), [rentals, stages]);
  const [map, setMap] = useState<StageMap>(initial);

  useEffect(() => setMap(initial), [initial]);

  const handleDragEnd = useCallback(
    async (result: DropResult) => {
      const { destination, source, draggableId } = result;
      if (!destination) return;

      const from = source.droppableId;
      const to = destination.droppableId;
      if (from === to && destination.index === source.index) return;

      // optimistic update
      const prev = map;
      const next = new Map(prev);
      const fromList = Array.from(next.get(from) ?? []);
      const toList = Array.from(next.get(to) ?? []);

      const moving = fromList.find((r) => r.id === draggableId);
      if (!moving) return;

      const fromIndex = fromList.findIndex((r) => r.id === draggableId);
      fromList.splice(fromIndex, 1);
      const patched = { ...moving, admin_stage_id: to } as AdminRentalWithProfile;
      toList.splice(destination.index, 0, patched);

      next.set(from, fromList);
      next.set(to, toList);
      setMap(next);

      try {
        await onMoveStage(draggableId, from, to);
      } catch (e: any) {
        setMap(prev);
        toast.error(e?.message ?? "Não foi possível mover a ficha");
      }
    },
    [map, onMoveStage]
  );

  const visibleStages = stageFilterId ? stages.filter((s) => s.id === stageFilterId) : stages;

  return (
    <DragDropContext onDragEnd={handleDragEnd}>
      <div className="flex gap-4 overflow-x-auto pb-4 min-h-[400px]">
        {visibleStages.map((s) => (
          <AdminKanbanColumn
            key={s.id}
            stageId={s.id}
            stageName={s.name}
            stageOrder={s.order_index}
            stageColorKey={s.color_key}
            rentals={map.get(s.id) ?? []}
            onCardClick={onCardClick}
            onOpenProperty={onOpenProperty}
          />
        ))}
      </div>
    </DragDropContext>
  );
}
