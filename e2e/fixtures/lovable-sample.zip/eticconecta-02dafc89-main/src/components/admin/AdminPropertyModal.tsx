import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Home } from "lucide-react";
import type { AdminProperty } from "@/hooks/useAdminRentals";

export function AdminPropertyModal({
  open,
  onOpenChange,
  property,
  fallbackAddress,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  property?: AdminProperty;
  fallbackAddress?: string;
}) {
  const title = property?.short_address ?? fallbackAddress ?? "Imóvel";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="w-[96vw] max-w-[96vw] md:max-w-lg">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <Card>
            <CardContent className="p-4">
              {property?.images?.[0] ? (
                <div className="aspect-video w-full rounded-lg overflow-hidden bg-muted mb-4">
                  <img
                    src={property.images[0]}
                    alt={title}
                    className="w-full h-full object-cover"
                  />
                </div>
              ) : (
                <div className="aspect-video w-full rounded-lg overflow-hidden bg-muted mb-4 flex items-center justify-center">
                  <Home className="h-12 w-12 text-muted-foreground" />
                </div>
              )}

              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Badge variant="secondary">
                    Valores
                  </Badge>
                </div>

                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <p className="text-xs text-muted-foreground">Aluguel</p>
                    <p className="font-semibold">
                      {property?.rent_value != null ? `R$ ${property.rent_value.toLocaleString("pt-BR")}` : "—"}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Cond.</p>
                    <p className="font-semibold">
                      {property?.condo_fee != null ? `R$ ${property.condo_fee.toLocaleString("pt-BR")}` : "—"}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">IPTU</p>
                    <p className="font-semibold">
                      {property?.iptu != null ? `R$ ${property.iptu.toLocaleString("pt-BR")}` : "—"}
                    </p>
                  </div>
                </div>

                <Separator />
                <p className="text-sm text-muted-foreground">{fallbackAddress ?? ""}</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
}
