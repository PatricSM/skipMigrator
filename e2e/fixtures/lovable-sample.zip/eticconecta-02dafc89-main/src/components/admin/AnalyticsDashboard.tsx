import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Clock, CheckCircle, XCircle, TrendingUp } from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  Legend,
  PieChart,
  Pie,
  Cell,
} from 'recharts';

export type FunnelDatum = {
  stageId: string;
  label: string;
  count: number;
  percentage: number;
};

export type StageTimeDatum = {
  stageId: string;
  label: string;
  hours: number;
};

export type RejectionDatum = {
  reason: string;
  count: number;
};

export type MonthlyDatum = {
  month: string;
  received: number;
  approved: number;
  rejected: number;
};

interface AnalyticsDashboardProps {
  counts: {
    received: number;
    analysis: number;
    approved: number;
    rejected: number;
  };
  funnelData: FunnelDatum[];
  stageTimeData: StageTimeDatum[];
  rejectionData: RejectionDatum[];
  monthlyData: MonthlyDatum[];
  onKpiClick?: (key: "received" | "analysis" | "approved" | "rejected") => void;
  onStageClick?: (stageId: string) => void;
  onRejectionClick?: (reason: string) => void;
}

const REJECTION_COLORS = [
  "hsl(var(--chart-c1))",
  "hsl(var(--chart-c2))",
  "hsl(var(--chart-c3))",
  "hsl(var(--chart-c4))",
  "hsl(var(--chart-c5))",
  "hsl(var(--destructive))",
];

export function AnalyticsDashboard({
  counts,
  funnelData,
  stageTimeData,
  rejectionData,
  monthlyData,
  onKpiClick,
  onStageClick,
  onRejectionClick,
}: AnalyticsDashboardProps) {
  const total = counts.received + counts.analysis + counts.approved + counts.rejected;

  return (
    <div className="space-y-6">
      {/* Métricas Gerais */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <Button
              variant="ghost"
              className="w-full h-full p-0 hover:bg-transparent"
              onClick={() => onKpiClick?.("received")}
              disabled={!onKpiClick}
            >
              <div className="flex items-center gap-3 w-full">
                <div className="p-2 rounded-lg bg-primary/10">
                  <FileText className="h-5 w-5 text-primary" />
                </div>
                <div className="text-left">
                  <p className="text-sm text-muted-foreground">Fichas</p>
                  <p className="text-2xl font-bold">{counts.received}</p>
                </div>
              </div>
            </Button>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <Button
              variant="ghost"
              className="w-full h-full p-0 hover:bg-transparent"
              onClick={() => onKpiClick?.("analysis")}
              disabled={!onKpiClick}
            >
              <div className="flex items-center gap-3 w-full">
                <div className="p-2 rounded-lg bg-sla-warning/10">
                  <Clock className="h-5 w-5 text-sla-warning" />
                </div>
                <div className="text-left">
                  <p className="text-sm text-muted-foreground">Em andamento</p>
                  <p className="text-2xl font-bold">{counts.analysis}</p>
                </div>
              </div>
            </Button>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <Button
              variant="ghost"
              className="w-full h-full p-0 hover:bg-transparent"
              onClick={() => onKpiClick?.("approved")}
              disabled={!onKpiClick}
            >
              <div className="flex items-center gap-3 w-full">
                <div className="p-2 rounded-lg bg-sla-ok/10">
                  <CheckCircle className="h-5 w-5 text-sla-ok" />
                </div>
                <div className="text-left">
                  <p className="text-sm text-muted-foreground">Concluídas</p>
                  <p className="text-2xl font-bold">{counts.approved}</p>
                </div>
              </div>
            </Button>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <Button
              variant="ghost"
              className="w-full h-full p-0 hover:bg-transparent"
              onClick={() => onKpiClick?.("rejected")}
              disabled={!onKpiClick}
            >
              <div className="flex items-center gap-3 w-full">
                <div className="p-2 rounded-lg bg-destructive/10">
                  <XCircle className="h-5 w-5 text-destructive" />
                </div>
                <div className="text-left">
                  <p className="text-sm text-muted-foreground">Reprovadas</p>
                  <p className="text-2xl font-bold">{counts.rejected}</p>
                </div>
              </div>
            </Button>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Funil de Vendas */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Funil de Conversão
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {funnelData.map((stage, index) => (
                <Button
                  key={stage.stageId}
                  variant="ghost"
                  className="w-full justify-between p-3 h-auto"
                  onClick={() => onStageClick?.(stage.stageId)}
                  disabled={!onStageClick}
                >
                  <div className="flex items-center justify-between w-full">
                    <span className="font-medium">{stage.label}</span>
                    <span className="text-muted-foreground">
                      {stage.count} ({stage.percentage}%)
                    </span>
                  </div>
                  <div className="w-full mt-2 bg-muted rounded-full h-2 overflow-hidden">
                    <div
                      className="h-full bg-primary transition-all"
                      style={{ width: `${stage.percentage}%` }}
                    />
                  </div>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Tempo Médio por Etapa */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Clock className="h-4 w-4" />
              Tempo Médio por Etapa
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart
                data={stageTimeData}
                layout="vertical"
                onClick={(state) => {
                  const payload = state?.activePayload?.[0]?.payload as StageTimeDatum | undefined;
                  if (payload?.stageId) onStageClick?.(payload.stageId);
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" />
                <YAxis type="category" dataKey="label" width={100} />
                <Tooltip formatter={(value) => [`${value}h`, 'Tempo']} />
                <Bar dataKey="hours" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
            {!stageTimeData.length && (
              <p className="text-sm text-muted-foreground text-center py-4">Sem dados suficientes para cálculo.</p>
            )}
          </CardContent>
        </Card>

        {/* Motivos de Perda */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Motivos de Reprovação</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={rejectionData}
                  dataKey="count"
                  nameKey="reason"
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  label={({ reason, percent }) => `${reason}: ${(percent * 100).toFixed(0)}%`}
                  labelLine={false}
                >
                  {rejectionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={REJECTION_COLORS[index % REJECTION_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            {onRejectionClick && rejectionData.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-4">
                {rejectionData.slice(0, 6).map((r) => (
                  <Button key={r.reason} variant="outline" size="sm" onClick={() => onRejectionClick(r.reason)}>
                    {r.reason}
                  </Button>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Conversão Mensal */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Evolução Mensal</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="received" name="Recebidas" stroke="hsl(var(--primary))" />
                <Line type="monotone" dataKey="approved" name="Aprovadas" stroke="hsl(var(--sla-ok))" />
                <Line type="monotone" dataKey="rejected" name="Reprovadas" stroke="hsl(var(--destructive))" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
