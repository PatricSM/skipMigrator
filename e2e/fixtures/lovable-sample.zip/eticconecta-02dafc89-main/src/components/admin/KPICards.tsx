import { KanbanStatus } from '@/types/admin';
import { Card, CardContent } from '@/components/ui/card';
import { FileText, Clock, CheckCircle, XCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

interface KPICardsProps {
  counts: {
    received: number;
    analysis: number;
    approved: number;
    rejected: number;
  };
  activeFilter: KanbanStatus | 'all';
  onFilterChange: (filter: KanbanStatus | 'all') => void;
}

const kpis = [
  {
    id: 'received' as const,
    label: 'Novos Documentos',
    icon: FileText,
    colorClass: 'text-blue-600',
    bgClass: 'bg-blue-50 hover:bg-blue-100',
    borderClass: 'border-blue-200',
    activeBgClass: 'bg-blue-600',
    activeTextClass: 'text-white',
  },
  {
    id: 'analysis' as const,
    label: 'Em Análise',
    icon: Clock,
    colorClass: 'text-yellow-600',
    bgClass: 'bg-yellow-50 hover:bg-yellow-100',
    borderClass: 'border-yellow-200',
    activeBgClass: 'bg-yellow-500',
    activeTextClass: 'text-white',
  },
  {
    id: 'approved' as const,
    label: 'Aprovadas',
    icon: CheckCircle,
    colorClass: 'text-green-600',
    bgClass: 'bg-green-50 hover:bg-green-100',
    borderClass: 'border-green-200',
    activeBgClass: 'bg-green-600',
    activeTextClass: 'text-white',
  },
  {
    id: 'rejected' as const,
    label: 'Reprovadas',
    icon: XCircle,
    colorClass: 'text-red-600',
    bgClass: 'bg-red-50 hover:bg-red-100',
    borderClass: 'border-red-200',
    activeBgClass: 'bg-red-600',
    activeTextClass: 'text-white',
  },
];

export function KPICards({ counts, activeFilter, onFilterChange }: KPICardsProps) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {kpis.map((kpi) => {
        const Icon = kpi.icon;
        const isActive = activeFilter === kpi.id;
        const count = counts[kpi.id];
        
        return (
          <Card
            key={kpi.id}
            className={cn(
              'cursor-pointer transition-all duration-200 border-2',
              isActive
                ? `${kpi.activeBgClass} ${kpi.activeTextClass} border-transparent shadow-lg`
                : `${kpi.bgClass} ${kpi.borderClass} hover:shadow-md`
            )}
            onClick={() => onFilterChange(isActive ? 'all' : kpi.id)}
          >
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={cn(
                    'p-2 rounded-lg',
                    isActive ? 'bg-white/20' : 'bg-white'
                  )}>
                    <Icon className={cn(
                      'h-5 w-5',
                      isActive ? kpi.activeTextClass : kpi.colorClass
                    )} />
                  </div>
                  <div>
                    <p className={cn(
                      'text-sm font-medium',
                      isActive ? kpi.activeTextClass : 'text-muted-foreground'
                    )}>
                      {kpi.label}
                    </p>
                    <p className={cn(
                      'text-2xl font-bold',
                      isActive ? kpi.activeTextClass : 'text-foreground'
                    )}>
                      {count}
                    </p>
                  </div>
                </div>
              </div>
              {isActive && (
                <p className={cn(
                  'text-xs mt-2',
                  kpi.activeTextClass,
                  'opacity-80'
                )}>
                  Clique para ver todas
                </p>
              )}
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
