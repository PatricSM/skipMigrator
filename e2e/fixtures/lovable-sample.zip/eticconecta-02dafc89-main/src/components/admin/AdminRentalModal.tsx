import * as React from "react";
import { useEffect, useMemo, useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import type { AdminRentalWithProfile, AdminStage } from "@/hooks/useAdminRentals";
import { ADMIN_STAGES, getAdminStageLabel } from "./AdminStageConfig";
import { CheckCircle2, FileText, XCircle, Home, Building2, FileImage, File, ExternalLink } from "lucide-react";
import { AdminRentalHistoryCard, type AdminRentalEvent } from "./AdminRentalHistoryCard";
import { rejectionReasonLabels, type RejectionReason } from "@/types/admin";

type DocRow = {
  id: string;
  file_name: string;
  file_type: string;
  file_path: string;
  document_type?: string;
  status: string;
  created_at: string;
  bucket: "documents" | "landlord-documents";
};

type LandlordDataRow = {
  full_name: string | null;
  email: string | null;
  phone: string | null;
  profession: string | null;
  marital_status: string | null;
  bills_responsible: string | null;
  bank_name: string | null;
  bank_agency: string | null;
  bank_account: string | null;
  bank_account_type: string | null;
  pix_key: string | null;
  has_second_landlord: boolean | null;
  second_landlord_name: string | null;
  second_landlord_email: string | null;
  second_landlord_phone: string | null;
  second_landlord_profession: string | null;
  second_landlord_marital_status: string | null;
};

function formatMoneyBR(value: number | null | undefined) {
  if (value == null) return "—";
  return `R$ ${Number(value).toLocaleString("pt-BR")}`;
}

function buildPropertyExternalUrl(propertyCode?: string | null) {
  const code = (propertyCode ?? "").trim();
  if (!code) return null;
  return `https://www.eticimoveis.com.br/imovel/${encodeURIComponent(code)}`;
}

function FieldRow({ label, value }: { label: string; value?: React.ReactNode }) {
  return (
    <p className="text-sm">
      <span className="text-muted-foreground">{label}:</span> {value ?? "—"}
    </p>
  );
}

function getDocTypeLabel(key?: string) {
  if (!key) return "Outros";
  const MAP: Record<string, string> = {
    identity: "Identidade",
    income: "Renda",
    residence: "Residência",
    marriage_certificate: "Certidão",
    bank_statement: "Extrato bancário",
  };
  return MAP[key] ?? key.split("_").join(" ");
}

async function getSignedUrl(bucket: DocRow["bucket"], path: string) {
  const { data, error } = await supabase.storage.from(bucket).createSignedUrl(path, 60 * 10);
  if (error) throw error;
  const signed = data.signedUrl;
  if (!signed) throw new Error("URL assinada inválida");
  if (signed.startsWith("http://") || signed.startsWith("https://")) return signed;
  return signed;
}

export function AdminRentalModal({
  rental,
  open,
  onOpenChange,
  onUpdated,
}: {
  rental: AdminRentalWithProfile | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onUpdated: () => void;
}) {
  const [tab, setTab] = useState<"tenant" | "landlord" | "property">("tenant");
  const [tenantDocs, setTenantDocs] = useState<DocRow[]>([]);
  const [landlordDocs, setLandlordDocs] = useState<DocRow[]>([]);
  const [loadingDocs, setLoadingDocs] = useState(false);
  const [updating, setUpdating] = useState(false);
  const [urlCache, setUrlCache] = useState<Record<string, string>>({});
  const [events, setEvents] = useState<AdminRentalEvent[]>([]);
  const [loadingEvents, setLoadingEvents] = useState(false);
  const [landlordData, setLandlordData] = useState<LandlordDataRow | null>(null);

  const [noteText, setNoteText] = useState("");
  const [rejectOpen, setRejectOpen] = useState(false);
  const [rejectReason, setRejectReason] = useState("");
  const [rejectDetails, setRejectDetails] = useState("");

  const stage = useMemo(() => {
    const n = Number(rental?.admin_stage ?? 1);
    return Math.min(7, Math.max(1, n)) as AdminStage;
  }, [rental?.admin_stage]);

  const propertyExternalUrl = useMemo(() => buildPropertyExternalUrl(rental?.property_code), [rental?.property_code]);
  const propertyImage = useMemo(() => rental?.property?.images?.[0] ?? null, [rental?.property?.images]);
  const propertyRent = rental?.property?.rent_value ?? rental?.rent_value;
  const propertyCondo = rental?.property?.condo_fee ?? rental?.condo_fee;
  const propertyIptu = rental?.property?.iptu ?? rental?.iptu;

  const refreshEvents = async () => {
    if (!rental || !open) return;
    setLoadingEvents(true);
    try {
      const { data, error } = await supabase
        .from("rental_events")
        .select("id, event_type, description, created_at, created_by")
        .eq("rental_id", rental.id)
        .order("created_at", { ascending: true });
      if (error) throw error;

      const baseEvents = (data ?? []) as AdminRentalEvent[];
      const authorIds = Array.from(new Set(baseEvents.map((e) => e.created_by).filter(Boolean) as string[]));

      if (authorIds.length) {
        const { data: authors, error: authorsError } = await supabase
          .from("profiles")
          .select("id, full_name, email")
          .in("id", authorIds);
        if (authorsError) throw authorsError;

        const map = new Map<string, { full_name: string | null; email: string | null }>();
        (authors ?? []).forEach((a: any) => map.set(a.id, { full_name: a.full_name ?? null, email: a.email ?? null }));

        setEvents(
          baseEvents.map((e) => {
            const author = e.created_by ? map.get(e.created_by) : undefined;
            return {
              ...e,
              author_name: author?.full_name ?? null,
              author_email: author?.email ?? null,
            };
          })
        );
      } else {
        setEvents(baseEvents);
      }
    } catch (e: any) {
      toast.error(e?.message ?? "Erro ao carregar histórico");
    } finally {
      setLoadingEvents(false);
    }
  };

  useEffect(() => {
    const run = async () => {
      if (!rental || !open) return;
      setLoadingDocs(true);
      try {
        setLandlordData(null);

        let docsData: any[] | null = null;
        const { data: docsByRental, error: docsByRentalError } = await supabase
          .from("documents")
          .select("id, file_name, file_type, file_path, document_type, status, created_at")
          .eq("rental_id", rental.id)
          .order("created_at", { ascending: false });
        if (docsByRentalError) throw docsByRentalError;
        docsData = docsByRental;

        if (!docsData?.length) {
          const { data: docsByUser, error: docsByUserError } = await supabase
            .from("documents")
            .select("id, file_name, file_type, file_path, document_type, status, created_at")
            .eq("user_id", rental.user_id)
            .order("created_at", { ascending: false });
          if (docsByUserError) throw docsByUserError;
          docsData = docsByUser;
        }

        setTenantDocs((docsData ?? []).map((d: any) => ({ ...d, bucket: "documents" })));

        const { data: ldData, error: ldError } = await supabase
          .from("landlord_documents")
          .select("id, file_name, file_type, file_path, document_type, status, created_at")
          .eq("rental_id", rental.id)
          .order("created_at", { ascending: false });
        if (ldError) throw ldError;
        setLandlordDocs(
          (ldData ?? []).map((d: any) => ({
            ...d,
            bucket: "landlord-documents",
          }))
        );

        const { data: landlordDataRow, error: landlordDataError } = await supabase
          .from("landlord_data")
          .select(
            "full_name, email, phone, profession, marital_status, bills_responsible, bank_name, bank_agency, bank_account, bank_account_type, pix_key, has_second_landlord, second_landlord_name, second_landlord_email, second_landlord_phone, second_landlord_profession, second_landlord_marital_status"
          )
          .eq("rental_id", rental.id)
          .maybeSingle();
        if (landlordDataError) throw landlordDataError;
        setLandlordData((landlordDataRow as any) ?? null);
      } catch (e: any) {
        toast.error(e?.message ?? "Erro ao carregar documentos");
      } finally {
        setLoadingDocs(false);
      }
    };

    run();
  }, [open, rental]);

  useEffect(() => {
    refreshEvents();
  }, [open, rental]);

  if (!rental) return null;

  const nextStage = Math.min(7, stage + 1) as AdminStage;
  const stageLabel = getAdminStageLabel(stage);

  const openDoc = async (doc: DocRow) => {
    try {
      const url = urlCache[doc.id] ?? (await getSignedUrl(doc.bucket, doc.file_path));
      setUrlCache((prev) => (prev[doc.id] ? prev : { ...prev, [doc.id]: url }));
      window.open(url, "_blank", "noopener,noreferrer");
    } catch (e: any) {
      toast.error(e?.message ?? "Não foi possível abrir o documento");
    }
  };

  const getUrl = async (doc: DocRow) => {
    if (urlCache[doc.id]) return urlCache[doc.id];
    const url = await getSignedUrl(doc.bucket, doc.file_path);
    setUrlCache((prev) => ({ ...prev, [doc.id]: url }));
    return url;
  };

  const downloadDoc = async (doc: DocRow) => {
    const url = await getUrl(doc);
    const res = await fetch(url);
    if (!res.ok) throw new Error("Falha ao baixar o arquivo");
    const blob = await res.blob();
    const blobUrl = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = blobUrl;
    a.download = doc.file_name || "arquivo";
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(blobUrl);
  };

  const addEvent = async (description: string, event_type: string) => {
    await supabase.from("rental_events").insert({
      rental_id: rental.id,
      description,
      event_type,
    });
  };

  const addNote = async () => {
    const text = noteText.trim();
    if (!text) return;
    setUpdating(true);
    try {
      await addEvent(text, "note");
      setNoteText("");
      toast.success("Nota adicionada");
      await refreshEvents();
      onUpdated();
    } catch (e: any) {
      toast.error(e?.message ?? "Erro ao adicionar nota");
    } finally {
      setUpdating(false);
    }
  };

  const approveStage1 = async () => {
    setUpdating(true);
    try {
      const { error } = await supabase
        .from("rentals")
        .update({ tenant_status: "approved", is_rejected: false, rejection_reason: null, admin_stage: 2 })
        .eq("id", rental.id);
      if (error) throw error;
      await addEvent("Aprovou a ficha (Etapa 1 → Etapa 2)", "approval");
      toast.success("Ficha aprovada");
      await refreshEvents();
      onUpdated();
      onOpenChange(false);
    } catch (e: any) {
      toast.error(e?.message ?? "Erro ao aprovar ficha");
    } finally {
      setUpdating(false);
    }
  };

  const rejectStage1 = async (reason: RejectionReason, details?: string) => {
    setUpdating(true);
    try {
      const label = rejectionReasonLabels[reason];
      const detailsText = (details ?? "").trim();
      const { error } = await supabase
        .from("rentals")
        .update({ tenant_status: "rejected", is_rejected: true, admin_stage: 1, rejection_reason: reason })
        .eq("id", rental.id);
      if (error) throw error;
      await addEvent(
        `Reprovou a ficha — Motivo: ${label}${detailsText ? ` — Detalhes: ${detailsText}` : ""}`,
        "rejection"
      );
      toast.success("Ficha reprovada");
      await refreshEvents();
      onUpdated();
      onOpenChange(false);
    } catch (e: any) {
      toast.error(e?.message ?? "Erro ao reprovar ficha");
    } finally {
      setUpdating(false);
    }
  };

  const advanceStage = async () => {
    if (stage >= 7) return;
    setUpdating(true);
    try {
      const next = ADMIN_STAGES.find((s) => s.id === nextStage);
      const { error } = await supabase.from("rentals").update({ admin_stage: nextStage }).eq("id", rental.id);
      if (error) throw error;
      await addEvent(`Moveu da Etapa ${stage} para ${next?.subtitle ?? `Etapa ${nextStage}`}`, "stage_change");
      toast.success(`Avançado para etapa ${nextStage}`);
      await refreshEvents();
      onUpdated();
      onOpenChange(false);
    } catch (e: any) {
      toast.error(e?.message ?? "Erro ao avançar etapa");
    } finally {
      setUpdating(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="w-[98vw] max-w-[98vw] md:max-w-4xl max-h-[90vh] overflow-hidden flex flex-col p-0">
        <div className="flex-1 overflow-y-auto">
          <DialogHeader className="p-5 pb-0">
            <DialogTitle className="sr-only">Aprovação da ficha</DialogTitle>
            <DialogDescription className="sr-only">Detalhes do imóvel, histórico e documentos para análise.</DialogDescription>

            <div className="space-y-1">
              <div className="flex items-center gap-2 flex-wrap">
                <Badge variant="outline" className="text-xs">
                  {rental.protocol}
                </Badge>
                <Badge variant="secondary" className="text-xs">
                  {stageLabel}
                </Badge>
              </div>
              <h2 className="text-xl font-bold">{rental.tenant?.full_name ?? "Locatário"}</h2>
              <p className="text-sm text-muted-foreground">
                {rental.property_code} • {rental.property_address}
              </p>
            </div>
          </DialogHeader>

          {/* Property Summary */}
          <div className="px-5 py-3">
            <Card>
              <CardContent className="p-4">
                <div className="flex gap-4">
                  <div className="w-24 h-24 rounded-lg overflow-hidden bg-muted shrink-0">
                    {propertyImage ? (
                      propertyExternalUrl ? (
                        <a href={propertyExternalUrl} target="_blank" rel="noopener noreferrer">
                          <img src={propertyImage} alt="Imóvel" className="w-full h-full object-cover" />
                        </a>
                      ) : (
                        <img src={propertyImage} alt="Imóvel" className="w-full h-full object-cover" />
                      )
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <Building2 className="h-8 w-8 text-muted-foreground" />
                      </div>
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <p className="font-medium truncate">{rental.property_address}</p>
                      {propertyExternalUrl && (
                        <a href={propertyExternalUrl} target="_blank" rel="noopener noreferrer" className="text-xs text-primary hover:underline shrink-0 flex items-center gap-1">
                          Ver no site <ExternalLink className="h-3 w-3" />
                        </a>
                      )}
                    </div>
                    <div className="grid grid-cols-3 gap-4 mt-2 text-center">
                      <div>
                        <p className="text-xs text-muted-foreground">Aluguel</p>
                        <p className="font-semibold text-sm">{formatMoneyBR(propertyRent)}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Cond.</p>
                        <p className="font-semibold text-sm">{formatMoneyBR(propertyCondo)}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">IPTU</p>
                        <p className="font-semibold text-sm">{formatMoneyBR(propertyIptu)}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="px-5 pb-5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Left Column - Tabs */}
              <div>
                <Tabs value={tab} onValueChange={(v) => setTab(v as any)} className="flex flex-col">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="tenant">Locatário</TabsTrigger>
                    <TabsTrigger value="landlord">Locador</TabsTrigger>
                    <TabsTrigger value="property">Imóvel</TabsTrigger>
                  </TabsList>

                  <TabsContent value="tenant" className="space-y-4 mt-4">
                    <Card>
                      <CardContent className="p-4 space-y-2">
                        <h4 className="font-semibold">Dados do Locatário</h4>
                        <div className="space-y-1">
                          <FieldRow label="Nome" value={rental.tenant?.full_name} />
                          <FieldRow label="Email" value={rental.tenant?.email} />
                          <FieldRow label="Telefone" value={rental.tenant?.phone} />
                          <FieldRow label="Nascimento" value={rental.tenant?.birth_date} />
                          <FieldRow label="Nacionalidade" value={rental.tenant?.nationality} />
                          <FieldRow label="País" value={rental.tenant?.nationality_country} />
                          <FieldRow label="Estado Civil" value={rental.tenant?.marital_status} />
                          <FieldRow label="Profissão" value={rental.tenant?.profession} />
                          <FieldRow label="Renda" value={rental.tenant?.monthly_income ? formatMoneyBR(rental.tenant.monthly_income) : undefined} />
                          <FieldRow label="PEP" value={rental.tenant?.is_politically_exposed ? "Sim" : "Não"} />
                          <p className="text-xs text-muted-foreground mt-2">CPF: armazenado de forma criptografada (LGPD)</p>
                        </div>
                      </CardContent>
                    </Card>

                    <Accordion type="single" collapsible>
                      <AccordionItem value="docs">
                        <AccordionTrigger>Documentos enviados (Locatário)</AccordionTrigger>
                        <AccordionContent>
                          <DocList loading={loadingDocs} docs={tenantDocs} onOpen={openDoc} getUrl={getUrl} onDownload={downloadDoc} />
                        </AccordionContent>
                      </AccordionItem>
                    </Accordion>
                  </TabsContent>

                  <TabsContent value="landlord" className="space-y-4 mt-4">
                    <Card>
                      <CardContent className="p-4 space-y-2">
                        <h4 className="font-semibold">Dados do Locador</h4>
                        <div className="space-y-1">
                          <FieldRow label="Nome" value={landlordData?.full_name} />
                          <FieldRow label="Email" value={landlordData?.email} />
                          <FieldRow label="Telefone" value={landlordData?.phone} />
                          <FieldRow label="Profissão" value={landlordData?.profession} />
                          <FieldRow label="Estado Civil" value={landlordData?.marital_status} />
                          <FieldRow label="Resp. Contas" value={landlordData?.bills_responsible} />
                        </div>

                        <Separator className="my-3" />
                        <h5 className="font-medium text-sm">Dados bancários</h5>
                        <div className="space-y-1">
                          <FieldRow label="Banco" value={landlordData?.bank_name} />
                          <FieldRow label="Agência" value={landlordData?.bank_agency} />
                          <FieldRow label="Conta" value={landlordData?.bank_account} />
                          <FieldRow label="Tipo" value={landlordData?.bank_account_type} />
                          <FieldRow label="PIX" value={landlordData?.pix_key} />
                        </div>

                        {landlordData?.has_second_landlord && (
                          <>
                            <Separator className="my-3" />
                            <h5 className="font-medium text-sm">2º Locador</h5>
                            <div className="space-y-1">
                              <FieldRow label="Nome" value={landlordData?.second_landlord_name} />
                              <FieldRow label="Email" value={landlordData?.second_landlord_email} />
                              <FieldRow label="Telefone" value={landlordData?.second_landlord_phone} />
                              <FieldRow label="Profissão" value={landlordData?.second_landlord_profession} />
                              <FieldRow label="Estado Civil" value={landlordData?.second_landlord_marital_status} />
                            </div>
                          </>
                        )}
                      </CardContent>
                    </Card>

                    <Accordion type="single" collapsible>
                      <AccordionItem value="docs">
                        <AccordionTrigger>Documentos enviados (Locador)</AccordionTrigger>
                        <AccordionContent>
                          <DocList loading={loadingDocs} docs={landlordDocs} onOpen={openDoc} getUrl={getUrl} onDownload={downloadDoc} />
                        </AccordionContent>
                      </AccordionItem>
                    </Accordion>
                  </TabsContent>

                  <TabsContent value="property" className="space-y-4 mt-4">
                    <Card>
                      <CardContent className="p-4">
                        {propertyImage ? (
                          <div className="aspect-video w-full rounded-lg overflow-hidden bg-muted mb-4">
                            {propertyExternalUrl ? (
                              <a href={propertyExternalUrl} target="_blank" rel="noopener noreferrer">
                                <img src={propertyImage} alt="Imóvel" className="w-full h-full object-cover" />
                              </a>
                            ) : (
                              <img src={propertyImage} alt="Imóvel" className="w-full h-full object-cover" />
                            )}
                          </div>
                        ) : (
                          <div className="aspect-video w-full rounded-lg bg-muted mb-4 flex items-center justify-center">
                            <Home className="h-12 w-12 text-muted-foreground" />
                          </div>
                        )}

                        <div className="space-y-3">
                          <div className="flex items-center gap-2">
                            <Building2 className="h-4 w-4 text-muted-foreground" />
                            <span className="font-medium">Dados do Imóvel</span>
                            {propertyExternalUrl && (
                              <a href={propertyExternalUrl} target="_blank" rel="noopener noreferrer" className="text-xs text-primary hover:underline flex items-center gap-1 ml-auto">
                                Ver no site <ExternalLink className="h-3 w-3" />
                              </a>
                            )}
                          </div>

                          <p className="text-sm">{rental.property_address}</p>

                          <div className="grid grid-cols-3 gap-4 text-center">
                            <div>
                              <p className="text-xs text-muted-foreground">Aluguel</p>
                              <p className="font-semibold">{formatMoneyBR(propertyRent)}</p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">Cond.</p>
                              <p className="font-semibold">{formatMoneyBR(propertyCondo)}</p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">IPTU</p>
                              <p className="font-semibold">{formatMoneyBR(propertyIptu)}</p>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>
                </Tabs>
              </div>

              {/* Right Column - History & Notes */}
              <div className="space-y-4">
                {loadingEvents ? (
                  <Card>
                    <CardContent className="p-4">
                      <p className="text-sm text-muted-foreground">Carregando histórico...</p>
                    </CardContent>
                  </Card>
                ) : (
                  <AdminRentalHistoryCard events={events} />
                )}

                <Card>
                  <CardContent className="p-4 space-y-3">
                    <h4 className="font-semibold">Anotações</h4>
                    <div className="space-y-2">
                      <Label htmlFor="note" className="text-sm text-muted-foreground">
                        Adicione uma nota ao histórico
                      </Label>
                      <Textarea
                        id="note"
                        value={noteText}
                        onChange={(e) => setNoteText(e.target.value)}
                        placeholder="Ex.: Cliente pediu para reenviar comprovante de renda…"
                        className="min-h-24"
                      />
                      <Button onClick={addNote} disabled={updating || !noteText.trim()}>
                        Adicionar nota
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="sticky bottom-0 border-t bg-background p-5 space-y-3 pb-[calc(env(safe-area-inset-bottom)+1.25rem)]">
          <div className="grid grid-cols-2 gap-3">
            <Button
              onClick={() => {
                setRejectOpen(true);
                setRejectReason("");
                setRejectDetails("");
              }}
              variant="destructive"
              disabled={updating}
            >
              <XCircle className="h-4 w-4 mr-2" />
              Reprovar
            </Button>

            {stage === 1 ? (
              <Button onClick={approveStage1} disabled={updating}>
                <CheckCircle2 className="h-4 w-4 mr-2" />
                Aprovar
              </Button>
            ) : (
              <Button onClick={advanceStage} disabled={updating || stage >= 7}>
                <CheckCircle2 className="h-4 w-4 mr-2" />
                Avançar
              </Button>
            )}
          </div>

          <Button variant="outline" className="w-full" onClick={() => onOpenChange(false)} disabled={updating}>
            Fechar
          </Button>
        </div>

        {/* Rejection Dialog */}
        <Dialog open={rejectOpen} onOpenChange={setRejectOpen}>
          <DialogContent className="w-[96vw] max-w-[96vw] md:max-w-lg">
            <DialogHeader>
              <DialogTitle>Reprovar ficha</DialogTitle>
              <DialogDescription>
                Selecione um motivo e descreva os detalhes (obrigatório em "Outros").
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Motivo</Label>
                <Select value={rejectReason} onValueChange={(v) => setRejectReason(v as any)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione um motivo" />
                  </SelectTrigger>
                  <SelectContent>
                    {(Object.keys(rejectionReasonLabels) as RejectionReason[]).map((k) => (
                      <SelectItem key={k} value={k}>
                        {rejectionReasonLabels[k]}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Detalhes</Label>
                <Textarea
                  value={rejectDetails}
                  onChange={(e) => setRejectDetails(e.target.value)}
                  placeholder="Explique o motivo (ex.: renda incompatível, doc ilegível, etc.)"
                  className="min-h-24"
                />
              </div>

              <div className="flex gap-2 justify-end">
                <Button variant="outline" onClick={() => setRejectOpen(false)} disabled={updating}>
                  Cancelar
                </Button>
                <Button
                  variant="destructive"
                  disabled={
                    updating ||
                    !rejectReason ||
                    (rejectReason === "outros" && !rejectDetails.trim())
                  }
                  onClick={async () => {
                    if (!rejectReason) return;
                    await rejectStage1(rejectReason as RejectionReason, rejectDetails);
                  }}
                >
                  Confirmar reprovação
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </DialogContent>
    </Dialog>
  );
}

type DocListProps = {
  loading: boolean;
  docs: DocRow[];
  onOpen: (doc: DocRow) => void;
  getUrl: (doc: DocRow) => Promise<string>;
  onDownload: (doc: DocRow) => Promise<void>;
};

const DocList = React.forwardRef<HTMLDivElement, DocListProps>(function DocList(
  { loading, docs, onOpen, getUrl, onDownload },
  ref
) {
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});
  const [previewUrls, setPreviewUrls] = useState<Record<string, string>>({});

  if (loading) {
    return <p className="text-sm text-muted-foreground">Carregando documentos...</p>;
  }

  if (!docs.length) {
    return (
      <div className="flex h-full items-center justify-center rounded-lg border bg-background p-6 text-center">
        <div>
          <FileText className="h-10 w-10 mx-auto text-muted-foreground" />
          <p className="mt-2 text-sm text-muted-foreground">Nenhum documento enviado.</p>
        </div>
      </div>
    );
  }

  return (
    <div ref={ref} className="space-y-2">
      {docs.map((d) => {
        const isImage = d.file_type?.startsWith("image/");
        const Icon = isImage ? FileImage : d.file_type?.includes("pdf") ? FileText : File;
        const isExpanded = !!expanded[d.id];

        return (
          <Card key={d.id}>
            <CardContent className="p-4">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                <div className="min-w-0 flex-1">
                  <div className="flex items-start gap-2">
                    <Icon className="h-4 w-4 mt-0.5 text-muted-foreground shrink-0" />
                    <div className="min-w-0">
                      <p className="font-medium truncate">{d.file_name}</p>
                      <p className="text-xs text-muted-foreground truncate">
                        {d.document_type ? getDocTypeLabel(d.document_type) : "Documento"} • {new Date(d.created_at).toLocaleString()}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="w-full sm:w-auto">
                  <div className="grid grid-cols-2 gap-2 sm:flex sm:items-center">
                    <Button variant="outline" size="sm" className="w-full sm:w-auto" onClick={() => onOpen(d)}>
                      Abrir
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full sm:w-auto"
                      onClick={async () => {
                        try {
                          await onDownload(d);
                        } catch (e: any) {
                          toast.error(e?.message ?? "Não foi possível baixar o arquivo");
                        }
                      }}
                    >
                      Baixar
                    </Button>
                  </div>
                  {isImage && (
                    <div className="mt-2">
                      <Button
                        variant="secondary"
                        size="sm"
                        className="w-full"
                        onClick={async () => {
                          const next = !isExpanded;
                          setExpanded((prev) => ({ ...prev, [d.id]: next }));
                          if (next && !previewUrls[d.id]) {
                            try {
                              const url = await getUrl(d);
                              setPreviewUrls((prev) => ({ ...prev, [d.id]: url }));
                            } catch (e: any) {
                              toast.error(e?.message ?? "Não foi possível carregar a imagem");
                            }
                          }
                        }}
                      >
                        {isExpanded ? "Ocultar imagem" : "Exibir imagem"}
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>

            {isImage && isExpanded && previewUrls[d.id] && (
              <div className="px-4 pb-4">
                <div className="w-full overflow-hidden rounded-md border bg-background">
                  <img
                    src={previewUrls[d.id]}
                    alt={`Imagem: ${d.file_name}`}
                    className="block w-full h-auto max-h-[50svh] md:max-h-[360px] object-contain"
                    loading="lazy"
                  />
                </div>
              </div>
            )}
          </Card>
        );
      })}
    </div>
  );
});
DocList.displayName = "DocList";
