import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Clock, CheckCircle2, XCircle, MessageSquare, ArrowRight, FileText } from "lucide-react";

export type AdminRentalEvent = {
  id: string;
  event_type: string;
  description: string;
  created_at: string | null;
  created_by?: string | null;
  author_name?: string | null;
  author_email?: string | null;
};

function getEventIcon(eventType: string) {
  switch (eventType) {
    case "approval":
      return <CheckCircle2 className="h-4 w-4 text-sla-ok" />;
    case "rejection":
      return <XCircle className="h-4 w-4 text-destructive" />;
    case "stage_change":
      return <ArrowRight className="h-4 w-4 text-primary" />;
    case "note":
      return <MessageSquare className="h-4 w-4 text-muted-foreground" />;
    case "document":
      return <FileText className="h-4 w-4 text-chart-c4" />;
    default:
      return <Clock className="h-4 w-4 text-muted-foreground" />;
  }
}

function getEventBadgeVariant(eventType: string): "default" | "secondary" | "destructive" | "outline" {
  switch (eventType) {
    case "approval":
      return "default";
    case "rejection":
      return "destructive";
    case "stage_change":
      return "secondary";
    default:
      return "outline";
  }
}

function getEventTypeLabel(eventType: string) {
  switch (eventType) {
    case "approval":
      return "Aprovação";
    case "rejection":
      return "Reprovação";
    case "stage_change":
      return "Mudança de etapa";
    case "note":
      return "Nota";
    case "document":
      return "Documento";
    case "creation":
      return "Criação";
    default:
      return eventType;
  }
}

export function AdminRentalHistoryCard({ events }: { events: AdminRentalEvent[] }) {
  if (!events.length) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Histórico</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">Nenhum evento registrado.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base flex items-center gap-2">
          <Clock className="h-4 w-4" />
          Histórico ({events.length})
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[300px]">
          <div className="space-y-0 divide-y">
            {events.map((event) => (
              <div key={event.id} className="p-4 hover:bg-muted/50 transition-colors">
                <div className="flex items-start gap-3">
                  <div className="mt-0.5">{getEventIcon(event.event_type)}</div>
                  <div className="flex-1 min-w-0 space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <Badge variant={getEventBadgeVariant(event.event_type)} className="text-xs">
                        {getEventTypeLabel(event.event_type)}
                      </Badge>
                      <span className="text-xs text-muted-foreground">
                        {event.created_at
                          ? new Date(event.created_at).toLocaleString("pt-BR", {
                              day: "2-digit",
                              month: "2-digit",
                              year: "numeric",
                              hour: "2-digit",
                              minute: "2-digit",
                            })
                          : "—"}
                      </span>
                    </div>
                    <p className="text-sm">{event.description}</p>
                    {(event.author_name || event.author_email) && (
                      <p className="text-xs text-muted-foreground">
                        por {event.author_name || event.author_email}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
