export type SlaLevel = "ok" | "warning" | "breach";

export function getStageSlaLevel(enteredAt?: string | null): { level: SlaLevel; days: number } {
  if (!enteredAt) return { level: "ok", days: 0 };

  const ms = Date.now() - new Date(enteredAt).getTime();
  const days = Math.max(0, Math.floor(ms / (1000 * 60 * 60 * 24)));

  const level: SlaLevel = days < 2 ? "ok" : days <= 4 ? "warning" : "breach";

  return { level, days };
}

export function formatSlaFromDays(days: number) {
  if (days <= 0) return "Hoje";
  if (days === 1) return "Há 1 dia";
  return `Há ${days} dias`;
}
