import type { AdminStage } from "@/hooks/useAdminRentals";

export const ADMIN_STAGES: { id: AdminStage; title: string; subtitle: string }[] = [
  { id: 1, title: "Etapa 1", subtitle: "Aprovação da ficha" },
  { id: 2, title: "Etapa 2", subtitle: "Receber docs. locador" },
  { id: 3, title: "Etapa 3", subtitle: "Emissão do contrato" },
  { id: 4, title: "Etapa 4", subtitle: "Assinatura do contrato" },
  { id: 5, title: "Etapa 5", subtitle: "Agendamento de vistoria" },
  { id: 6, title: "Etapa 6", subtitle: "Assinatura da vistoria" },
  { id: 7, title: "Etapa 7", subtitle: "Entrega das chaves" },
];

export function getAdminStageLabel(stage: AdminStage) {
  const found = ADMIN_STAGES.find((s) => s.id === stage);
  return found ? `${found.title} — ${found.subtitle}` : `Etapa ${stage}`;
}
