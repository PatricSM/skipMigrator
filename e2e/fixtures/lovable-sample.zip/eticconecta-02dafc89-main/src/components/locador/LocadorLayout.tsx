import { Outlet, Link, useLocation, useNavigate } from "react-router-dom";
import { 
  Home, 
  FileText, 
  Building, 
  HelpCircle, 
  LogOut, 
  Menu, 
  Plus,
  User,
  ChevronLeft
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { useState } from "react";
import { cn } from "@/lib/utils";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
  useSidebar,
} from "@/components/ui/sidebar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { NotificationBell } from "./dashboard/NotificationBell";

const navItems = [
  { href: "/locador/home", label: "Início", icon: Home },
  { href: "/locador/imoveis", label: "Meus Imóveis", icon: Building },
  { href: "/locador/propostas", label: "Propostas", icon: FileText },
  { href: "/locador/anunciar", label: "Anunciar", icon: Plus },
  { href: "/locador/ajuda", label: "Ajuda", icon: HelpCircle },
];

function LocadorSidebar() {
  const location = useLocation();
  const { state } = useSidebar();
  const collapsed = state === "collapsed";

  return (
    <Sidebar 
      className={cn(
        "border-r bg-sidebar transition-all duration-300",
        collapsed ? "w-14" : "w-56"
      )}
      collapsible="icon"
    >
      <div className="p-3 border-b border-sidebar-border">
        <Link to="/locador/home" className="flex items-center gap-2">
          <div className="w-8 h-8 bg-sidebar-primary rounded-lg flex items-center justify-center shrink-0">
            <span className="text-sidebar-primary-foreground font-bold text-sm">E</span>
          </div>
          {!collapsed && (
            <span className="font-bold text-sidebar-foreground">Etic Proprietário</span>
          )}
        </Link>
      </div>

      <SidebarContent className="p-2">
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              {navItems.map((item) => {
                const isActive = location.pathname === item.href;
                return (
                  <SidebarMenuItem key={item.href}>
                    <SidebarMenuButton 
                      asChild
                      isActive={isActive}
                      tooltip={collapsed ? item.label : undefined}
                    >
                      <Link 
                        to={item.href} 
                        className={cn(
                          "flex items-center gap-3 px-3 py-2 rounded-lg transition-colors",
                          isActive 
                            ? "bg-sidebar-accent text-sidebar-accent-foreground" 
                            : "text-sidebar-foreground hover:bg-sidebar-accent/50"
                        )}
                      >
                        <item.icon className="h-5 w-5 shrink-0" />
                        {!collapsed && <span>{item.label}</span>}
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}

function LocadorHeader({ urgentProposals = 0 }: { urgentProposals?: number }) {
  const { logout, profile } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
  };

  const getInitials = (name?: string | null) => {
    if (!name) return "P";
    return name.split(" ").map(n => n[0]).join("").slice(0, 2).toUpperCase();
  };

  return (
    <header className="h-14 border-b bg-background/80 backdrop-blur-sm sticky top-0 z-40 flex items-center justify-between px-4">
      <div className="flex items-center gap-3">
        <SidebarTrigger className="h-8 w-8" />
        <span className="text-lg font-semibold text-foreground hidden sm:block">
          Olá, {profile?.full_name?.split(" ")[0] || "Proprietário"}!
        </span>
      </div>

      <div className="flex items-center gap-2">
        <NotificationBell 
          urgentCount={urgentProposals} 
          onClick={() => navigate('/locador/propostas')}
        />

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="relative h-9 w-9 rounded-full">
              <Avatar className="h-9 w-9">
                <AvatarFallback className="bg-primary text-primary-foreground">
                  {getInitials(profile?.full_name)}
                </AvatarFallback>
              </Avatar>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48">
            <div className="flex items-center gap-2 p-2">
              <Avatar className="h-8 w-8">
                <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                  {getInitials(profile?.full_name)}
                </AvatarFallback>
              </Avatar>
              <div className="flex flex-col">
                <span className="text-sm font-medium truncate">
                  {profile?.full_name || "Proprietário"}
                </span>
                <span className="text-xs text-muted-foreground truncate">
                  {profile?.email}
                </span>
              </div>
            </div>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={handleLogout} className="text-destructive">
              <LogOut className="mr-2 h-4 w-4" />
              Sair
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}

function LocadorLayoutContent() {
  return (
    <div className="min-h-screen flex w-full bg-background">
      <LocadorSidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <LocadorHeader />
        <main className="flex-1 p-4 md:p-6 overflow-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}

export function LocadorLayout() {
  return (
    <SidebarProvider defaultOpen={true}>
      <LocadorLayoutContent />
    </SidebarProvider>
  );
}
