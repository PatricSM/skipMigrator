import {
  Check,
  FileText,
  ThumbsUp,
  ClipboardCheck,
  Files,
  FileCheck2,
  Pen,
  Calendar,
  Key,
  FileUser,
} from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";
import { JOURNEY_STEPS } from "@/types/locador-dashboard";

interface RentalJourneyStepperProps {
  currentStep: number;
  documentProgress?: number; // 0-100 for step 3
}

export function RentalJourneyStepper({
  currentStep,
  documentProgress = 80,
}: RentalJourneyStepperProps) {
  const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
    FileText,
    ThumbsUp,
    ClipboardCheck,
    Files,
    FileCheck: FileCheck2,
    FileUser,
    Pen,
    Calendar,
    Key,
  };

  const getStepStatus = (stepNumber: number) => {
    if (stepNumber < currentStep) return "completed";
    if (stepNumber === currentStep) return "current";
    return "blocked";
  };

  return (
    <div className="space-y-4">
      <h4 className="text-sm font-medium text-muted-foreground">
        Jornada da Locação
      </h4>

      {/* Vertical timeline */}
      <div className="flex flex-col gap-2">
        {JOURNEY_STEPS.map((step, index) => {
          const status = getStepStatus(step.step);
          const Icon = iconMap[step.icon] || FileText;
          const isLast = index === JOURNEY_STEPS.length - 1;

          return (
            <div key={step.step} className="flex items-start gap-3">
              {/* Step indicator */}
              <div className="flex flex-col items-center">
                <div
                  className={cn(
                    "w-8 h-8 rounded-full flex items-center justify-center shrink-0 transition-colors",
                    status === "completed" && "bg-sla-ok text-white",
                    status === "current" && "bg-primary text-primary-foreground",
                    status === "blocked" && "bg-muted text-muted-foreground"
                  )}
                >
                  {status === "completed" ? (
                    <Check className="h-4 w-4" />
                  ) : (
                    <Icon className="h-4 w-4" />
                  )}
                </div>

                {/* Connector line */}
                {!isLast && (
                  <div
                    className={cn(
                      "w-0.5 h-6 mt-1",
                      index < currentStep - 1 ? "bg-sla-ok" : "bg-muted"
                    )}
                  />
                )}
              </div>

              {/* Step content */}
              <div className="flex-1 pb-2">
                <p
                  className={cn(
                    "text-sm font-medium",
                    status === "blocked" && "text-muted-foreground"
                  )}
                >
                  {step.title}
                </p>

                {/* Progress bar for documentation step (step 3) */}
                {status === "current" && step.step === 3 && (
                  <div className="flex items-center gap-2 mt-1.5">
                    <Progress value={documentProgress} className="h-1.5 flex-1" />
                    <span className="text-xs text-muted-foreground">
                      {documentProgress}%
                    </span>
                  </div>
                )}

                {/* Status labels */}
                {status === "completed" && (
                  <span className="text-xs text-sla-ok">Concluído</span>
                )}
                {status === "current" && step.step !== 3 && (
                  <span className="text-xs text-primary">Em andamento</span>
                )}
                {status === "blocked" && (
                  <span className="text-xs text-muted-foreground">Pendente</span>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
