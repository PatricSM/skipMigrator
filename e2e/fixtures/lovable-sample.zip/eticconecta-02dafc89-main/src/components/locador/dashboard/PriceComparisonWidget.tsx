import { Button } from "@/components/ui/button";

interface PriceComparisonWidgetProps {
  rentValue: number;
  averageRegionPrice: number;
  suggestedPrice: number;
  onAdjustPrice?: () => void;
}

export function PriceComparisonWidget({ 
  rentValue, 
  averageRegionPrice, 
  suggestedPrice,
  onAdjustPrice 
}: PriceComparisonWidgetProps) {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
      minimumFractionDigits: 0,
    }).format(value);
  };

  const maxPrice = Math.max(rentValue, averageRegionPrice) * 1.1;
  const yourPricePercentage = (rentValue / maxPrice) * 100;
  const avgPricePercentage = (averageRegionPrice / maxPrice) * 100;

  const priceDiff = ((rentValue - averageRegionPrice) / averageRegionPrice) * 100;
  const isAboveMarket = priceDiff > 5;
  const isBelowMarket = priceDiff < -5;

  return (
    <div className="space-y-3">
      <h4 className="text-sm font-medium text-muted-foreground">
        Comparativo de Preço
      </h4>
      
      <div className="space-y-3">
        {/* Your Property */}
        <div className="space-y-1">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Seu imóvel</span>
            <span className="font-semibold">{formatCurrency(rentValue)}</span>
          </div>
          <div className="h-3 bg-muted rounded-full overflow-hidden">
            <div 
              className="h-full bg-primary rounded-full transition-all"
              style={{ width: `${yourPricePercentage}%` }}
            />
          </div>
        </div>

        {/* Market Average */}
        <div className="space-y-1">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Média da região</span>
            <span className="font-semibold">{formatCurrency(averageRegionPrice)}</span>
          </div>
          <div className="h-3 bg-muted rounded-full overflow-hidden">
            <div 
              className="h-full bg-muted-foreground/40 rounded-full transition-all"
              style={{ width: `${avgPricePercentage}%` }}
            />
          </div>
        </div>
      </div>

      {/* Price Analysis */}
      <div className="p-3 rounded-lg bg-muted/30">
        {isAboveMarket && (
          <p className="text-sm text-sla-warning">
            Seu preço está {priceDiff.toFixed(0)}% acima da média da região
          </p>
        )}
        {isBelowMarket && (
          <p className="text-sm text-sla-ok">
            Seu preço está {Math.abs(priceDiff).toFixed(0)}% abaixo da média - ótimo para alugar rápido!
          </p>
        )}
        {!isAboveMarket && !isBelowMarket && (
          <p className="text-sm text-muted-foreground">
            Seu preço está alinhado com o mercado
          </p>
        )}
      </div>

      {isAboveMarket && (
        <Button 
          variant="outline" 
          className="w-full"
          onClick={onAdjustPrice}
        >
          Ajustar para {formatCurrency(suggestedPrice)} e alugar 15% mais rápido
        </Button>
      )}
    </div>
  );
}
