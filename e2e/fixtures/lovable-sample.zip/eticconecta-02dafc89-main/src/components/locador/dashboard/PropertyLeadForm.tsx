import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { UserPlus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";

interface PropertyLeadFormProps {
  onSuccess?: () => void;
}

export function PropertyLeadForm({ onSuccess }: PropertyLeadFormProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    reason: "aluguel",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email) {
      toast({
        title: "Campos obrigatórios",
        description: "Preencha nome e email.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    try {
      // For now, use notification_queue to register the lead
      // In the future, create a property_leads table
      const { error } = await supabase.from("notification_queue").insert({
        template_key: "new_property_lead",
        channel: "internal",
        payload: {
          name: form.name,
          email: form.email,
          phone: form.phone,
          reason: form.reason,
          referred_by: user?.id,
        },
      });

      if (error) throw error;

      // Audit log
      await supabase.rpc("log_audit", {
        p_action: "PROPERTY_LEAD_CREATED",
        p_table_name: "notification_queue",
        p_new_data: { ...form },
      });

      toast({
        title: "Indicação enviada!",
        description: "Entraremos em contato em breve.",
      });

      setForm({ name: "", email: "", phone: "", reason: "aluguel" });
      onSuccess?.();
    } catch (error) {
      console.error("Error submitting lead:", error);
      toast({
        title: "Erro ao enviar indicação",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center gap-2">
          <UserPlus className="h-5 w-5" />
          Indicar Imóvel
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="lead-name">Nome *</Label>
            <Input
              id="lead-name"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              placeholder="Nome completo"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="lead-email">Email *</Label>
            <Input
              id="lead-email"
              type="email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              placeholder="email@exemplo.com"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="lead-phone">Telefone</Label>
            <Input
              id="lead-phone"
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
              placeholder="(11) 99999-9999"
            />
          </div>

          <div className="space-y-2">
            <Label>Interesse</Label>
            <RadioGroup
              value={form.reason}
              onValueChange={(value) => setForm({ ...form, reason: value })}
              className="flex gap-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="aluguel" id="aluguel" />
                <Label htmlFor="aluguel" className="cursor-pointer">
                  Aluguel
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="venda" id="venda" />
                <Label htmlFor="venda" className="cursor-pointer">
                  Venda
                </Label>
              </div>
            </RadioGroup>
          </div>

          <Button type="submit" className="w-full" disabled={isSubmitting}>
            {isSubmitting ? "Enviando..." : "Enviar Indicação"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
