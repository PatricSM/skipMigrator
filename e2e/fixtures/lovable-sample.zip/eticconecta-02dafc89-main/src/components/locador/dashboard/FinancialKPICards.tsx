import { Link } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TrendingUp, AlertTriangle, FileText } from "lucide-react";
import { ResponsiveContainer, LineChart, Line } from "recharts";
import { LandlordKPI } from "@/types/locador-dashboard";
import { cn } from "@/lib/utils";

interface FinancialKPICardsProps {
  kpis: LandlordKPI;
}

export function FinancialKPICards({ kpis }: FinancialKPICardsProps) {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
      minimumFractionDigits: 0,
    }).format(value);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {/* Monthly Revenue Card */}
      <Card className="overflow-hidden">
        <CardContent className="p-4">
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Receita Mensal</p>
              <p className="text-2xl font-bold text-foreground">
                {formatCurrency(kpis.monthlyRevenue)}
              </p>
              <p className="text-xs text-muted-foreground">
                {kpis.activeProperties} {kpis.activeProperties === 1 ? 'imóvel alugado' : 'imóveis alugados'}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-sla-ok" />
            </div>
          </div>

          {/* Sparkline */}
          <div className="mt-4 h-10">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={kpis.revenueTrend}>
                <Line
                  type="monotone"
                  dataKey="value"
                  stroke="hsl(var(--sla-ok))"
                  strokeWidth={2}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <p className="text-xs text-muted-foreground mt-1 text-center">
            Últimos 6 meses
          </p>
        </CardContent>
      </Card>

      {/* Vacancy Cost Card - Enhanced */}
      <Card className={cn(
        "overflow-hidden",
        kpis.vacancyCost > 0 && "border-destructive/50"
      )}>
        <CardContent className="p-4">
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <p className="text-sm font-semibold text-destructive flex items-center gap-1.5">
                <AlertTriangle className={cn(
                  "h-4 w-4",
                  kpis.vacancyCost > 0 && "animate-pulse"
                )} />
                Custo de Oportunidade
              </p>
              <p className="text-2xl font-bold text-foreground">
                {formatCurrency(kpis.vacancyCostWithExpenses)}
              </p>
              <p className="text-xs text-muted-foreground">
                Aluguel + condomínio + IPTU
              </p>
            </div>
          </div>

          {kpis.vacancyCost > 0 && (
            <div className="mt-4 space-y-3">
              <div className="p-3 bg-destructive/10 rounded-lg">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-destructive font-medium">
                    Perda por dia:
                  </span>
                  <span className="text-lg font-bold text-destructive animate-pulse">
                    {formatCurrency(kpis.dailyVacancyLoss)}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  {kpis.vacantProperties} {kpis.vacantProperties === 1 ? 'imóvel vago' : 'imóveis vagos'}
                </p>
              </div>

              {/* CTA to reduce vacancy */}
              <Button
                variant="outline"
                size="sm"
                className="w-full text-destructive border-destructive/30 hover:bg-destructive/10"
                asChild
              >
                <Link to="/locador/propostas">
                  <FileText className="h-4 w-4 mr-2" />
                  Ver propostas para reduzir vacância
                </Link>
              </Button>
            </div>
          )}

          {kpis.vacancyCost === 0 && (
            <div className="mt-4 p-3 bg-sla-ok/10 rounded-lg">
              <p className="text-sm text-sla-ok font-medium text-center">
                ✓ Todos os imóveis alugados!
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
