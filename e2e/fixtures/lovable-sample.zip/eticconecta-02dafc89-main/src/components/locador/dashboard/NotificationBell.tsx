import { Bell } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface NotificationBellProps {
  urgentCount: number;
  onClick?: () => void;
}

export function NotificationBell({ urgentCount, onClick }: NotificationBellProps) {
  return (
    <Button 
      variant="ghost" 
      size="icon" 
      className="relative"
      onClick={onClick}
    >
      <Bell className={cn(
        "h-5 w-5",
        urgentCount > 0 && "text-destructive"
      )} />
      {urgentCount > 0 && (
        <span className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-destructive text-destructive-foreground text-xs flex items-center justify-center animate-pulse">
          {urgentCount > 9 ? '9+' : urgentCount}
        </span>
      )}
    </Button>
  );
}
