interface TenantScoreGaugeProps {
  score: number;
  size?: 'sm' | 'md' | 'lg';
}

export function TenantScoreGauge({ score, size = 'md' }: TenantScoreGaugeProps) {
  // Clamp score between 0 and 100
  const clampedScore = Math.min(100, Math.max(0, score));
  
  // Determine color based on score
  const getScoreColor = () => {
    if (clampedScore >= 70) return 'hsl(var(--sla-ok))';
    if (clampedScore >= 40) return 'hsl(var(--sla-warning))';
    return 'hsl(var(--destructive))';
  };

  const getScoreLabel = () => {
    if (clampedScore >= 70) return 'Excelente';
    if (clampedScore >= 40) return 'Regular';
    return 'Baixo';
  };

  // Arc calculation for semi-circle gauge
  // The arc goes from 180 degrees to 0 degrees (left to right)
  const scorePercentage = clampedScore / 100;
  const dashArray = 126; // Approximate arc length
  const dashOffset = dashArray * (1 - scorePercentage);

  const sizeClasses = {
    sm: 'w-16 h-10',
    md: 'w-24 h-14',
    lg: 'w-32 h-20',
  };

  const textSizes = {
    sm: 'text-sm',
    md: 'text-lg',
    lg: 'text-2xl',
  };

  return (
    <div className="flex flex-col items-center">
      <svg 
        viewBox="0 0 100 60" 
        className={sizeClasses[size]}
      >
        {/* Background arc */}
        <path 
          d="M 10 50 A 40 40 0 0 1 90 50" 
          fill="none" 
          stroke="hsl(var(--muted))" 
          strokeWidth="8" 
          strokeLinecap="round"
        />
        {/* Score arc */}
        <path 
          d="M 10 50 A 40 40 0 0 1 90 50" 
          fill="none" 
          stroke={getScoreColor()} 
          strokeWidth="8" 
          strokeLinecap="round"
          strokeDasharray={dashArray}
          strokeDashoffset={dashOffset}
          className="transition-all duration-700 ease-out"
        />
        {/* Score text */}
        <text 
          x="50" 
          y="48" 
          textAnchor="middle" 
          className={`${textSizes[size]} font-bold fill-foreground`}
        >
          {clampedScore}
        </text>
      </svg>
      <span className="text-xs text-muted-foreground mt-1">
        {getScoreLabel()}
      </span>
    </div>
  );
}
