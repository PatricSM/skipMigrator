import { Smile, Meh, Frown } from "lucide-react";
import { VisitFeedback } from "@/types/locador-dashboard";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

interface VisitFeedbackListProps {
  feedbacks: VisitFeedback[];
}

export function VisitFeedbackList({ feedbacks }: VisitFeedbackListProps) {
  const sentimentIcons = {
    happy: <Smile className="h-5 w-5 text-sla-ok shrink-0" />,
    neutral: <Meh className="h-5 w-5 text-sla-warning shrink-0" />,
    sad: <Frown className="h-5 w-5 text-destructive shrink-0" />,
  };

  if (feedbacks.length === 0) {
    return (
      <div className="text-center py-4 text-muted-foreground text-sm">
        Nenhum feedback de visita ainda.
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <h4 className="text-sm font-medium text-muted-foreground">
        Feedback das Visitas ({feedbacks.length})
      </h4>
      
      <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
        {feedbacks.map((feedback) => (
          <div 
            key={feedback.id}
            className="flex items-start gap-3 p-3 bg-muted/30 rounded-lg"
          >
            {sentimentIcons[feedback.sentiment]}
            <div className="flex-1 min-w-0">
              <p className="text-sm text-foreground line-clamp-2">
                "{feedback.comment}"
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                {format(new Date(feedback.date), "dd 'de' MMM", { locale: ptBR })}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
