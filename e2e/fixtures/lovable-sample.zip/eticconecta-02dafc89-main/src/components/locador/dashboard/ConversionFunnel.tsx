import { ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

interface ConversionFunnelProps {
  views: number;
  visits: number;
  proposals: number;
}

export function ConversionFunnel({ views, visits, proposals }: ConversionFunnelProps) {
  const viewsToVisits = views > 0 ? ((visits / views) * 100).toFixed(1) : '0';
  const visitsToProposals = visits > 0 ? ((proposals / visits) * 100).toFixed(1) : '0';

  return (
    <div className="space-y-3">
      <h4 className="text-sm font-medium text-muted-foreground">Funil de Conversão</h4>
      
      {/* Horizontal on desktop, vertical on mobile */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <FunnelStep label="Views" value={views} />
        
        <div className="flex items-center gap-1 text-muted-foreground">
          <ChevronRight className="h-4 w-4 hidden sm:block" />
          <span className="text-xs sm:hidden">↓ {viewsToVisits}%</span>
          <span className="text-xs hidden sm:block">{viewsToVisits}%</span>
        </div>
        
        <FunnelStep 
          label="Visitas" 
          value={visits} 
          percentage={viewsToVisits}
          showPercentage
        />
        
        <div className="flex items-center gap-1 text-muted-foreground">
          <ChevronRight className="h-4 w-4 hidden sm:block" />
          <span className="text-xs sm:hidden">↓ {visitsToProposals}%</span>
          <span className="text-xs hidden sm:block">{visitsToProposals}%</span>
        </div>
        
        <FunnelStep 
          label="Propostas" 
          value={proposals} 
          percentage={visitsToProposals}
          showPercentage
          highlight
        />
      </div>
    </div>
  );
}

interface FunnelStepProps {
  label: string;
  value: number;
  percentage?: string;
  showPercentage?: boolean;
  highlight?: boolean;
}

function FunnelStep({ label, value, highlight }: FunnelStepProps) {
  return (
    <div className={cn(
      "flex-1 p-3 rounded-lg text-center",
      highlight 
        ? "bg-primary/10 border border-primary/20" 
        : "bg-muted/50"
    )}>
      <p className="text-2xl font-bold">{value}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
    </div>
  );
}
