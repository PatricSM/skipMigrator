import { Badge } from "@/components/ui/badge";
import { Check, X } from "lucide-react";
import { cn } from "@/lib/utils";

interface TrustBadgesProps {
  badges: {
    incomeVerified: boolean;
    guaranteeApproved: boolean;
    goodHistory: boolean;
  };
}

export function TrustBadges({ badges }: TrustBadgesProps) {
  const badgeConfig = [
    {
      key: 'incomeVerified',
      label: 'Renda Comprovada',
      verified: badges.incomeVerified,
    },
    {
      key: 'guaranteeApproved',
      label: 'Garantia Pré-Aprovada',
      verified: badges.guaranteeApproved,
    },
    {
      key: 'goodHistory',
      label: 'Bom Histórico',
      verified: badges.goodHistory,
    },
  ];

  return (
    <div className="flex flex-wrap gap-1.5">
      {badgeConfig.map((badge) => (
        <Badge
          key={badge.key}
          variant={badge.verified ? "default" : "secondary"}
          className={cn(
            "text-xs gap-1",
            badge.verified 
              ? "bg-sla-ok/20 text-sla-ok border-sla-ok/30 hover:bg-sla-ok/30" 
              : "bg-muted text-muted-foreground"
          )}
        >
          {badge.verified ? (
            <Check className="h-3 w-3" />
          ) : (
            <X className="h-3 w-3" />
          )}
          {badge.label}
        </Badge>
      ))}
    </div>
  );
}
