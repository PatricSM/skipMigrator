import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  ChevronDown,
  MapPin,
  Home,
  User,
  Eye,
  Calendar,
  FileText,
  Edit2,
} from "lucide-react";
import { PropertyPerformance } from "@/types/locador-dashboard";
import { ConversionFunnel } from "./ConversionFunnel";
import { VisitFeedbackList } from "./VisitFeedbackList";
import { PriceComparisonWidget } from "./PriceComparisonWidget";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface PropertyExpandableCardProps {
  property: PropertyPerformance;
  onEditValue?: (propertyId: string, newValue: number) => void;
  onEditDescription?: (propertyId: string, newDescription: string) => void;
}

export function PropertyExpandableCard({
  property,
  onEditValue,
  onEditDescription,
}: PropertyExpandableCardProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [editValueOpen, setEditValueOpen] = useState(false);
  const [editDescOpen, setEditDescOpen] = useState(false);
  const [newRentValue, setNewRentValue] = useState(property.rentValue.toString());
  const [newDescription, setNewDescription] = useState(property.description || "");
  const [isUpdating, setIsUpdating] = useState(false);
  const { toast } = useToast();

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
      minimumFractionDigits: 0,
    }).format(value);
  };

  const handleUpdateValue = async () => {
    const value = parseFloat(newRentValue.replace(/\D/g, ""));
    if (!value) return;

    setIsUpdating(true);
    try {
      const { error } = await supabase
        .from("properties")
        .update({ rent_value: value })
        .eq("id", property.id);

      if (error) throw error;

      toast({
        title: "Valor atualizado",
        description: `Novo valor: ${formatCurrency(value)}`,
      });
      setEditValueOpen(false);
      onEditValue?.(property.id, value);
    } catch (error) {
      console.error("Error updating rent value:", error);
      toast({
        title: "Erro ao atualizar valor",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      });
    } finally {
      setIsUpdating(false);
    }
  };

  const handleUpdateDescription = async () => {
    setIsUpdating(true);
    try {
      const { error } = await supabase
        .from("properties")
        .update({ description: newDescription })
        .eq("id", property.id);

      if (error) throw error;

      toast({
        title: "Descrição atualizada",
        description: "As alterações foram salvas.",
      });
      setEditDescOpen(false);
      onEditDescription?.(property.id, newDescription);
    } catch (error) {
      console.error("Error updating description:", error);
      toast({
        title: "Erro ao atualizar descrição",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      });
    } finally {
      setIsUpdating(false);
    }
  };

  const getStatusBadgeStyle = () => {
    switch (property.status) {
      case "rented":
        return "bg-sla-ok/20 text-sla-ok border-sla-ok/30";
      case "vacant":
        return "bg-sla-warning/20 text-sla-warning border-sla-warning/30";
      case "em_negociacao":
        return "bg-primary/20 text-primary border-primary/30";
      case "suspenso":
        return "bg-muted text-muted-foreground";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  const getStatusLabel = () => {
    switch (property.status) {
      case "rented":
        return "Alugado";
      case "vacant":
        return "Vago";
      case "em_negociacao":
        return "Em Negociação";
      case "suspenso":
        return "Suspenso";
      default:
        return property.status;
    }
  };

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <Card className="overflow-hidden mb-3">
        <CollapsibleTrigger asChild>
          <CardContent className="p-0 cursor-pointer hover:bg-muted/30 transition-colors">
            <div className="flex gap-3 p-3">
              {/* Property Image */}
              <div className="w-20 h-20 rounded-lg overflow-hidden bg-muted shrink-0">
                <img
                  src={property.image}
                  alt={property.code}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    e.currentTarget.src =
                      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=400&h=300&fit=crop";
                  }}
                />
              </div>

              {/* Property Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      {/* Property Code - Highlighted */}
                      <Badge
                        variant="outline"
                        className="font-mono text-sm font-semibold"
                      >
                        {property.code}
                      </Badge>
                      <Badge
                        variant="secondary"
                        className={cn("text-xs", getStatusBadgeStyle())}
                      >
                        {getStatusLabel()}
                      </Badge>
                      {/* Proposal count badge */}
                      {property.proposals > 0 && (
                        <Badge variant="default" className="text-xs gap-1">
                          <FileText className="h-3 w-3" />
                          {property.proposals} proposta
                          {property.proposals > 1 ? "s" : ""}
                        </Badge>
                      )}
                    </div>

                    <p className="text-sm text-muted-foreground flex items-center gap-1 mt-1">
                      <MapPin className="h-3 w-3" />
                      <span className="truncate">{property.address}</span>
                    </p>
                  </div>

                  <ChevronDown
                    className={cn(
                      "h-5 w-5 text-muted-foreground transition-transform shrink-0",
                      isOpen && "rotate-180"
                    )}
                  />
                </div>

                <div className="flex items-center justify-between mt-2">
                  <p className="font-semibold text-foreground">
                    {formatCurrency(property.rentValue)}/mês
                  </p>

                  {property.status === "rented" && property.tenant && (
                    <span className="text-xs text-muted-foreground flex items-center gap-1">
                      <User className="h-3 w-3" />
                      {property.tenant}
                    </span>
                  )}

                  {property.status === "vacant" && (
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Eye className="h-3 w-3" />
                        {property.views}
                      </span>
                      <span className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        {property.visits}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </CollapsibleTrigger>

        <CollapsibleContent>
          <div className="border-t p-4 space-y-6 bg-muted/10">
            {/* Property details */}
            <div className="grid grid-cols-3 gap-4 text-sm">
              <div>
                <span className="text-muted-foreground">Aluguel</span>
                <p className="font-medium">{formatCurrency(property.rentValue)}</p>
              </div>
              <div>
                <span className="text-muted-foreground">Condomínio</span>
                <p className="font-medium">{formatCurrency(property.condoFee)}</p>
              </div>
              <div>
                <span className="text-muted-foreground">IPTU</span>
                <p className="font-medium">{formatCurrency(property.iptu)}</p>
              </div>
            </div>

            {property.status === "vacant" && (
              <>
                {/* Conversion Funnel */}
                <ConversionFunnel
                  views={property.views}
                  visits={property.visits}
                  proposals={property.proposals}
                />

                {/* Visit Feedbacks */}
                <VisitFeedbackList feedbacks={property.visitFeedbacks} />

                {/* Price Comparison */}
                <PriceComparisonWidget
                  rentValue={property.rentValue}
                  averageRegionPrice={property.averageRegionPrice}
                  suggestedPrice={property.suggestedPrice}
                />
              </>
            )}

            {property.status === "rented" && (
              <div className="text-center py-4">
                <Home className="h-8 w-8 text-sla-ok mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">
                  Este imóvel está alugado para {property.tenant}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Receita dos últimos 6 meses:{" "}
                  {formatCurrency(
                    property.revenueHistory.reduce((a, b) => a + b, 0)
                  )}
                </p>
              </div>
            )}

            {/* Action buttons */}
            <div className="flex flex-wrap gap-2 pt-4 border-t">
              <Dialog open={editValueOpen} onOpenChange={setEditValueOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Edit2 className="h-4 w-4 mr-2" />
                    Alterar Valor
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Alterar Valor do Aluguel</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="rent-value">Novo valor (R$)</Label>
                      <Input
                        id="rent-value"
                        type="text"
                        value={newRentValue}
                        onChange={(e) => {
                          const value = e.target.value.replace(/\D/g, "");
                          setNewRentValue(value);
                        }}
                        placeholder="0"
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button
                      variant="outline"
                      onClick={() => setEditValueOpen(false)}
                    >
                      Cancelar
                    </Button>
                    <Button onClick={handleUpdateValue} disabled={isUpdating}>
                      {isUpdating ? "Salvando..." : "Salvar"}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>

              <Dialog open={editDescOpen} onOpenChange={setEditDescOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Edit2 className="h-4 w-4 mr-2" />
                    Alterar Descrição
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Alterar Descrição do Imóvel</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="description">Descrição</Label>
                      <Textarea
                        id="description"
                        value={newDescription}
                        onChange={(e) => setNewDescription(e.target.value)}
                        placeholder="Descreva o imóvel..."
                        rows={4}
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button
                      variant="outline"
                      onClick={() => setEditDescOpen(false)}
                    >
                      Cancelar
                    </Button>
                    <Button
                      onClick={handleUpdateDescription}
                      disabled={isUpdating}
                    >
                      {isUpdating ? "Salvando..." : "Salvar"}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </CollapsibleContent>
      </Card>
    </Collapsible>
  );
}
