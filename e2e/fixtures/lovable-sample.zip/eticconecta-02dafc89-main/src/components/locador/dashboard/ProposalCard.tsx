import { useState } from "react";
import { Link } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  User,
  Users,
  Banknote,
  Check,
  Star,
  Sparkles,
  X,
  MessageSquare,
  FileCheck,
  ClipboardCheck,
} from "lucide-react";
import { TenantProposal, REJECTION_REASONS } from "@/types/locador-dashboard";
import { TenantScoreGauge } from "./TenantScoreGauge";
import { TrustBadges } from "./TrustBadges";
import { RentalJourneyStepper } from "./RentalJourneyStepper";
import { cn } from "@/lib/utils";

interface ProposalCardProps {
  proposal: TenantProposal;
  onAccept: (proposalId: string) => Promise<void>;
  onReject?: (proposalId: string, reason: string, details?: string) => Promise<void>;
  onCounterProposal?: (proposalId: string, newValue: number) => Promise<void>;
}

export function ProposalCard({
  proposal,
  onAccept,
  onReject,
  onCounterProposal,
}: ProposalCardProps) {
  const [isAccepting, setIsAccepting] = useState(false);
  const [isRejecting, setIsRejecting] = useState(false);
  
  const [rejectDialogOpen, setRejectDialogOpen] = useState(false);
  const [counterDialogOpen, setCounterDialogOpen] = useState(false);
  const [rejectReason, setRejectReason] = useState<string>("");
  const [rejectDetails, setRejectDetails] = useState("");
  const [counterValue, setCounterValue] = useState<string>("");

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
      minimumFractionDigits: 0,
    }).format(value);
  };

  const handleAccept = async () => {
    setIsAccepting(true);
    try {
      await onAccept(proposal.id);
    } finally {
      setIsAccepting(false);
    }
  };

  const handleReject = async () => {
    if (!rejectReason || !onReject) return;
    setIsRejecting(true);
    try {
      await onReject(proposal.id, rejectReason, rejectDetails || undefined);
      setRejectDialogOpen(false);
      setRejectReason("");
      setRejectDetails("");
    } finally {
      setIsRejecting(false);
    }
  };

  const handleCounterProposal = async () => {
    const value = parseFloat(counterValue.replace(/\D/g, ""));
    if (!value || !onCounterProposal) return;

    // Validate: counter-proposal should not exceed original rent value
    if (value > proposal.propertyRentValue) {
      return;
    }

    try {
      await onCounterProposal(proposal.id, value);
      setCounterDialogOpen(false);
      setCounterValue("");
    } catch (error) {
      console.error("Error sending counter-proposal:", error);
    }
  };

  const timeSinceCreated = () => {
    const diff = Date.now() - proposal.createdAt.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));

    if (hours > 0) return `há ${hours}h${minutes > 0 ? ` ${minutes}min` : ""}`;
    return `há ${minutes}min`;
  };

  // Check if proposal is in step 2 (landlord decision)
  const isInDecisionStep = proposal.currentStep === 2 && !proposal.landlordAccepted;

  return (
    <Card
      className={cn(
        "transition-all duration-300 relative overflow-visible",
        proposal.isUrgent &&
          !proposal.respondedAt &&
          "border-destructive/50 shadow-destructive/20 shadow-lg",
        proposal.isDirectRental && "border-primary/50 bg-primary/5"
      )}
    >
      {/* URGENTE Badge for Direct Rentals */}
      {proposal.isDirectRental && (
        <div className="absolute -top-2 -left-2 z-10">
          <Badge className="bg-destructive text-white border-0 shadow-lg gap-1 animate-pulse">
            URGENTE
          </Badge>
        </div>
      )}

      {/* Priority Badge */}
      {proposal.isDirectRental && (
        <div className="absolute -top-2 -right-2 z-10">
          <Badge className="bg-gradient-to-r from-emerald-500 to-teal-500 text-white border-0 shadow-lg gap-1">
            <Star className="h-3 w-3" />
            Prioridade
          </Badge>
        </div>
      )}

      <CardContent className="p-4">
        {/* Urgent Banner */}
        {proposal.isUrgent && !proposal.respondedAt && (
          <div className="mb-3 p-2 bg-destructive/10 rounded-lg border border-destructive/20">
            <p className="text-sm text-destructive font-medium text-center">
              ⚠️ Locatário aguardando - Responda para não perder o negócio
            </p>
          </div>
        )}

        <div className="flex flex-col sm:flex-row gap-4">
          {/* Tenant Profile */}
          <div className="flex items-start gap-3 flex-1">
            {/* Avatar */}
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
              <User className="h-6 w-6 text-primary" />
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h3 className="font-semibold text-foreground truncate">
                    {proposal.tenantName}
                  </h3>
                  <p className="text-xs text-muted-foreground">
                    Protocolo: {proposal.protocol}
                  </p>
                </div>

                {/* Etic Badge */}
                {proposal.imobiliariaApproved && (
                  <Badge
                    variant="outline"
                    className="shrink-0 gap-1 border-primary/30 text-primary"
                  >
                    <Check className="h-3 w-3" />
                    Aprovado pela Etic
                  </Badge>
                )}
              </div>

              {/* Property Info - Code in highlight */}
              <div className="flex items-center gap-2 mt-1">
                <Badge variant="outline" className="font-mono text-xs">
                  {proposal.propertyCode}
                </Badge>
                <p className="text-sm text-muted-foreground truncate">
                  {proposal.propertyAddress}
                </p>
              </div>

              {/* Family Info */}
              <div className="flex items-center gap-4 mt-2 text-sm">
                <span className="flex items-center gap-1 text-muted-foreground">
                  <Users className="h-4 w-4" />
                  {proposal.familyMembers}{" "}
                  {proposal.familyMembers === 1 ? "morador" : "moradores"}
                </span>
                <span className="flex items-center gap-1 text-muted-foreground">
                  <Banknote className="h-4 w-4" />
                  Renda: {formatCurrency(proposal.familyIncome)}
                </span>
              </div>

              {/* Trust Badges */}
              <div className="mt-3">
                <TrustBadges badges={proposal.badges} />
              </div>

              {/* Document & Ficha Status */}
              <div className="flex flex-wrap gap-2 mt-3">
                <Badge
                  variant={proposal.docsStatus === "complete" ? "default" : "secondary"}
                  className={cn(
                    "gap-1",
                    proposal.docsStatus === "complete" &&
                      "bg-sla-ok/20 text-sla-ok border-sla-ok/30"
                  )}
                >
                  <FileCheck className="h-3 w-3" />
                  {proposal.docsStatus === "complete"
                    ? "Docs enviados"
                    : proposal.docsStatus === "partial"
                    ? "Docs parciais"
                    : "Docs pendentes"}
                </Badge>

                {proposal.fichaStatus && (
                  <Badge
                    variant={
                      proposal.fichaStatus === "aprovada" ? "default" : "secondary"
                    }
                    className={cn(
                      "gap-1",
                      proposal.fichaStatus === "aprovada" &&
                        "bg-sla-ok/20 text-sla-ok border-sla-ok/30",
                      proposal.fichaStatus === "reprovada" &&
                        "bg-destructive/20 text-destructive border-destructive/30"
                    )}
                  >
                    <ClipboardCheck className="h-3 w-3" />
                    {proposal.fichaStatus === "em_analise"
                      ? "Ficha em aprovação (até 24h)"
                      : proposal.fichaStatus === "aprovada"
                      ? "Ficha aprovada"
                      : "Ficha reprovada"}
                  </Badge>
                )}
              </div>
            </div>
          </div>

          {/* Tenant Score */}
          <div className="flex flex-col items-center justify-center shrink-0">
            <TenantScoreGauge score={proposal.tenantScore} size="md" />
            <span className="text-xs text-muted-foreground mt-1">
              {proposal.tenantScoreStatus}
            </span>
            <div className="mt-2 text-xs text-muted-foreground text-center space-y-0.5">
              {proposal.tenantScoreReasons.map((r, i) => (
                <p key={i}>• {r}</p>
              ))}
            </div>
          </div>
        </div>

        {/* Direct proposal highlight */}
        {proposal.isDirectRental && (
          <div className="bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 rounded-lg p-3 mt-3">
            <div className="flex items-center gap-2 text-emerald-700">
              <Sparkles className="h-4 w-4" />
              <span className="font-semibold text-sm">
                Locatário aceitou o valor do anúncio!
              </span>
            </div>
            <p className="text-xs text-emerald-600 mt-1">
              Esta ficha será analisada com prioridade máxima.
            </p>
          </div>
        )}

        {/* Counter-proposal value */}
        {!proposal.isDirectRental && proposal.proposedValue && (
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 mt-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-amber-700">Valor proposto:</span>
              <span className="font-bold text-amber-800">
                {formatCurrency(proposal.proposedValue)}/mês
              </span>
            </div>
          </div>
        )}

        {/* Time indicator */}
        <p className="text-xs text-muted-foreground mt-3">
          Proposta recebida {timeSinceCreated()}
        </p>

        {/* Actions - Stage 2 Decision */}
        {isInDecisionStep && (
          <div className="flex flex-wrap gap-2 mt-4 pt-4 border-t">
            {/* Approve */}
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button
                  className="bg-sla-ok hover:bg-sla-ok/90 text-white"
                  disabled={isAccepting}
                >
                  {isAccepting ? "Processando..." : "Aprovar Proposta"}
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Confirmar aceite da proposta</AlertDialogTitle>
                  <AlertDialogDescription>
                    Ao aceitar esta proposta, você está autorizando o
                    prosseguimento do processo de locação com{" "}
                    {proposal.tenantName}. O locatário será notificado
                    automaticamente.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={handleAccept}
                    className="bg-sla-ok hover:bg-sla-ok/90"
                  >
                    Confirmar Aceite
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>

            {/* Counter-proposal */}
            {onCounterProposal && (
              <Dialog open={counterDialogOpen} onOpenChange={setCounterDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline">
                    <MessageSquare className="h-4 w-4 mr-2" />
                    Contra-proposta
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Enviar Contra-proposta</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <p className="text-sm text-muted-foreground">
                      Valor atual do anúncio:{" "}
                      <strong>{formatCurrency(proposal.propertyRentValue)}</strong>
                    </p>
                    <div className="space-y-2">
                      <Label htmlFor="counter-value">Novo valor proposto</Label>
                      <Input
                        id="counter-value"
                        type="text"
                        placeholder="R$ 0"
                        value={counterValue}
                        onChange={(e) => {
                          const value = e.target.value.replace(/\D/g, "");
                          setCounterValue(value ? `R$ ${parseInt(value).toLocaleString("pt-BR")}` : "");
                        }}
                      />
                      <p className="text-xs text-muted-foreground">
                        O valor não pode ultrapassar{" "}
                        {formatCurrency(proposal.propertyRentValue)}
                      </p>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button
                      variant="outline"
                      onClick={() => setCounterDialogOpen(false)}
                    >
                      Cancelar
                    </Button>
                    <Button onClick={handleCounterProposal}>
                      Enviar Proposta
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            )}

            {/* Reject */}
            {onReject && (
              <Dialog open={rejectDialogOpen} onOpenChange={setRejectDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="destructive">
                    <X className="h-4 w-4 mr-2" />
                    Recusar
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Motivo da Recusa</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <RadioGroup
                      value={rejectReason}
                      onValueChange={setRejectReason}
                    >
                      {REJECTION_REASONS.map((reason) => (
                        <div
                          key={reason}
                          className="flex items-center space-x-2"
                        >
                          <RadioGroupItem value={reason} id={reason} />
                          <Label htmlFor={reason}>{reason}</Label>
                        </div>
                      ))}
                    </RadioGroup>
                    <div className="space-y-2">
                      <Label htmlFor="reject-details">
                        Detalhes (opcional)
                      </Label>
                      <Textarea
                        id="reject-details"
                        placeholder="Informações adicionais..."
                        value={rejectDetails}
                        onChange={(e) => setRejectDetails(e.target.value)}
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button
                      variant="outline"
                      onClick={() => setRejectDialogOpen(false)}
                    >
                      Cancelar
                    </Button>
                    <Button
                      variant="destructive"
                      onClick={handleReject}
                      disabled={!rejectReason || isRejecting}
                    >
                      {isRejecting ? "Processando..." : "Confirmar Recusa"}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            )}
          </div>
        )}

        {/* View Details (when not in decision step or already accepted) */}
        {(!isInDecisionStep || proposal.landlordAccepted) && (
          <div className="flex gap-2 mt-4">
            <Button variant="outline" className="w-full" asChild>
              <Link to={`/locador/proposta/${proposal.protocol || proposal.id}`}>
                Ver Detalhes
              </Link>
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
