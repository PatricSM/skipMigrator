import { Check, FileText, ThumbsUp, Upload, ClipboardCheck, Building, FileCheck, Pen, Calendar, Key, AlertTriangle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Progress } from '@/components/ui/progress';

const STEPPER_STEPS = [
  { step: 1, label: 'Proposta', icon: FileText },
  { step: 2, label: 'Aceite', icon: ThumbsUp },
  { step: 3, label: 'Docs', icon: Upload },
  { step: 4, label: 'Análise', icon: ClipboardCheck },
  { step: 5, label: 'Docs Locador', icon: Building },
  { step: 6, label: 'Emissão', icon: FileCheck },
  { step: 7, label: 'Assinatura', icon: Pen },
  { step: 8, label: 'Vistoria', icon: Calendar },
  { step: 9, label: 'Laudo', icon: ClipboardCheck },
  { step: 10, label: 'Chaves', icon: Key },
];

interface GamifiedStepperProps {
  currentStep: number;
  hasPendingDocs?: boolean;
  isRejected?: boolean;
  docsSubmittedEarly?: boolean;
}

export function GamifiedStepper({ currentStep, hasPendingDocs, isRejected, docsSubmittedEarly }: GamifiedStepperProps) {
  const totalSteps = STEPPER_STEPS.length;
  const completedSteps = Math.max(0, currentStep - 1);
  const progressPercent = Math.round((completedSteps / totalSteps) * 100);

  // Determine which steps are "parallel" (both active)
  // Example: step 2 (Aceite) + step 3 (Docs) can be simultaneous when docsSubmittedEarly
  const parallelSteps = docsSubmittedEarly && currentStep === 2 ? [2, 3] : [];

  return (
    <div className="space-y-3">
      {/* Progress bar with percentage */}
      <div className="flex items-center gap-3">
        <Progress value={progressPercent} className="flex-1 h-2" />
        <span className="text-xs font-semibold text-primary whitespace-nowrap">
          {progressPercent}%
        </span>
      </div>

      {/* Horizontal stepper - scrollable on mobile */}
      <div className="overflow-x-auto -mx-1 px-1 pb-1">
        <div className="flex items-start gap-0.5 min-w-max">
          {STEPPER_STEPS.map((step, index) => {
            const isCompleted = step.step < currentStep;
            const isCurrent = step.step === currentStep;
            const isParallel = parallelSteps.includes(step.step);
            const isFuture = step.step > currentStep && !isParallel;
            const isDocsPending = step.step === 3 && hasPendingDocs && (isCurrent || isParallel);
            const isDocsEarlyDone = step.step === 3 && docsSubmittedEarly && currentStep === 2;
            const isStepRejected = isRejected && step.step === 2;
            const StepIcon = step.icon;

            return (
              <div key={step.step} className="flex items-center">
                <div className="flex flex-col items-center" style={{ width: '40px' }}>
                  {/* Circle */}
                  <div
                    className={cn(
                      "w-7 h-7 rounded-full flex items-center justify-center transition-all duration-300 shrink-0",
                      isCompleted && !isStepRejected && "bg-step-complete text-step-complete-foreground",
                      isDocsEarlyDone && "bg-step-complete text-step-complete-foreground",
                      isStepRejected && "bg-destructive text-destructive-foreground",
                      isDocsPending && "bg-destructive text-destructive-foreground animate-pulse",
                      (isCurrent || isParallel) && !isDocsPending && !isDocsEarlyDone && !isStepRejected && "bg-primary text-primary-foreground ring-2 ring-primary/30 animate-pulse",
                      isFuture && !isDocsEarlyDone && "bg-muted text-muted-foreground",
                    )}
                  >
                    {isCompleted || isDocsEarlyDone ? (
                      <Check className="h-3.5 w-3.5" />
                    ) : isDocsPending ? (
                      <AlertTriangle className="h-3.5 w-3.5" />
                    ) : isStepRejected ? (
                      <span className="text-xs font-bold">✕</span>
                    ) : (
                      <StepIcon className="h-3.5 w-3.5" />
                    )}
                  </div>

                  {/* Label */}
                  <span
                    className={cn(
                      "text-[9px] mt-1 text-center font-medium leading-tight",
                      isCompleted && "text-step-complete",
                      isDocsEarlyDone && "text-step-complete",
                      isStepRejected && "text-destructive",
                      isDocsPending && "text-destructive font-semibold",
                      (isCurrent || isParallel) && !isDocsPending && !isDocsEarlyDone && !isStepRejected && "text-primary font-semibold",
                      isFuture && !isDocsEarlyDone && "text-muted-foreground",
                    )}
                  >
                    {step.label}
                  </span>
                </div>

                {/* Connector line */}
                {index < STEPPER_STEPS.length - 1 && (
                  <div
                    className={cn(
                      "h-0.5 w-3 mt-[-12px] transition-all",
                      isCompleted && !isStepRejected ? "bg-step-complete" : "bg-muted",
                    )}
                  />
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Current step callout */}
      <div className={cn(
        "flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium",
        isRejected 
          ? "bg-destructive/10 text-destructive" 
          : hasPendingDocs 
            ? "bg-destructive/10 text-destructive" 
            : "bg-primary/10 text-primary"
      )}>
        {isRejected ? (
          <>✕ Proposta não aceita pelo locador</>
        ) : hasPendingDocs ? (
          <>
            <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
            Faltam documentos para completar o envio
          </>
        ) : parallelSteps.length > 0 ? (
          <>🔄 Etapas paralelas em andamento: Aceite + Documentação</>
        ) : (
          <>
            Etapa atual: {STEPPER_STEPS.find(s => s.step === currentStep)?.label || ''}
          </>
        )}
      </div>
    </div>
  );
}
