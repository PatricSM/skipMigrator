import { Bell, BellOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNotificationPermission } from '@/hooks/useNotificationPermission';
import { toast } from 'sonner';

export function NotificationToggle() {
  const { supported, enabled, permission, requestPermission, disable } = useNotificationPermission();

  if (!supported) return null;

  const handleToggle = async () => {
    if (enabled) {
      disable();
      toast.info('Notificações desativadas');
    } else {
      const granted = await requestPermission();
      if (granted) {
        toast.success('Notificações ativadas! Você receberá alertas sobre avanços da locação.');
      } else if (permission === 'denied') {
        toast.error('Notificações bloqueadas pelo navegador. Habilite nas configurações do navegador.');
      }
    }
  };

  return (
    <Button
      variant="ghost"
      size="icon"
      onClick={handleToggle}
      title={enabled ? 'Desativar notificações' : 'Ativar notificações'}
      className="relative"
    >
      {enabled ? (
        <Bell className="h-5 w-5 text-primary" />
      ) : (
        <BellOff className="h-5 w-5 text-muted-foreground" />
      )}
    </Button>
  );
}
