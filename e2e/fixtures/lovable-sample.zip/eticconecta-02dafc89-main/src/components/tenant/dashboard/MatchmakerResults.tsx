 import { useNavigate } from 'react-router-dom';
 import { Heart, MapPin, ArrowRight, Sparkles } from 'lucide-react';
 import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
 import { Button } from '@/components/ui/button';
 import { Badge } from '@/components/ui/badge';
 import { AspectRatio } from '@/components/ui/aspect-ratio';
 import { UserPreferences, MatchedProperty } from '@/types/tenant-dashboard';
 import { cn } from '@/lib/utils';
 
 interface MatchmakerResultsProps {
   properties: MatchedProperty[];
   preferences: UserPreferences;
   onInterest: (propertyId: string) => void;
 }
 
 const FALLBACK_IMAGE = 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=400&h=300&fit=crop';
 
 export function MatchmakerResults({ properties, preferences, onInterest }: MatchmakerResultsProps) {
   const navigate = useNavigate();
 
   const formatCurrency = (value: number) => {
     return new Intl.NumberFormat('pt-BR', {
       style: 'currency',
       currency: 'BRL',
       minimumFractionDigits: 0,
     }).format(value);
   };
 
   if (properties.length === 0) {
     return (
       <Card className="rounded-2xl">
         <CardContent className="p-8 text-center">
           <div className="w-16 h-16 rounded-full bg-muted mx-auto flex items-center justify-center mb-4">
             <Sparkles className="h-8 w-8 text-muted-foreground" />
           </div>
           <h3 className="text-lg font-semibold mb-2">
             Nenhum imóvel encontrado
           </h3>
           <p className="text-sm text-muted-foreground mb-6">
             Não encontramos imóveis com exatamente essas características.
             Tente ajustar seus filtros ou nos contate para ajuda personalizada.
           </p>
           <Button onClick={() => navigate('/locatario/selecionar-imovel')}>
             Ver Todos os Imóveis
           </Button>
         </CardContent>
       </Card>
     );
   }
 
   return (
     <div className="space-y-4">
       <div className="flex items-center justify-between">
         <h2 className="text-lg font-semibold flex items-center gap-2">
           <Sparkles className="h-5 w-5 text-primary" />
           Imóveis com seu perfil
         </h2>
         <Button variant="ghost" size="sm" asChild>
           <a href="/locatario/selecionar-imovel">
             Ver todos
             <ArrowRight className="ml-1 h-4 w-4" />
           </a>
         </Button>
       </div>
 
       {/* Horizontal Scroll on Mobile */}
       <div className="flex gap-4 overflow-x-auto pb-4 -mx-4 px-4 md:mx-0 md:px-0 md:grid md:grid-cols-2 md:overflow-visible">
         {properties.map((property) => (
           <Card 
             key={property.id}
             className="flex-shrink-0 w-[280px] md:w-auto rounded-2xl overflow-hidden hover:shadow-lg transition-shadow"
           >
             {/* Image */}
             <div className="relative">
               <AspectRatio ratio={4 / 3}>
                 <img
                   src={property.images[0] || FALLBACK_IMAGE}
                   alt={property.shortAddress}
                   className="object-cover w-full h-full"
                 />
               </AspectRatio>
 
               {/* Match Score Badge */}
               <Badge 
                 className={cn(
                   "absolute top-2 left-2",
                   property.matchScore >= 90 
                     ? "bg-step-complete text-white" 
                     : property.matchScore >= 70 
                       ? "bg-primary text-primary-foreground"
                       : "bg-secondary text-secondary-foreground"
                 )}
               >
                 {property.matchScore}% match
               </Badge>
 
               {/* Code Badge */}
               <Badge 
                 variant="secondary"
                 className="absolute top-2 right-2 font-mono bg-background/90 backdrop-blur-sm"
               >
                 {property.code}
               </Badge>
             </div>
 
             <CardContent className="p-4 space-y-3">
               {/* Price */}
               <div className="flex items-center justify-between">
                 <span className="text-lg font-bold text-primary">
                   {formatCurrency(property.price)}
                   <span className="text-xs font-normal text-muted-foreground">/mês</span>
                 </span>
                 {property.condoFee && (
                   <span className="text-xs text-muted-foreground">
                     + {formatCurrency(property.condoFee)} cond.
                   </span>
                 )}
               </div>
 
               {/* Address */}
               <div className="flex items-start gap-1.5 text-sm text-muted-foreground">
                 <MapPin className="h-4 w-4 mt-0.5 shrink-0" />
                 <span className="line-clamp-2">{property.shortAddress}</span>
               </div>
 
               {/* Matched Features */}
               {property.matchedFeatures.length > 0 && (
                 <div className="flex flex-wrap gap-1">
                   {property.matchedFeatures.slice(0, 3).map((feature) => (
                     <Badge key={feature} variant="outline" className="text-xs">
                       {feature}
                     </Badge>
                   ))}
                   {property.matchedFeatures.length > 3 && (
                     <Badge variant="outline" className="text-xs">
                       +{property.matchedFeatures.length - 3}
                     </Badge>
                   )}
                 </div>
               )}
 
               {/* CTA */}
               <Button 
                 className="w-full" 
                 size="sm"
                 onClick={() => onInterest(property.id)}
               >
                 <Heart className="mr-2 h-4 w-4" />
                 Tenho Interesse
               </Button>
             </CardContent>
           </Card>
         ))}
       </div>
     </div>
   );
 }