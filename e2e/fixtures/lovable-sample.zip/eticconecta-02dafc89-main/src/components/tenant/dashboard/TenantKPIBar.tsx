import { Link } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { FileText, AlertTriangle, CheckCircle2, ArrowRight } from 'lucide-react';
import { cn } from '@/lib/utils';
import { RentalTracking } from '@/types/tracking';

interface TenantKPIBarProps {
  activeProposals: RentalTracking[];
  approvedProposals: RentalTracking[];
  rejectedProposals: RentalTracking[];
  onFilterChange?: (filter: string) => void;
  activeFilter?: string;
}

const PENDING_ACTION_TEXT: Record<number, string> = {
  2: 'Responder contraproposta',
  3: 'Enviar documentos pendentes',
  7: 'Assinar contrato',
};

export function TenantKPIBar({
  activeProposals,
  approvedProposals,
  rejectedProposals,
  onFilterChange,
  activeFilter,
}: TenantKPIBarProps) {
  const pendingActions = activeProposals
    .filter(p => p.hasPending)
    .map(p => ({
      proposalCode: p.propertyCode,
      text: PENDING_ACTION_TEXT[p.currentStep] || p.pendingDescription || 'Resolver pendência',
      link: `/locatario/acompanhamento/${p.id}`,
    }));

  const kpis = [
    {
      icon: FileText,
      label: 'Em andamento',
      value: activeProposals.length,
      color: 'text-[hsl(var(--step-active))]',
      bg: 'bg-[hsl(var(--step-active))]/10',
      filterKey: 'active',
    },
    {
      icon: CheckCircle2,
      label: 'Aprovadas',
      value: approvedProposals.length,
      color: 'text-[hsl(var(--step-complete))]',
      bg: 'bg-[hsl(var(--step-complete))]/10',
      filterKey: 'approved',
    },
    {
      icon: AlertTriangle,
      label: 'Pendências',
      value: pendingActions.length,
      color: 'text-[hsl(var(--sla-warning))]',
      bg: 'bg-[hsl(var(--sla-warning))]/10',
      filterKey: 'pending',
    },
  ];

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-3 gap-3">
        {kpis.map((kpi) => {
          const isActive = activeFilter === kpi.filterKey;
          return (
            <Card
              key={kpi.label}
              className={cn(
                'border-border/60 cursor-pointer transition-all hover:shadow-md',
                isActive && 'ring-2 ring-primary border-primary/40 shadow-md'
              )}
              onClick={() => onFilterChange?.(kpi.filterKey)}
            >
              <CardContent className="p-3 flex flex-col items-center gap-1">
                <div className={`w-8 h-8 rounded-full ${kpi.bg} flex items-center justify-center`}>
                  <kpi.icon className={`h-4 w-4 ${kpi.color}`} />
                </div>
                <span className="text-xl font-bold text-foreground">{kpi.value}</span>
                <span className="text-[10px] text-muted-foreground text-center">{kpi.label}</span>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Pending actions with links - show when pending filter is active or always */}
      {pendingActions.length > 0 && (activeFilter === 'pending' || !activeFilter) && (
        <div className="space-y-2">
          {pendingActions.map((action, i) => (
            <Link
              key={i}
              to={action.link}
              className="flex items-center gap-2 px-3 py-2.5 rounded-lg bg-[hsl(var(--sla-warning))]/10 border border-[hsl(var(--sla-warning))]/20 hover:bg-[hsl(var(--sla-warning))]/15 transition-colors group"
            >
              <AlertTriangle className="h-4 w-4 text-[hsl(var(--sla-warning))] flex-shrink-0 animate-pulse" />
              <div className="flex-1 min-w-0">
                <span className="text-xs font-medium text-foreground">{action.proposalCode}</span>
                <span className="text-xs text-muted-foreground"> — {action.text}</span>
              </div>
              <ArrowRight className="h-3.5 w-3.5 text-muted-foreground group-hover:text-foreground transition-colors flex-shrink-0" />
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
