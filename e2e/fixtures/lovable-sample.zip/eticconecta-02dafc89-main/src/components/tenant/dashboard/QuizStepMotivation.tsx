 import { Briefcase, Users, Maximize2, Sparkles } from 'lucide-react';
 import { cn } from '@/lib/utils';
 
 interface QuizStepMotivationProps {
   value: string | null;
   onChange: (value: 'trabalho' | 'familia' | 'espaco' | 'outro') => void;
 }
 
 const MOTIVATION_OPTIONS = [
   { 
     id: 'trabalho' as const, 
     label: 'Trabalho', 
     description: 'Mudança profissional',
     icon: Briefcase,
   },
   { 
     id: 'familia' as const, 
     label: 'Família', 
     description: 'Mais espaço para a família',
     icon: Users,
   },
   { 
     id: 'espaco' as const, 
     label: 'Mais Espaço', 
     description: 'Preciso de mais ambiente',
     icon: Maximize2,
   },
   { 
     id: 'outro' as const, 
     label: 'Outro', 
     description: 'Outros motivos',
     icon: Sparkles,
   },
 ];
 
 export function QuizStepMotivation({ value, onChange }: QuizStepMotivationProps) {
   return (
     <div className="space-y-4">
       <div className="text-center mb-6">
         <h3 className="text-lg font-semibold text-foreground">
           O que te faz buscar um novo lar?
         </h3>
         <p className="text-sm text-muted-foreground mt-1">
           Selecione a opção que mais se encaixa
         </p>
       </div>
 
       <div className="grid grid-cols-2 gap-3">
         {MOTIVATION_OPTIONS.map((option) => {
           const Icon = option.icon;
           const isSelected = value === option.id;
 
           return (
             <button
               key={option.id}
               type="button"
               onClick={() => onChange(option.id)}
               className={cn(
                 "flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all",
                 "hover:border-primary/50 hover:bg-primary/5",
                 isSelected 
                   ? "border-primary bg-primary/10" 
                   : "border-border bg-card"
               )}
             >
               <div className={cn(
                 "w-12 h-12 rounded-full flex items-center justify-center transition-colors",
                 isSelected ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
               )}>
                 <Icon className="h-6 w-6" />
               </div>
               <div className="text-center">
                 <p className={cn(
                   "font-medium text-sm",
                   isSelected ? "text-primary" : "text-foreground"
                 )}>
                   {option.label}
                 </p>
                 <p className="text-xs text-muted-foreground mt-0.5">
                   {option.description}
                 </p>
               </div>
             </button>
           );
         })}
       </div>
     </div>
   );
 }