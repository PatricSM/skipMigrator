 import { MapPin, Home, Receipt } from 'lucide-react';
 import { Card, CardContent } from '@/components/ui/card';
 import { Badge } from '@/components/ui/badge';
 import { AspectRatio } from '@/components/ui/aspect-ratio';
 import { RentalTracking } from '@/types/tracking';
 import { TENANT_JOURNEY_STEPS } from '@/types/tenant-dashboard';
 import { JourneyStepperHorizontal } from './JourneyStepperHorizontal';
 import { SmartCTAButton } from './SmartCTAButton';
 import { cn } from '@/lib/utils';
 
 interface JourneyCardProps {
   rental: RentalTracking;
 }
 
 const FALLBACK_IMAGE = 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&h=450&fit=crop';
 
 export function JourneyCard({ rental }: JourneyCardProps) {
   const currentStepData = TENANT_JOURNEY_STEPS.find(s => s.step === rental.currentStep);
   
   const formatCurrency = (value: number | null) => {
     if (!value) return null;
     return new Intl.NumberFormat('pt-BR', {
       style: 'currency',
       currency: 'BRL',
       minimumFractionDigits: 0,
     }).format(value);
   };
 
   const totalValue = (rental.rentValue || 0) + (rental.condoFee || 0) + (rental.iptu || 0);
 
   return (
     <Card className="bg-card rounded-2xl shadow-lg border overflow-hidden">
       {/* Property Image */}
       <div className="relative">
         <AspectRatio ratio={16 / 9}>
           <img
             src={rental.propertyImage || FALLBACK_IMAGE}
             alt={rental.propertyAddress}
             className="object-cover w-full h-full"
           />
         </AspectRatio>
         
         {/* Property Code Badge */}
         <Badge 
           variant="secondary" 
           className="absolute top-3 left-3 bg-background/90 backdrop-blur-sm font-mono"
         >
           {rental.propertyCode}
         </Badge>
         
         {/* Status Badge */}
         {rental.isRejected ? (
           <Badge 
             variant="destructive" 
             className="absolute top-3 right-3"
           >
             Proposta Recusada
           </Badge>
         ) : rental.hasPending ? (
           <Badge 
             className="absolute top-3 right-3 bg-amber-500 text-white hover:bg-amber-600"
           >
             Ação Necessária
           </Badge>
         ) : null}
       </div>
 
       <CardContent className="p-6 space-y-6">
         {/* Property Info */}
         <div className="space-y-3">
           <h2 className="text-xl font-semibold text-foreground leading-tight line-clamp-2">
             Minha Jornada para o Novo Lar
           </h2>
           
           <div className="flex items-start gap-2 text-muted-foreground">
             <MapPin className="h-4 w-4 mt-0.5 shrink-0" />
             <span className="text-sm">{rental.propertyAddress}</span>
           </div>
 
           {/* Financial Summary */}
           {(rental.rentValue || rental.condoFee || rental.iptu) && (
             <div className="flex flex-wrap gap-3 text-sm">
               {rental.rentValue && (
                 <div className="flex items-center gap-1.5 text-muted-foreground">
                   <Home className="h-4 w-4" />
                   <span>Aluguel: <span className="text-foreground font-medium">{formatCurrency(rental.rentValue)}</span></span>
                 </div>
               )}
               {rental.condoFee && (
                 <div className="flex items-center gap-1.5 text-muted-foreground">
                   <span>Cond: <span className="text-foreground font-medium">{formatCurrency(rental.condoFee)}</span></span>
                 </div>
               )}
               {rental.iptu && (
                 <div className="flex items-center gap-1.5 text-muted-foreground">
                   <span>IPTU: <span className="text-foreground font-medium">{formatCurrency(rental.iptu)}</span></span>
                 </div>
               )}
             </div>
           )}
           
           {totalValue > 0 && (
             <div className="flex items-center gap-2 p-3 bg-primary/5 rounded-lg">
               <Receipt className="h-4 w-4 text-primary" />
               <span className="text-sm text-muted-foreground">Total mensal:</span>
               <span className="text-base font-semibold text-primary">{formatCurrency(totalValue)}</span>
             </div>
           )}
         </div>
 
         {/* Motivational Message */}
         {currentStepData && (
           <div className={cn(
             "p-4 rounded-xl text-center",
             rental.isRejected ? "bg-destructive/10" : "bg-secondary"
           )}>
             <p className={cn(
               "text-sm",
               rental.isRejected ? "text-destructive" : "text-muted-foreground"
             )}>
               {rental.isRejected 
                 ? rental.rejectionReason || 'Esta proposta não foi aceita.' 
                 : currentStepData.motivationalMessage
               }
             </p>
           </div>
         )}
 
         {/* Journey Stepper */}
         <JourneyStepperHorizontal 
           currentStep={rental.currentStep} 
           isRejected={rental.isRejected}
         />
 
         {/* Smart CTA */}
         <SmartCTAButton
           currentStep={rental.currentStep}
           hasPendingDocs={rental.hasPending || (rental.pendingDocuments?.length ?? 0) > 0}
           isRejected={rental.isRejected}
           rentalId={rental.id}
           contractPreviewUrl={rental.contractPreviewUrl}
           contractSignUrl={rental.contractSignUrl}
         />
       </CardContent>
     </Card>
   );
 }