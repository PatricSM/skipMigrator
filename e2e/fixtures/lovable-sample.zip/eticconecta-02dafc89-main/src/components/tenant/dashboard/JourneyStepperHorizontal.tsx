 import { Check } from 'lucide-react';
 import { cn } from '@/lib/utils';
 import { TENANT_JOURNEY_STEPS } from '@/types/tenant-dashboard';
 
 interface JourneyStepperHorizontalProps {
   currentStep: number;
   isRejected?: boolean;
 }
 
 export function JourneyStepperHorizontal({ currentStep, isRejected }: JourneyStepperHorizontalProps) {
   return (
     <div className="w-full">
       {/* Desktop: Horizontal stepper */}
       <div className="hidden md:flex items-center justify-between relative">
         {/* Progress line background */}
         <div className="absolute left-0 right-0 top-4 h-0.5 bg-border z-0" />
         
         {/* Progress line filled */}
         <div 
           className={cn(
             "absolute left-0 top-4 h-0.5 z-0 transition-all duration-500",
             isRejected ? "bg-destructive" : "bg-step-complete"
           )}
           style={{ width: `${Math.max(0, ((currentStep - 1) / (TENANT_JOURNEY_STEPS.length - 1)) * 100)}%` }}
         />
         
         {TENANT_JOURNEY_STEPS.map((step) => {
           const isCompleted = currentStep > step.step;
           const isCurrent = currentStep === step.step;
           const StepIcon = step.icon;
           
           return (
             <div key={step.step} className="flex flex-col items-center relative z-10">
               <div
                 className={cn(
                   "w-8 h-8 rounded-full flex items-center justify-center transition-all duration-300",
                   isCompleted && "bg-step-complete text-white",
                   isCurrent && !isRejected && "bg-primary text-primary-foreground ring-4 ring-primary/20",
                   isCurrent && isRejected && "bg-destructive text-white ring-4 ring-destructive/20",
                   !isCompleted && !isCurrent && "bg-muted text-muted-foreground"
                 )}
               >
                 {isCompleted ? (
                   <Check className="h-4 w-4" />
                 ) : (
                   <StepIcon className="h-4 w-4" />
                 )}
               </div>
               <span 
                 className={cn(
                   "text-xs mt-2 text-center font-medium transition-colors max-w-[50px]",
                   isCompleted && "text-step-complete",
                   isCurrent && "text-foreground",
                   !isCompleted && !isCurrent && "text-muted-foreground"
                 )}
               >
                 {step.shortTitle}
               </span>
             </div>
           );
         })}
       </div>
       
       {/* Mobile: Compact horizontal with current step highlighted */}
       <div className="md:hidden">
         <div className="flex items-center gap-1 mb-2">
           {TENANT_JOURNEY_STEPS.map((step) => {
             const isCompleted = currentStep > step.step;
             const isCurrent = currentStep === step.step;
             
             return (
               <div
                 key={step.step}
                 className={cn(
                   "flex-1 h-1.5 rounded-full transition-all",
                   isCompleted && "bg-step-complete",
                   isCurrent && !isRejected && "bg-primary",
                   isCurrent && isRejected && "bg-destructive",
                   !isCompleted && !isCurrent && "bg-muted"
                 )}
               />
             );
           })}
         </div>
         
         {/* Current step label */}
         <div className="flex items-center justify-between">
           <div className="flex items-center gap-2">
             {(() => {
               const currentStepData = TENANT_JOURNEY_STEPS.find(s => s.step === currentStep);
               if (!currentStepData) return null;
               const StepIcon = currentStepData.icon;
               return (
                 <>
                   <div className={cn(
                     "w-6 h-6 rounded-full flex items-center justify-center",
                     isRejected ? "bg-destructive/10 text-destructive" : "bg-primary/10 text-primary"
                   )}>
                     <StepIcon className="h-3.5 w-3.5" />
                   </div>
                   <span className="text-sm font-medium">{currentStepData.title}</span>
                 </>
               );
             })()}
           </div>
           <span className="text-xs text-muted-foreground">
             Etapa {currentStep} de {TENANT_JOURNEY_STEPS.length}
           </span>
         </div>
       </div>
     </div>
   );
 }