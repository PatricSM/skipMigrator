 import { formatDistanceToNow } from 'date-fns';
 import { ptBR } from 'date-fns/locale';
 import { RentalEvent } from '@/types/tracking';
 import { EVENT_TYPE_CONFIG } from '@/types/tenant-dashboard';
 import { cn } from '@/lib/utils';
 
 interface UpdateFeedItemProps {
   event: RentalEvent;
   isLast?: boolean;
 }
 
 export function UpdateFeedItem({ event, isLast }: UpdateFeedItemProps) {
   const config = EVENT_TYPE_CONFIG[event.eventType] || EVENT_TYPE_CONFIG.default;
   const Icon = config.icon;
 
   const relativeTime = formatDistanceToNow(event.createdAt, {
     addSuffix: true,
     locale: ptBR,
   });
 
   return (
     <div className={cn(
       "flex gap-3 py-4",
       !isLast && "border-b border-border"
     )}>
       {/* Icon */}
       <div className={cn(
         "w-10 h-10 rounded-full flex items-center justify-center shrink-0",
         config.bgClass
       )}>
         <Icon className={cn("h-5 w-5", config.colorClass)} />
       </div>
 
       {/* Content */}
       <div className="flex-1 min-w-0">
         <p className="text-sm text-foreground leading-relaxed">
           {event.description}
         </p>
         <p className="text-xs text-muted-foreground mt-1">
           {relativeTime}
         </p>
       </div>
     </div>
   );
 }