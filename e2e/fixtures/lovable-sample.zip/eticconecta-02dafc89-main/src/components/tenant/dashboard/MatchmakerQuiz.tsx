 import { useState } from 'react';
 import { ChevronLeft, ChevronRight, Search, Sparkles } from 'lucide-react';
 import { Card, CardContent } from '@/components/ui/card';
 import { Button } from '@/components/ui/button';
 import { Progress } from '@/components/ui/progress';
 import { UserPreferences, DEFAULT_USER_PREFERENCES } from '@/types/tenant-dashboard';
 import { QuizStepMotivation } from './QuizStepMotivation';
 import { QuizStepBudget } from './QuizStepBudget';
 import { QuizStepFeatures } from './QuizStepFeatures';
 import { QuizStepLocation } from './QuizStepLocation';
 
 interface MatchmakerQuizProps {
   onComplete: (preferences: UserPreferences) => void;
 }
 
 const QUIZ_STEPS = [
   { id: 'motivation', title: 'Motivação' },
   { id: 'budget', title: 'Investimento' },
   { id: 'features', title: 'Essenciais' },
   { id: 'location', title: 'Localização' },
 ];
 
 export function MatchmakerQuiz({ onComplete }: MatchmakerQuizProps) {
   const [currentStep, setCurrentStep] = useState(0);
   const [preferences, setPreferences] = useState<UserPreferences>(DEFAULT_USER_PREFERENCES);
 
   const progress = ((currentStep + 1) / QUIZ_STEPS.length) * 100;
 
   const canProceed = () => {
     switch (currentStep) {
       case 0:
         return preferences.motivation !== null;
       case 1:
         return preferences.budget.min > 0 && preferences.budget.max > preferences.budget.min;
       case 2:
         return true; // Features are optional
       case 3:
         return preferences.neighborhoods.length > 0;
       default:
         return false;
     }
   };
 
   const handleNext = () => {
     if (currentStep < QUIZ_STEPS.length - 1) {
       setCurrentStep(currentStep + 1);
     } else {
       onComplete(preferences);
     }
   };
 
   const handleBack = () => {
     if (currentStep > 0) {
       setCurrentStep(currentStep - 1);
     }
   };
 
   const renderStepContent = () => {
     switch (currentStep) {
       case 0:
         return (
           <QuizStepMotivation
             value={preferences.motivation}
             onChange={(value) => setPreferences({ ...preferences, motivation: value })}
           />
         );
       case 1:
         return (
           <QuizStepBudget
             value={preferences.budget}
             onChange={(value) => setPreferences({ ...preferences, budget: value })}
           />
         );
       case 2:
         return (
           <QuizStepFeatures
             value={preferences.features}
             onChange={(value) => setPreferences({ ...preferences, features: value })}
           />
         );
       case 3:
         return (
           <QuizStepLocation
             value={preferences.neighborhoods}
             onChange={(value) => setPreferences({ ...preferences, neighborhoods: value })}
           />
         );
       default:
         return null;
     }
   };
 
   return (
     <Card className="rounded-2xl shadow-lg overflow-hidden">
       {/* Header */}
       <div className="bg-gradient-to-r from-primary to-primary/80 p-6 text-primary-foreground">
         <div className="flex items-center gap-3 mb-4">
           <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
             <Sparkles className="h-5 w-5" />
           </div>
           <div>
             <h2 className="text-xl font-semibold">
               Vamos encontrar o imóvel certo para você?
             </h2>
             <p className="text-sm text-primary-foreground/80">
               Responda 4 perguntas rápidas
             </p>
           </div>
         </div>
 
         {/* Progress */}
         <div className="space-y-2">
           <div className="flex justify-between text-xs text-primary-foreground/80">
             <span>Etapa {currentStep + 1} de {QUIZ_STEPS.length}</span>
             <span>{QUIZ_STEPS[currentStep].title}</span>
           </div>
           <Progress value={progress} className="h-2 bg-white/20" />
         </div>
       </div>
 
       {/* Content */}
       <CardContent className="p-6">
         {renderStepContent()}
 
         {/* Navigation */}
         <div className="flex items-center justify-between mt-8 gap-4">
           <Button
             variant="outline"
             onClick={handleBack}
             disabled={currentStep === 0}
             className="flex-1"
           >
             <ChevronLeft className="mr-2 h-4 w-4" />
             Voltar
           </Button>
 
           <Button
             onClick={handleNext}
             disabled={!canProceed()}
             className="flex-1"
           >
             {currentStep === QUIZ_STEPS.length - 1 ? (
               <>
                 <Search className="mr-2 h-4 w-4" />
                 Ver Resultados
               </>
             ) : (
               <>
                 Próximo
                 <ChevronRight className="ml-2 h-4 w-4" />
               </>
             )}
           </Button>
         </div>
       </CardContent>
     </Card>
   );
 }