 import { Skeleton } from '@/components/ui/skeleton';
 import { Card, CardContent } from '@/components/ui/card';
 
 export function DashboardSkeleton() {
   return (
     <div className="space-y-6">
       {/* Journey Card Skeleton */}
       <Card className="rounded-2xl overflow-hidden">
         <Skeleton className="w-full h-48" />
         <CardContent className="p-6 space-y-4">
           <Skeleton className="h-6 w-3/4" />
           <Skeleton className="h-4 w-1/2" />
           <div className="flex gap-2">
             {[1, 2, 3, 4, 5, 6, 7].map((i) => (
               <Skeleton key={i} className="h-8 w-8 rounded-full" />
             ))}
           </div>
           <Skeleton className="h-12 w-full rounded-xl" />
         </CardContent>
       </Card>
 
       {/* Updates Feed Skeleton */}
       <Card className="rounded-2xl">
         <CardContent className="p-6 space-y-4">
           <Skeleton className="h-5 w-32" />
           {[1, 2, 3].map((i) => (
             <div key={i} className="flex gap-3">
               <Skeleton className="h-10 w-10 rounded-full" />
               <div className="flex-1 space-y-2">
                 <Skeleton className="h-4 w-3/4" />
                 <Skeleton className="h-3 w-1/4" />
               </div>
             </div>
           ))}
         </CardContent>
       </Card>
     </div>
   );
 }