 import { BookOpen, CheckSquare, Map, ArrowRight } from 'lucide-react';
 import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
 import { Button } from '@/components/ui/button';
 import { TENANT_RESOURCES } from '@/types/tenant-dashboard';
 import { cn } from '@/lib/utils';
 
 const ICONS = {
   manual: BookOpen,
   checklist: CheckSquare,
   guia: Map,
 };
 
 export function ResourcesCard() {
   return (
     <Card className="rounded-2xl bg-gradient-to-br from-step-complete/5 to-step-complete/10 border-step-complete/20">
       <CardHeader className="pb-2">
         <CardTitle className="text-lg font-semibold flex items-center gap-2 text-step-complete">
           🎉 Tudo pronto para a mudança?
         </CardTitle>
         <p className="text-sm text-muted-foreground">
           Organize-se com nossos recursos exclusivos
         </p>
       </CardHeader>
       <CardContent className="space-y-3">
         {TENANT_RESOURCES.map((resource) => {
           const Icon = ICONS[resource.id as keyof typeof ICONS] || BookOpen;
           
           return (
             <a
               key={resource.id}
               href={resource.href}
               className={cn(
                 "flex items-center gap-3 p-3 rounded-xl bg-card hover:bg-secondary/50 transition-colors",
                 "border border-border hover:border-step-complete/30"
               )}
             >
               <div className="w-10 h-10 rounded-full bg-step-complete/10 flex items-center justify-center shrink-0">
                 <Icon className="h-5 w-5 text-step-complete" />
               </div>
               <div className="flex-1 min-w-0">
                 <p className="font-medium text-foreground text-sm">{resource.title}</p>
                 <p className="text-xs text-muted-foreground">{resource.description}</p>
               </div>
               <ArrowRight className="h-4 w-4 text-muted-foreground shrink-0" />
             </a>
           );
         })}
       </CardContent>
     </Card>
   );
 }