 import { useState } from 'react';
 import { Link } from 'react-router-dom';
 import { Building2, Menu, X, LogOut, Home, Search, HelpCircle, UserCog } from 'lucide-react';
 import { Button } from '@/components/ui/button';
 import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
 import { useAuth } from '@/hooks/useAuth';
import logoEtic from '@/assets/logo-etic-blue.png';
import { NotificationToggle } from '@/components/notifications/NotificationToggle';
 
 export function TenantHeader() {
   const { profile, logout } = useAuth();
   const [open, setOpen] = useState(false);
 
   const handleLogout = () => {
     setOpen(false);
     logout();
   };
 
   return (
     <header className="border-b bg-card sticky top-0 z-50">
       <div className="container flex h-16 items-center justify-between px-4">
         {/* Logo */}
         <Link to="/locatario/painel" className="flex items-center gap-2">
           <img src={logoEtic} alt="Etic Imóveis" className="h-8" />
         </Link>
         
         {/* Desktop Menu */}
         <div className="hidden md:flex items-center gap-4">
           <Button variant="ghost" size="sm" asChild>
             <Link to="/locatario/selecionar-imovel">
               <Search className="mr-2 h-4 w-4" />
               Buscar Imóveis
             </Link>
           </Button>
            <NotificationToggle />
            <span className="text-sm text-muted-foreground">
              Olá, {profile?.full_name?.split(' ')[0] || 'Usuário'}
            </span>
           <Button variant="outline" size="sm" onClick={logout}>
             <LogOut className="mr-2 h-4 w-4" />
             Sair
           </Button>
         </div>
 
         {/* Mobile Menu */}
         <Sheet open={open} onOpenChange={setOpen}>
           <SheetTrigger asChild>
             <Button variant="ghost" size="icon" className="md:hidden">
               <Menu className="h-5 w-5" />
               <span className="sr-only">Menu</span>
             </Button>
           </SheetTrigger>
           <SheetContent side="right" className="w-[280px]">
             <SheetHeader>
               <SheetTitle className="text-left">
                 Olá, {profile?.full_name?.split(' ')[0] || 'Usuário'}
               </SheetTitle>
             </SheetHeader>
             <nav className="flex flex-col gap-2 mt-6">
               <Button variant="ghost" className="justify-start" asChild onClick={() => setOpen(false)}>
                 <Link to="/locatario/painel">
                   <Home className="mr-3 h-5 w-5" />
                   Meu Painel
                 </Link>
               </Button>
                <Button variant="ghost" className="justify-start" asChild onClick={() => setOpen(false)}>
                  <Link to="/locatario/selecionar-imovel">
                    <Search className="mr-3 h-5 w-5" />
                    Buscar Imóveis
                  </Link>
                </Button>
                <Button variant="ghost" className="justify-start" asChild onClick={() => setOpen(false)}>
                  <Link to="/locatario/meu-cadastro">
                    <UserCog className="mr-3 h-5 w-5" />
                    Meu Cadastro
                  </Link>
                </Button>
                <Button variant="ghost" className="justify-start" asChild onClick={() => setOpen(false)}>
                  <Link to="/locador/ajuda">
                   <HelpCircle className="mr-3 h-5 w-5" />
                   Ajuda
                 </Link>
               </Button>
               <div className="border-t my-4" />
               <Button variant="ghost" className="justify-start text-destructive" onClick={handleLogout}>
                 <LogOut className="mr-3 h-5 w-5" />
                 Sair da Conta
               </Button>
             </nav>
           </SheetContent>
         </Sheet>
       </div>
     </header>
   );
 }