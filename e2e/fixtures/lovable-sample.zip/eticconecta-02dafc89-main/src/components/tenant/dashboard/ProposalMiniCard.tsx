 import { useNavigate } from 'react-router-dom';
 import { ChevronRight, AlertTriangle, CheckCircle2, Clock, FileText } from 'lucide-react';
 import { Card, CardContent } from '@/components/ui/card';
 import { Badge } from '@/components/ui/badge';
 import { RentalTracking } from '@/types/tracking';
 import { TENANT_JOURNEY_STEPS } from '@/types/tenant-dashboard';
 import { cn } from '@/lib/utils';
 
 interface ProposalMiniCardProps {
   proposal: RentalTracking;
 }
 
 export function ProposalMiniCard({ proposal }: ProposalMiniCardProps) {
   const navigate = useNavigate();
   const currentStepData = TENANT_JOURNEY_STEPS.find(s => s.step === proposal.currentStep);
 
   const getStatusConfig = () => {
     if (proposal.isRejected) {
       return {
         icon: AlertTriangle,
         iconClass: 'text-destructive',
         bgClass: 'bg-destructive/10',
         badge: <Badge variant="destructive" className="text-xs">Recusada</Badge>,
       };
     }
     if (proposal.currentStep >= 8) {
       return {
         icon: CheckCircle2,
         iconClass: 'text-step-complete',
         bgClass: 'bg-step-complete/10',
         badge: <Badge className="bg-step-complete/10 text-step-complete border-step-complete/30 text-xs">Concluída</Badge>,
       };
     }
     if (proposal.hasPending) {
       return {
         icon: Clock,
         iconClass: 'text-amber-500',
         bgClass: 'bg-amber-500/10',
         badge: <Badge className="bg-amber-500/10 text-amber-600 border-amber-500/30 text-xs">Pendências</Badge>,
       };
     }
     return {
       icon: FileText,
       iconClass: 'text-primary',
       bgClass: 'bg-primary/10',
       badge: <Badge className="bg-primary/10 text-primary border-primary/30 text-xs">Em andamento</Badge>,
     };
   };
 
   const status = getStatusConfig();
   const Icon = status.icon;
 
   return (
     <Card 
       className={cn(
         "cursor-pointer transition-all hover:shadow-md hover:border-primary/30 rounded-xl",
         proposal.hasPending && !proposal.isRejected && "border-amber-500/30"
       )}
       onClick={() => navigate(`/acompanhamento/${proposal.id}`)}
     >
       <CardContent className="p-4">
         <div className="flex items-center gap-3">
           {/* Status Icon */}
           <div className={cn(
             "w-10 h-10 rounded-full flex items-center justify-center shrink-0",
             status.bgClass
           )}>
             <Icon className={cn("h-5 w-5", status.iconClass)} />
           </div>
           
           {/* Content */}
           <div className="flex-1 min-w-0">
             <div className="flex items-center gap-2 mb-1">
               <Badge variant="outline" className="font-mono text-xs">
                 {proposal.propertyCode}
               </Badge>
               {status.badge}
             </div>
             <p className="text-sm font-medium text-foreground truncate">
               {proposal.propertyAddress}
             </p>
             <p className="text-xs text-muted-foreground mt-0.5">
               {currentStepData?.shortTitle} • Etapa {proposal.currentStep}/{TENANT_JOURNEY_STEPS.length}
             </p>
           </div>
           
           {/* Chevron */}
           <ChevronRight className="h-5 w-5 text-muted-foreground shrink-0" />
         </div>
       </CardContent>
     </Card>
   );
 }