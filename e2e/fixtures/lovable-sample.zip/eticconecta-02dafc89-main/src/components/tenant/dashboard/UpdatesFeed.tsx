 import { useState } from 'react';
 import { ChevronDown, ChevronUp, Bell } from 'lucide-react';
 import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
 import { Button } from '@/components/ui/button';
 import { RentalEvent } from '@/types/tracking';
 import { UpdateFeedItem } from './UpdateFeedItem';
 
 interface UpdatesFeedProps {
   events: RentalEvent[];
   maxVisible?: number;
 }
 
 export function UpdatesFeed({ events, maxVisible = 5 }: UpdatesFeedProps) {
   const [expanded, setExpanded] = useState(false);
 
   if (events.length === 0) {
     return (
       <Card className="rounded-2xl">
         <CardContent className="p-6">
           <div className="flex flex-col items-center justify-center py-8 text-center">
             <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center mb-3">
               <Bell className="h-6 w-6 text-muted-foreground" />
             </div>
             <p className="text-sm text-muted-foreground">
               As atualizações da sua proposta aparecerão aqui.
             </p>
           </div>
         </CardContent>
       </Card>
     );
   }
 
   const visibleEvents = expanded ? events : events.slice(0, maxVisible);
   const hasMore = events.length > maxVisible;
 
   return (
     <Card className="rounded-2xl">
       <CardHeader className="pb-2">
         <CardTitle className="text-lg font-semibold flex items-center gap-2">
           <Bell className="h-5 w-5 text-primary" />
           Atualizações
         </CardTitle>
       </CardHeader>
       <CardContent className="px-6 pb-4">
         <div className="divide-y-0">
           {visibleEvents.map((event, index) => (
             <UpdateFeedItem 
               key={event.id} 
               event={event} 
               isLast={index === visibleEvents.length - 1}
             />
           ))}
         </div>
 
         {hasMore && (
           <Button
             variant="ghost"
             size="sm"
             className="w-full mt-2 text-muted-foreground"
             onClick={() => setExpanded(!expanded)}
           >
             {expanded ? (
               <>
                 <ChevronUp className="mr-2 h-4 w-4" />
                 Ver menos
               </>
             ) : (
               <>
                 <ChevronDown className="mr-2 h-4 w-4" />
                 Ver {events.length - maxVisible} atualizações anteriores
               </>
             )}
           </Button>
         )}
       </CardContent>
     </Card>
   );
 }