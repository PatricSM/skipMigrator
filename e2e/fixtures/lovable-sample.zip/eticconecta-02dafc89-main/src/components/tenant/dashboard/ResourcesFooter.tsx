 import { BookOpen, CheckSquare, Map } from 'lucide-react';
 import { TENANT_RESOURCES } from '@/types/tenant-dashboard';
 
 const ICONS = {
   manual: BookOpen,
   checklist: CheckSquare,
   guia: Map,
 };
 
 export function ResourcesFooter() {
   return (
     <div className="py-6 border-t border-border">
       <p className="text-xs text-muted-foreground text-center mb-3">
         Recursos úteis
       </p>
       <div className="flex items-center justify-center gap-6">
         {TENANT_RESOURCES.map((resource) => {
           const Icon = ICONS[resource.id as keyof typeof ICONS] || BookOpen;
           
           return (
             <a
               key={resource.id}
               href={resource.href}
               className="flex flex-col items-center gap-1 text-muted-foreground hover:text-primary transition-colors"
             >
               <Icon className="h-5 w-5" />
               <span className="text-xs">{resource.title.split(' ')[0]}</span>
             </a>
           );
         })}
       </div>
     </div>
   );
 }