 import { MapPin, Check } from 'lucide-react';
 import { cn } from '@/lib/utils';
 import { NEIGHBORHOOD_OPTIONS } from '@/types/tenant-dashboard';
 
 interface QuizStepLocationProps {
   value: string[];
   onChange: (value: string[]) => void;
 }
 
 export function QuizStepLocation({ value, onChange }: QuizStepLocationProps) {
   const toggleNeighborhood = (neighborhood: string) => {
     if (value.includes(neighborhood)) {
       onChange(value.filter(n => n !== neighborhood));
     } else {
       onChange([...value, neighborhood]);
     }
   };
 
   return (
     <div className="space-y-4">
       <div className="text-center mb-6">
         <h3 className="text-lg font-semibold text-foreground">
           Onde você quer morar?
         </h3>
         <p className="text-sm text-muted-foreground mt-1">
           Selecione os bairros de interesse
         </p>
       </div>
 
       <div className="grid grid-cols-2 gap-2">
         {NEIGHBORHOOD_OPTIONS.map((neighborhood) => {
           const isSelected = value.includes(neighborhood);
 
           return (
             <button
               key={neighborhood}
               type="button"
               onClick={() => toggleNeighborhood(neighborhood)}
               className={cn(
                 "flex items-center gap-2 px-3 py-3 rounded-xl border-2 transition-all text-sm",
                 "hover:border-primary/50",
                 isSelected 
                   ? "border-primary bg-primary/10" 
                   : "border-border bg-card hover:bg-secondary/50"
               )}
             >
               <div className={cn(
                 "w-5 h-5 rounded-full flex items-center justify-center shrink-0 transition-colors",
                 isSelected ? "bg-primary text-primary-foreground" : "bg-muted"
               )}>
                 {isSelected ? (
                   <Check className="h-3 w-3" />
                 ) : (
                   <MapPin className="h-3 w-3 text-muted-foreground" />
                 )}
               </div>
               <span className={cn(
                 "font-medium truncate",
                 isSelected ? "text-primary" : "text-foreground"
               )}>
                 {neighborhood}
               </span>
             </button>
           );
         })}
       </div>
 
       {value.length > 0 && (
         <p className="text-center text-sm text-muted-foreground mt-4">
           {value.length} {value.length === 1 ? 'bairro selecionado' : 'bairros selecionados'}
         </p>
       )}
     </div>
   );
 }