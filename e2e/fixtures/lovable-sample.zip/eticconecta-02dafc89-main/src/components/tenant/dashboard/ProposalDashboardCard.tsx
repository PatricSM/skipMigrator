import { useNavigate } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { ChevronRight, AlertTriangle, Home, Clock } from 'lucide-react';
import { cn } from '@/lib/utils';
import { RentalTracking } from '@/types/tracking';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';

const STEP_SHORT_LABELS: Record<number, string> = {
  1: 'Proposta Enviada',
  2: 'Aprovação Locador',
  3: 'Enviar Documentação',
  4: 'Aprovação da Ficha',
  5: 'Dados do Locador',
  6: 'Emissão Contrato',
  7: 'Assinatura Contrato',
  8: 'Agendamento Vistoria',
  9: 'Assinatura Vistoria',
  10: 'Entrega das Chaves',
};

const PENDING_ACTION_TEXT: Record<number, string> = {
  2: 'Responder contraproposta do locador',
  3: 'Enviar documentos pendentes',
  7: 'Assinar contrato',
};

type ProposalStatus = 'active' | 'approved' | 'rejected' | 'pending';

function getProposalStatus(proposal: RentalTracking): ProposalStatus {
  if (proposal.isRejected) return 'rejected';
  if (proposal.currentStep >= 8) return 'approved';
  if (proposal.hasPending) return 'pending';
  return 'active';
}

const statusConfig: Record<ProposalStatus, { color: string; badgeClass: string }> = {
  active: {
    color: 'bg-[hsl(var(--step-active))]',
    badgeClass: 'bg-[hsl(var(--step-active))]/10 text-[hsl(var(--step-active))] border-[hsl(var(--step-active))]/20',
  },
  approved: {
    color: 'bg-[hsl(var(--step-complete))]',
    badgeClass: 'bg-[hsl(var(--step-complete))]/10 text-[hsl(var(--step-complete))] border-[hsl(var(--step-complete))]/20',
  },
  rejected: {
    color: 'bg-destructive',
    badgeClass: 'bg-destructive/10 text-destructive border-destructive/20',
  },
  pending: {
    color: 'bg-[hsl(var(--sla-warning))]',
    badgeClass: 'bg-[hsl(var(--sla-warning))]/10 text-[hsl(var(--sla-warning))] border-[hsl(var(--sla-warning))]/20',
  },
};

function getStepLabel(proposal: RentalTracking, status: ProposalStatus): string {
  if (status === 'rejected') return 'Reprovada';
  const stepLabel = STEP_SHORT_LABELS[proposal.currentStep] || `Etapa ${proposal.currentStep}`;
  return stepLabel;
}

interface ProposalDashboardCardProps {
  proposal: RentalTracking;
}

export function ProposalDashboardCard({ proposal }: ProposalDashboardCardProps) {
  const navigate = useNavigate();
  const status = getProposalStatus(proposal);
  const config = statusConfig[status];
  const progressPercent = Math.round((proposal.currentStep / 10) * 100);
  const stepLabel = getStepLabel(proposal, status);

  const pendingActionText = status === 'pending'
    ? PENDING_ACTION_TEXT[proposal.currentStep] || proposal.pendingDescription || 'Resolver pendência'
    : null;

  const formatCurrency = (value: number | null) =>
    value ? `R$ ${value.toLocaleString('pt-BR', { minimumFractionDigits: 0 })}` : '—';

  return (
    <Card
      className="relative overflow-hidden cursor-pointer transition-all hover:shadow-lg hover:-translate-y-0.5 group border-border/60"
      onClick={() => navigate(`/locatario/acompanhamento/${proposal.id}`)}
    >
      {/* Lateral color stripe */}
      <div className={cn('absolute left-0 top-0 bottom-0 w-1.5', config.color)} />

      <CardContent className="pl-5 pr-4 py-4">
        <div className="flex items-start gap-3">
          {/* Property thumbnail */}
          <div className="w-16 h-16 rounded-xl bg-muted flex-shrink-0 overflow-hidden flex items-center justify-center">
            {proposal.propertyImage ? (
              <img
                src={proposal.propertyImage}
                alt={proposal.propertyCode}
                className="w-full h-full object-cover"
              />
            ) : (
              <Home className="h-6 w-6 text-muted-foreground" />
            )}
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0 space-y-2">
            {/* Header row */}
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0 flex-wrap">
                <span className="font-semibold text-foreground text-sm truncate">
                  {proposal.propertyCode}
                </span>
                <Badge className={cn('text-[10px] px-2 py-0 h-5 font-medium border whitespace-nowrap', config.badgeClass)}>
                  {status !== 'rejected' && (
                    <span className="hidden sm:inline">Etapa {proposal.currentStep} - </span>
                  )}
                  {stepLabel}
                </Badge>
              </div>
              <ChevronRight className="h-4 w-4 text-muted-foreground flex-shrink-0 group-hover:text-primary transition-colors" />
            </div>

            {/* Address */}
            <p className="text-xs text-muted-foreground truncate">
              {proposal.propertyAddress}
            </p>

            {/* Values row */}
            <div className="flex items-center gap-3 text-xs text-muted-foreground">
              <span className="font-medium text-foreground">
                {formatCurrency(proposal.rentValue)}
              </span>
              {proposal.condoFee && (
                <span>+ {formatCurrency(proposal.condoFee)} cond.</span>
              )}
            </div>

            {/* Progress bar for active/pending */}
            {status !== 'rejected' && (
              <div className="space-y-1">
                <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                  <span>Etapa {proposal.currentStep} de 10</span>
                  <span>{progressPercent}%</span>
                </div>
                <Progress value={progressPercent} className="h-1.5" />
              </div>
            )}

            {/* Rejection reason */}
            {status === 'rejected' && proposal.rejectionReason && (
              <p className="text-xs text-destructive line-clamp-1">
                {proposal.rejectionReason}
              </p>
            )}

            {/* Pending action - enhanced UX */}
            {pendingActionText && (
              <div className="rounded-lg bg-[hsl(var(--sla-warning))]/8 border border-[hsl(var(--sla-warning))]/20 p-2.5 space-y-1.5">
                <div className="flex items-center gap-1.5 text-xs font-medium text-[hsl(var(--sla-warning))]">
                  <AlertTriangle className="h-3.5 w-3.5 flex-shrink-0 animate-pulse" />
                  <span>Ação necessária</span>
                </div>
                <p className="text-xs text-foreground pl-5">{pendingActionText}</p>
                <Button
                  variant="outline"
                  size="sm"
                  className="h-7 text-xs ml-5 border-[hsl(var(--sla-warning))]/30 text-[hsl(var(--sla-warning))] hover:bg-[hsl(var(--sla-warning))]/10"
                  onClick={(e) => {
                    e.stopPropagation();
                    navigate(`/locatario/acompanhamento/${proposal.id}`);
                  }}
                >
                  Resolver agora
                </Button>
              </div>
            )}

            {/* Updated at */}
            <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
              <Clock className="h-3 w-3" />
              <span>
                Atualizado {formatDistanceToNow(proposal.updatedAt, { addSuffix: true, locale: ptBR })}
              </span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
