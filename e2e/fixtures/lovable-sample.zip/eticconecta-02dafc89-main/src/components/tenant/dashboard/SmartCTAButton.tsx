 import { useNavigate } from 'react-router-dom';
 import { Button } from '@/components/ui/button';
 import { 
   Upload, 
   Clock, 
   FileCheck, 
   Pen, 
   Calendar, 
   Key,
   ExternalLink,
   ArrowRight
 } from 'lucide-react';
 import { cn } from '@/lib/utils';
 
 interface SmartCTAButtonProps {
   currentStep: number;
   hasPendingDocs: boolean;
   isRejected: boolean;
   rentalId: string;
   contractPreviewUrl?: string;
   contractSignUrl?: string;
 }
 
 interface CTAConfig {
   label: string;
   icon: React.ElementType;
   variant: 'default' | 'outline' | 'secondary';
   disabled: boolean;
   pulse?: boolean;
   action: 'navigate' | 'external' | 'none';
   href?: string;
 }
 
 export function SmartCTAButton({
   currentStep,
   hasPendingDocs,
   isRejected,
   rentalId,
   contractPreviewUrl,
   contractSignUrl,
 }: SmartCTAButtonProps) {
   const navigate = useNavigate();
 
   const getCTAConfig = (): CTAConfig => {
     if (isRejected) {
       return {
         label: 'Proposta não aceita',
         icon: Clock,
         variant: 'outline',
         disabled: true,
         action: 'none',
       };
     }
 
     // Step 1: Proposal - needs documents
     if (currentStep === 1 && hasPendingDocs) {
       return {
         label: 'Enviar Documentos Agora',
         icon: Upload,
         variant: 'default',
         disabled: false,
         pulse: true,
         action: 'navigate',
         href: `/enviar-documentos-pendentes/${rentalId}`,
       };
     }
 
     // Step 2: Analysis in progress
     if (currentStep === 2) {
       return {
         label: 'Aguardando Análise',
         icon: Clock,
         variant: 'secondary',
         disabled: true,
         action: 'none',
       };
     }
 
     // Step 3: Approved, waiting landlord
     if (currentStep === 3) {
       return {
         label: 'Ficha Aprovada! Aguardando Locador',
         icon: Clock,
         variant: 'secondary',
         disabled: true,
         action: 'none',
       };
     }
 
     // Step 4: Landlord docs / Contract preparation
     if (currentStep === 4) {
       return {
         label: 'Contrato em Preparação',
         icon: Clock,
         variant: 'secondary',
         disabled: true,
         action: 'none',
       };
     }
 
     // Step 5: Contract ready for review
     if (currentStep === 5) {
       if (contractPreviewUrl) {
         return {
           label: 'Revisar Contrato',
           icon: FileCheck,
           variant: 'default',
           disabled: false,
           action: 'external',
           href: contractPreviewUrl,
         };
       }
       return {
         label: 'Contrato Pronto',
         icon: FileCheck,
         variant: 'secondary',
         disabled: true,
         action: 'none',
       };
     }
 
     // Step 6: Sign contract
     if (currentStep === 6) {
       if (contractSignUrl) {
         return {
           label: 'Assinar Digitalmente',
           icon: Pen,
           variant: 'default',
           disabled: false,
           pulse: true,
           action: 'external',
           href: contractSignUrl,
         };
       }
       return {
         label: 'Aguardando Link de Assinatura',
         icon: Clock,
         variant: 'secondary',
         disabled: true,
         action: 'none',
       };
     }
 
     // Step 7: Inspection and keys
     if (currentStep === 7) {
       return {
         label: 'Agendar Vistoria',
         icon: Calendar,
         variant: 'default',
         disabled: false,
         action: 'navigate',
         href: '#', // TODO: Implement inspection scheduling
       };
     }
 
     // Step 8: Completed
     if (currentStep >= 8) {
       return {
         label: 'Chaves Entregues! 🎉',
         icon: Key,
         variant: 'secondary',
         disabled: true,
         action: 'none',
       };
     }
 
     // Default fallback
     return {
       label: 'Ver Detalhes',
       icon: ArrowRight,
       variant: 'outline',
       disabled: false,
       action: 'navigate',
       href: `/acompanhamento/${rentalId}`,
     };
   };
 
   const config = getCTAConfig();
   const Icon = config.icon;
 
   const handleClick = () => {
     if (config.action === 'navigate' && config.href) {
       navigate(config.href);
     } else if (config.action === 'external' && config.href) {
       window.open(config.href, '_blank');
     }
   };
 
   return (
     <Button
       variant={config.variant}
       size="lg"
       className={cn(
         "w-full py-6 text-base font-semibold rounded-xl transition-all",
         config.pulse && "animate-pulse",
         !config.disabled && "hover:shadow-md"
       )}
       disabled={config.disabled}
       onClick={handleClick}
     >
       <Icon className="mr-2 h-5 w-5" />
       {config.label}
       {config.action === 'external' && !config.disabled && (
         <ExternalLink className="ml-2 h-4 w-4" />
       )}
     </Button>
   );
 }