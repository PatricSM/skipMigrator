 import { DollarSign } from 'lucide-react';
 import { Slider } from '@/components/ui/slider';
 
 interface QuizStepBudgetProps {
   value: { min: number; max: number };
   onChange: (value: { min: number; max: number }) => void;
 }
 
 const MIN_BUDGET = 1000;
 const MAX_BUDGET = 20000;
 const STEP = 500;
 
 export function QuizStepBudget({ value, onChange }: QuizStepBudgetProps) {
   const formatCurrency = (val: number) => {
     if (val >= MAX_BUDGET) {
       return `R$ ${(val / 1000).toFixed(0)}k+`;
     }
     return new Intl.NumberFormat('pt-BR', {
       style: 'currency',
       currency: 'BRL',
       minimumFractionDigits: 0,
     }).format(val);
   };
 
   const handleSliderChange = (values: number[]) => {
     onChange({ min: values[0], max: values[1] });
   };
 
   return (
     <div className="space-y-6">
       <div className="text-center mb-6">
         <h3 className="text-lg font-semibold text-foreground">
           Qual seu investimento mensal?
         </h3>
         <p className="text-sm text-muted-foreground mt-1">
           Defina a faixa de valor do aluguel
         </p>
       </div>
 
       {/* Current Values Display */}
       <div className="flex items-center justify-center gap-4">
         <div className="text-center">
           <span className="text-xs text-muted-foreground block">Mínimo</span>
           <span className="text-lg font-semibold text-primary">
             {formatCurrency(value.min)}
           </span>
         </div>
         <div className="w-8 h-px bg-border" />
         <div className="text-center">
           <span className="text-xs text-muted-foreground block">Máximo</span>
           <span className="text-lg font-semibold text-primary">
             {formatCurrency(value.max)}
           </span>
         </div>
       </div>
 
       {/* Slider */}
       <div className="px-2 py-4">
         <Slider
           min={MIN_BUDGET}
           max={MAX_BUDGET}
           step={STEP}
           value={[value.min, value.max]}
           onValueChange={handleSliderChange}
           className="w-full"
         />
       </div>
 
       {/* Visual Budget Bar */}
       <div className="flex items-center justify-between text-xs text-muted-foreground px-2">
         <span>{formatCurrency(MIN_BUDGET)}</span>
         <span>{formatCurrency(MAX_BUDGET)}</span>
       </div>
 
       {/* Hint */}
       <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground bg-secondary/50 rounded-lg p-3">
         <DollarSign className="h-4 w-4" />
         <span>Valores incluem aluguel + condomínio</span>
       </div>
     </div>
   );
 }