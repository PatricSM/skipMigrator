 import { Check } from 'lucide-react';
 import { cn } from '@/lib/utils';
 import { FEATURE_OPTIONS } from '@/types/tenant-dashboard';
 
 interface QuizStepFeaturesProps {
   value: string[];
   onChange: (value: string[]) => void;
 }
 
 export function QuizStepFeatures({ value, onChange }: QuizStepFeaturesProps) {
   const toggleFeature = (featureId: string) => {
     if (value.includes(featureId)) {
       onChange(value.filter(f => f !== featureId));
     } else {
       onChange([...value, featureId]);
     }
   };
 
   return (
     <div className="space-y-4">
       <div className="text-center mb-6">
         <h3 className="text-lg font-semibold text-foreground">
           O que é imprescindível para você?
         </h3>
         <p className="text-sm text-muted-foreground mt-1">
           Selecione os itens que não podem faltar
         </p>
       </div>
 
       <div className="flex flex-wrap gap-2 justify-center">
         {FEATURE_OPTIONS.map((feature) => {
           const isSelected = value.includes(feature.id);
 
           return (
             <button
               key={feature.id}
               type="button"
               onClick={() => toggleFeature(feature.id)}
               className={cn(
                 "flex items-center gap-2 px-4 py-2.5 rounded-full border-2 transition-all text-sm font-medium",
                 "hover:border-primary/50",
                 isSelected 
                   ? "border-primary bg-primary text-primary-foreground" 
                   : "border-border bg-card text-foreground hover:bg-secondary/50"
               )}
             >
               {isSelected && <Check className="h-4 w-4" />}
               {feature.label}
             </button>
           );
         })}
       </div>
 
       {value.length > 0 && (
         <p className="text-center text-sm text-muted-foreground mt-4">
           {value.length} {value.length === 1 ? 'item selecionado' : 'itens selecionados'}
         </p>
       )}
     </div>
   );
 }