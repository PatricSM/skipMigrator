export interface Property {
  id: number;
  code: string;
  title: string;
  address: string;
  price: number;
  bedrooms: number;
  bathrooms: number;
  area: number;
  image: string;
  condoFee?: number;
  iptu?: number;
}

export const mockProperties: Property[] = [
  {
    id: 1,
    code: "ETIC-001",
    title: "Apartamento 2 quartos - Vila Prudente",
    address: "Rua das Flores, 123 - Vila Prudente",
    price: 2500,
    bedrooms: 2,
    bathrooms: 1,
    area: 65,
    image: "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=400&h=300&fit=crop",
    condoFee: 450,
    iptu: 180,
  },
  {
    id: 2,
    code: "ETIC-002",
    title: "Casa 3 quartos - Mooca",
    address: "Av. Paes de Barros, 456 - Mooca",
    price: 4200,
    bedrooms: 3,
    bathrooms: 2,
    area: 120,
    image: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=400&h=300&fit=crop",
    condoFee: 0,
    iptu: 320,
  },
  {
    id: 3,
    code: "ETIC-003",
    title: "Studio moderno - Tatuapé",
    address: "Rua Serra de Botucatu, 789 - Tatuapé",
    price: 1800,
    bedrooms: 1,
    bathrooms: 1,
    area: 35,
    image: "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=400&h=300&fit=crop",
    condoFee: 380,
    iptu: 95,
  },
  {
    id: 4,
    code: "ETIC-004",
    title: "Apartamento 3 quartos - Belém",
    address: "Rua Conselheiro Cotegipe, 321 - Belém",
    price: 3100,
    bedrooms: 3,
    bathrooms: 2,
    area: 90,
    image: "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=400&h=300&fit=crop",
    condoFee: 520,
    iptu: 210,
  },
];

export function findPropertyByCode(code: string): Property | undefined {
  return mockProperties.find(
    (p) => p.code.toLowerCase() === code.toLowerCase()
  );
}

export function findPropertyById(id: number | string): Property | undefined {
  return mockProperties.find((p) => p.id === Number(id));
}
