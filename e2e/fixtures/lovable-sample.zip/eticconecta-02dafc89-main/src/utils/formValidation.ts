import { TenantData, DocumentUploadState } from "@/types/rental";
import { isValidCPF } from "@/lib/masks";
import { REQUIRED_DOC_TYPES } from "@/types/documentLimits";

// Age validation: must be 18-100 years old
export function validateAge(birthDate: string): { valid: boolean; error?: string } {
  // Expect format DD/MM/YYYY or YYYY-MM-DD
  let date: Date | null = null;
  
  if (birthDate.includes('/')) {
    const parts = birthDate.split('/');
    if (parts.length === 3) {
      const [day, month, year] = parts;
      date = new Date(parseInt(year), parseInt(month) - 1, parseInt(day));
    }
  } else if (birthDate.includes('-')) {
    date = new Date(birthDate);
  }

  if (!date || isNaN(date.getTime())) {
    return { valid: false, error: "Data inválida" };
  }

  const today = new Date();
  const birthYear = date.getFullYear();
  const currentYear = today.getFullYear();
  
  // Basic year range check
  if (birthYear > currentYear || birthYear < currentYear - 120) {
    return { valid: false, error: "Ano de nascimento inválido" };
  }

  // Calculate age
  let age = currentYear - birthYear;
  const monthDiff = today.getMonth() - date.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < date.getDate())) {
    age--;
  }

  if (age < 18) {
    return { valid: false, error: "Você precisa ter pelo menos 18 anos" };
  }

  if (age > 100) {
    return { valid: false, error: "Verifique a data de nascimento informada" };
  }

  return { valid: true };
}

export interface ValidationErrors {
  fullName?: string;
  email?: string;
  phone?: string;
  birthDate?: string;
  cpf?: string;
  nationality?: string;
  nationalityCountry?: string;
  maritalStatus?: string;
  profession?: string;
  monthlyIncome?: string;
  documents?: {
    identity?: string;
    income?: string;
    residence?: string;
  };
}

export function validatePersonalData(data: TenantData): ValidationErrors {
  return {
    ...validateIdentityFields(data),
    ...validateCivilFields(data),
  };
}

/** Validate only identity sub-step: name, email, phone */
export function validateIdentityFields(data: TenantData): ValidationErrors {
  const errors: ValidationErrors = {};

  if (!data.fullName?.trim()) {
    errors.fullName = "Nome completo é obrigatório";
  }

  if (!data.email?.trim()) {
    errors.email = "E-mail é obrigatório";
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.email = "E-mail inválido";
  }

  const cleanPhone = data.phone?.replace(/\D/g, '') || '';
  if (!cleanPhone) {
    errors.phone = "Telefone é obrigatório";
  } else if (cleanPhone.length < 10) {
    errors.phone = "Telefone incompleto";
  }

  return errors;
}

/** Validate only civil sub-step: birthDate, cpf, nationality, maritalStatus */
export function validateCivilFields(data: TenantData): ValidationErrors {
  const errors: ValidationErrors = {};

  if (!data.birthDate) {
    errors.birthDate = "Data de nascimento é obrigatória";
  } else {
    const ageValidation = validateAge(data.birthDate);
    if (!ageValidation.valid) {
      errors.birthDate = ageValidation.error;
    }
  }

  const cleanCpf = data.cpf?.replace(/\D/g, '') || '';
  if (!cleanCpf) {
    errors.cpf = "CPF é obrigatório";
  } else if (cleanCpf.length !== 11) {
    errors.cpf = "CPF deve ter 11 dígitos";
  } else if (!isValidCPF(data.cpf)) {
    errors.cpf = "CPF inválido";
  }

  if (!data.nationality) {
    errors.nationality = "Nacionalidade é obrigatória";
  }

  if (data.nationality === "Estrangeira" && !data.nationalityCountry?.trim()) {
    errors.nationalityCountry = "País de origem é obrigatório";
  }

  if (!data.maritalStatus) {
    errors.maritalStatus = "Estado civil é obrigatório";
  }

  return errors;
}

export function validateIncomeData(data: TenantData): ValidationErrors {
  const errors: ValidationErrors = {};

  if (!data.profession?.trim()) {
    errors.profession = "Profissão é obrigatória";
  }

  if (!data.monthlyIncome?.trim()) {
    errors.monthlyIncome = "Renda mensal é obrigatória";
  }

  return errors;
}

export function validateDocuments(documents: DocumentUploadState[]): ValidationErrors {
  const errors: ValidationErrors = { documents: {} };

  const labelMap: Record<string, string> = {
    identity: 'RG ou CNH é obrigatório',
    income: 'Comprovante de renda é obrigatório',
    residence: 'Comprovante de residência é obrigatório',
  };

  for (const docType of REQUIRED_DOC_TYPES) {
    const hasUploaded = documents.some(d => d.type === docType && d.status === 'uploaded');
    if (!hasUploaded) {
      (errors.documents as Record<string, string>)[docType] = labelMap[docType];
    }
  }

  if (Object.keys(errors.documents!).length === 0) {
    delete errors.documents;
  }

  return errors;
}

export function validateAllData(data: TenantData, documents: DocumentUploadState[]): ValidationErrors {
  return {
    ...validatePersonalData(data),
    ...validateIncomeData(data),
    ...validateDocuments(documents),
  };
}

export function validateRequiredData(data: TenantData): ValidationErrors {
  return {
    ...validatePersonalData(data),
    ...validateIncomeData(data),
  };
}

export function getMissingDocuments(documents: DocumentUploadState[]): string[] {
  const labelMap: Record<string, string> = {
    identity: 'RG ou CNH',
    income: 'Comprovante de Renda',
    residence: 'Comprovante de Residência',
  };

  return REQUIRED_DOC_TYPES.filter(
    docType => !documents.some(d => d.type === docType && d.status === 'uploaded')
  ).map(docType => labelMap[docType]);
}

// Returns the document type keys (for database storage)
export function getMissingDocumentTypes(documents: DocumentUploadState[]): string[] {
  return REQUIRED_DOC_TYPES.filter(
    docType => !documents.some(d => d.type === docType && d.status === 'uploaded')
  );
}

export function hasErrors(errors: ValidationErrors): boolean {
  return Object.keys(errors).length > 0;
}

export function getFirstErrorStep(errors: ValidationErrors): 'personal' | 'income' | 'documents' | null {
  const personalFields = ['fullName', 'email', 'phone', 'birthDate', 'cpf', 'nationality', 'nationalityCountry', 'maritalStatus'];
  const incomeFields = ['profession', 'monthlyIncome'];

  for (const field of personalFields) {
    if (errors[field as keyof ValidationErrors]) {
      return 'personal';
    }
  }

  for (const field of incomeFields) {
    if (errors[field as keyof ValidationErrors]) {
      return 'income';
    }
  }

  if (errors.documents) {
    return 'documents';
  }

  return null;
}
