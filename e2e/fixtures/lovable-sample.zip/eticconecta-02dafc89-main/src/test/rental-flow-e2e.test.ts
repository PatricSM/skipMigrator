/**
 * E2E Test: Full Rental Flow (Steps 1–10)
 * 
 * Tests the complete rental lifecycle using the business logic functions
 * from proposalEvents.ts. Each scenario validates state transitions,
 * event logging, and QA consistency checks.
 * 
 * NOTE: These tests call Supabase directly and require an authenticated
 * session. They are integration tests meant to run against a dev database.
 */
import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { supabase } from '@/integrations/supabase/client';
import {
  logRentalEvent,
  setRentalStepAndLog,
  createTenantProposal,
  createCounterProposal,
  acceptCounterProposal,
  rejectCounterProposal,
  fetchProposals,
  emitContract,
  sendContractForSignature,
  signContract,
  fetchContract,
  scheduleInspection,
  signInspectionReport,
  deliverKeys,
  fetchInspection,
  runConsistencyChecks,
  type ProposalRow,
} from '@/lib/proposalEvents';

// ── Test Helpers ──

interface TestRental {
  id: string;
  protocol: string;
}

async function createTestRental(suffix: string): Promise<TestRental | null> {
  const protocol = `TEST-E2E-${suffix}-${Date.now()}`;
  const { data, error } = await supabase
    .from('rentals')
    .insert({
      protocol,
      property_code: `TEST-${suffix}`,
      property_address: `Rua Teste ${suffix}, 123`,
      property_id: `test-property-${suffix}`,
      user_id: (await supabase.auth.getUser()).data.user?.id || '',
      current_step: 1,
      proposal_status: 'waiting_landlord_acceptance',
      step_status: 'in_progress',
      tenant_status: 'in_analysis',
    } as any)
    .select('id, protocol')
    .single();

  if (error) {
    console.error('[TEST] Create rental error:', error);
    return null;
  }
  return data as TestRental;
}

async function getRentalState(rentalId: string) {
  const { data } = await supabase
    .from('rentals')
    .select('current_step, proposal_status, step_status, tenant_status, documents_finalized_at, documents_cycle, has_pending, is_rejected, contract_preview_url, contract_sign_url, landlord_accepted')
    .eq('id', rentalId)
    .single();
  return data;
}

async function getEvents(rentalId: string) {
  const { data } = await supabase
    .from('rental_events')
    .select('event_type, description, idempotency_key')
    .eq('rental_id', rentalId)
    .order('created_at', { ascending: true });
  return data || [];
}

async function cleanupTestRental(rentalId: string) {
  // Delete in dependency order
  await (supabase as any).from('inspections').delete().eq('rental_id', rentalId);
  await (supabase as any).from('contracts').delete().eq('rental_id', rentalId);
  await (supabase as any).from('proposals').delete().eq('rental_id', rentalId);
  await supabase.from('rental_events').delete().eq('rental_id', rentalId);
  await supabase.from('rentals').delete().eq('id', rentalId);
}

// ── Test Report ──
interface TestResult {
  scenario: string;
  step: string;
  pass: boolean;
  detail?: string;
}

const testReport: TestResult[] = [];

function logResult(scenario: string, step: string, pass: boolean, detail?: string) {
  testReport.push({ scenario, step, pass, detail });
  if (!pass) console.warn(`❌ [${scenario}] ${step}: ${detail}`);
}

// ══════════════════════════════════════════════════════════════
// Scenario 1: Full happy path (Steps 1→10)
// ══════════════════════════════════════════════════════════════
describe('Rental Flow E2E', () => {
  let rentalId: string;
  let userId: string;

  beforeAll(async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      console.warn('⚠️ No authenticated user — skipping E2E tests');
      return;
    }
    userId = user.id;
  });

  afterAll(() => {
    console.log('\n══════ E2E TEST REPORT ══════');
    const passed = testReport.filter(r => r.pass).length;
    const failed = testReport.filter(r => !r.pass).length;
    console.log(`Total: ${testReport.length} | ✅ Passed: ${passed} | ❌ Failed: ${failed}`);
    testReport.forEach(r => {
      const icon = r.pass ? '✅' : '❌';
      console.log(`  ${icon} [${r.scenario}] ${r.step}${r.detail ? ` — ${r.detail}` : ''}`);
    });
    console.log('═════════════════════════════\n');
  });

  describe('Scenario 1: Happy Path — Proposal → Keys', () => {
    beforeAll(async () => {
      if (!userId) return;
      const rental = await createTestRental('S1');
      if (!rental) throw new Error('Failed to create test rental');
      rentalId = rental.id;
    });

    afterAll(async () => {
      if (rentalId) await cleanupTestRental(rentalId);
    });

    it('Step 1: Tenant creates proposal', async () => {
      if (!userId) return;

      const ok = await createTenantProposal({
        rentalId,
        rentValue: 2500,
        depositValue: 5000,
        notes: 'Teste E2E',
      });
      expect(ok).toBe(true);
      logResult('S1', 'Step 1 - Create proposal', ok);

      const state = await getRentalState(rentalId);
      expect(state?.current_step).toBe(1);

      const events = await getEvents(rentalId);
      const hasProposalSent = events.some(e => e.event_type === 'proposal_sent');
      expect(hasProposalSent).toBe(true);
      logResult('S1', 'Step 1 - proposal_sent event', hasProposalSent);
    });

    it('Step 2: Landlord sends counter-proposal', async () => {
      if (!userId) return;

      const ok = await createCounterProposal({
        rentalId,
        rentValue: 2800,
        depositValue: 5600,
        notes: 'Valor ajustado',
      });
      expect(ok).toBe(true);
      logResult('S1', 'Step 2 - Counter-proposal', ok);

      const state = await getRentalState(rentalId);
      expect(state?.proposal_status).toBe('counter_proposal_pending');
      expect(state?.current_step).toBe(2);

      const events = await getEvents(rentalId);
      expect(events.some(e => e.event_type === 'proposal_countered')).toBe(true);
      logResult('S1', 'Step 2 - proposal_countered event', true);
    });

    it('Step 2b: Tenant accepts counter-proposal', async () => {
      if (!userId) return;

      const proposals = await fetchProposals(rentalId);
      const landlordProposal = proposals.find(p => p.author === 'landlord' && p.status === 'pending');
      expect(landlordProposal).toBeDefined();

      const ok = await acceptCounterProposal({
        rentalId,
        proposalId: landlordProposal!.id,
      });
      expect(ok).toBe(true);
      logResult('S1', 'Step 2b - Accept counter', ok);

      const state = await getRentalState(rentalId);
      expect(state?.proposal_status).toBe('proposal_accepted');
      expect(state?.landlord_accepted).toBe(true);

      const events = await getEvents(rentalId);
      expect(events.some(e => e.event_type === 'counter_proposal_accepted')).toBe(true);
      expect(events.some(e => e.event_type === 'proposal_accepted')).toBe(true);
      logResult('S1', 'Step 2b - acceptance events', true);
    });

    it('Step 3: Document finalization', async () => {
      if (!userId) return;

      // Simulate advancing to step 3 (docs)
      const stepOk = await setRentalStepAndLog({
        rentalId,
        newStep: 3,
        reason: 'Documentação enviada pelo locatário.',
        extraUpdate: {
          documents_finalized_at: new Date().toISOString(),
        },
      });
      expect(stepOk).toBe(true);

      await logRentalEvent({
        rentalId,
        eventType: 'documents_finalized',
        description: 'Documentação finalizada pelo locatário.',
        idempotencyKey: `documents_finalized_${rentalId}`,
      });

      const state = await getRentalState(rentalId);
      expect(state?.current_step).toBe(3);
      expect(state?.documents_finalized_at).toBeTruthy();
      logResult('S1', 'Step 3 - Documents finalized', true);
    });

    it('Step 4: Ficha analysis approved', async () => {
      if (!userId) return;

      await setRentalStepAndLog({
        rentalId,
        newStep: 4,
        reason: 'Análise de ficha iniciada.',
      });

      await logRentalEvent({
        rentalId,
        eventType: 'ficha_analysis_started',
        description: 'Análise de ficha iniciada.',
        idempotencyKey: `ficha_started_${rentalId}`,
      });

      await logRentalEvent({
        rentalId,
        eventType: 'ficha_analysis_completed',
        description: 'Análise concluída.',
        idempotencyKey: `ficha_completed_${rentalId}`,
      });

      await logRentalEvent({
        rentalId,
        eventType: 'ficha_approved',
        description: 'Ficha aprovada.',
        idempotencyKey: `ficha_approved_${rentalId}`,
      });

      const state = await getRentalState(rentalId);
      expect(state?.current_step).toBe(4);
      logResult('S1', 'Step 4 - Ficha approved', true);
    });

    it('Step 5: Landlord documents sent', async () => {
      if (!userId) return;

      await setRentalStepAndLog({
        rentalId,
        newStep: 5,
        reason: 'Documentos do locador recebidos.',
      });

      await logRentalEvent({
        rentalId,
        eventType: 'landlord_documents_sent',
        description: 'Documentos do locador enviados.',
        idempotencyKey: `landlord_docs_${rentalId}`,
      });

      const state = await getRentalState(rentalId);
      expect(state?.current_step).toBe(5);
      logResult('S1', 'Step 5 - Landlord docs', true);
    });

    it('Step 6: Contract emitted', async () => {
      if (!userId) return;

      const result = await emitContract({ rentalId });
      expect(result).toBeTruthy();
      expect(result?.contractId).toBeTruthy();

      const state = await getRentalState(rentalId);
      expect(state?.current_step).toBe(6);
      expect(state?.contract_preview_url).toBeTruthy();

      const events = await getEvents(rentalId);
      expect(events.some(e => e.event_type === 'contract_emitted')).toBe(true);
      logResult('S1', 'Step 6 - Contract emitted', true);
    });

    it('Step 7: Contract sent for signature', async () => {
      if (!userId) return;

      const ok = await sendContractForSignature(rentalId);
      expect(ok).toBe(true);

      const state = await getRentalState(rentalId);
      expect(state?.current_step).toBe(7);

      const contract = await fetchContract(rentalId);
      expect(contract?.status).toBe('pending_signature');
      logResult('S1', 'Step 7 - Contract sent', true);
    });

    it('Step 7b: Both parties sign contract → Step 8', async () => {
      if (!userId) return;

      await signContract({ rentalId, signerRole: 'tenant' });
      await signContract({ rentalId, signerRole: 'landlord' });

      const state = await getRentalState(rentalId);
      expect(state?.current_step).toBe(8);

      const contract = await fetchContract(rentalId);
      expect(contract?.status).toBe('signed');
      expect(contract?.signed_by_tenant_at).toBeTruthy();
      expect(contract?.signed_by_landlord_at).toBeTruthy();

      const events = await getEvents(rentalId);
      expect(events.some(e => e.event_type === 'contract_signed')).toBe(true);
      logResult('S1', 'Step 7b - Both signed → Step 8', true);
    });

    it('Step 8→9: Inspection scheduled', async () => {
      if (!userId) return;

      const inspection = await scheduleInspection({
        rentalId,
        date: '2026-03-15',
        time: '10:00',
        locationNotes: 'Portaria principal',
      });
      expect(inspection).toBeTruthy();

      const state = await getRentalState(rentalId);
      expect(state?.current_step).toBe(9);

      const events = await getEvents(rentalId);
      expect(events.some(e => e.event_type === 'inspection_scheduled')).toBe(true);
      logResult('S1', 'Step 8→9 - Inspection scheduled', true);
    });

    it('Step 9→10: Both sign inspection report', async () => {
      if (!userId) return;

      await signInspectionReport({ rentalId, signerRole: 'tenant' });
      await signInspectionReport({ rentalId, signerRole: 'landlord' });

      const state = await getRentalState(rentalId);
      expect(state?.current_step).toBe(10);

      const inspection = await fetchInspection(rentalId);
      expect(inspection?.status).toBe('signed');

      const events = await getEvents(rentalId);
      expect(events.some(e => e.event_type === 'inspection_signed')).toBe(true);
      logResult('S1', 'Step 9→10 - Inspection signed', true);
    });

    it('Step 10: Keys delivered → Completed', async () => {
      if (!userId) return;

      const ok = await deliverKeys({ rentalId });
      expect(ok).toBe(true);

      const state = await getRentalState(rentalId);
      expect(state?.step_status).toBe('completed');
      expect(state?.tenant_status).toBe('active');

      const events = await getEvents(rentalId);
      expect(events.some(e => e.event_type === 'keys_delivered')).toBe(true);
      logResult('S1', 'Step 10 - Keys delivered', true);
    });

    it('QA: Full consistency check passes', async () => {
      if (!userId) return;

      const state = await getRentalState(rentalId);
      const events = await getEvents(rentalId);
      const proposals = await fetchProposals(rentalId);

      const checks = runConsistencyChecks({
        currentStep: state?.current_step || 10,
        proposalStatus: state?.proposal_status || '',
        documentsFinalizedAt: state?.documents_finalized_at ? new Date(state.documents_finalized_at) : undefined,
        documentsCycle: state?.documents_cycle || 1,
        missingTypes: [],
        events: events.map(e => ({ eventType: e.event_type })),
        proposals: proposals as ProposalRow[],
        isRejected: state?.is_rejected || false,
      });

      const failedChecks = checks.filter(c => !c.ok);
      failedChecks.forEach(c => {
        logResult('S1', `QA FAIL: ${c.label}`, false, c.fixAction);
      });

      // Log passed checks
      checks.filter(c => c.ok).forEach(c => {
        logResult('S1', `QA OK: ${c.label}`, true);
      });

      expect(failedChecks.length).toBe(0);
    });
  });

  // ══════════════════════════════════════════════════════════════
  // Scenario 2: Counter-proposal rejected
  // ══════════════════════════════════════════════════════════════
  describe('Scenario 2: Counter-proposal Rejected', () => {
    let rejRentalId: string;

    beforeAll(async () => {
      if (!userId) return;
      const rental = await createTestRental('S2');
      if (!rental) throw new Error('Failed to create test rental S2');
      rejRentalId = rental.id;
    });

    afterAll(async () => {
      if (rejRentalId) await cleanupTestRental(rejRentalId);
    });

    it('Full rejection flow', async () => {
      if (!userId) return;

      // 1. Tenant proposes
      await createTenantProposal({ rentalId: rejRentalId, rentValue: 2000 });

      // 2. Landlord counters
      await createCounterProposal({ rentalId: rejRentalId, rentValue: 3000 });

      // 3. Tenant rejects
      const proposals = await fetchProposals(rejRentalId);
      const landlordProp = proposals.find(p => p.author === 'landlord' && p.status === 'pending');
      expect(landlordProp).toBeDefined();

      const ok = await rejectCounterProposal({ rentalId: rejRentalId, proposalId: landlordProp!.id });
      expect(ok).toBe(true);

      const state = await getRentalState(rejRentalId);
      expect(state?.proposal_status).toBe('proposal_rejected');
      expect(state?.current_step).toBe(2);

      const events = await getEvents(rejRentalId);
      expect(events.some(e => e.event_type === 'counter_proposal_rejected')).toBe(true);
      expect(events.some(e => e.event_type === 'proposal_rejected')).toBe(true);

      logResult('S2', 'Full rejection flow', true);
    });
  });

  // ══════════════════════════════════════════════════════════════
  // Scenario 3: Document reopening
  // ══════════════════════════════════════════════════════════════
  describe('Scenario 3: Document Reopen Cycle', () => {
    let reopenRentalId: string;

    beforeAll(async () => {
      if (!userId) return;
      const rental = await createTestRental('S3');
      if (!rental) throw new Error('Failed to create test rental S3');
      reopenRentalId = rental.id;
    });

    afterAll(async () => {
      if (reopenRentalId) await cleanupTestRental(reopenRentalId);
    });

    it('Finalize → Reopen → Re-finalize', async () => {
      if (!userId) return;

      // Advance to docs step
      await setRentalStepAndLog({
        rentalId: reopenRentalId,
        newStep: 3,
        reason: 'Avançando para documentação.',
        extraUpdate: {
          proposal_status: 'proposal_accepted',
          documents_finalized_at: new Date().toISOString(),
        },
      });

      await logRentalEvent({
        rentalId: reopenRentalId,
        eventType: 'proposal_accepted',
        description: 'Proposta aceita.',
        idempotencyKey: `accepted_${reopenRentalId}`,
      });

      await logRentalEvent({
        rentalId: reopenRentalId,
        eventType: 'documents_finalized',
        description: 'Docs finalizados.',
        idempotencyKey: `docs_final_${reopenRentalId}`,
      });

      // Reopen
      await setRentalStepAndLog({
        rentalId: reopenRentalId,
        newStep: 3,
        reason: 'Reabertura de documentação.',
        extraUpdate: {
          documents_finalized_at: null,
          documents_cycle: 2,
        },
      });

      await logRentalEvent({
        rentalId: reopenRentalId,
        eventType: 'documents_reopened',
        description: 'Documentação reaberta para ciclo 2.',
        idempotencyKey: `docs_reopened_${reopenRentalId}_c2`,
      });

      const state = await getRentalState(reopenRentalId);
      expect(state?.documents_cycle).toBe(2);
      expect(state?.documents_finalized_at).toBeNull();

      // Re-finalize
      await supabase
        .from('rentals')
        .update({ documents_finalized_at: new Date().toISOString() } as any)
        .eq('id', reopenRentalId);

      await logRentalEvent({
        rentalId: reopenRentalId,
        eventType: 'documents_finalized',
        description: 'Docs re-finalizados ciclo 2.',
        idempotencyKey: `docs_final_${reopenRentalId}_c2`,
      });

      const events = await getEvents(reopenRentalId);
      expect(events.filter(e => e.event_type === 'documents_finalized').length).toBe(2);
      expect(events.some(e => e.event_type === 'documents_reopened')).toBe(true);

      logResult('S3', 'Document reopen cycle', true);
    });
  });

  // ══════════════════════════════════════════════════════════════
  // Scenario 4: Idempotency validation
  // ══════════════════════════════════════════════════════════════
  describe('Scenario 4: Idempotency', () => {
    let idempRentalId: string;

    beforeAll(async () => {
      if (!userId) return;
      const rental = await createTestRental('S4');
      if (!rental) throw new Error('Failed to create test rental S4');
      idempRentalId = rental.id;
    });

    afterAll(async () => {
      if (idempRentalId) await cleanupTestRental(idempRentalId);
    });

    it('Duplicate events are deduplicated', async () => {
      if (!userId) return;

      const key = `test_idemp_${idempRentalId}`;

      const ok1 = await logRentalEvent({
        rentalId: idempRentalId,
        eventType: 'proposal_sent',
        description: 'Proposta 1',
        idempotencyKey: key,
      });
      expect(ok1).toBe(true);

      // Same key — should be deduplicated (returns true, no error)
      const ok2 = await logRentalEvent({
        rentalId: idempRentalId,
        eventType: 'proposal_sent',
        description: 'Proposta duplicada',
        idempotencyKey: key,
      });
      expect(ok2).toBe(true);

      const events = await getEvents(idempRentalId);
      const proposalEvents = events.filter(e => e.event_type === 'proposal_sent');
      expect(proposalEvents.length).toBe(1);

      logResult('S4', 'Idempotency dedup', true);
    });
  });
});
